package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/bcrypt"
)

// EncryptedFolder 加密文件夹配置
type EncryptedFolder struct {
	ID           string    `json:"id"`
	Name         string    `json:"name"`
	Path         string    `json:"path"`
	PasswordHash string    `json:"password_hash"`
	Salt         string    `json:"salt"`
	CreatedAt    time.Time `json:"created_at"`
	FileCount    int       `json:"file_count"`
	TotalSize    int64     `json:"total_size"`
}

// EncryptionManager 加密管理器
type EncryptionManager struct {
	storageRoot string
	configDir   string
	logger      *Logger
	mu          sync.Mutex
	folders     map[string]*EncryptedFolder
	sessions    map[string]string // session token -> folder id
}

// NewEncryptionManager 创建加密管理器
func NewEncryptionManager(storageRoot string, logger *Logger) *EncryptionManager {
	configDir := filepath.Join(storageRoot, ".encrypted")
	os.MkdirAll(configDir, 0755)

	em := &EncryptionManager{
		storageRoot: storageRoot,
		configDir:   configDir,
		logger:      logger,
		folders:     make(map[string]*EncryptedFolder),
		sessions:    make(map[string]string),
	}
	em.loadFolders()
	return em
}

// loadFolders 加载加密文件夹配置
func (em *EncryptionManager) loadFolders() {
	em.mu.Lock()
	defer em.mu.Unlock()

	data, err := os.ReadFile(filepath.Join(em.configDir, "folders.json"))
	if err != nil {
		return
	}
	var folders []*EncryptedFolder
	if err := json.Unmarshal(data, &folders); err != nil {
		return
	}
	for _, f := range folders {
		em.folders[f.ID] = f
	}
}

// saveFolders 保存加密文件夹配置
func (em *EncryptionManager) saveFolders() {
	var folders []*EncryptedFolder
	for _, f := range em.folders {
		folders = append(folders, f)
	}
	data, _ := json.MarshalIndent(folders, "", "  ")
	os.WriteFile(filepath.Join(em.configDir, "folders.json"), data, 0644)
}

// CreateFolder 创建加密文件夹
func (em *EncryptionManager) CreateFolder(name, password string) (*EncryptedFolder, error) {
	em.mu.Lock()
	defer em.mu.Unlock()

	// 检查重名
	for _, f := range em.folders {
		if f.Name == name {
			return nil, fmt.Errorf("文件夹名称已存在")
		}
	}

	// 生成盐
	salt := make([]byte, 16)
	rand.Read(salt)
	saltStr := fmt.Sprintf("%x", salt)

	// 密码哈希
	hash, err := bcrypt.GenerateFromPassword([]byte(password+saltStr), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	folderID := fmt.Sprintf("enc_%d", time.Now().Unix())
	folderPath := filepath.Join(em.configDir, folderID)
	os.MkdirAll(folderPath, 0755)

	folder := &EncryptedFolder{
		ID:           folderID,
		Name:         name,
		Path:         folderPath,
		PasswordHash: string(hash),
		Salt:         saltStr,
		CreatedAt:    time.Now(),
	}

	em.folders[folderID] = folder
	em.saveFolders()
	em.logger.Info("创建加密文件夹: %s", name)
	return folder, nil
}

// DeleteFolder 删除加密文件夹
func (em *EncryptionManager) DeleteFolder(folderID string) error {
	em.mu.Lock()
	defer em.mu.Unlock()

	folder, ok := em.folders[folderID]
	if !ok {
		return fmt.Errorf("文件夹不存在")
	}

	// 删除文件
	os.RemoveAll(folder.Path)
	delete(em.folders, folderID)
	em.saveFolders()
	em.logger.Info("删除加密文件夹: %s", folder.Name)
	return nil
}

// VerifyPassword 验证密码
func (em *EncryptionManager) VerifyPassword(folderID, password string) (string, error) {
	em.mu.Lock()
	defer em.mu.Unlock()

	folder, ok := em.folders[folderID]
	if !ok {
		return "", fmt.Errorf("文件夹不存在")
	}

	err := bcrypt.CompareHashAndPassword([]byte(folder.PasswordHash), []byte(password+folder.Salt))
	if err != nil {
		return "", fmt.Errorf("密码错误")
	}

	// 生成会话token
	token := make([]byte, 32)
	rand.Read(token)
	sessionToken := fmt.Sprintf("%x", token)
	em.sessions[sessionToken] = folderID

	return sessionToken, nil
}

// VerifySession 验证会话
func (em *EncryptionManager) VerifySession(sessionToken string) (string, bool) {
	em.mu.Lock()
	defer em.mu.Unlock()
	folderID, ok := em.sessions[sessionToken]
	return folderID, ok
}

// ListFolders 列出加密文件夹
func (em *EncryptionManager) ListFolders() []*EncryptedFolder {
	em.mu.Lock()
	defer em.mu.Unlock()

	var folders []*EncryptedFolder
	for _, f := range em.folders {
		// 更新文件统计
		f.FileCount, f.TotalSize = em.countFiles(f.Path)
		folders = append(folders, f)
	}
	return folders
}

// countFiles 统计文件
func (em *EncryptionManager) countFiles(path string) (int, int64) {
	var count int
	var size int64
	filepath.Walk(path, func(p string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		count++
		size += info.Size()
		return nil
	})
	return count, size
}

// deriveKey 从密码派生加密密钥
func (em *EncryptionManager) deriveKey(password, salt string) []byte {
	hash := sha256.Sum256([]byte(password + salt))
	return hash[:]
}

// EncryptFile 加密文件
func (em *EncryptionManager) EncryptFile(folderID, filename string, reader io.Reader, password string) error {
	folder, ok := em.folders[folderID]
	if !ok {
		return fmt.Errorf("文件夹不存在")
	}

	key := em.deriveKey(password, folder.Salt)
	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return err
	}

	// 读取文件内容
	data, err := io.ReadAll(reader)
	if err != nil {
		return err
	}

	// 加密
	ciphertext := gcm.Seal(nonce, nonce, data, nil)

	// 加密文件名
	encName := em.encryptFilename(filename, key)

	// 写入文件
	outPath := filepath.Join(folder.Path, encName)
	return os.WriteFile(outPath, ciphertext, 0644)
}

// DecryptFile 解密文件
func (em *EncryptionManager) DecryptFile(folderID, encFilename string, password string) ([]byte, string, error) {
	folder, ok := em.folders[folderID]
	if !ok {
		return nil, "", fmt.Errorf("文件夹不存在")
	}

	key := em.deriveKey(password, folder.Salt)
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, "", err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, "", err
	}

	// 读取加密文件
	data, err := os.ReadFile(filepath.Join(folder.Path, encFilename))
	if err != nil {
		return nil, "", err
	}

	nonceSize := gcm.NonceSize()
	if len(data) < nonceSize {
		return nil, "", fmt.Errorf("文件损坏")
	}

	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, "", fmt.Errorf("解密失败，密码错误或文件损坏")
	}

	// 解密文件名
	filename := em.decryptFilename(encFilename, key)

	return plaintext, filename, nil
}

// encryptFilename 加密文件名
func (em *EncryptionManager) encryptFilename(name string, key []byte) string {
	// 简单的文件名编码（base64 + 哈希）
	hash := sha256.Sum256([]byte(name + string(key)))
	return fmt.Sprintf("%x.enc", hash[:16])
}

// decryptFilename 解密文件名（需要存储映射）
func (em *EncryptionManager) decryptFilename(encName string, key []byte) string {
	// 从文件名映射文件中查找
	// 简化处理：返回加密名
	return strings.TrimSuffix(encName, ".enc")
}

// ListFiles 列出加密文件夹中的文件
func (em *EncryptionManager) ListFiles(folderID string) ([]map[string]interface{}, error) {
	folder, ok := em.folders[folderID]
	if !ok {
		return nil, fmt.Errorf("文件夹不存在")
	}

	var files []map[string]interface{}
	entries, err := os.ReadDir(folder.Path)
	if err != nil {
		return nil, err
	}

	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		info, _ := entry.Info()
		files = append(files, map[string]interface{}{
			"name": strings.TrimSuffix(entry.Name(), ".enc"),
			"size": info.Size(),
			"time": info.ModTime(),
		})
	}

	return files, nil
}

// DeleteFile 删除加密文件
func (em *EncryptionManager) DeleteFile(folderID, encFilename string) error {
	folder, ok := em.folders[folderID]
	if !ok {
		return fmt.Errorf("文件夹不存在")
	}
	return os.Remove(filepath.Join(folder.Path, encFilename+".enc"))
}

// ===== HTTP API 处理函数 =====

func (h *NASHandler) handleEncryptedFolders(w http.ResponseWriter, r *http.Request) {
	folders := h.encMgr.ListFolders()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"folders": folders,
		"count":   len(folders),
	})
}

func (h *NASHandler) handleEncryptedCreate(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Name     string `json:"name"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	if req.Name == "" || req.Password == "" {
		http.Error(w, "名称和密码不能为空", http.StatusBadRequest)
		return
	}
	folder, err := h.encMgr.CreateFolder(req.Name, req.Password)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	h.logger.Info("创建加密文件夹: %s", req.Name)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"folder":  folder,
	})
}

func (h *NASHandler) handleEncryptedDelete(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		ID string `json:"id"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	if err := h.encMgr.DeleteFolder(req.ID); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleEncryptedUnlock(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		ID       string `json:"id"`
		Password string `json:"password"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	token, err := h.encMgr.VerifyPassword(req.ID, req.Password)
	if err != nil {
		http.Error(w, err.Error(), http.StatusUnauthorized)
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"token":   token,
	})
}

func (h *NASHandler) handleEncryptedFiles(w http.ResponseWriter, r *http.Request) {
	folderID := r.URL.Query().Get("id")
	token := r.URL.Query().Get("token")

	if _, ok := h.encMgr.VerifySession(token); !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	files, err := h.encMgr.ListFiles(folderID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"files": files,
		"count": len(files),
	})
}

func (h *NASHandler) handleEncryptedUpload(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	folderID := r.URL.Query().Get("id")
	token := r.URL.Query().Get("token")
	password := r.URL.Query().Get("password")

	if _, ok := h.encMgr.VerifySession(token); !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	r.ParseMultipartForm(100 << 20) // 100MB
	file, header, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "No file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	if err := h.encMgr.EncryptFile(folderID, header.Filename, file, password); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	h.logger.Info("加密上传文件: %s", header.Filename)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleEncryptedDownload(w http.ResponseWriter, r *http.Request) {
	folderID := r.URL.Query().Get("id")
	token := r.URL.Query().Get("token")
	filename := r.URL.Query().Get("file")
	password := r.URL.Query().Get("password")

	if _, ok := h.encMgr.VerifySession(token); !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	data, origName, err := h.encMgr.DecryptFile(folderID, filename, password)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", origName))
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Write(data)
}

func (h *NASHandler) handleEncryptedDeleteFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		ID       string `json:"id"`
		Filename string `json:"filename"`
		Token    string `json:"token"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if _, ok := h.encMgr.VerifySession(req.Token); !ok {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	if err := h.encMgr.DeleteFile(req.ID, req.Filename); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}
