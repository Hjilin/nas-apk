package main

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"flag"
	"fmt"
	"math/big"
	"net"
	"net/http"
	"net/http/httputil"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"syscall"
	"time"
)

func main() {
	// 命令行参数
	configPath := flag.String("config", "", "配置文件路径（默认: $NAS_DATA_DIR/config.yaml 或 ./config.yaml）")
	genPass := flag.String("gen-pass", "", "生成 bcrypt 密码哈希")
	genSecret := flag.Bool("gen-secret", false, "生成 JWT 密钥")
	genCert := flag.Bool("gen-cert", false, "生成自签名 TLS 证书")
	initConfig := flag.Bool("init", false, "生成默认配置文件")
	dataDir := flag.String("data-dir", "", "数据目录（默认: $NAS_DATA_DIR 或当前目录）")
	port := flag.Int("port", 0, "监听端口（默认: 配置文件或 $NAS_PORT）")
	flag.Parse()

	// 解析数据目录（优先级：命令行 > 环境变量 > 当前目录）
	if *dataDir == "" {
		*dataDir = os.Getenv("NAS_DATA_DIR")
	}
	if *dataDir == "" {
		*dataDir = "."
	}
	// 确保数据目录存在
	os.MkdirAll(*dataDir, 0755)

	// 解析配置文件路径
	if *configPath == "" {
		*configPath = filepath.Join(*dataDir, "config.yaml")
	}

	// 生成密码哈希
	if *genPass != "" {
		hash, err := HashPassword(*genPass)
		if err != nil {
			fmt.Fprintf(os.Stderr, "生成密码哈希失败: %v\n", err)
			os.Exit(1)
		}
		fmt.Println("密码哈希（复制到配置文件 password_hash）:")
		fmt.Println(hash)
		return
	}

	// 生成 JWT 密钥
	if *genSecret {
		secret, err := GenerateSecret(32)
		if err != nil {
			fmt.Fprintf(os.Stderr, "生成密钥失败: %v\n", err)
			os.Exit(1)
		}
		fmt.Println("JWT 密钥（复制到配置文件 jwt_secret）:")
		fmt.Println(secret)
		return
	}

	// 生成自签名证书
	if *genCert {
		if err := generateSelfSignedCert(); err != nil {
			fmt.Fprintf(os.Stderr, "生成证书失败: %v\n", err)
			os.Exit(1)
		}
		fmt.Println("证书已生成: cert.pem, key.pem")
		return
	}

	// 初始化配置
	if *initConfig {
		cfg := DefaultConfig()
		// 生成随机密钥
		secret, _ := GenerateSecret(32)
		cfg.Auth.JWTSecret = secret
		// 设置数据目录相关路径
		cfg.Storage.RootDir = filepath.Join(*dataDir, "storage")
		if err := cfg.SaveConfig(*configPath); err != nil {
			fmt.Fprintf(os.Stderr, "保存配置失败: %v\n", err)
			os.Exit(1)
		}
		fmt.Printf("默认配置已生成: %s\n", *configPath)
		fmt.Println("请编辑配置文件，设置 password_hash（用 -gen-pass 生成）")
		return
	}

	// 正常启动服务
	startServer(*configPath, *dataDir, *port)
}

func startServer(configPath string, dataDir string, overridePort int) {
	// 加载配置
	cfg, err := LoadConfig(configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "加载配置失败: %v\n", err)
		fmt.Println("提示: 使用 -init 生成默认配置，-gen-pass 生成密码哈希，-gen-cert 生成证书")
		os.Exit(1)
	}

	// 环境变量覆盖配置
	if envPort := os.Getenv("NAS_PORT"); envPort != "" {
		if p, err := strconv.Atoi(envPort); err == nil {
			cfg.Server.Port = p
		}
	}
	if envHost := os.Getenv("NAS_HOST"); envHost != "" {
		cfg.Server.Host = envHost
	}
	if envStorage := os.Getenv("NAS_STORAGE"); envStorage != "" {
		cfg.Storage.RootDir = envStorage
	}

	// 命令行端口覆盖
	if overridePort > 0 {
		cfg.Server.Port = overridePort
	}

	// 端口冲突自动选择可用端口
	if !isPortAvailable(cfg.Server.Host, cfg.Server.Port) {
		fmt.Printf("端口 %d 被占用，正在自动选择可用端口...\n", cfg.Server.Port)
		newPort := findAvailablePort(cfg.Server.Host, cfg.Server.Port)
		if newPort > 0 {
			fmt.Printf("已自动选择端口: %d\n", newPort)
			cfg.Server.Port = newPort
		}
	}

	// 确保存储目录存在
	os.MkdirAll(cfg.Storage.RootDir, 0755)

	// 初始化日志
	logger, err := NewLogger(&cfg.Log)
	if err != nil {
		fmt.Fprintf(os.Stderr, "初始化日志失败: %v\n", err)
		os.Exit(1)
	}
	defer logger.Close()

	logger.Info("system", "startup", "========================================")
	logger.Info("system", "startup", "NAS 私有云服务启动中...")
	logger.Info("system", "startup", "存储目录: %s", cfg.Storage.RootDir)
	logger.Info("system", "startup", "监听地址: %s:%d", cfg.Server.Host, cfg.Server.Port)
	logger.Info("system", "startup", "HTTPS: %v", cfg.Server.HTTPS)
	logger.Info("system", "startup", "只读模式: %v", cfg.Storage.ReadOnly)
	logger.Info("system", "startup", "========================================")

	// 初始化认证
	auth := NewAuthManager(&cfg.Auth, &cfg.Security)
	globalAuthMgr = auth

	// 初始化用户管理器
	InitUserManager(cfg.Storage.RootDir)

	// 初始化增强版系统监控器
	InitEnhancedMonitor(cfg.Storage.RootDir)

	// 初始化处理器
	nasHandler := NewNASHandler(cfg, auth, logger)

	// 初始化安全中间件
	secMiddleware := NewSecurityMiddleware(cfg, auth, logger.logger)

	// 包装处理器
	handler := secMiddleware.Chain(nasHandler)

	// 启动AList HTTPS代理（8444端口，解决混合内容问题）
	// 立即启动代理，不等待AList就绪（AList未启动时访问会显示错误，但端口一定在监听）
	if cfg.Server.HTTPS {
		go func() {
			alistProxy := &httputil.ReverseProxy{
				Rewrite: func(r *httputil.ProxyRequest) {
					r.SetURL(mustParseURL("http://127.0.0.1:" + AListPort))
					r.Out.Host = "127.0.0.1:" + AListPort
					r.Out.Header.Set("X-Forwarded-Proto", "https")
					r.Out.Header.Set("X-Forwarded-Host", r.In.Host)
				},
				ModifyResponse: func(resp *http.Response) error {
					// 移除阻止iframe嵌入的响应头
					resp.Header.Del("X-Frame-Options")
					resp.Header.Del("Content-Security-Policy")
					resp.Header.Del("X-Content-Security-Policy")
					resp.Header.Del("Frame-Options")
					// 允许被任何页面iframe嵌入
					resp.Header.Set("X-Frame-Options", "ALLOWALL")
					return nil
				},
				ErrorHandler: func(w http.ResponseWriter, r *http.Request, err error) {
					w.Header().Set("Content-Type", "text/html; charset=utf-8")
					w.WriteHeader(http.StatusBadGateway)
					w.Write([]byte(`
						<!DOCTYPE html>
						<html><head><meta charset="utf-8"><title>AList未启动</title>
						<style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#f5f5f5;}
						.card{background:#fff;padding:40px;border-radius:12px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,.1);}
						h2{color:#d32f2f;margin:0 0 12px;}p{color:#666;margin:0;}</style></head>
						<body><div class="card"><h2>AList 服务未启动</h2><p>正在启动中，请等待5秒后刷新页面...</p></div></body></html>
					`))
				},
			}
			alistServer := &http.Server{
				Addr:         fmt.Sprintf("%s:8444", cfg.Server.Host),
				Handler:      alistProxy,
				ReadTimeout:  30 * time.Second,
				WriteTimeout: 300 * time.Second,
			}
			logger.Info("alist", "proxy", "AList HTTPS代理已启动: https://%s:8444", cfg.Server.Host)
			if err := alistServer.ListenAndServeTLS(cfg.Server.CertFile, cfg.Server.KeyFile); err != nil && err != http.ErrServerClosed {
				logger.Error("alist", "proxy", "AList代理启动失败: %v", err)
			}
		}()
	}

	// 异步启动AList服务（内置网盘管理）
	go func() {
		time.Sleep(2 * time.Second) // 等待NAS服务启动
		if err := initAList(); err != nil {
			logger.Warn("alist", "startup", "AList启动失败（不影响NAS主服务）: %v", err)
		} else {
			logger.Info("alist", "startup", "AList网盘服务已启动: http://127.0.0.1:%s", AListPort)
		}
	}()

	// 启动FTP服务（供Amaze File Manager等第三方文件管理器连接）
	ftpManager := NewFTPManager(cfg, auth)
	go func() {
		if err := ftpManager.Start(); err != nil {
			logger.Error("ftp", "startup", "FTP服务启动失败: %v", err)
		}
	}()
	logger.Info("ftp", "startup", "FTP服务已启动: ftp://%s:%d (供Amaze等第三方文件管理器连接)", cfg.Server.Host, ftpManager.GetPort())

	// 配置 HTTP 服务器
	server := &http.Server{
		Addr:         fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port),
		Handler:      handler,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 300 * time.Second, // 大文件上传需要更长时间
		IdleTimeout:  120 * time.Second,
		MaxHeaderBytes: 1 << 20, // 1MB
	}

	// 优雅关闭
	go func() {
		sigChan := make(chan os.Signal, 1)
		signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
		<-sigChan
		logger.Info("system", "shutdown", "收到关闭信号，正在停止服务...")
		stopAList() // 停止AList服务
		server.Close()
	}()

	// 启动服务
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	if cfg.Server.HTTPS {
		logger.Info("system", "startup", "HTTPS 服务已启动: https://%s", addr)
		logger.Info("system", "startup", "Web 管理界面: https://%s/", addr)
		logger.Info("system", "startup", "WebDAV 地址: https://%s/webdav/", addr)
		if err := server.ListenAndServeTLS(cfg.Server.CertFile, cfg.Server.KeyFile); err != nil && err != http.ErrServerClosed {
			logger.Error("system", "startup", "HTTPS 服务启动失败: %v", err)
			os.Exit(1)
		}
	} else {
		logger.Warn("system", "startup", "警告: 当前使用 HTTP，传输未加密！建议启用 HTTPS")
		logger.Info("system", "startup", "HTTP 服务已启动: http://%s", addr)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Error("system", "startup", "HTTP 服务启动失败: %v", err)
			os.Exit(1)
		}
	}

	logger.Info("system", "shutdown", "服务已停止")
}

// generateSelfSignedCert 生成自签名 TLS 证书
// isPortAvailable 检查端口是否可用
func isPortAvailable(host string, port int) bool {
	addr := fmt.Sprintf("%s:%d", host, port)
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return false
	}
	ln.Close()
	return true
}

// findAvailablePort 从指定端口开始查找可用端口
func findAvailablePort(host string, startPort int) int {
	for port := startPort; port < startPort+100; port++ {
		if isPortAvailable(host, port) {
			return port
		}
	}
	return 0
}

func generateSelfSignedCert() error {
	// 生成 ECDSA 私钥（比 RSA 更快更短，适合手机）
	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return err
	}

	// 证书模板
	template := x509.Certificate{
		SerialNumber: big.NewInt(time.Now().UnixNano()),
		Subject: pkix.Name{
			Organization: []string{"NAS Private Cloud"},
			CommonName:   "nas.local",
		},
		NotBefore:             time.Now(),
		NotAfter:              time.Now().AddDate(10, 0, 0), // 10年有效期
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}

	// 添加 SAN（Subject Alternative Name）
	template.IPAddresses = []net.IP{net.ParseIP("127.0.0.1"), net.ParseIP("::1")}
	template.DNSNames = []string{"localhost", "nas.local"}

	// 获取本机所有 IP 加入 SAN
	addrs, err := net.InterfaceAddrs()
	if err == nil {
		for _, addr := range addrs {
			if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
				if ipnet.IP.To4() != nil {
					template.IPAddresses = append(template.IPAddresses, ipnet.IP)
				}
			}
		}
	}

	// 自签名
	certDER, err := x509.CreateCertificate(rand.Reader, &template, &template, &priv.PublicKey, priv)
	if err != nil {
		return err
	}

	// 写入证书文件
	certFile, err := os.Create("cert.pem")
	if err != nil {
		return err
	}
	defer certFile.Close()
	pem.Encode(certFile, &pem.Block{Type: "CERTIFICATE", Bytes: certDER})

	// 写入私钥文件
	keyBytes, err := x509.MarshalECPrivateKey(priv)
	if err != nil {
		return err
	}
	keyFile, err := os.OpenFile("key.pem", os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if err != nil {
		return err
	}
	defer keyFile.Close()
	pem.Encode(keyFile, &pem.Block{Type: "EC PRIVATE KEY", Bytes: keyBytes})

	return nil
}

// 确保存储目录路径安全
func init() {
	// 程序启动时检查当前目录
	if dir, err := os.Getwd(); err == nil {
		_ = filepath.Join(dir, "data")
	}
}
