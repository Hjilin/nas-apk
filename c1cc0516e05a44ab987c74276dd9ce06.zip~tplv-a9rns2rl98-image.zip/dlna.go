package main

import (
	"encoding/json"
	"encoding/xml"
	"fmt"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

// DlnaManager DLNA管理器
type DlnaManager struct {
	cfg          *Config
	logger       *Logger
	notifyMgr    *NotificationManager
	running      bool
	mu           sync.Mutex
	ssdpConn     *net.UDPConn
	ssdpOK       bool
	ssdpError    string
	httpServer   *http.Server
	mediaRoot    string
	deviceUUID   string
	bootID       int
	configID     int
}

// NewDlnaManager 创建DLNA管理器
func NewDlnaManager(cfg *Config, logger *Logger, notifyMgr *NotificationManager) *DlnaManager {
	return &DlnaManager{
		cfg:        cfg,
		logger:     logger,
		notifyMgr:  notifyMgr,
		mediaRoot:  cfg.Storage.RootDir,
		deviceUUID: generateUUID(),
		bootID:     1,
		configID:   1,
	}
}

func generateUUID() string {
	hostname, _ := os.Hostname()
	return fmt.Sprintf("uuid:5d795378-a44d-4d8c-9e3f-%s", hostname)
}

// Start 启动DLNA服务
func (dm *DlnaManager) Start() error {
	dm.mu.Lock()
	defer dm.mu.Unlock()

	if dm.running {
		return fmt.Errorf("DLNA服务已在运行")
	}

	// 启动SSDP发现
	if err := dm.startSSDP(); err != nil {
		dm.ssdpOK = false
		dm.ssdpError = err.Error()
		dm.logger.Warn("SSDP启动失败（可能需要root权限）: %v", err)
	} else {
		dm.ssdpOK = true
		dm.ssdpError = ""
	}

	// 启动HTTP媒体服务器
	if err := dm.startHTTPServer(); err != nil {
		return err
	}

	dm.running = true
	dm.bootID++
	dm.logger.Info("DLNA媒体服务器已启动，设备UUID: %s, SSDP: %v", dm.deviceUUID, dm.ssdpOK)

	// 发送设备上线公告
	go dm.sendSSDPAlive()

	if dm.notifyMgr != nil {
		dm.notifyMgr.Add("info", "system", "DLNA已启动", "电视/投影可发现并播放NAS视频")
	}
	return nil
}

// Stop 停止DLNA服务
func (dm *DlnaManager) Stop() {
	dm.mu.Lock()
	defer dm.mu.Unlock()

	if !dm.running {
		return
	}

	// 发送设备下线公告
	dm.sendSSDPByeBye()

	if dm.ssdpConn != nil {
		dm.ssdpConn.Close()
		dm.ssdpConn = nil
	}

	if dm.httpServer != nil {
		dm.httpServer.Close()
		dm.httpServer = nil
	}

	dm.running = false
	dm.logger.Info("dlna", "action", "DLNA媒体服务器已停止")
}

func (dm *DlnaManager) IsRunning() bool {
	dm.mu.Lock()
	defer dm.mu.Unlock()
	return dm.running
}

// ===== SSDP 设备发现 =====

func (dm *DlnaManager) startSSDP() error {
	addr, err := net.ResolveUDPAddr("udp", "239.255.255.250:1900")
	if err != nil {
		return err
	}

	conn, err := net.ListenMulticastUDP("udp", nil, addr)
	if err != nil {
		return err
	}
	conn.SetReadBuffer(1024 * 1024)
	dm.ssdpConn = conn

	go dm.ssdpLoop()
	return nil
}

func (dm *DlnaManager) ssdpLoop() {
	buf := make([]byte, 65536)
	for {
		if dm.ssdpConn == nil {
			return
		}
		n, remoteAddr, err := dm.ssdpConn.ReadFromUDP(buf)
		if err != nil {
			return
		}

		msg := string(buf[:n])
		if strings.Contains(msg, "M-SEARCH") && strings.Contains(msg, "ssdp:discover") {
			go dm.handleMSearch(remoteAddr, msg)
		}
	}
}

func (dm *DlnaManager) handleMSearch(addr *net.UDPAddr, msg string) {
	// 解析搜索目标
	st := "ssdp:all"
	for _, line := range strings.Split(msg, "\r\n") {
		if strings.HasPrefix(strings.ToLower(line), "st:") {
			st = strings.TrimSpace(line[3:])
			break
		}
	}

	localIP := getLocalIP()
	if localIP == "" {
		localIP = "127.0.0.1"
	}
	location := fmt.Sprintf("http://%s:8200/rootDesc.xml", localIP)

	// 响应多种搜索目标
	targets := []string{
		"upnp:rootdevice",
		"urn:schemas-upnp-org:device:MediaServer:1",
		"urn:schemas-upnp-org:device:MediaServer:2",
		"urn:schemas-upnp-org:service:ContentDirectory:1",
		"urn:schemas-upnp-org:service:ConnectionManager:1",
		dm.deviceUUID,
	}

	shouldRespond := st == "ssdp:all"
	for _, t := range targets {
		if st == t {
			shouldRespond = true
			break
		}
	}

	if !shouldRespond {
		return
	}

	// 发送多个响应（标准UPnP要求）
	for _, target := range targets {
		if st == "ssdp:all" || st == target {
			response := fmt.Sprintf("HTTP/1.1 200 OK\r\n"+
				"CACHE-CONTROL: max-age=1800\r\n"+
				"DATE: %s\r\n"+
				"EXT:\r\n"+
				"LOCATION: %s\r\n"+
				"SERVER: Linux/1.0 UPnP/1.0 DLNADOC/1.50 NAS-DLNA/1.0\r\n"+
				"ST: %s\r\n"+
				"USN: %s::%s\r\n"+
				"BOOTID.UPNP.ORG: %d\r\n"+
				"CONFIGID.UPNP.ORG: %d\r\n"+
				"\r\n",
				time.Now().Format(time.RFC1123),
				location,
				target,
				dm.deviceUUID, target,
				dm.bootID, dm.configID)

			if dm.ssdpConn != nil {
				dm.ssdpConn.WriteToUDP([]byte(response), addr)
				time.Sleep(50 * time.Millisecond)
			}
		}
	}
}

func (dm *DlnaManager) sendSSDPAlive() {
	time.Sleep(1 * time.Second)
	localIP := getLocalIP()
	if localIP == "" {
		return
	}
	location := fmt.Sprintf("http://%s:8200/rootDesc.xml", localIP)

	addr, _ := net.ResolveUDPAddr("udp", "239.255.255.250:1900")

	targets := []string{
		"upnp:rootdevice",
		"urn:schemas-upnp-org:device:MediaServer:1",
		"urn:schemas-upnp-org:service:ContentDirectory:1",
		"urn:schemas-upnp-org:service:ConnectionManager:1",
		dm.deviceUUID,
	}

	for _, target := range targets {
		notify := fmt.Sprintf("NOTIFY * HTTP/1.1\r\n"+
			"HOST: 239.255.255.250:1900\r\n"+
			"CACHE-CONTROL: max-age=1800\r\n"+
			"LOCATION: %s\r\n"+
			"NT: %s\r\n"+
			"NTS: ssdp:alive\r\n"+
			"SERVER: Linux/1.0 UPnP/1.0 DLNADOC/1.50 NAS-DLNA/1.0\r\n"+
			"USN: %s::%s\r\n"+
			"BOOTID.UPNP.ORG: %d\r\n"+
			"CONFIGID.UPNP.ORG: %d\r\n"+
			"\r\n",
			location, target, dm.deviceUUID, target, dm.bootID, dm.configID)

		if dm.ssdpConn != nil {
			dm.ssdpConn.WriteToUDP([]byte(notify), addr)
			time.Sleep(100 * time.Millisecond)
		}
	}
}

func (dm *DlnaManager) sendSSDPByeBye() {
	localIP := getLocalIP()
	if localIP == "" || dm.ssdpConn == nil {
		return
	}
	addr, _ := net.ResolveUDPAddr("udp", "239.255.255.250:1900")

	targets := []string{
		"upnp:rootdevice",
		"urn:schemas-upnp-org:device:MediaServer:1",
		dm.deviceUUID,
	}

	for _, target := range targets {
		notify := fmt.Sprintf("NOTIFY * HTTP/1.1\r\n"+
			"HOST: 239.255.255.250:1900\r\n"+
			"NT: %s\r\n"+
			"NTS: ssdp:byebye\r\n"+
			"USN: %s::%s\r\n"+
			"BOOTID.UPNP.ORG: %d\r\n"+
			"CONFIGID.UPNP.ORG: %d\r\n"+
			"\r\n",
			target, dm.deviceUUID, target, dm.bootID, dm.configID)

		dm.ssdpConn.WriteToUDP([]byte(notify), addr)
		time.Sleep(50 * time.Millisecond)
	}
}

// ===== HTTP 媒体服务器 =====

func (dm *DlnaManager) startHTTPServer() error {
	mux := http.NewServeMux()

	mux.HandleFunc("/rootDesc.xml", dm.handleRootDesc)
	mux.HandleFunc("/ContentDirectory/", dm.handleContentDirectory)
	mux.HandleFunc("/ConnectionManager/", dm.handleConnectionManager)
	mux.HandleFunc("/media/", dm.handleMedia)
	mux.HandleFunc("/icon.png", dm.handleIcon)

	dm.httpServer = &http.Server{
		Addr:    ":8200",
		Handler: mux,
	}

	go func() {
		if err := dm.httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			dm.logger.Error("DLNA HTTP服务器错误: %v", err)
		}
	}()

	return nil
}

// ===== 设备描述 =====

func (dm *DlnaManager) handleRootDesc(w http.ResponseWriter, r *http.Request) {
	localIP := getLocalIP()
	if localIP == "" {
		localIP = "127.0.0.1"
	}
	baseURL := fmt.Sprintf("http://%s:8200", localIP)

	desc := DeviceDescription{
		Xmlns: "urn:schemas-upnp-org:device-1-0",
		SpecVersion: SpecVersion{Major: 1, Minor: 0},
		Device: DeviceDesc{
			DeviceType:   "urn:schemas-upnp-org:device:MediaServer:1",
			FriendlyName: "NAS私有云 - 媒体服务器",
			Manufacturer: "NAS",
			ManufacturerURL: "https://github.com/nas",
			ModelName:    "NAS Media Server",
			ModelDescription: "NAS DLNA Media Server",
			ModelNumber:  "1.0",
			ModelURL:     "https://github.com/nas",
			UDN:          dm.deviceUUID,
			IconList: IconList{
				Icon: []Icon{
					{Mimetype: "image/png", Width: 48, Height: 48, Depth: 24, URL: "/icon.png"},
					{Mimetype: "image/png", Width: 120, Height: 120, Depth: 24, URL: "/icon.png"},
				},
			},
			ServiceList: ServiceList{
				Service: []Service{
					{
						ServiceType: "urn:schemas-upnp-org:service:ContentDirectory:1",
						ServiceId:   "urn:upnp-org:serviceId:ContentDirectory",
						ControlURL:  baseURL + "/ContentDirectory/control",
						EventSubURL: baseURL + "/ContentDirectory/event",
						SCPDURL:     baseURL + "/ContentDirectory/scpd.xml",
					},
					{
						ServiceType: "urn:schemas-upnp-org:service:ConnectionManager:1",
						ServiceId:   "urn:upnp-org:serviceId:ConnectionManager",
						ControlURL:  baseURL + "/ConnectionManager/control",
						EventSubURL: baseURL + "/ConnectionManager/event",
						SCPDURL:     baseURL + "/ConnectionManager/scpd.xml",
					},
				},
			},
			PresentationURL: baseURL + "/",
		},
	}

	w.Header().Set("Content-Type", "text/xml; charset=utf-8")
	w.Header().Set("Server", "Linux/1.0 UPnP/1.0 DLNADOC/1.50")
	xml.NewEncoder(w).Encode(desc)
}

// XML 结构定义
type DeviceDescription struct {
	XMLName     xml.Name    `xml:"root"`
	Xmlns       string      `xml:"xmlns,attr"`
	SpecVersion SpecVersion `xml:"specVersion"`
	Device      DeviceDesc  `xml:"device"`
}
type SpecVersion struct {
	Major int `xml:"major"`
	Minor int `xml:"minor"`
}
type DeviceDesc struct {
	DeviceType       string      `xml:"deviceType"`
	FriendlyName     string      `xml:"friendlyName"`
	Manufacturer     string      `xml:"manufacturer"`
	ManufacturerURL  string      `xml:"manufacturerURL,omitempty"`
	ModelDescription string      `xml:"modelDescription,omitempty"`
	ModelName        string      `xml:"modelName"`
	ModelNumber      string      `xml:"modelNumber,omitempty"`
	ModelURL         string      `xml:"modelURL,omitempty"`
	UDN              string      `xml:"UDN"`
	IconList         IconList    `xml:"iconList"`
	ServiceList      ServiceList `xml:"serviceList"`
	PresentationURL  string      `xml:"presentationURL,omitempty"`
}
type IconList struct {
	Icon []Icon `xml:"icon"`
}
type Icon struct {
	Mimetype string `xml:"mimetype"`
	Width    int    `xml:"width"`
	Height   int    `xml:"height"`
	Depth    int    `xml:"depth"`
	URL      string `xml:"url"`
}
type ServiceList struct {
	Service []Service `xml:"service"`
}
type Service struct {
	ServiceType string `xml:"serviceType"`
	ServiceId   string `xml:"serviceId"`
	ControlURL  string `xml:"controlURL"`
	EventSubURL string `xml:"eventSubURL"`
	SCPDURL     string `xml:"SCPDURL"`
}

// ===== ContentDirectory 服务 =====

func (dm *DlnaManager) handleContentDirectory(w http.ResponseWriter, r *http.Request) {
	if strings.HasSuffix(r.URL.Path, "/scpd.xml") {
		w.Header().Set("Content-Type", "text/xml; charset=utf-8")
		w.Write([]byte(contentDirectorySCPD))
		return
	}

	if strings.HasSuffix(r.URL.Path, "/control") {
		body := make([]byte, 65536)
		n, _ := r.Body.Read(body)
		request := string(body[:n])

		if strings.Contains(request, "Browse") {
			dm.handleBrowse(w, request)
			return
		}
		if strings.Contains(request, "GetSortCapabilities") {
			dm.handleGetSortCapabilities(w)
			return
		}
		if strings.Contains(request, "GetSearchCapabilities") {
			dm.handleGetSearchCapabilities(w)
			return
		}
		if strings.Contains(request, "GetSystemUpdateID") {
			dm.handleGetSystemUpdateID(w)
			return
		}
	}

	w.WriteHeader(http.StatusOK)
}

const contentDirectorySCPD = `<?xml version="1.0" encoding="utf-8"?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0">
<specVersion><major>1</major><minor>0</minor></specVersion>
<actionList>
<action><name>Browse</name>
<argumentList>
<argument><name>ObjectID</name><direction>in</direction><relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable></argument>
<argument><name>BrowseFlag</name><direction>in</direction><relatedStateVariable>A_ARG_TYPE_BrowseFlag</relatedStateVariable></argument>
<argument><name>Filter</name><direction>in</direction><relatedStateVariable>A_ARG_TYPE_Filter</relatedStateVariable></argument>
<argument><name>StartingIndex</name><direction>in</direction><relatedStateVariable>A_ARG_TYPE_Index</relatedStateVariable></argument>
<argument><name>RequestedCount</name><direction>in</direction><relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable></argument>
<argument><name>SortCriteria</name><direction>in</direction><relatedStateVariable>A_ARG_TYPE_SortCriteria</relatedStateVariable></argument>
<argument><name>Result</name><direction>out</direction><relatedStateVariable>A_ARG_TYPE_Result</relatedStateVariable></argument>
<argument><name>NumberReturned</name><direction>out</direction><relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable></argument>
<argument><name>TotalMatches</name><direction>out</direction><relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable></argument>
<argument><name>UpdateID</name><direction>out</direction><relatedStateVariable>A_ARG_TYPE_UpdateID</relatedStateVariable></argument>
</argumentList>
</action>
<action><name>GetSortCapabilities</name>
<argumentList><argument><name>SortCaps</name><direction>out</direction><relatedStateVariable>SortCapabilities</relatedStateVariable></argument></argumentList>
</action>
<action><name>GetSearchCapabilities</name>
<argumentList><argument><name>SearchCaps</name><direction>out</direction><relatedStateVariable>SearchCapabilities</relatedStateVariable></argument></argumentList>
</action>
<action><name>GetSystemUpdateID</name>
<argumentList><argument><name>Id</name><direction>out</direction><relatedStateVariable>SystemUpdateID</relatedStateVariable></argument></argumentList>
</action>
</actionList>
<serviceStateTable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_ObjectID</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_BrowseFlag</name><dataType>string</dataType><allowedValueList><allowedValue>BrowseMetadata</allowedValue><allowedValue>BrowseDirectChildren</allowedValue></allowedValueList></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_Filter</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_Index</name><dataType>ui4</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_Count</name><dataType>ui4</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_SortCriteria</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_Result</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>A_ARG_TYPE_UpdateID</name><dataType>ui4</dataType></stateVariable>
<stateVariable sendEvents="no"><name>SortCapabilities</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>SearchCapabilities</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="yes"><name>SystemUpdateID</name><dataType>ui4</dataType></stateVariable>
</serviceStateTable>
</scpd>`

func (dm *DlnaManager) handleBrowse(w http.ResponseWriter, request string) {
	// 解析参数
	objectID := "0"
	browseFlag := "BrowseDirectChildren"
	startingIndex := 0
	requestedCount := 0

	for _, line := range strings.Split(request, "\n") {
		line = strings.TrimSpace(line)
		if strings.Contains(line, "<ObjectID>") {
			objectID = extractXMLValue(line, "ObjectID")
		}
		if strings.Contains(line, "<BrowseFlag>") {
			browseFlag = extractXMLValue(line, "BrowseFlag")
		}
		if strings.Contains(line, "<StartingIndex>") {
			startingIndex, _ = strconv.Atoi(extractXMLValue(line, "StartingIndex"))
		}
		if strings.Contains(line, "<RequestedCount>") {
			requestedCount, _ = strconv.Atoi(extractXMLValue(line, "RequestedCount"))
		}
	}

	localIP := getLocalIP()
	if localIP == "" {
		localIP = "127.0.0.1"
	}

	var didl string
	var totalMatches int

	if browseFlag == "BrowseMetadata" && objectID == "0" {
		// 根目录元数据
		didl = fmt.Sprintf(`<container id="0" parentID="-1" restricted="1" searchable="1">
<dc:title>NAS 媒体库</dc:title>
<upnp:class>object.container.storageFolder</upnp:class>
<upnp:storageUsed>-1</upnp:storageUsed>
</container>`)
		totalMatches = 1
	} else {
		// 浏览子目录 - 返回所有媒体文件
		files := dm.scanAllMedia()
		var items []string

		for i, f := range files {
			if i < startingIndex {
				continue
			}
			if requestedCount > 0 && len(items) >= requestedCount {
				break
			}

			itemURL := fmt.Sprintf("http://%s:8200/media/%s", localIP, f.Name)
			mimeType := getMimeType(f.Ext)
			upnpClass := getUPnPClass(f.MediaType)
			protocolInfo := fmt.Sprintf("http-get:*:%s:*", mimeType)

			item := fmt.Sprintf(`<item id="%d" parentID="0" restricted="1">
<dc:title>%s</dc:title>
<upnp:class>%s</upnp:class>
<dc:date>%s</dc:date>
<upnp:writeStatus>PROTECTED</upnp:writeStatus>
<res size="%d" duration="%s" protocolInfo="%s">%s</res>
</item>`, i+1, f.Name, upnpClass, f.ModTime.Format("2006-01-02"), f.Size, f.Duration, protocolInfo, itemURL)

			items = append(items, item)
		}

		didl = strings.Join(items, "")
		totalMatches = len(files)
	}

	// 转义DIDL中的特殊字符
	didlEscaped := escapeXML(didl)

	response := fmt.Sprintf(`<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<s:Body>
<u:BrowseResponse xmlns:u="urn:schemas-upnp-org:service:ContentDirectory:1">
<Result>%s</Result>
<NumberReturned>%d</NumberReturned>
<TotalMatches>%d</TotalMatches>
<UpdateID>1</UpdateID>
</u:BrowseResponse>
</s:Body>
</s:Envelope>`, didlEscaped, totalMatches, totalMatches)

	w.Header().Set("Content-Type", "text/xml; charset=utf-8")
	w.Header().Set("Server", "Linux/1.0 UPnP/1.0 DLNADOC/1.50")
	w.Write([]byte(response))
}

func (dm *DlnaManager) handleGetSortCapabilities(w http.ResponseWriter) {
	response := `<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<s:Body>
<u:GetSortCapabilitiesResponse xmlns:u="urn:schemas-upnp-org:service:ContentDirectory:1">
<SortCaps>dc:title,dc:date</SortCaps>
</u:GetSortCapabilitiesResponse>
</s:Body>
</s:Envelope>`
	w.Header().Set("Content-Type", "text/xml; charset=utf-8")
	w.Write([]byte(response))
}

func (dm *DlnaManager) handleGetSearchCapabilities(w http.ResponseWriter) {
	response := `<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<s:Body>
<u:GetSearchCapabilitiesResponse xmlns:u="urn:schemas-upnp-org:service:ContentDirectory:1">
<SearchCaps>dc:title,dc:creator,upnp:class</SearchCaps>
</u:GetSearchCapabilitiesResponse>
</s:Body>
</s:Envelope>`
	w.Header().Set("Content-Type", "text/xml; charset=utf-8")
	w.Write([]byte(response))
}

func (dm *DlnaManager) handleGetSystemUpdateID(w http.ResponseWriter) {
	response := `<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<s:Body>
<u:GetSystemUpdateIDResponse xmlns:u="urn:schemas-upnp-org:service:ContentDirectory:1">
<Id>1</Id>
</u:GetSystemUpdateIDResponse>
</s:Body>
</s:Envelope>`
	w.Header().Set("Content-Type", "text/xml; charset=utf-8")
	w.Write([]byte(response))
}

// ===== ConnectionManager 服务 =====

func (dm *DlnaManager) handleConnectionManager(w http.ResponseWriter, r *http.Request) {
	if strings.HasSuffix(r.URL.Path, "/scpd.xml") {
		w.Header().Set("Content-Type", "text/xml; charset=utf-8")
		w.Write([]byte(connectionManagerSCPD))
		return
	}

	if strings.HasSuffix(r.URL.Path, "/control") {
		body := make([]byte, 65536)
		n, _ := r.Body.Read(body)
		request := string(body[:n])

		if strings.Contains(request, "GetProtocolInfo") {
			dm.handleGetProtocolInfo(w)
			return
		}
	}

	w.WriteHeader(http.StatusOK)
}

const connectionManagerSCPD = `<?xml version="1.0" encoding="utf-8"?>
<scpd xmlns="urn:schemas-upnp-org:service-1-0">
<specVersion><major>1</major><minor>0</minor></specVersion>
<actionList>
<action><name>GetProtocolInfo</name>
<argumentList>
<argument><name>Source</name><direction>out</direction><relatedStateVariable>SourceProtocolInfo</relatedStateVariable></argument>
<argument><name>Sink</name><direction>out</direction><relatedStateVariable>SinkProtocolInfo</relatedStateVariable></argument>
</argumentList>
</action>
</actionList>
<serviceStateTable>
<stateVariable sendEvents="no"><name>SourceProtocolInfo</name><dataType>string</dataType></stateVariable>
<stateVariable sendEvents="no"><name>SinkProtocolInfo</name><dataType>string</dataType></stateVariable>
</serviceStateTable>
</scpd>`

func (dm *DlnaManager) handleGetProtocolInfo(w http.ResponseWriter) {
	sourceProtocols := "http-get:*:video/mp4:*,http-get:*:video/x-matroska:*,http-get:*:video/x-msvideo:*,http-get:*:video/quicktime:*,http-get:*:video/x-ms-wmv:*,http-get:*:video/x-flv:*,http-get:*:video/webm:*,http-get:*:audio/mpeg:*,http-get:*:audio/mp4:*,http-get:*:image/jpeg:*,http-get:*:image/png:*,http-get:*:*:*"

	response := fmt.Sprintf(`<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<s:Body>
<u:GetProtocolInfoResponse xmlns:u="urn:schemas-upnp-org:service:ConnectionManager:1">
<Source>%s</Source>
<Sink></Sink>
</u:GetProtocolInfoResponse>
</s:Body>
</s:Envelope>`, sourceProtocols)

	w.Header().Set("Content-Type", "text/xml; charset=utf-8")
	w.Write([]byte(response))
}

// ===== 媒体文件服务 =====

type DlnaMediaFile struct {
	Name      string
	Path      string
	Ext       string
	MediaType string // video / audio / image
	Size      int64
	Duration  string
	ModTime   time.Time
}

func (dm *DlnaManager) scanAllMedia() []DlnaMediaFile {
	var files []DlnaMediaFile

	videoExts := map[string]string{
		".mp4": "video/mp4", ".mkv": "video/x-matroska", ".avi": "video/x-msvideo",
		".mov": "video/quicktime", ".wmv": "video/x-ms-wmv", ".flv": "video/x-flv",
		".webm": "video/webm", ".m4v": "video/x-m4v", ".mpg": "video/mpeg",
		".mpeg": "video/mpeg", ".ts": "video/mp2t", ".3gp": "video/3gpp",
	}
	audioExts := map[string]string{
		".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".aac": "audio/aac",
		".flac": "audio/flac", ".wav": "audio/wav", ".ogg": "audio/ogg",
		".wma": "audio/x-ms-wma",
	}
	imageExts := map[string]string{
		".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
		".gif": "image/gif", ".bmp": "image/bmp", ".webp": "image/webp",
	}

	filepath.Walk(dm.mediaRoot, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		// 跳过隐藏目录和缩略图缓存
		if strings.Contains(path, "/.") || strings.Contains(path, ".thumbs") {
			return nil
		}

		ext := strings.ToLower(filepath.Ext(path))
		var mediaType string

		if mimeType, ok := videoExts[ext]; ok {
			mediaType = "video"
			_ = mimeType
		} else if _, ok := audioExts[ext]; ok {
			mediaType = "audio"
		} else if _, ok := imageExts[ext]; ok {
			mediaType = "image"
		} else {
			return nil
		}

		files = append(files, DlnaMediaFile{
			Name:      info.Name(),
			Path:      path,
			Ext:       strings.TrimPrefix(ext, "."),
			MediaType: mediaType,
			Size:      info.Size(),
			Duration:  "0:00:00",
			ModTime:   info.ModTime(),
		})
		return nil
	})

	return files
}

func (dm *DlnaManager) handleMedia(w http.ResponseWriter, r *http.Request) {
	filename := strings.TrimPrefix(r.URL.Path, "/media/")
	filePath := filepath.Join(dm.mediaRoot, filename)

	if !strings.HasPrefix(filepath.Clean(filePath), filepath.Clean(dm.mediaRoot)) {
		http.Error(w, "Forbidden", http.StatusForbidden)
		return
	}

	// 设置DLNA相关响应头
	ext := strings.ToLower(filepath.Ext(filePath))
	w.Header().Set("Content-Type", getMimeType(ext))
	w.Header().Set("Accept-Ranges", "bytes")
	w.Header().Set("transferMode.dlna.org", "Streaming")
	w.Header().Set("contentFeatures.dlna.org", "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000")

	http.ServeFile(w, r, filePath)
}

func (dm *DlnaManager) handleIcon(w http.ResponseWriter, r *http.Request) {
	pngData := []byte{
		0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
		0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
		0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x30,
		0x08, 0x02, 0x00, 0x00, 0x00, 0x0B, 0xD3, 0x1E,
		0x66, 0x00, 0x00, 0x00, 0x01, 0x73, 0x52, 0x47,
		0x42, 0x00, 0xAE, 0xCE, 0x1C, 0xE9, 0x00, 0x00,
		0x00, 0x15, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C,
		0x62, 0x60, 0x18, 0x05, 0xA3, 0x60, 0x14, 0x8C,
		0x82, 0x51, 0x30, 0x0A, 0x46, 0xC1, 0x18, 0x05,
		0x00, 0x01, 0x00, 0x00, 0xFF, 0xFF, 0x0D, 0x0A,
		0x00, 0x9B, 0x77, 0xDE, 0xD4, 0x00, 0x00, 0x00,
		0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82,
	}
	w.Header().Set("Content-Type", "image/png")
	w.Write(pngData)
}

// ===== 辅助函数 =====

func extractXMLValue(line, tag string) string {
	start := strings.Index(line, "<"+tag+">")
	end := strings.Index(line, "</"+tag+">")
	if start >= 0 && end > start {
		return line[start+len(tag)+2 : end]
	}
	return ""
}

func escapeXML(s string) string {
	s = strings.ReplaceAll(s, "&", "&amp;")
	s = strings.ReplaceAll(s, "<", "&lt;")
	s = strings.ReplaceAll(s, ">", "&gt;")
	s = strings.ReplaceAll(s, "\"", "&quot;")
	s = strings.ReplaceAll(s, "'", "&apos;")
	return s
}

func getMimeType(ext string) string {
	ext = strings.ToLower(ext)
	ext = strings.TrimPrefix(ext, ".")
	mimeTypes := map[string]string{
		"mp4": "video/mp4", "mkv": "video/x-matroska", "avi": "video/x-msvideo",
		"mov": "video/quicktime", "wmv": "video/x-ms-wmv", "flv": "video/x-flv",
		"webm": "video/webm", "m4v": "video/x-m4v", "mpg": "video/mpeg",
		"mpeg": "video/mpeg", "ts": "video/mp2t", "3gp": "video/3gpp",
		"mp3": "audio/mpeg", "m4a": "audio/mp4", "aac": "audio/aac",
		"flac": "audio/flac", "wav": "audio/wav", "ogg": "audio/ogg",
		"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
		"gif": "image/gif", "bmp": "image/bmp", "webp": "image/webp",
	}
	if m, ok := mimeTypes[ext]; ok {
		return m
	}
	return "application/octet-stream"
}

func getUPnPClass(mediaType string) string {
	switch mediaType {
	case "video":
		return "object.item.videoItem"
	case "audio":
		return "object.item.audioItem.musicTrack"
	case "image":
		return "object.item.imageItem.photo"
	default:
		return "object.item"
	}
}

func (dm *DlnaManager) GetStatus() map[string]interface{} {
	files := dm.scanAllMedia()
	videoCount := 0
	audioCount := 0
	imageCount := 0
	for _, f := range files {
		switch f.MediaType {
		case "video":
			videoCount++
		case "audio":
			audioCount++
		case "image":
			imageCount++
		}
	}

	// 网络诊断
	localIP := getLocalIP()
	networkInfo := dm.diagnoseNetwork()

	return map[string]interface{}{
		"running":      dm.IsRunning(),
		"device_uuid":  dm.deviceUUID,
		"device_name":  "NAS私有云 - 媒体服务器",
		"media_count":  len(files),
		"video_count":  videoCount,
		"audio_count":  audioCount,
		"image_count":  imageCount,
		"port":         8200,
		"local_ip":     localIP,
		"ssdp_ok":      dm.ssdpOK,
		"ssdp_error":   dm.ssdpError,
		"network":      networkInfo,
		"manual_url":   fmt.Sprintf("http://%s:8200", localIP),
	}
}

// diagnoseNetwork 网络诊断
func (dm *DlnaManager) diagnoseNetwork() map[string]interface{} {
	info := make(map[string]interface{})

	// 检查网络接口
	ifaces, err := net.Interfaces()
	if err == nil {
		var ifaceNames []string
		for _, iface := range ifaces {
			if iface.Flags&net.FlagUp != 0 && iface.Flags&net.FlagLoopback == 0 {
				ifaceNames = append(ifaceNames, iface.Name)
			}
		}
		info["interfaces"] = ifaceNames
	}

	// 检查8200端口是否监听
	conn, err := net.DialTimeout("tcp", "127.0.0.1:8200", 2*time.Second)
	if err == nil {
		info["port_8200_listening"] = true
		conn.Close()
	} else {
		info["port_8200_listening"] = false
	}

	// 检查1900端口（SSDP）
	info["ssdp_port"] = 1900
	info["ssdp_multicast"] = "239.255.255.250"

	return info
}

// ===== HTTP API =====

func (h *NASHandler) handleDlnaStatus(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(h.dlnaMgr.GetStatus())
}

func (h *NASHandler) handleDlnaStart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if err := h.dlnaMgr.Start(); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleDlnaStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	h.dlnaMgr.Stop()
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleDlnaMediaList(w http.ResponseWriter, r *http.Request) {
	files := h.dlnaMgr.scanAllMedia()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"files": files,
		"count": len(files),
	})
}
