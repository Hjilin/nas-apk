package main

import (
	"os"
	"path/filepath"
	"strings"
)

// FileService 文件业务逻辑层
// 与HTTP handler解耦，方便未来编译成.so通过JNI调用
type FileService struct {
	rootDir string
}

// NewFileService 创建文件服务
func NewFileService(rootDir string) *FileService {
	return &FileService{rootDir: rootDir}
}

// FileInfo 文件信息
type FileInfo struct {
	Name    string `json:"name"`
	Path    string `json:"path"`
	Size    int64  `json:"size"`
	IsDir   bool   `json:"is_dir"`
	ModTime string `json:"mod_time"`
}

// ListFiles 列出目录文件
func (fs *FileService) ListFiles(dirPath string) ([]FileInfo, error) {
	fullPath := filepath.Join(fs.rootDir, dirPath)
	entries, err := os.ReadDir(fullPath)
	if err != nil {
		return nil, err
	}

	var files []FileInfo
	for _, entry := range entries {
		info, err := entry.Info()
		if err != nil {
			continue
		}
		relPath := filepath.Join(dirPath, entry.Name())
		files = append(files, FileInfo{
			Name:    entry.Name(),
			Path:    relPath,
			Size:    info.Size(),
			IsDir:   entry.IsDir(),
			ModTime: info.ModTime().Format("2006-01-02T15:04:05Z"),
		})
	}
	return files, nil
}

// CreateFolder 创建文件夹
func (fs *FileService) CreateFolder(dirPath string) error {
	fullPath := filepath.Join(fs.rootDir, dirPath)
	return os.MkdirAll(fullPath, 0755)
}

// DeleteFile 删除文件或文件夹
func (fs *FileService) DeleteFile(path string) error {
	fullPath := filepath.Join(fs.rootDir, path)
	return os.RemoveAll(fullPath)
}

// RenameFile 重命名
func (fs *FileService) RenameFile(oldPath, newName string) error {
	fullOldPath := filepath.Join(fs.rootDir, oldPath)
	dir := filepath.Dir(fullOldPath)
	fullNewPath := filepath.Join(dir, newName)
	return os.Rename(fullOldPath, fullNewPath)
}

// GetFileInfo 获取文件信息
func (fs *FileService) GetFileInfo(path string) (*FileInfo, error) {
	fullPath := filepath.Join(fs.rootDir, path)
	info, err := os.Stat(fullPath)
	if err != nil {
		return nil, err
	}
	return &FileInfo{
		Name:    info.Name(),
		Path:    path,
		Size:    info.Size(),
		IsDir:   info.IsDir(),
		ModTime: info.ModTime().Format("2006-01-02T15:04:05Z"),
	}, nil
}

// MediaService 媒体业务逻辑层
type MediaService struct {
	rootDir string
}

// NewMediaService 创建媒体服务
func NewMediaService(rootDir string) *MediaService {
	return &MediaService{rootDir: rootDir}
}

// ServiceMediaFile 媒体文件信息
type ServiceMediaFile struct {
	Name string `json:"name"`
	Path string `json:"path"`
	Size int64  `json:"size"`
	Type string `json:"type"` // video, audio, image
}

// ScanMedia 扫描媒体文件
func (ms *MediaService) ScanMedia(mediaType string) ([]ServiceMediaFile, error) {
	var files []ServiceMediaFile
	err := filepath.Walk(ms.rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if info.IsDir() {
			name := info.Name()
			if strings.HasPrefix(name, ".") || name == "Android" {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.HasPrefix(info.Name(), ".") {
			return nil
		}

		ext := strings.ToLower(filepath.Ext(path))
		relPath, _ := filepath.Rel(ms.rootDir, path)
		relPath = "/" + strings.ReplaceAll(relPath, "\\", "/")

		fileType := serviceGetMediaType(ext)
		if fileType == mediaType || mediaType == "all" {
			files = append(files, ServiceMediaFile{
				Name: info.Name(),
				Path: relPath,
				Size: info.Size(),
				Type: fileType,
			})
		}
		return nil
	})
	return files, err
}

// serviceGetMediaType 获取媒体类型
func serviceGetMediaType(ext string) string {
	videoExts := map[string]bool{
		".mp4": true, ".mkv": true, ".avi": true, ".mov": true, ".flv": true,
		".webm": true, ".m4v": true, ".ts": true,
	}
	audioExts := map[string]bool{
		".mp3": true, ".flac": true, ".wav": true, ".aac": true, ".ogg": true,
		".m4a": true, ".wma": true, ".ape": true, ".opus": true,
	}
	imageExts := map[string]bool{
		".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".webp": true,
		".bmp": true, ".heic": true, ".heif": true, ".avif": true, ".tiff": true,
	}

	if videoExts[ext] {
		return "video"
	}
	if audioExts[ext] {
		return "audio"
	}
	if imageExts[ext] {
		return "image"
	}
	return "other"
}
