package main

import (
	"archive/tar"
	"archive/zip"
	"compress/bzip2"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// 支持的压缩格式
var supportedFormats = map[string]bool{
	".zip":    true,
	".tar":    true,
	".tar.gz": true,
	".tgz":    true,
	".tar.bz2": true,
	".tbz2":   true,
	".gz":     true,
	".bz2":    true,
	".7z":     true,
	".rar":    true,
}

// CompressRequest 压缩请求
type CompressRequest struct {
	Files   []string `json:"files"`
	Target  string   `json:"target"`
	ZipName string   `json:"zip_name"`
	Format  string   `json:"format"` // zip, tar, tar.gz, tar.bz2
}

// ExtractRequest 解压请求
type ExtractRequest struct {
	File   string `json:"file"`
	Target string `json:"target"`
}

// handleCompress 压缩文件/文件夹
func (h *NASHandler) handleCompress(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	var req CompressRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "请求格式错误: " + err.Error(),
		})
		return
	}

	if len(req.Files) == 0 {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "请选择要压缩的文件",
		})
		return
	}

	format := req.Format
	if format == "" {
		format = "zip"
	}

	rootDir := h.cfg.Storage.RootDir

	// 确定压缩包名称和路径
	baseName := req.ZipName
	if baseName == "" {
		baseName = fmt.Sprintf("archive_%s", time.Now().Format("20060102_150405"))
	}

	var ext string
	switch format {
	case "zip":
		ext = ".zip"
	case "tar":
		ext = ".tar"
	case "tar.gz", "tgz":
		ext = ".tar.gz"
	case "tar.bz2", "tbz2":
		ext = ".tar.bz2"
	default:
		ext = ".zip"
		format = "zip"
	}

	zipName := baseName + ext
	targetDir := req.Target
	if targetDir == "" {
		targetDir = "/"
	}
	outPath := filepath.Join(rootDir, targetDir, zipName)

	var compressedCount int
	var totalSize int64
	var err error

	switch format {
	case "zip":
		compressedCount, totalSize, err = compressZip(rootDir, req.Files, outPath)
	case "tar":
		compressedCount, totalSize, err = compressTar(rootDir, req.Files, outPath, "")
	case "tar.gz", "tgz":
		compressedCount, totalSize, err = compressTar(rootDir, req.Files, outPath, "gz")
	case "tar.bz2", "tbz2":
		compressedCount, totalSize, err = compressTar(rootDir, req.Files, outPath, "bz2")
	}

	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "压缩失败: " + err.Error(),
		})
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success":  true,
		"message":  fmt.Sprintf("压缩完成，共 %d 个文件", compressedCount),
		"path":     filepath.ToSlash(filepath.Join(targetDir, zipName)),
		"format":   format,
		"count":    compressedCount,
		"size":     totalSize,
	})
}

// compressZip zip压缩
func compressZip(rootDir string, files []string, outPath string) (int, int64, error) {
	zipFile, err := os.Create(outPath)
	if err != nil {
		return 0, 0, err
	}
	defer zipFile.Close()

	zw := zip.NewWriter(zipFile)
	defer zw.Close()

	count := 0
	totalSize := int64(0)

	for _, relPath := range files {
		fullPath := filepath.Join(rootDir, relPath)
		info, err := os.Stat(fullPath)
		if err != nil {
			continue
		}

		if info.IsDir() {
			filepath.Walk(fullPath, func(path string, fi os.FileInfo, err error) error {
				if err != nil || fi.IsDir() {
					return nil
				}
				rel, _ := filepath.Rel(rootDir, path)
				addFileToZip(zw, path, filepath.ToSlash(rel))
				count++
				totalSize += fi.Size()
				return nil
			})
		} else {
			rel, _ := filepath.Rel(rootDir, fullPath)
			addFileToZip(zw, fullPath, filepath.ToSlash(rel))
			count++
			totalSize += info.Size()
		}
	}
	return count, totalSize, nil
}

// compressTar tar压缩（支持gz/bz2）
func compressTar(rootDir string, files []string, outPath string, compression string) (int, int64, error) {
	outFile, err := os.Create(outPath)
	if err != nil {
		return 0, 0, err
	}
	defer outFile.Close()

	var writer io.WriteCloser = outFile

	if compression == "gz" {
		gzWriter := gzip.NewWriter(outFile)
		defer gzWriter.Close()
		writer = gzWriter
	} else if compression == "bz2" {
		// Go标准库没有bzip2 writer，用外部命令
		return compressTarExternal(rootDir, files, outPath, compression)
	}

	tw := tar.NewWriter(writer)
	defer tw.Close()

	count := 0
	totalSize := int64(0)

	for _, relPath := range files {
		fullPath := filepath.Join(rootDir, relPath)
		info, err := os.Stat(fullPath)
		if err != nil {
			continue
		}

		if info.IsDir() {
			filepath.Walk(fullPath, func(path string, fi os.FileInfo, err error) error {
				if err != nil {
					return nil
				}
				rel, _ := filepath.Rel(rootDir, path)
				if fi.IsDir() {
					tw.WriteHeader(&tar.Header{
						Name:     filepath.ToSlash(rel) + "/",
						Mode:     int64(fi.Mode()),
						ModTime:  fi.ModTime(),
					})
					return nil
				}
				if addFileToTar(tw, path, filepath.ToSlash(rel), fi) == nil {
					count++
					totalSize += fi.Size()
				}
				return nil
			})
		} else {
			rel, _ := filepath.Rel(rootDir, fullPath)
			if addFileToTar(tw, fullPath, filepath.ToSlash(rel), info) == nil {
				count++
				totalSize += info.Size()
			}
		}
	}
	return count, totalSize, nil
}

// compressTarExternal 用外部tar命令压缩（bz2等）
func compressTarExternal(rootDir string, files []string, outPath string, compression string) (int, int64, error) {
	// 创建临时文件列表
	listFile, err := os.CreateTemp("", "tar-list-*.txt")
	if err != nil {
		return 0, 0, err
	}
	defer os.Remove(listFile.Name())

	for _, f := range files {
		listFile.WriteString(f + "\n")
	}
	listFile.Close()

	var cmd *exec.Cmd
	if compression == "bz2" {
		cmd = exec.Command("tar", "-cjf", outPath, "-C", rootDir, "-T", listFile.Name())
	} else {
		cmd = exec.Command("tar", "-cf", outPath, "-C", rootDir, "-T", listFile.Name())
	}

	output, err := cmd.CombinedOutput()
	if err != nil {
		return 0, 0, fmt.Errorf("%s: %s", err.Error(), string(output))
	}

	// 统计文件数
	count := len(files)
	return count, 0, nil
}

// addFileToTar 添加文件到tar
func addFileToTar(tw *tar.Writer, filePath, tarPath string, info os.FileInfo) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	header := &tar.Header{
		Name:    tarPath,
		Size:    info.Size(),
		Mode:    int64(info.Mode()),
		ModTime: info.ModTime(),
	}

	if err := tw.WriteHeader(header); err != nil {
		return err
	}
	_, err = io.Copy(tw, file)
	return err
}

// handleExtract 解压文件
func (h *NASHandler) handleExtract(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	var req ExtractRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "请求格式错误: " + err.Error(),
		})
		return
	}

	if req.File == "" {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "请选择要解压的文件",
		})
		return
	}

	rootDir := h.cfg.Storage.RootDir
	filePath := filepath.Join(rootDir, req.File)

	if _, err := os.Stat(filePath); err != nil {
		w.WriteHeader(http.StatusNotFound)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "文件不存在: " + req.File,
		})
		return
	}

	// 确定解压目标目录
	targetDir := req.Target
	if targetDir == "" {
		baseName := strings.TrimSuffix(filepath.Base(req.File), filepath.Ext(req.File))
		// 处理.tar.gz等双重扩展名
		baseName = strings.TrimSuffix(baseName, ".tar")
		targetDir = filepath.Join(filepath.Dir(req.File), baseName)
	}
	extractPath := filepath.Join(rootDir, targetDir)

	if err := os.MkdirAll(extractPath, 0755); err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "创建目标目录失败: " + err.Error(),
		})
		return
	}

	// 根据扩展名选择解压方式
	lowerName := strings.ToLower(req.File)
	var count int
	var totalSize int64
	var err error

	switch {
	case strings.HasSuffix(lowerName, ".zip"):
		count, totalSize, err = extractZip(filePath, extractPath)
	case strings.HasSuffix(lowerName, ".tar.gz"), strings.HasSuffix(lowerName, ".tgz"):
		count, totalSize, err = extractTar(filePath, extractPath, "gz")
	case strings.HasSuffix(lowerName, ".tar.bz2"), strings.HasSuffix(lowerName, ".tbz2"):
		count, totalSize, err = extractTar(filePath, extractPath, "bz2")
	case strings.HasSuffix(lowerName, ".tar"):
		count, totalSize, err = extractTar(filePath, extractPath, "")
	case strings.HasSuffix(lowerName, ".gz"):
		count, totalSize, err = extractGzip(filePath, extractPath)
	case strings.HasSuffix(lowerName, ".bz2"):
		count, totalSize, err = extractBzip2(filePath, extractPath)
	case strings.HasSuffix(lowerName, ".7z"):
		count, totalSize, err = extract7z(filePath, extractPath)
	case strings.HasSuffix(lowerName, ".rar"):
		count, totalSize, err = extractRar(filePath, extractPath)
	default:
		err = fmt.Errorf("不支持的压缩格式")
	}

	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "解压失败: " + err.Error(),
		})
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": fmt.Sprintf("解压完成，共 %d 个文件", count),
		"target":  filepath.ToSlash(targetDir),
		"count":   count,
		"size":    totalSize,
	})
}

// extractZip 解压zip
func extractZip(zipPath, destDir string) (int, int64, error) {
	reader, err := zip.OpenReader(zipPath)
	if err != nil {
		return 0, 0, err
	}
	defer reader.Close()

	count := 0
	totalSize := int64(0)

	for _, f := range reader.File {
		if strings.Contains(f.Name, "..") {
			continue
		}
		targetPath := filepath.Join(destDir, f.Name)

		if f.FileInfo().IsDir() {
			os.MkdirAll(targetPath, 0755)
			continue
		}

		os.MkdirAll(filepath.Dir(targetPath), 0755)

		outFile, err := os.OpenFile(targetPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, f.Mode())
		if err != nil {
			continue
		}

		rc, err := f.Open()
		if err != nil {
			outFile.Close()
			continue
		}

		size, err := io.Copy(outFile, rc)
		rc.Close()
		outFile.Close()

		if err == nil {
			count++
			totalSize += size
		}
	}
	return count, totalSize, nil
}

// extractTar 解压tar（支持gz/bz2）
func extractTar(tarPath, destDir string, compression string) (int, int64, error) {
	file, err := os.Open(tarPath)
	if err != nil {
		return 0, 0, err
	}
	defer file.Close()

	var reader io.Reader = file

	if compression == "gz" {
		gzReader, err := gzip.NewReader(file)
		if err != nil {
			return 0, 0, err
		}
		defer gzReader.Close()
		reader = gzReader
	} else if compression == "bz2" {
		reader = bzip2.NewReader(file)
	}

	tr := tar.NewReader(reader)
	count := 0
	totalSize := int64(0)

	for {
		header, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			break
		}

		if strings.Contains(header.Name, "..") {
			continue
		}

		targetPath := filepath.Join(destDir, header.Name)

		if header.Typeflag == tar.TypeDir {
			os.MkdirAll(targetPath, 0755)
			continue
		}

		os.MkdirAll(filepath.Dir(targetPath), 0755)

		outFile, err := os.Create(targetPath)
		if err != nil {
			continue
		}

		size, err := io.Copy(outFile, tr)
		outFile.Close()

		if err == nil {
			count++
			totalSize += size
		}
	}
	return count, totalSize, nil
}

// extractGzip 解压单个gz文件
func extractGzip(gzPath, destDir string) (int, int64, error) {
	file, err := os.Open(gzPath)
	if err != nil {
		return 0, 0, err
	}
	defer file.Close()

	gzReader, err := gzip.NewReader(file)
	if err != nil {
		return 0, 0, err
	}
	defer gzReader.Close()

	outName := strings.TrimSuffix(filepath.Base(gzPath), ".gz")
	outPath := filepath.Join(destDir, outName)

	outFile, err := os.Create(outPath)
	if err != nil {
		return 0, 0, err
	}
	defer outFile.Close()

	size, err := io.Copy(outFile, gzReader)
	if err != nil {
		return 0, 0, err
	}
	return 1, size, nil
}

// extractBzip2 解压单个bz2文件
func extractBzip2(bz2Path, destDir string) (int, int64, error) {
	file, err := os.Open(bz2Path)
	if err != nil {
		return 0, 0, err
	}
	defer file.Close()

	bzReader := bzip2.NewReader(file)

	outName := strings.TrimSuffix(filepath.Base(bz2Path), ".bz2")
	outPath := filepath.Join(destDir, outName)

	outFile, err := os.Create(outPath)
	if err != nil {
		return 0, 0, err
	}
	defer outFile.Close()

	size, err := io.Copy(outFile, bzReader)
	if err != nil {
		return 0, 0, err
	}
	return 1, size, nil
}

// extract7z 解压7z（调用外部7z命令）
func extract7z(archivePath, destDir string) (int, int64, error) {
	cmd := exec.Command("7z", "x", archivePath, "-o"+destDir, "-y")
	output, err := cmd.CombinedOutput()
	if err != nil {
		return 0, 0, fmt.Errorf("7z解压失败（请先安装p7zip）: %s, %s", err.Error(), string(output))
	}
	return 1, 0, nil
}

// extractRar 解压rar（调用外部unrar命令）
func extractRar(archivePath, destDir string) (int, int64, error) {
	cmd := exec.Command("unrar", "x", "-y", archivePath, destDir+"/")
	output, err := cmd.CombinedOutput()
	if err != nil {
		return 0, 0, fmt.Errorf("rar解压失败（请先安装unrar）: %s, %s", err.Error(), string(output))
	}
	return 1, 0, nil
}

// handleListArchive 列出压缩包内容
func (h *NASHandler) handleListZip(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	archiveFile := r.URL.Query().Get("file")
	if archiveFile == "" {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "请指定压缩包路径",
		})
		return
	}

	rootDir := h.cfg.Storage.RootDir
	fullPath := filepath.Join(rootDir, archiveFile)

	lowerName := strings.ToLower(archiveFile)
	var files []map[string]interface{}

	switch {
	case strings.HasSuffix(lowerName, ".zip"):
		reader, err := zip.OpenReader(fullPath)
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "打开压缩包失败: " + err.Error(),
			})
			return
		}
		defer reader.Close()

		for _, f := range reader.File {
			files = append(files, map[string]interface{}{
				"name":     f.Name,
				"size":     f.UncompressedSize64,
				"is_dir":   f.FileInfo().IsDir(),
				"modified": f.Modified.Format("2006-01-02 15:04:05"),
			})
		}
	default:
		// 其他格式用外部命令列出
		cmd := exec.Command("tar", "-tf", fullPath)
		output, err := cmd.Output()
		if err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "不支持的格式或打开失败: " + err.Error(),
			})
			return
		}
		for _, line := range strings.Split(string(output), "\n") {
			if line != "" {
				files = append(files, map[string]interface{}{
					"name":   line,
					"is_dir": strings.HasSuffix(line, "/"),
				})
			}
		}
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"files":   files,
		"count":   len(files),
	})
}

// handleSupportedFormats 获取支持的格式
func (h *NASHandler) handleSupportedFormats(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"compress": []string{"zip", "tar", "tar.gz", "tar.bz2"},
		"extract":  []string{".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".gz", ".bz2", ".7z", ".rar"},
		"note":     "7z/rar需要安装p7zip/unrar工具",
	})
}
