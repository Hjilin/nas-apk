package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// LogEntry 结构化日志条目
type LogEntry struct {
	Time     string      `json:"time"`
	Level    string      `json:"level"`
	Module   string      `json:"module"`
	Action   string      `json:"action"`
	Message  string      `json:"message"`
	User     string      `json:"user,omitempty"`
	IP       string      `json:"ip,omitempty"`
	Duration string      `json:"duration,omitempty"`
	Data     interface{} `json:"data,omitempty"`
}

// Logger 日志封装
type Logger struct {
	level     int
	file      *os.File
	logger    *log.Logger
	logPath   string
	maxSize   int64
	maxDays   int
	mu        sync.Mutex
	entries   []LogEntry
	maxMemory int
}

const (
	levelDebug = 0
	levelInfo  = 1
	levelWarn  = 2
	levelError = 3
)

// NewLogger 创建日志器
func NewLogger(cfg *LogConfig) (*Logger, error) {
	l := &Logger{
		maxSize:   int64(cfg.MaxSize) * 1024 * 1024,
		maxDays:   cfg.MaxDays,
		logPath:   cfg.File,
		maxMemory: 1000,
	}

	switch cfg.Level {
	case "debug":
		l.level = levelDebug
	case "warn":
		l.level = levelWarn
	case "error":
		l.level = levelError
	default:
		l.level = levelInfo
	}

	if cfg.File != "" {
		if err := os.MkdirAll(filepath.Dir(cfg.File), 0755); err != nil {
			return nil, fmt.Errorf("创建日志目录失败: %w", err)
		}
		f, err := os.OpenFile(cfg.File, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
		if err != nil {
			return nil, fmt.Errorf("打开日志文件失败: %w", err)
		}
		l.file = f
		l.logger = log.New(f, "", 0)
	} else {
		l.logger = log.New(os.Stdout, "", 0)
	}

	l.Info("system", "startup", "日志系统初始化完成")
	return l, nil
}

// writeLog 写入日志（内部方法）
func (l *Logger) writeLog(level int, module, action, msg string) {
	levelStr := []string{"DEBUG", "INFO", "WARN", "ERROR"}[level]
	now := time.Now().Format("2006-01-02 15:04:05")

	entry := LogEntry{
		Time:    now,
		Level:   levelStr,
		Module:  module,
		Action:  action,
		Message: msg,
	}

	jsonData, _ := json.Marshal(entry)
	l.logger.Println(string(jsonData))

	l.mu.Lock()
	l.entries = append(l.entries, entry)
	if len(l.entries) > l.maxMemory {
		l.entries = l.entries[len(l.entries)-l.maxMemory:]
	}
	l.mu.Unlock()

	if l.file != nil {
		l.rotateIfNeeded()
	}
}

// 智能解析调用：兼容旧格式(format, args)和新格式(module, action, format, args)
func (l *Logger) logSmart(level int, args ...interface{}) {
	if level < l.level {
		return
	}

	if len(args) == 0 {
		return
	}

	module := "general"
	action := "log"
	format := ""
	var fmtArgs []interface{}

	// 判断是否是新格式：前两个参数都是字符串
	if len(args) >= 3 {
		if m, ok := args[0].(string); ok {
			if a, ok := args[1].(string); ok {
				if f, ok := args[2].(string); ok {
					module = m
					action = a
					format = f
					fmtArgs = args[3:]
				}
			}
		}
	}

	// 旧格式：第一个参数是 format
	if format == "" && len(args) >= 1 {
		if f, ok := args[0].(string); ok {
			format = f
			fmtArgs = args[1:]
		}
	}

	msg := fmt.Sprintf(format, fmtArgs...)
	l.writeLog(level, module, action, msg)
}

// 兼容旧接口的方法
func (l *Logger) Debug(args ...interface{}) { l.logSmart(levelDebug, args...) }
func (l *Logger) Info(args ...interface{})  { l.logSmart(levelInfo, args...) }
func (l *Logger) Warn(args ...interface{})  { l.logSmart(levelWarn, args...) }
func (l *Logger) Error(args ...interface{}) { l.logSmart(levelError, args...) }

// UserInfo 带用户信息的日志
func (l *Logger) UserInfo(module, action, user, ip, format string, args ...interface{}) {
	if levelInfo < l.level {
		return
	}
	msg := fmt.Sprintf(format, args...)
	now := time.Now().Format("2006-01-02 15:04:05")
	entry := LogEntry{Time: now, Level: "INFO", Module: module, Action: action, Message: msg, User: user, IP: ip}
	jsonData, _ := json.Marshal(entry)
	l.logger.Println(string(jsonData))
	l.mu.Lock()
	l.entries = append(l.entries, entry)
	if len(l.entries) > l.maxMemory {
		l.entries = l.entries[len(l.entries)-l.maxMemory:]
	}
	l.mu.Unlock()
}

// GetLogs 查询日志
func (l *Logger) GetLogs(level, module string, limit int, keyword string) []LogEntry {
	l.mu.Lock()
	defer l.mu.Unlock()

	var result []LogEntry
	for i := len(l.entries) - 1; i >= 0; i-- {
		entry := l.entries[i]
		if level != "" && level != "all" && entry.Level != level {
			continue
		}
		if module != "" && module != "all" && entry.Module != module {
			continue
		}
		if keyword != "" && !strings.Contains(strings.ToLower(entry.Message+entry.Action+entry.Module), strings.ToLower(keyword)) {
			continue
		}
		result = append(result, entry)
		if len(result) >= limit {
			break
		}
	}
	return result
}

// GetLogStats 获取日志统计
func (l *Logger) GetLogStats() map[string]interface{} {
	l.mu.Lock()
	defer l.mu.Unlock()

	stats := map[string]int{"DEBUG": 0, "INFO": 0, "WARN": 0, "ERROR": 0}
	modules := make(map[string]int)
	for _, e := range l.entries {
		stats[e.Level]++
		modules[e.Module]++
	}
	return map[string]interface{}{"total": len(l.entries), "levels": stats, "modules": modules}
}

// GetModules 获取所有模块
func (l *Logger) GetModules() []string {
	l.mu.Lock()
	defer l.mu.Unlock()
	moduleSet := make(map[string]bool)
	for _, e := range l.entries {
		moduleSet[e.Module] = true
	}
	var modules []string
	for m := range moduleSet {
		modules = append(modules, m)
	}
	return modules
}

// ClearLogs 清空内存日志
func (l *Logger) ClearLogs() {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.entries = []LogEntry{}
}

// rotateIfNeeded 日志轮转
func (l *Logger) rotateIfNeeded() {
	info, err := l.file.Stat()
	if err != nil || info.Size() < l.maxSize {
		return
	}
	l.file.Close()
	backup := l.logPath + "." + time.Now().Format("20060102-150405")
	os.Rename(l.logPath, backup)
	l.cleanupOldLogs()
	f, err := os.OpenFile(l.logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err == nil {
		l.file = f
		l.logger.SetOutput(f)
	}
}

// cleanupOldLogs 清理过期日志
func (l *Logger) cleanupOldLogs() {
	dir := filepath.Dir(l.logPath)
	base := filepath.Base(l.logPath)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	cutoff := time.Now().AddDate(0, 0, -l.maxDays)
	for _, e := range entries {
		if !e.IsDir() && len(e.Name()) > len(base) && e.Name()[:len(base)] == base {
			info, err := e.Info()
			if err == nil && info.ModTime().Before(cutoff) {
				os.Remove(filepath.Join(dir, e.Name()))
			}
		}
	}
}

// Close 关闭日志文件
func (l *Logger) Close() {
	if l.file != nil {
		l.file.Close()
	}
}
