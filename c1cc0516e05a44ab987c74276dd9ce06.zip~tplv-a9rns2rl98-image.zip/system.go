package main

import (
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

// SystemMonitor 系统监控器
type SystemMonitor struct {
	lastCPUTotal uint64
	lastCPUIdle  uint64
	lastNetRx    uint64
	lastNetTx    uint64
	lastTime     time.Time
	mu           sync.Mutex
}

// NewSystemMonitor 创建系统监控器
func NewSystemMonitor() *SystemMonitor {
	sm := &SystemMonitor{
		lastTime: time.Now(),
	}
	// 初始化时读取CPU基线数据
	sm.readCPUBaseline()
	return sm
}

// readCPUBaseline 读取CPU基线数据
func (sm *SystemMonitor) readCPUBaseline() {
	// 读取/proc/stat基线数据
	if data, err := os.ReadFile("/proc/stat"); err == nil {
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, "cpu ") {
				parts := strings.Fields(line)
				if len(parts) >= 5 {
					var total, idle uint64
					for i := 1; i < len(parts); i++ {
						val, _ := strconv.ParseUint(parts[i], 10, 64)
						total += val
					}
					idle, _ = strconv.ParseUint(parts[4], 10, 64)
					if len(parts) >= 6 {
						iowait, _ := strconv.ParseUint(parts[5], 10, 64)
						idle += iowait
					}
					sm.lastCPUTotal = total
					sm.lastCPUIdle = idle
				}
				break
			}
		}
	}
}

// SystemInfo 系统信息
type SystemInfo struct {
	CPU       CPUInfo       `json:"cpu"`
	Memory    MemoryInfo    `json:"memory"`
	Storage   StorageInfo   `json:"storage"`
	Network   NetworkInfo   `json:"network"`
	Uptime    string        `json:"uptime"`
	Timestamp int64         `json:"timestamp"`
	Processes []ProcessInfo `json:"processes"`
}

// CPUInfo CPU信息
type CPUInfo struct {
	Usage    float64 `json:"usage"`
	Cores    int     `json:"cores"`
	Model    string  `json:"model"`
	LoadAvg  string  `json:"load_avg"`
}

// MemoryInfo 内存信息
type MemoryInfo struct {
	Total     uint64  `json:"total"`
	Used      uint64  `json:"used"`
	Free      uint64  `json:"free"`
	Available uint64  `json:"available"`
	Usage     float64 `json:"usage"`
	SwapTotal uint64  `json:"swap_total"`
	SwapUsed  uint64  `json:"swap_used"`
}

// StorageInfo 存储信息
type StorageInfo struct {
	Total uint64  `json:"total"`
	Used  uint64  `json:"used"`
	Free  uint64  `json:"free"`
	Usage float64 `json:"usage"`
	Path  string  `json:"path"`
}

// NetworkInfo 网络信息
type NetworkInfo struct {
	Interfaces []NetInterface `json:"interfaces"`
	Connected  bool           `json:"connected"`
}

// NetInterface 网络接口
type NetInterface struct {
	Name      string `json:"name"`
	IP        string `json:"ip"`
	MTU       int    `json:"mtu"`
	Up        bool   `json:"up"`
}

// ProcessInfo 进程信息
type ProcessInfo struct {
	PID    int     `json:"pid"`
	Name   string  `json:"name"`
	CPU    float64 `json:"cpu"`
	Memory uint64  `json:"memory"`
	Status string  `json:"status"`
}

// GetSystemInfo 获取系统信息
func (sm *SystemMonitor) GetSystemInfo() *SystemInfo {
	sm.mu.Lock()
	defer sm.mu.Unlock()

	info := &SystemInfo{
		Timestamp: time.Now().Unix(),
	}

	// CPU
	info.CPU = sm.getCPUInfo()

	// 内存
	info.Memory = sm.getMemoryInfo()

	// 存储
	info.Storage = sm.getStorageInfo()

	// 网络
	info.Network = sm.getNetworkInfo()

	// 运行时间
	info.Uptime = sm.getUptime()

	// 进程
	info.Processes = sm.getProcesses()

	return info
}

// getCPUInfo 获取CPU信息
func (sm *SystemMonitor) getCPUInfo() CPUInfo {
	info := CPUInfo{Cores: runtime.NumCPU()}

	// 读取CPU型号
	if data, err := os.ReadFile("/proc/cpuinfo"); err == nil {
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, "Hardware") || strings.HasPrefix(line, "model name") {
				parts := strings.SplitN(line, ":", 2)
				if len(parts) == 2 {
					info.Model = strings.TrimSpace(parts[1])
					break
				}
			}
		}
	}

	// 用 /proc/stat 获取 CPU 使用率（稳定可靠，Android兼容）
	info.Usage = sm.getCPUUsageFromProc()

	return info
}

// getCPUUsageFromProc 用/proc/stat获取CPU使用率
func (sm *SystemMonitor) getCPUUsageFromProc() float64 {
	data, err := os.ReadFile("/proc/stat")
	if err != nil {
		return 0
	}

	var currentTotal, currentIdle uint64
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "cpu ") {
			parts := strings.Fields(line)
			if len(parts) < 5 {
				continue
			}
			for i := 1; i < len(parts); i++ {
				val, _ := strconv.ParseUint(parts[i], 10, 64)
				currentTotal += val
			}
			currentIdle, _ = strconv.ParseUint(parts[4], 10, 64)
			if len(parts) >= 6 {
				iowait, _ := strconv.ParseUint(parts[5], 10, 64)
				currentIdle += iowait
			}
			break
		}
	}

	if currentTotal == 0 || sm.lastCPUTotal == 0 {
		sm.lastCPUTotal = currentTotal
		sm.lastCPUIdle = currentIdle
		return 0
	}

	totalDiff := currentTotal - sm.lastCPUTotal
	idleDiff := currentIdle - sm.lastCPUIdle

	sm.lastCPUTotal = currentTotal
	sm.lastCPUIdle = currentIdle

	if totalDiff <= 0 {
		return 0
	}

	usage := (float64(totalDiff-idleDiff) / float64(totalDiff)) * 100
	if usage < 0 {
		usage = 0
	}
	if usage > 100 {
		usage = 100
	}
	return usage
}

// getMemoryInfo 获取内存信息
func (sm *SystemMonitor) getMemoryInfo() MemoryInfo {
	info := MemoryInfo{}

	if data, err := os.ReadFile("/proc/meminfo"); err == nil {
		for _, line := range strings.Split(string(data), "\n") {
			fields := strings.Fields(line)
			if len(fields) < 2 {
				continue
			}
			val, _ := strconv.ParseUint(fields[1], 10, 64)
			val *= 1024 // KB to bytes

			switch fields[0] {
			case "MemTotal:":
				info.Total = val
			case "MemFree:":
				info.Free = val
			case "MemAvailable:":
				info.Available = val
			case "SwapTotal:":
				info.SwapTotal = val
			case "SwapFree:":
				info.SwapUsed = info.SwapTotal - val
			}
		}
	}

	if info.Total > 0 {
		info.Used = info.Total - info.Available
		info.Usage = float64(info.Used) / float64(info.Total) * 100
	}

	return info
}

// getStorageInfo 获取存储信息
func (sm *SystemMonitor) getStorageInfo() StorageInfo {
	info := StorageInfo{Path: "/data"}

	// 使用 syscall.Statfs 获取存储信息
	var stat syscall.Statfs_t
	if err := syscall.Statfs(info.Path, &stat); err == nil {
		info.Total = stat.Blocks * uint64(stat.Bsize)
		info.Free = stat.Bfree * uint64(stat.Bsize)
		info.Used = info.Total - info.Free
		if info.Total > 0 {
			info.Usage = float64(info.Used) / float64(info.Total) * 100
		}
	}

	return info
}

// getNetworkInfo 获取网络信息
func (sm *SystemMonitor) getNetworkInfo() NetworkInfo {
	info := NetworkInfo{}

	ifaces, err := net.Interfaces()
	if err != nil {
		return info
	}

	for _, iface := range ifaces {
		if iface.Name == "lo" {
			continue
		}
		ni := NetInterface{
			Name: iface.Name,
			MTU:  iface.MTU,
			Up:   iface.Flags&net.FlagUp != 0,
		}

		// 获取 IP 地址
		addrs, err := iface.Addrs()
		if err == nil && len(addrs) > 0 {
			for _, addr := range addrs {
				if ipNet, ok := addr.(*net.IPNet); ok {
					if ipNet.IP.To4() != nil {
						ni.IP = ipNet.IP.String()
						break
					}
				}
			}
		}

		if ni.Up {
			info.Connected = true
		}
		info.Interfaces = append(info.Interfaces, ni)
	}

	return info
}

// getUptime 获取运行时间
func (sm *SystemMonitor) getUptime() string {
	// 方式1：读取 /proc/uptime
	if data, err := os.ReadFile("/proc/uptime"); err == nil {
		fields := strings.Fields(string(data))
		if len(fields) >= 1 {
			seconds, err := strconv.ParseFloat(fields[0], 64)
			if err == nil && seconds > 0 {
				return formatUptime(seconds)
			}
		}
	}
	// 方式2：用 uptime 命令
	if output, err := exec.Command("uptime").Output(); err == nil {
		line := string(output)
		// 解析 "up 1 day, 2:30" 格式
		if idx := strings.Index(line, "up "); idx >= 0 {
			rest := line[idx+3:]
			if commaIdx := strings.Index(rest, ","); commaIdx > 0 {
				return "运行 " + rest[:commaIdx]
			}
		}
	}
	return "运行中"
}

func formatUptime(seconds float64) string {
	days := int(seconds) / 86400
	hours := (int(seconds) % 86400) / 3600
	minutes := (int(seconds) % 3600) / 60
	if days > 0 {
		return fmt.Sprintf("%d天 %d小时 %d分钟", days, hours, minutes)
	}
	return fmt.Sprintf("%d小时 %d分钟", hours, minutes)
}

// getProcesses 获取进程列表
func (sm *SystemMonitor) getProcesses() []ProcessInfo {
	var processes []ProcessInfo

	entries, err := os.ReadDir("/proc")
	if err != nil {
		return processes
	}

	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		pid, err := strconv.Atoi(entry.Name())
		if err != nil {
			continue
		}

		proc := ProcessInfo{PID: pid}

		// 读取进程状态
		if data, err := os.ReadFile(filepath.Join("/proc", entry.Name(), "status")); err == nil {
			for _, line := range strings.Split(string(data), "\n") {
				fields := strings.Fields(line)
				if len(fields) < 2 {
					continue
				}
				switch fields[0] {
				case "Name:":
					proc.Name = fields[1]
				case "State:":
					proc.Status = fields[1]
				case "VmRSS:":
					val, _ := strconv.ParseUint(fields[1], 10, 64)
					proc.Memory = val * 1024
				}
			}
		}

		// 读取CPU使用率
		if data, err := os.ReadFile(filepath.Join("/proc", entry.Name(), "stat")); err == nil {
			fields := strings.Fields(string(data))
			if len(fields) >= 15 {
				utime, _ := strconv.ParseUint(fields[13], 10, 64)
				stime, _ := strconv.ParseUint(fields[14], 10, 64)
				proc.CPU = float64(utime+stime) / 100 // 简化计算
			}
		}

		if proc.Name != "" {
			processes = append(processes, proc)
		}
	}

	// 按内存排序，取前20
	sort.Slice(processes, func(i, j int) bool {
		return processes[i].Memory > processes[j].Memory
	})
	if len(processes) > 20 {
		processes = processes[:20]
	}

	return processes
}

// HandleSystemInfo 处理系统信息请求
func (sm *SystemMonitor) HandleSystemInfo(w http.ResponseWriter, r *http.Request) {
	info := sm.GetSystemInfo()
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(info)
}
