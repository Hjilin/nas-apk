package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// NetworkStatus 组网状态
type NetworkStatus struct {
	Provider   string   `json:"provider"`
	Connected  bool     `json:"connected"`
	DeviceName string   `json:"device_name"`
	DeviceIP   string   `json:"device_ip"`
	NetworkID  string   `json:"network_id"`
	Peers      []Peer   `json:"peers"`
	LastCheck  string   `json:"last_check"`
	Error      string   `json:"error,omitempty"`
}

// Peer 组网中的其他设备
type Peer struct {
	Name     string `json:"name"`
	IP       string `json:"ip"`
	OS       string `json:"os"`
	Online   bool   `json:"online"`
	LastSeen string `json:"last_seen"`
}

// NetworkManager 组网管理器
type NetworkManager struct {
	cfg      *NetworkConfig
	logger   *Logger
	mu       sync.Mutex
	status   *NetworkStatus
	lastPoll time.Time
}

// NewNetworkManager 创建组网管理器
func NewNetworkManager(cfg *NetworkConfig, logger *Logger) *NetworkManager {
	nm := &NetworkManager{
		cfg:    cfg,
		logger: logger,
		status: &NetworkStatus{
			Provider:   cfg.Provider,
			DeviceName: cfg.DeviceName,
		},
	}
	// 如果配置了自动加入，启动时尝试加入
	if cfg.AutoJoin && cfg.AuthKey != "" {
		go nm.Join(cfg.AuthKey)
	}
	return nm
}

// Join 加入组网（自助接入）
func (nm *NetworkManager) Join(authKey string) (*NetworkStatus, error) {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	nm.logger.Info("尝试加入组网: provider=%s", nm.cfg.Provider)

	switch nm.cfg.Provider {
	case "tailscale":
		return nm.joinTailscale(authKey)
	case "zerotier":
		return nm.joinZeroTier(authKey)
	case "n2n":
		return nm.joinN2N(authKey)
	case "custom":
		return nm.joinCustom(authKey)
	default:
		return nil, fmt.Errorf("不支持的组网服务商: %s", nm.cfg.Provider)
	}
}

// joinTailscale 加入 Tailscale 网络
func (nm *NetworkManager) joinTailscale(authKey string) (*NetworkStatus, error) {
	// 检查 tailscale 是否安装
	if _, err := exec.LookPath("tailscale"); err != nil {
		nm.status.Error = "tailscale 未安装，请先执行: pkg install tailscale"
		return nm.status, fmt.Errorf("tailscale 未安装")
	}

	// 启动 tailscaled（如果未运行）
	exec.Command("tailscaled", "--tun=userspace-networking").Start()
	time.Sleep(2 * time.Second)

	// 使用 auth key 登录
	cmd := exec.Command("tailscale", "up", "--authkey="+authKey, "--hostname="+nm.cfg.DeviceName)
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		nm.status.Error = fmt.Sprintf("加入失败: %v, %s", err, stderr.String())
		nm.logger.Error("Tailscale 加入失败: %v", err)
		return nm.status, err
	}

	// 获取状态
	status, err := nm.getTailscaleStatus()
	if err != nil {
		nm.status.Error = err.Error()
		return nm.status, err
	}

	nm.status = status
	nm.status.Connected = true
	nm.status.LastCheck = time.Now().Format("2006-01-02 15:04:05")
	nm.logger.Info("Tailscale 加入成功，IP: %s", status.DeviceIP)
	return nm.status, nil
}

// getTailscaleStatus 获取 Tailscale 状态
func (nm *NetworkManager) getTailscaleStatus() (*NetworkStatus, error) {
	cmd := exec.Command("tailscale", "status", "--json")
	output, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("获取状态失败: %v", err)
	}

	var tsStatus struct {
		Self struct {
			HostName string `json:"HostName"`
			TailscaleIPs []string `json:"TailscaleIPs"`
		} `json:"Self"`
		Peer map[string]struct {
			HostName string `json:"HostName"`
			TailscaleIPs []string `json:"TailscaleIPs"`
			OS string `json:"OS"`
			Online bool `json:"Online"`
			LastSeen string `json:"LastSeen"`
		} `json:"Peer"`
	}

	if err := json.Unmarshal(output, &tsStatus); err != nil {
		return nil, err
	}

	status := &NetworkStatus{
		Provider:   "tailscale",
		Connected:  true,
		DeviceName: tsStatus.Self.HostName,
		LastCheck:  time.Now().Format("2006-01-02 15:04:05"),
	}
	if len(tsStatus.Self.TailscaleIPs) > 0 {
		status.DeviceIP = tsStatus.Self.TailscaleIPs[0]
	}

	for _, peer := range tsStatus.Peer {
		ip := ""
		if len(peer.TailscaleIPs) > 0 {
			ip = peer.TailscaleIPs[0]
		}
		status.Peers = append(status.Peers, Peer{
			Name:     peer.HostName,
			IP:       ip,
			OS:       peer.OS,
			Online:   peer.Online,
			LastSeen: peer.LastSeen,
		})
	}

	return status, nil
}

// joinZeroTier 加入 ZeroTier 网络
func (nm *NetworkManager) joinZeroTier(networkID string) (*NetworkStatus, error) {
	if _, err := exec.LookPath("zerotier-cli"); err != nil {
		nm.status.Error = "zerotier-cli 未安装"
		return nm.status, fmt.Errorf("zerotier-cli 未安装")
	}

	cmd := exec.Command("zerotier-cli", "join", networkID)
	if err := cmd.Run(); err != nil {
		nm.status.Error = fmt.Sprintf("加入失败: %v", err)
		return nm.status, err
	}

	nm.status.Connected = true
	nm.status.NetworkID = networkID
	nm.status.LastCheck = time.Now().Format("2006-01-02 15:04:05")
	nm.logger.Info("ZeroTier 加入网络: %s", networkID)
	return nm.status, nil
}

// joinCustom 加入自定义组网服务
func (nm *NetworkManager) joinCustom(authKey string) (*NetworkStatus, error) {
	if nm.cfg.APIEndpoint == "" {
		return nil, fmt.Errorf("自定义组网需要配置 api_endpoint")
	}

	// 调用自定义 API 加入
	payload := map[string]string{
		"auth_key":    authKey,
		"device_name": nm.cfg.DeviceName,
	}
	data, _ := json.Marshal(payload)

	resp, err := http.Post(nm.cfg.APIEndpoint+"/join", "application/json", bytes.NewReader(data))
	if err != nil {
		nm.status.Error = fmt.Sprintf("加入失败: %v", err)
		return nm.status, err
	}
	defer resp.Body.Close()

	var result struct {
		Success bool   `json:"success"`
		IP      string `json:"ip"`
		Network string `json:"network"`
		Error   string `json:"error"`
	}
	json.NewDecoder(resp.Body).Decode(&result)

	if !result.Success {
		nm.status.Error = result.Error
		return nm.status, fmt.Errorf("%s", result.Error)
	}

	nm.status.Connected = true
	nm.status.DeviceIP = result.IP
	nm.status.NetworkID = result.Network
	nm.status.LastCheck = time.Now().Format("2006-01-02 15:04:05")
	nm.logger.Info("自定义组网加入成功，IP: %s", result.IP)
	return nm.status, nil
}

// joinN2N 加入 n2n 网络（免费P2P组网，无需公网IP）
func (nm *NetworkManager) joinN2N(authKey string) (*NetworkStatus, error) {
	nm.logger.Info("启动 n2n 组网: supernode=%s, community=%s", nm.cfg.N2NSupernode, nm.cfg.N2NCommunity)

	// 检查 edge 命令是否存在
	edgePath := ""
	for _, p := range []string{"edge", "n2n-edge", "/data/data/com.termux/files/usr/bin/edge"} {
		if _, err := exec.LookPath(p); err == nil {
			edgePath = p
			break
		}
	}

	if edgePath == "" {
		nm.status.Error = "n2n edge 未安装。Android 请安装 Hin2n App，或执行: pkg install n2n"
		return nm.status, fmt.Errorf("n2n edge 未安装")
	}

	// 生成配置文件
	configFile := filepath.Join(os.TempDir(), "n2n_edge.conf")
	configContent := fmt.Sprintf(`-d=n2n0
-c=%s
-k=%s
-l=%s
-a=%s
-u=0
-g=0
-f
-m=DE:AD:BE:EF:01:01
`, nm.cfg.N2NCommunity, nm.cfg.N2NEncryptKey, nm.cfg.N2NSupernode, nm.cfg.N2NIP)

	if err := os.WriteFile(configFile, []byte(configContent), 0644); err != nil {
		nm.status.Error = fmt.Sprintf("写入配置失败: %v", err)
		return nm.status, err
	}

	// 启动 edge（需要 root 权限创建 tun 设备）
	cmd := exec.Command(edgePath, configFile)
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	if err := cmd.Start(); err != nil {
		nm.status.Error = fmt.Sprintf("启动失败: %v（可能需要 root 权限）", err)
		return nm.status, err
	}

	time.Sleep(3 * time.Second)

	// 检查是否启动成功
	if cmd.ProcessState != nil && cmd.ProcessState.Exited() {
		nm.status.Error = fmt.Sprintf("启动失败退出: %s", stderr.String())
		return nm.status, fmt.Errorf("edge 启动失败")
	}

	nm.status.Provider = "n2n"
	nm.status.Connected = true
	nm.status.DeviceName = nm.cfg.DeviceName
	nm.status.DeviceIP = nm.cfg.N2NIP
	nm.status.NetworkID = nm.cfg.N2NCommunity
	nm.status.LastCheck = time.Now().Format("2006-01-02 15:04:05")
	nm.logger.Info("n2n 组网启动成功，IP: %s", nm.cfg.N2NIP)
	return nm.status, nil
}

// GenerateN2NConfig 生成 n2n 配置文件内容（用于 Hin2n App 导入）
func (nm *NetworkManager) GenerateN2NConfig() string {
	return fmt.Sprintf(`# n2n 配置（导入 Hin2n App 使用）
# 超级节点（免费公共节点）
supernode = %s
# 社区名（同一社区的设备互通）
community = %s
# 加密密钥
encryptkey = %s
# 虚拟IP（同一社区内不能重复）
ipaddr = %s
# 子网掩码
netmask = 255.255.255.0
# 本地端口
localport = %d
`, nm.cfg.N2NSupernode, nm.cfg.N2NCommunity, nm.cfg.N2NEncryptKey, nm.cfg.N2NIP, nm.cfg.N2NPort)
}

// GetStatus 获取组网状态（带缓存）
func (nm *NetworkManager) GetStatus() *NetworkStatus {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	// 5分钟内不重复查询
	if time.Since(nm.lastPoll) < 5*time.Minute && nm.status != nil {
		return nm.status
	}

	// 尝试刷新状态
	if nm.cfg.Provider == "tailscale" && nm.status.Connected {
		if status, err := nm.getTailscaleStatus(); err == nil {
			nm.status = status
			nm.lastPoll = time.Now()
		}
	}

	return nm.status
}

// Leave 离开组网
func (nm *NetworkManager) Leave() error {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	switch nm.cfg.Provider {
	case "tailscale":
		exec.Command("tailscale", "down").Run()
	case "zerotier":
		if nm.status.NetworkID != "" {
			exec.Command("zerotier-cli", "leave", nm.status.NetworkID).Run()
		}
	}

	nm.status.Connected = false
	nm.status.DeviceIP = ""
	nm.logger.Info("network", "action", "已离开组网")
	return nil
}

// GenerateJoinLink 生成自助加入链接
func (nm *NetworkManager) GenerateJoinLink(expireHours int) (string, error) {
	if nm.cfg.APIEndpoint == "" {
		return "", fmt.Errorf("需要配置 api_endpoint 才能生成加入链接")
	}

	// 调用 API 生成临时加入令牌
	resp, err := http.Post(fmt.Sprintf("%s/generate-token?expire=%d", nm.cfg.APIEndpoint, expireHours), "", nil)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	var result struct {
		Token string `json:"token"`
		URL   string `json:"url"`
	}
	json.NewDecoder(resp.Body).Decode(&result)
	return result.URL, nil
}

// CheckInstalled 检查组网客户端是否已安装
func (nm *NetworkManager) CheckInstalled() map[string]bool {
	result := make(map[string]bool)
	for _, cmd := range []string{"tailscale", "zerotier-cli"} {
		_, err := exec.LookPath(cmd)
		result[cmd] = err == nil
	}
	return result
}

// ===== HTTP API 处理函数 =====

func (h *NASHandler) handleNetworkStatus(w http.ResponseWriter, r *http.Request) {
	status := h.networkMgr.GetStatus()
	installed := h.networkMgr.CheckInstalled()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":    status,
		"installed": installed,
		"config": map[string]interface{}{
			"provider":    h.cfg.Network.Provider,
			"device_name": h.cfg.Network.DeviceName,
			"auto_join":   h.cfg.Network.AutoJoin,
		},
	})
}

func (h *NASHandler) handleNetworkJoin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		AuthKey  string `json:"auth_key"`
		Provider string `json:"provider"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}

	if req.Provider != "" {
		h.cfg.Network.Provider = req.Provider
	}

	status, err := h.networkMgr.Join(req.AuthKey)
	if err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   err.Error(),
			"status":  status,
		})
		return
	}

	h.logger.Info("组网加入成功: %s", req.Provider)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"status":  status,
	})
}

func (h *NASHandler) handleNetworkLeave(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if err := h.networkMgr.Leave(); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// 辅助：检查命令是否存在
func commandExists(name string) bool {
	_, err := exec.LookPath(name)
	return err == nil
}

// 辅助：执行命令并返回输出
func runCommand(name string, args ...string) (string, error) {
	cmd := exec.Command(name, args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	if err != nil {
		return "", fmt.Errorf("%v: %s", err, strings.TrimSpace(stderr.String()))
	}
	return strings.TrimSpace(stdout.String()), nil
}
