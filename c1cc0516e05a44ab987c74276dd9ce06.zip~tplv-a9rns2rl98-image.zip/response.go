package main

import (
	"encoding/json"
	"net/http"
)

// APIResponse 统一API响应格式
type APIResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
	Code    int         `json:"code,omitempty"`
}

// 错误码定义
const (
	CodeSuccess        = 0
	CodeInvalidParams  = 1001
	CodeUnauthorized   = 1002
	CodeForbidden      = 1003
	CodeNotFound       = 1004
	CodeInternalError  = 1005
	CodeFileNotFound   = 2001
	CodeFileExists     = 2002
	CodeFileTooLarge   = 2003
	CodeUploadFailed   = 2004
	CodeVaultLocked    = 3001
	CodeVaultInitFail  = 3002
	CodeVaultWrongPwd  = 3003
)

// 错误信息映射
var errorMessages = map[int]string{
	CodeSuccess:       "成功",
	CodeInvalidParams: "参数错误",
	CodeUnauthorized:  "未授权",
	CodeForbidden:     "权限不足",
	CodeNotFound:      "资源不存在",
	CodeInternalError: "服务器内部错误",
	CodeFileNotFound:  "文件不存在",
	CodeFileExists:    "文件已存在",
	CodeFileTooLarge:  "文件过大",
	CodeUploadFailed:  "上传失败",
	CodeVaultLocked:   "加密空间已锁定",
	CodeVaultInitFail: "加密空间初始化失败",
	CodeVaultWrongPwd: "密码错误",
}

// WriteSuccess 写入成功响应
func WriteSuccess(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(APIResponse{
		Success: true,
		Data:    data,
		Code:    CodeSuccess,
	})
}

// WriteError 写入错误响应
func WriteError(w http.ResponseWriter, code int, message string) {
	w.Header().Set("Content-Type", "application/json")
	
	// 根据错误码设置HTTP状态
	httpStatus := http.StatusOK
	switch code {
	case CodeUnauthorized:
		httpStatus = http.StatusUnauthorized
	case CodeForbidden:
		httpStatus = http.StatusForbidden
	case CodeNotFound, CodeFileNotFound:
		httpStatus = http.StatusNotFound
	case CodeInternalError:
		httpStatus = http.StatusInternalServerError
	case CodeFileTooLarge:
		httpStatus = http.StatusRequestEntityTooLarge
	}
	
	w.WriteHeader(httpStatus)
	
	if message == "" {
		if msg, ok := errorMessages[code]; ok {
			message = msg
		} else {
			message = "未知错误"
		}
	}
	
	json.NewEncoder(w).Encode(APIResponse{
		Success: false,
		Error:   message,
		Code:    code,
	})
}

// WriteErrorWithStatus 写入带自定义HTTP状态的错误响应
func WriteErrorWithStatus(w http.ResponseWriter, httpStatus int, code int, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(httpStatus)
	json.NewEncoder(w).Encode(APIResponse{
		Success: false,
		Error:   message,
		Code:    code,
	})
}
