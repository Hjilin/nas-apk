package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// AppInfo 应用信息
type AppInfo struct {
	PackageName string `json:"package_name"`
	AppName     string `json:"app_name"`
	VersionName string `json:"version_name"`
	VersionCode int    `json:"version_code"`
	APKPath     string `json:"apk_path"`
	APKSize     int64  `json:"apk_size"`
	Source      string `json:"source"` // google_play / other
	InstalledAt string `json:"installed_at"`
}

// AppBackupInfo 应用备份信息
type AppBackupInfo struct {
	ID         string    `json:"id"`
	Name       string    `json:"name"`
	AppCount   int       `json:"app_count"`
	TotalSize  int64     `json:"total_size"`
	CreatedAt  time.Time `json:"created_at"`
	Apps       []AppInfo `json:"apps"`
	HasAPK     bool      `json:"has_apk"`
}

// AppBackupManager 应用备份管理器
type AppBackupManager struct {
	backupDir string
	logger    *Logger
	mu        sync.Mutex
}

// NewAppBackupManager 创建应用备份管理器
func NewAppBackupManager(storageRoot string, logger *Logger) *AppBackupManager {
	dir := filepath.Join(storageRoot, ".app_backups")
	os.MkdirAll(dir, 0755)
	return &AppBackupManager{
		backupDir: dir,
		logger:    logger,
	}
}

// GetInstalledApps 获取已安装应用列表
func (abm *AppBackupManager) GetInstalledApps() ([]AppInfo, error) {
	var apps []AppInfo

	// 使用 pm list packages 获取已安装应用
	output, err := exec.Command("pm", "list", "packages", "-3").Output()
	if err != nil {
		// 备用：使用 cmd package list packages
		output, err = exec.Command("cmd", "package", "list", "packages", "-3").Output()
		if err != nil {
			return nil, fmt.Errorf("无法获取应用列表: %v", err)
		}
	}

	lines := strings.Split(string(output), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		// 格式: package:com.example.app
		pkg := strings.TrimPrefix(line, "package:")
		if pkg == "" {
			continue
		}

		app := AppInfo{PackageName: pkg}

		// 获取应用名称
		if name, err := getAppName(pkg); err == nil {
			app.AppName = name
		} else {
			app.AppName = pkg
		}

		// 获取版本信息
		if version, code, err := getAppVersion(pkg); err == nil {
			app.VersionName = version
			app.VersionCode = code
		}

		// 获取 APK 路径
		if apkPath, err := getAPKPath(pkg); err == nil {
			app.APKPath = apkPath
			if info, err := os.Stat(apkPath); err == nil {
				app.APKSize = info.Size()
			}
		}

		// 判断来源
		if installer, err := getInstaller(pkg); err == nil {
			app.Source = installer
		}

		apps = append(apps, app)
	}

	return apps, nil
}

// getAppName 获取应用名称
func getAppName(pkg string) (string, error) {
	// 尝试使用 dumpsys
	output, err := exec.Command("dumpsys", "package", pkg).Output()
	if err != nil {
		return "", err
	}
	lines := strings.Split(string(output), "\n")
	for _, line := range lines {
		if strings.Contains(line, "applicationLabel") || strings.Contains(line, "appLabel") {
			parts := strings.Split(line, "=")
			if len(parts) >= 2 {
				return strings.TrimSpace(parts[len(parts)-1]), nil
			}
		}
	}
	return "", fmt.Errorf("not found")
}

// getAppVersion 获取应用版本
func getAppVersion(pkg string) (string, int, error) {
	output, err := exec.Command("dumpsys", "package", pkg).Output()
	if err != nil {
		return "", 0, err
	}
	versionName := ""
	versionCode := 0
	lines := strings.Split(string(output), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "versionName=") {
			versionName = strings.TrimPrefix(line, "versionName=")
		}
		if strings.HasPrefix(line, "versionCode=") {
			fmt.Sscanf(strings.TrimPrefix(line, "versionCode="), "%d", &versionCode)
		}
	}
	if versionName == "" {
		return "", 0, fmt.Errorf("not found")
	}
	return versionName, versionCode, nil
}

// getAPKPath 获取 APK 路径
func getAPKPath(pkg string) (string, error) {
	output, err := exec.Command("pm", "path", pkg).Output()
	if err != nil {
		return "", err
	}
	// 格式: package:/data/app/.../base.apk
	line := strings.TrimSpace(string(output))
	path := strings.TrimPrefix(line, "package:")
	if path == "" {
		return "", fmt.Errorf("not found")
	}
	return path, nil
}

// getInstaller 获取安装来源
func getInstaller(pkg string) (string, error) {
	output, err := exec.Command("pm", "get-installer", pkg).Output()
	if err != nil {
		return "other", nil
	}
	installer := strings.TrimSpace(string(output))
	if strings.Contains(installer, "com.android.vending") {
		return "google_play", nil
	}
	if strings.Contains(installer, "com.xiaomi.market") {
		return "xiaomi_store", nil
	}
	if strings.Contains(installer, "com.oppo.market") {
		return "oppo_store", nil
	}
	if installer == "" {
		return "other", nil
	}
	return installer, nil
}

// BackupApps 备份应用列表
func (abm *AppBackupManager) BackupApps(name string, includeAPK bool) (*AppBackupInfo, error) {
	abm.mu.Lock()
	defer abm.mu.Unlock()

	apps, err := abm.GetInstalledApps()
	if err != nil {
		return nil, err
	}

	if name == "" {
		name = fmt.Sprintf("apps-%s", time.Now().Format("20060102-150405"))
	}

	info := &AppBackupInfo{
		ID:        fmt.Sprintf("appbk_%d", time.Now().Unix()),
		Name:      name,
		AppCount:  len(apps),
		CreatedAt: time.Now(),
		Apps:      apps,
		HasAPK:    includeAPK,
	}

	// 计算总大小
	var totalSize int64
	for _, app := range apps {
		totalSize += app.APKSize
	}
	info.TotalSize = totalSize

	// 保存备份信息
	data, err := json.MarshalIndent(info, "", "  ")
	if err != nil {
		return nil, err
	}
	backupPath := filepath.Join(abm.backupDir, info.ID+".json")
	if err := os.WriteFile(backupPath, data, 0644); err != nil {
		return nil, err
	}

	// 如果需要包含 APK，复制 APK 文件
	if includeAPK {
		apkDir := filepath.Join(abm.backupDir, info.ID+"_apks")
		os.MkdirAll(apkDir, 0755)
		for _, app := range apps {
			if app.APKPath != "" {
				// 尝试复制 APK（可能需要 root 权限）
				src, err := os.Open(app.APKPath)
				if err != nil {
					continue
				}
				dstPath := filepath.Join(apkDir, app.PackageName+".apk")
				dst, err := os.Create(dstPath)
				if err != nil {
					src.Close()
					continue
				}
				// 复制文件
				buf := make([]byte, 1024*1024)
				for {
					n, err := src.Read(buf)
					if n > 0 {
						dst.Write(buf[:n])
					}
					if err != nil {
						break
					}
				}
				src.Close()
				dst.Close()
			}
		}
	}

	abm.logger.Info("应用备份完成: %s, 应用数: %d", name, len(apps))
	return info, nil
}

// ListAppBackups 列出应用备份
func (abm *AppBackupManager) ListAppBackups() ([]AppBackupInfo, error) {
	entries, err := os.ReadDir(abm.backupDir)
	if err != nil {
		return nil, err
	}

	var backups []AppBackupInfo
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".json") {
			continue
		}
		data, err := os.ReadFile(filepath.Join(abm.backupDir, entry.Name()))
		if err != nil {
			continue
		}
		var info AppBackupInfo
		if err := json.Unmarshal(data, &info); err == nil {
			backups = append(backups, info)
		}
	}

	// 按时间倒序
	for i := 0; i < len(backups); i++ {
		for j := i + 1; j < len(backups); j++ {
			if backups[j].CreatedAt.After(backups[i].CreatedAt) {
				backups[i], backups[j] = backups[j], backups[i]
			}
		}
	}

	return backups, nil
}

// GetAppBackup 获取应用备份详情
func (abm *AppBackupManager) GetAppBackup(id string) (*AppBackupInfo, error) {
	data, err := os.ReadFile(filepath.Join(abm.backupDir, id+".json"))
	if err != nil {
		return nil, fmt.Errorf("备份不存在")
	}
	var info AppBackupInfo
	if err := json.Unmarshal(data, &info); err != nil {
		return nil, err
	}
	return &info, nil
}

// DeleteAppBackup 删除应用备份
func (abm *AppBackupManager) DeleteAppBackup(id string) error {
	os.Remove(filepath.Join(abm.backupDir, id+".json"))
	os.RemoveAll(filepath.Join(abm.backupDir, id+"_apks"))
	return nil
}

// GetAppDownloadLinks 获取应用下载链接
func GetAppDownloadLinks(pkg string) map[string]string {
	links := make(map[string]string)

	// Google Play
	links["google_play"] = fmt.Sprintf("market://details?id=%s", pkg)
	links["google_play_web"] = fmt.Sprintf("https://play.google.com/store/apps/details?id=%s", pkg)

	// 小米应用商店
	links["xiaomi_store"] = fmt.Sprintf("mimarket://details?id=%s", pkg)
	links["xiaomi_web"] = fmt.Sprintf("https://app.mi.com/details?id=%s", pkg)

	// OPPO/一加应用商店
	links["oppo_store"] = fmt.Sprintf("oppomarket://details?pkg_name=%s", pkg)

	// APKPure（浏览器下载）
	links["apkpure"] = fmt.Sprintf("https://apkpure.com/cn/android/%s", pkg)

	// APKMirror（浏览器下载）
	links["apkmirror"] = fmt.Sprintf("https://www.apkmirror.com/?s=%s", pkg)

	// 酷安
	links["coolapk"] = fmt.Sprintf("coolmarket://apk/%s", pkg)
	links["coolapk_web"] = fmt.Sprintf("https://www.coolapk.com/apk/%s", pkg)

	return links
}

// ===== HTTP API 处理函数 =====

func (h *NASHandler) handleAppBackupList(w http.ResponseWriter, r *http.Request) {
	backups, err := h.appBackupMgr.ListAppBackups()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	installed, _ := h.appBackupMgr.GetInstalledApps()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"backups":   backups,
		"installed": len(installed),
	})
}

func (h *NASHandler) handleAppBackupCreate(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Name       string `json:"name"`
		IncludeAPK bool   `json:"include_apk"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	info, err := h.appBackupMgr.BackupApps(req.Name, req.IncludeAPK)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"backup":  info,
	})
}

func (h *NASHandler) handleAppBackupDetail(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "Missing id", http.StatusBadRequest)
		return
	}
	info, err := h.appBackupMgr.GetAppBackup(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusNotFound)
		return
	}
	json.NewEncoder(w).Encode(info)
}

func (h *NASHandler) handleAppBackupDelete(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "Missing id", http.StatusBadRequest)
		return
	}
	if err := h.appBackupMgr.DeleteAppBackup(id); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleAppInstalled(w http.ResponseWriter, r *http.Request) {
	apps, err := h.appBackupMgr.GetInstalledApps()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"apps":  apps,
		"count": len(apps),
	})
}

func (h *NASHandler) handleAppDownloadLinks(w http.ResponseWriter, r *http.Request) {
	pkg := r.URL.Query().Get("package")
	if pkg == "" {
		http.Error(w, "Missing package", http.StatusBadRequest)
		return
	}
	links := GetAppDownloadLinks(pkg)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"package": pkg,
		"links":   links,
	})
}
