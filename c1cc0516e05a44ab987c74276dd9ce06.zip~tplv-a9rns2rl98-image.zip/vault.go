package main

import (
	"archive/zip"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// 加密文件格式常量
const (
	VaultMagic   = "VAULT"
	VaultVersion = 1
)

// VaultFileEntry 加密文件清单条目
type VaultFileEntry struct {
	ID         string    `json:"id"`
	OriginName string    `json:"origin_name"`
	EncName    string    `json:"enc_name"`
	Size       int64     `json:"size"`
	EncSize    int64     `json:"enc_size"`
	Checksum   string    `json:"checksum"`
	Type       string    `json:"type"`
	CreatedAt  time.Time `json:"created_at"`
	ModifiedAt time.Time `json:"modified_at"`
}

// VaultShare 分享链接
type VaultShare struct {
	Token      string    `json:"token"`
	FileID     string    `json:"file_id"`
	FileName   string    `json:"file_name"`
	Password   string    `json:"password,omitempty"`
	ExpireAt   time.Time `json:"expire_at"`
	CreatedAt  time.Time `json:"created_at"`
	Downloads  int       `json:"downloads"`
	MaxDownloads int     `json:"max_downloads"`
}

// VaultConfig 加密空间配置
type VaultConfig struct {
	Enabled      bool      `json:"enabled"`
	PasswordHash string    `json:"password_hash"`
	PatternHash  string    `json:"pattern_hash"`
	PINHash      string    `json:"pin_hash"`
	Salt         string    `json:"salt"`
	UnlockMethod string    `json:"unlock_method"`
	CreatedAt    time.Time `json:"created_at"`
	LastUnlock   time.Time `json:"last_unlock"`
	// 加密后的主密钥（用各解锁方式的派生密钥加密）
	MasterKeyByPassword string `json:"master_key_by_password,omitempty"`
	MasterKeyByPattern  string `json:"master_key_by_pattern,omitempty"`
	MasterKeyByPIN      string `json:"master_key_by_pin,omitempty"`
}

// VaultManager 加密空间管理器
type VaultManager struct {
	vaultDir   string
	configPath string
	manifestPath string
	sharesPath string
	logger     *Logger
	mu         sync.Mutex
	config     *VaultConfig
	manifest   map[string]*VaultFileEntry
	shares     map[string]*VaultShare
	unlocked   bool
	unlockTime time.Time
	secret     string
}

// NewVaultManager 创建加密空间管理器
func NewVaultManager(storageRoot string, logger *Logger) *VaultManager {
	vaultDir := filepath.Join(storageRoot, ".vault")
	os.MkdirAll(vaultDir, 0755)

	vm := &VaultManager{
		vaultDir:     vaultDir,
		configPath:   filepath.Join(vaultDir, "config.json"),
		manifestPath: filepath.Join(vaultDir, "manifest.json"),
		sharesPath:   filepath.Join(vaultDir, "shares.json"),
		logger:       logger,
		manifest:     make(map[string]*VaultFileEntry),
		shares:       make(map[string]*VaultShare),
	}
	vm.loadConfig()
	vm.loadManifest()
	vm.loadShares()
	return vm
}

func (vm *VaultManager) loadConfig() {
	data, err := os.ReadFile(vm.configPath)
	if err != nil {
		vm.config = &VaultConfig{Enabled: false, UnlockMethod: "any", CreatedAt: time.Now()}
		return
	}
	var config VaultConfig
	if err := json.Unmarshal(data, &config); err == nil {
		vm.config = &config
	}
}

func (vm *VaultManager) saveConfig() {
	data, _ := json.MarshalIndent(vm.config, "", "  ")
	os.WriteFile(vm.configPath, data, 0600)
}

func (vm *VaultManager) loadManifest() {
	data, err := os.ReadFile(vm.manifestPath)
	if err != nil {
		return
	}
	var manifest map[string]*VaultFileEntry
	if err := json.Unmarshal(data, &manifest); err == nil {
		vm.manifest = manifest
	}
}

func (vm *VaultManager) saveManifest() {
	data, _ := json.MarshalIndent(vm.manifest, "", "  ")
	os.WriteFile(vm.manifestPath, data, 0600)
}

func (vm *VaultManager) loadShares() {
	data, err := os.ReadFile(vm.sharesPath)
	if err != nil {
		return
	}
	var shares map[string]*VaultShare
	if err := json.Unmarshal(data, &shares); err == nil {
		vm.shares = shares
	}
}

func (vm *VaultManager) saveShares() {
	data, _ := json.MarshalIndent(vm.shares, "", "  ")
	os.WriteFile(vm.sharesPath, data, 0600)
}

func (vm *VaultManager) IsEnabled() bool {
	vm.mu.Lock()
	defer vm.mu.Unlock()
	return vm.config.Enabled
}

func (vm *VaultManager) IsUnlocked() bool {
	vm.mu.Lock()
	defer vm.mu.Unlock()
	return vm.isUnlockedLocked()
}

// isUnlockedLocked 内部函数，调用方必须已持有锁
func (vm *VaultManager) isUnlockedLocked() bool {
	if !vm.unlocked {
		return false
	}
	if time.Since(vm.unlockTime) > 30*time.Minute {
		vm.unlocked = false
		vm.secret = ""
		return false
	}
	return true
}

func (vm *VaultManager) Initialize(password, pattern, pin string) error {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	if vm.config.Enabled {
		return fmt.Errorf("加密空间已初始化")
	}

	salt := make([]byte, 16)
	rand.Read(salt)
	saltStr := fmt.Sprintf("%x", salt)

	// 生成随机主密钥（32字节）
	masterKey := make([]byte, 32)
	rand.Read(masterKey)
	masterKeyHex := hex.EncodeToString(masterKey)

	config := &VaultConfig{
		Enabled:      true,
		Salt:         saltStr,
		UnlockMethod: "any",
		CreatedAt:    time.Now(),
	}

	// 用各解锁方式的派生密钥加密主密钥
	encryptMasterKey := func(secret string) string {
		if secret == "" {
			return ""
		}
		keyHash := sha256.Sum256([]byte(secret + saltStr))
		block, _ := aes.NewCipher(keyHash[:])
		gcm, _ := cipher.NewGCM(block)
		nonce := make([]byte, gcm.NonceSize())
		rand.Read(nonce)
		encrypted := gcm.Seal(nonce, nonce, []byte(masterKeyHex), nil)
		return hex.EncodeToString(encrypted)
	}

	if password != "" {
		// 用SHA256+盐代替bcrypt，初始化速度快，不会卡住
		hash := sha256.Sum256([]byte(password + saltStr))
		config.PasswordHash = hex.EncodeToString(hash[:])
		config.MasterKeyByPassword = encryptMasterKey(password)
	}
	if pattern != "" {
		hash := sha256.Sum256([]byte(pattern + saltStr))
		config.PatternHash = hex.EncodeToString(hash[:])
		config.MasterKeyByPattern = encryptMasterKey(pattern)
	}
	if pin != "" {
		hash := sha256.Sum256([]byte(pin + saltStr))
		config.PINHash = hex.EncodeToString(hash[:])
		config.MasterKeyByPIN = encryptMasterKey(pin)
	}

	vm.config = config
	vm.saveConfig()
	vm.logger.Info("vault", "action", "加密空间已初始化")
	return nil
}

func (vm *VaultManager) Unlock(password, pattern, pin string) error {
	start := time.Now()
	vm.mu.Lock()
	defer vm.mu.Unlock()

	vm.logger.Debug("[VAULT] 开始解锁, 密码长度=%d, 图案长度=%d, PIN长度=%d, 当前unlocked=%v", 
		len(password), len(pattern), len(pin), vm.unlocked)

	if !vm.config.Enabled {
		vm.logger.Warn("[VAULT] 解锁失败: 加密空间未初始化")
		return fmt.Errorf("加密空间未初始化")
	}

	check := func(hash, input string) bool {
		if hash == "" || input == "" {
			return false
		}
		// 用SHA256+盐验证（与初始化一致）
		inputHash := sha256.Sum256([]byte(input + vm.config.Salt))
		return hex.EncodeToString(inputHash[:]) == hash
	}

	// 解密主密钥
	decryptMasterKey := func(encryptedHex, secret string) (string, error) {
		if encryptedHex == "" || secret == "" {
			return "", fmt.Errorf("无可用密钥")
		}
		encrypted, err := hex.DecodeString(encryptedHex)
		if err != nil {
			return "", err
		}
		keyHash := sha256.Sum256([]byte(secret + vm.config.Salt))
		block, err := aes.NewCipher(keyHash[:])
		if err != nil {
			return "", err
		}
		gcm, err := cipher.NewGCM(block)
		if err != nil {
			return "", err
		}
		nonceSize := gcm.NonceSize()
		if len(encrypted) < nonceSize {
			return "", fmt.Errorf("密文太短")
		}
		nonce, ciphertext := encrypted[:nonceSize], encrypted[nonceSize:]
		plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
		if err != nil {
			return "", err
		}
		return string(plaintext), nil
	}

	var masterKey string
	var err error
	var method string

	if check(vm.config.PasswordHash, password) {
		method = "password"
		masterKey, err = decryptMasterKey(vm.config.MasterKeyByPassword, password)
	} else if check(vm.config.PatternHash, pattern) {
		method = "pattern"
		masterKey, err = decryptMasterKey(vm.config.MasterKeyByPattern, pattern)
	} else if check(vm.config.PINHash, pin) {
		method = "pin"
		masterKey, err = decryptMasterKey(vm.config.MasterKeyByPIN, pin)
	} else {
		vm.logger.Warn("[VAULT] 解锁验证失败: 所有方式都不匹配, 耗时=%v", time.Since(start))
		return fmt.Errorf("验证失败")
	}

	if err != nil || masterKey == "" {
		vm.logger.Error("[VAULT] 主密钥解密失败: method=%s, err=%v, 耗时=%v", method, err, time.Since(start))
		return fmt.Errorf("主密钥解密失败")
	}

	vm.unlocked = true
	vm.unlockTime = time.Now()
	vm.secret = masterKey // 统一使用主密钥
	vm.config.LastUnlock = time.Now()
	vm.saveConfig()
	vm.logger.Info("[VAULT] 解锁成功: method=%s, 耗时=%v", method, time.Since(start))
	return nil
}

func (vm *VaultManager) Lock() {
	vm.mu.Lock()
	defer vm.mu.Unlock()
	vm.unlocked = false
	vm.secret = ""
}

func (vm *VaultManager) deriveKey(secret string) []byte {
	// secret 已经是主密钥的hex编码，直接解码使用
	if key, err := hex.DecodeString(secret); err == nil && len(key) == 32 {
		return key
	}
	// 兼容旧格式：从secret+salt派生
	hash := sha256.Sum256([]byte(secret + vm.config.Salt))
	return hash[:]
}

// EncryptFile 加密并存储文件（保留原始文件名）
func (vm *VaultManager) EncryptFile(filename string, reader io.Reader, secret string) error {
	if !vm.IsUnlocked() {
		return fmt.Errorf("加密空间已锁定")
	}

	// 优先使用后端主密钥，确保加解密一致
	useSecret := vm.secret
	if useSecret == "" {
		useSecret = secret
	}
	vm.logger.Debug("[VAULT] 加密文件使用密钥: 主密钥长度=%d, 传入secret长度=%d", len(useSecret), len(secret))
	
	key := vm.deriveKey(useSecret)
	block, err := aes.NewCipher(key)
	if err != nil {
		return err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}

	nonce := make([]byte, gcm.NonceSize())
	io.ReadFull(rand.Reader, nonce)

	data, err := io.ReadAll(reader)
	if err != nil {
		return err
	}

	// 计算原始文件校验和
	checksum := sha256.Sum256(data)

	// 加密：[magic(5)][version(1)][nonce(12)][ciphertext][checksum(32)]
	ciphertext := gcm.Seal(nil, nonce, data, nil)

	// 构建加密文件内容
	encData := make([]byte, 0)
	encData = append(encData, []byte(VaultMagic)...)
	encData = append(encData, VaultVersion)
	encData = append(encData, nonce...)
	encData = append(encData, ciphertext...)
	encData = append(encData, checksum[:]...)

	// 生成唯一ID和加密文件名
	fileID := fmt.Sprintf("%d", time.Now().UnixNano())
	encName := fileID + ".vault"
	encPath := filepath.Join(vm.vaultDir, encName)

	if err := os.WriteFile(encPath, encData, 0600); err != nil {
		return err
	}

	// 记录到 manifest
	vm.mu.Lock()
	vm.manifest[fileID] = &VaultFileEntry{
		ID:         fileID,
		OriginName: filename,
		EncName:    encName,
		Size:       int64(len(data)),
		EncSize:    int64(len(encData)),
		Checksum:   hex.EncodeToString(checksum[:]),
		Type:       getFileType(filename),
		CreatedAt:  time.Now(),
		ModifiedAt: time.Now(),
	}
	vm.saveManifest()
	vm.mu.Unlock()

	return nil
}

// DecryptFile 解密文件（返回原始文件名和内容）
func (vm *VaultManager) DecryptFile(fileID, secret string) ([]byte, string, error) {
	if !vm.IsUnlocked() {
		return nil, "", fmt.Errorf("加密空间已锁定")
	}

	// 优先使用后端主密钥，确保加解密一致
	useSecret := vm.secret
	if useSecret == "" {
		useSecret = secret
	}
	vm.logger.Debug("[VAULT] 解密文件使用密钥: 主密钥长度=%d, 传入secret长度=%d", len(useSecret), len(secret))
	
	vm.mu.Lock()
	entry, ok := vm.manifest[fileID]
	vm.mu.Unlock()
	if !ok {
		return nil, "", fmt.Errorf("文件不存在")
	}

	key := vm.deriveKey(useSecret)
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, "", err
	}

	encData, err := os.ReadFile(filepath.Join(vm.vaultDir, entry.EncName))
	if err != nil {
		return nil, "", err
	}

	vm.logger.Debug("[VAULT] 解密文件详情: id=%s, 加密文件大小=%d, 原始大小=%d, 原始名=%s", 
		fileID, len(encData), entry.Size, entry.OriginName)

	// 解析加密文件格式
	headerLen := len(VaultMagic) + 1
	if len(encData) < headerLen || string(encData[:len(VaultMagic)]) != VaultMagic {
		vm.logger.Error("[VAULT] 无效的加密文件格式: magic=%v", encData[:min(len(encData), 10)])
		return nil, "", fmt.Errorf("无效的加密文件格式")
	}

	nonceSize := gcm.NonceSize()
	if len(encData) < headerLen+nonceSize+32 {
		vm.logger.Error("[VAULT] 加密文件太小: %d < %d", len(encData), headerLen+nonceSize+32)
		return nil, "", fmt.Errorf("加密文件太小")
	}
	
	nonce := encData[headerLen : headerLen+nonceSize]
	ciphertext := encData[headerLen+nonceSize : len(encData)-32]
	storedChecksum := encData[len(encData)-32:]

	vm.logger.Debug("[VAULT] 解密参数: headerLen=%d, nonceSize=%d, ciphertextLen=%d, checksumLen=%d",
		headerLen, nonceSize, len(ciphertext), len(storedChecksum))

	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		vm.logger.Error("[VAULT] AES-GCM解密失败: id=%s, 错误=%v, 密钥长度=%d, 密钥前8字符=%s",
			fileID, err, len(useSecret), useSecret[:min(8, len(useSecret))])
		return nil, "", fmt.Errorf("解密失败，密码错误或文件已损坏")
	}

	// 校验文件完整性
	actualChecksum := sha256.Sum256(plaintext)
	if string(actualChecksum[:]) != string(storedChecksum) {
		vm.logger.Error("[VAULT] 文件校验失败: id=%s, 期望=%x, 实际=%x, 解密后大小=%d",
			fileID, storedChecksum[:8], actualChecksum[:8], len(plaintext))
		return nil, "", fmt.Errorf("文件校验失败，可能已损坏")
	}

	vm.logger.Info("[VAULT] 解密成功: id=%s, 原始名=%s, 解密后大小=%d, 校验通过",
		fileID, entry.OriginName, len(plaintext))
	return plaintext, entry.OriginName, nil
}

// ListFiles 列出加密文件
func (vm *VaultManager) ListFiles(fileType string) []map[string]interface{} {
	if !vm.IsUnlocked() {
		return nil
	}

	vm.mu.Lock()
	defer vm.mu.Unlock()

	var files []map[string]interface{}
	for _, entry := range vm.manifest {
		if fileType != "" && fileType != "all" && entry.Type != fileType {
			continue
		}
		files = append(files, map[string]interface{}{
			"id":         entry.ID,
			"name":       entry.OriginName,
			"size":       entry.Size,
			"enc_size":   entry.EncSize,
			"type":       entry.Type,
			"checksum":   entry.Checksum[:16] + "...",
			"created_at": entry.CreatedAt,
			"modified_at": entry.ModifiedAt,
		})
	}
	return files
}

// RenameFile 重命名加密文件
func (vm *VaultManager) RenameFile(fileID, newName string) error {
	if !vm.IsUnlocked() {
		return fmt.Errorf("加密空间已锁定")
	}

	vm.mu.Lock()
	defer vm.mu.Unlock()

	entry, ok := vm.manifest[fileID]
	if !ok {
		return fmt.Errorf("文件不存在")
	}

	entry.OriginName = newName
	entry.Type = getFileType(newName)
	entry.ModifiedAt = time.Now()
	vm.saveManifest()
	return nil
}

// DeleteFile 删除加密文件
func (vm *VaultManager) DeleteFile(fileID string) error {
	if !vm.IsUnlocked() {
		return fmt.Errorf("加密空间已锁定")
	}

	vm.mu.Lock()
	defer vm.mu.Unlock()

	entry, ok := vm.manifest[fileID]
	if !ok {
		return fmt.Errorf("文件不存在")
	}

	os.Remove(filepath.Join(vm.vaultDir, entry.EncName))
	delete(vm.manifest, fileID)
	vm.saveManifest()
	return nil
}

// EncryptFileFromPath 从路径加密文件
func (vm *VaultManager) EncryptFileFromPath(srcPath, secret string) error {
	file, err := os.Open(srcPath)
	if err != nil {
		return err
	}
	defer file.Close()
	return vm.EncryptFile(filepath.Base(srcPath), file, secret)
}

// EncryptFolderFromPath 从路径加密文件夹
func (vm *VaultManager) EncryptFolderFromPath(srcPath, secret string) error {
	info, err := os.Stat(srcPath)
	if err != nil {
		return err
	}
	if !info.IsDir() {
		return fmt.Errorf("不是文件夹")
	}

	folderName := filepath.Base(srcPath)
	zipName := folderName + ".zip"

	tmpZip, err := os.CreateTemp("", "vault-*.zip")
	if err != nil {
		return err
	}
	tmpZipPath := tmpZip.Name()
	defer os.Remove(tmpZipPath)

	zipWriter := zip.NewWriter(tmpZip)
	filepath.Walk(srcPath, func(path string, fileInfo os.FileInfo, err error) error {
		if err != nil || fileInfo.IsDir() {
			return nil
		}
		relPath, _ := filepath.Rel(srcPath, path)
		header, _ := zip.FileInfoHeader(fileInfo)
		header.Name = filepath.ToSlash(relPath)
		header.Method = zip.Deflate
		writer, _ := zipWriter.CreateHeader(header)
		file, _ := os.Open(path)
		defer file.Close()
		io.Copy(writer, file)
		return nil
	})
	zipWriter.Close()
	tmpZip.Close()

	zipFile, _ := os.Open(tmpZipPath)
	defer zipFile.Close()
	return vm.EncryptFile(zipName, zipFile, secret)
}

// CreateShare 创建分享链接
func (vm *VaultManager) CreateShare(fileID, password string, expireHours, maxDownloads int) (*VaultShare, error) {
	if !vm.IsUnlocked() {
		return nil, fmt.Errorf("加密空间已锁定")
	}

	vm.mu.Lock()
	entry, ok := vm.manifest[fileID]
	vm.mu.Unlock()
	if !ok {
		return nil, fmt.Errorf("文件不存在")
	}

	tokenBytes := make([]byte, 16)
	rand.Read(tokenBytes)
	token := hex.EncodeToString(tokenBytes)

	share := &VaultShare{
		Token:        token,
		FileID:       fileID,
		FileName:     entry.OriginName,
		Password:     password,
		ExpireAt:     time.Now().Add(time.Duration(expireHours) * time.Hour),
		CreatedAt:    time.Now(),
		Downloads:    0,
		MaxDownloads: maxDownloads,
	}

	vm.mu.Lock()
	vm.shares[token] = share
	vm.saveShares()
	vm.mu.Unlock()

	return share, nil
}

// GetShare 获取分享链接
func (vm *VaultManager) GetShare(token string) (*VaultShare, error) {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	share, ok := vm.shares[token]
	if !ok {
		return nil, fmt.Errorf("分享链接不存在")
	}
	if time.Now().After(share.ExpireAt) {
		delete(vm.shares, token)
		vm.saveShares()
		return nil, fmt.Errorf("分享链接已过期")
	}
	return share, nil
}

// AccessShare 访问分享链接（下载文件）
func (vm *VaultManager) AccessShare(token, password string) ([]byte, string, error) {
	share, err := vm.GetShare(token)
	if err != nil {
		return nil, "", err
	}

	if share.Password != "" && share.Password != password {
		return nil, "", fmt.Errorf("分享密码错误")
	}

	if share.MaxDownloads > 0 && share.Downloads >= share.MaxDownloads {
		return nil, "", fmt.Errorf("下载次数已达上限")
	}

	// 解密文件需要 secret，但分享时不能暴露 secret
	// 这里需要一个特殊处理：分享时文件临时解密
	// 由于架构限制，分享功能需要已解锁状态
	if !vm.IsUnlocked() {
		return nil, "", fmt.Errorf("加密空间已锁定，无法访问分享")
	}

	vm.mu.Lock()
	share.Downloads++
	vm.saveShares()
	vm.mu.Unlock()

	// 使用当前解锁的 secret 解密
	return vm.DecryptFile(share.FileID, vm.secret)
}

// ListShares 列出分享链接
func (vm *VaultManager) ListShares() []*VaultShare {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	var shares []*VaultShare
	for _, s := range vm.shares {
		if time.Now().Before(s.ExpireAt) {
			shares = append(shares, s)
		}
	}
	return shares
}

// DeleteShare 删除分享链接
func (vm *VaultManager) DeleteShare(token string) {
	vm.mu.Lock()
	defer vm.mu.Unlock()
	delete(vm.shares, token)
	vm.saveShares()
}

// GetStatus 获取状态
func (vm *VaultManager) GetStatus() map[string]interface{} {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	var totalSize int64
	for _, e := range vm.manifest {
		totalSize += e.Size
	}

	// 检测是否为旧版本（无主密钥字段）
	isLegacy := vm.config.Enabled &&
		vm.config.MasterKeyByPassword == "" &&
		vm.config.MasterKeyByPattern == "" &&
		vm.config.MasterKeyByPIN == ""

	return map[string]interface{}{
		"enabled":       vm.config.Enabled,
		"unlocked":      vm.isUnlockedLocked(),
		"unlock_method": vm.config.UnlockMethod,
		"has_password":  vm.config.PasswordHash != "",
		"has_pattern":   vm.config.PatternHash != "",
		"has_pin":       vm.config.PINHash != "",
		"created_at":    vm.config.CreatedAt,
		"last_unlock":   vm.config.LastUnlock,
		"total_files":   len(vm.manifest),
		"total_size":    totalSize,
		"vault_dir":     vm.vaultDir,
		"algorithm":     "AES-256-GCM + SHA-256校验",
		"is_legacy":     isLegacy,
	}
}

func (vm *VaultManager) Reset() error {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	entries, _ := os.ReadDir(vm.vaultDir)
	for _, e := range entries {
		if !e.IsDir() {
			os.Remove(filepath.Join(vm.vaultDir, e.Name()))
		}
	}
	vm.config = &VaultConfig{Enabled: false, UnlockMethod: "any", CreatedAt: time.Now()}
	vm.manifest = make(map[string]*VaultFileEntry)
	vm.shares = make(map[string]*VaultShare)
	vm.unlocked = false
	vm.secret = ""
	vm.saveConfig()
	vm.saveManifest()
	vm.saveShares()
	return nil
}

// getFileType 判断文件类型
func getFileType(filename string) string {
	ext := strings.ToLower(filepath.Ext(filename))
	videoExts := map[string]bool{".mp4": true, ".mkv": true, ".avi": true, ".mov": true, ".wmv": true, ".flv": true, ".webm": true, ".m4v": true, ".ts": true, ".rmvb": true, ".3gp": true, ".mpg": true, ".mpeg": true}
	imageExts := map[string]bool{".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".bmp": true, ".webp": true, ".svg": true, ".heic": true, ".tiff": true, ".ico": true}
	audioExts := map[string]bool{".mp3": true, ".wav": true, ".flac": true, ".aac": true, ".ogg": true, ".m4a": true, ".wma": true, ".ape": true, ".opus": true}
	docExts := map[string]bool{".pdf": true, ".doc": true, ".docx": true, ".xls": true, ".xlsx": true, ".ppt": true, ".pptx": true, ".txt": true, ".md": true, ".rtf": true, ".csv": true}

	if videoExts[ext] {
		return "video"
	}
	if imageExts[ext] {
		return "image"
	}
	if audioExts[ext] {
		return "audio"
	}
	if docExts[ext] {
		return "document"
	}
	return "other"
}

// GetSupportedFormats 获取支持的文件格式
func GetSupportedFormats() map[string][]string {
	return map[string][]string{
		"视频":   {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm", ".m4v", ".ts", ".rmvb", ".3gp", ".mpg", ".mpeg"},
		"音乐":   {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma", ".ape", ".opus"},
		"图片":   {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".heic", ".tiff", ".ico"},
		"文档":   {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".md", ".rtf", ".csv"},
		"压缩包": {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"},
		"代码":   {".go", ".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".rs", ".rb", ".php", ".html", ".css", ".json", ".xml", ".yaml", ".yml", ".sh"},
		"安装包": {".apk", ".exe", ".msi", ".dmg", ".pkg", ".deb", ".rpm"},
		"其他":   {"*"},
	}
}

// GetFileDetail 获取文件详情
func (vm *VaultManager) GetFileDetail(fileID string) (*VaultFileEntry, error) {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	entry, ok := vm.manifest[fileID]
	if !ok {
		return nil, fmt.Errorf("文件不存在")
	}
	return entry, nil
}

// SaveEditedFile 保存编辑后的文件（重新加密）
func (vm *VaultManager) SaveEditedFile(fileID string, content []byte, secret string) error {
	if !vm.IsUnlocked() {
		return fmt.Errorf("加密空间已锁定")
	}

	vm.mu.Lock()
	entry, ok := vm.manifest[fileID]
	vm.mu.Unlock()
	if !ok {
		return fmt.Errorf("文件不存在")
	}

	// 删除旧加密文件
	os.Remove(filepath.Join(vm.vaultDir, entry.EncName))

	// 重新加密
	key := vm.deriveKey(secret)
	block, _ := aes.NewCipher(key)
	gcm, _ := cipher.NewGCM(block)
	nonce := make([]byte, gcm.NonceSize())
	io.ReadFull(rand.Reader, nonce)

	checksum := sha256.Sum256(content)
	ciphertext := gcm.Seal(nil, nonce, content, nil)

	encData := make([]byte, 0)
	encData = append(encData, []byte(VaultMagic)...)
	encData = append(encData, VaultVersion)
	encData = append(encData, nonce...)
	encData = append(encData, ciphertext...)
	encData = append(encData, checksum[:]...)

	encName := fileID + ".vault"
	os.WriteFile(filepath.Join(vm.vaultDir, encName), encData, 0600)

	// 更新 manifest
	vm.mu.Lock()
	entry.Size = int64(len(content))
	entry.EncSize = int64(len(encData))
	entry.Checksum = hex.EncodeToString(checksum[:])
	entry.ModifiedAt = time.Now()
	vm.saveManifest()
	vm.mu.Unlock()

	return nil
}

// RepairFile 修复加密文件（校验失败时尝试用备用密钥解密）
func (vm *VaultManager) RepairFile(fileID, secret string) (bool, error) {
	if !vm.IsUnlocked() {
		return false, fmt.Errorf("加密空间已锁定")
	}

	vm.mu.Lock()
	entry, ok := vm.manifest[fileID]
	vm.mu.Unlock()
	if !ok {
		return false, fmt.Errorf("文件不存在")
	}

	encData, err := os.ReadFile(filepath.Join(vm.vaultDir, entry.EncName))
	if err != nil {
		return false, err
	}

	key := vm.deriveKey(secret)
	block, _ := aes.NewCipher(key)
	gcm, _ := cipher.NewGCM(block)

	headerLen := len(VaultMagic) + 1
	nonceSize := gcm.NonceSize()

	// 尝试不同的 nonce 位置偏移来修复
	for offset := 0; offset <= 4; offset++ {
		if len(encData) < headerLen+offset+nonceSize+32 {
			continue
		}
		nonce := encData[headerLen+offset : headerLen+offset+nonceSize]
		ciphertext := encData[headerLen+offset+nonceSize : len(encData)-32]

		plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
		if err == nil {
			// 修复成功，重新正确加密
			checksum := sha256.Sum256(plaintext)
			newNonce := make([]byte, nonceSize)
			io.ReadFull(rand.Reader, newNonce)
			newCiphertext := gcm.Seal(nil, newNonce, plaintext, nil)

			newEncData := make([]byte, 0)
			newEncData = append(newEncData, []byte(VaultMagic)...)
			newEncData = append(newEncData, VaultVersion)
			newEncData = append(newEncData, newNonce...)
			newEncData = append(newEncData, newCiphertext...)
			newEncData = append(newEncData, checksum[:]...)

			os.WriteFile(filepath.Join(vm.vaultDir, entry.EncName), newEncData, 0600)

			vm.mu.Lock()
			entry.Size = int64(len(plaintext))
			entry.EncSize = int64(len(newEncData))
			entry.Checksum = hex.EncodeToString(checksum[:])
			entry.ModifiedAt = time.Now()
			vm.saveManifest()
			vm.mu.Unlock()

			return true, nil
		}
	}

	return false, fmt.Errorf("无法修复，密码错误或文件已损坏")
}

// CreateTempLink 创建临时访问链接（用于其他应用打开）
func (vm *VaultManager) CreateTempLink(fileID string, durationMinutes int) (string, error) {
	if !vm.IsUnlocked() {
		return "", fmt.Errorf("加密空间已锁定")
	}

	vm.mu.Lock()
	entry, ok := vm.manifest[fileID]
	vm.mu.Unlock()
	if !ok {
		return "", fmt.Errorf("文件不存在")
	}

	tokenBytes := make([]byte, 16)
	rand.Read(tokenBytes)
	token := hex.EncodeToString(tokenBytes)

	// 临时链接存储在 shares 中，设置短有效期
	share := &VaultShare{
		Token:        token,
		FileID:       fileID,
		FileName:     entry.OriginName,
		ExpireAt:     time.Now().Add(time.Duration(durationMinutes) * time.Minute),
		CreatedAt:    time.Now(),
		MaxDownloads: 0, // 不限次数
	}

	vm.mu.Lock()
	vm.shares[token] = share
	vm.saveShares()
	vm.mu.Unlock()

	return token, nil
}

// ===== HTTP API =====

func (h *NASHandler) handleVaultStatus(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(h.vaultMgr.GetStatus())
}

func (h *NASHandler) handleVaultInit(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	h.logger.Info("[VAULT] 收到初始化请求")
	var req struct {
		Password string `json:"password"`
		Pattern  string `json:"pattern"`
		PIN      string `json:"pin"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		h.logger.Error("[VAULT] 请求解析失败: %v", err)
		http.Error(w, "请求格式错误", http.StatusBadRequest)
		return
	}
	h.logger.Info("[VAULT] 密码:%v 图案:%v PIN:%v", req.Password != "", req.Pattern != "", req.PIN != "")

	if req.Password == "" && req.Pattern == "" && req.PIN == "" {
		http.Error(w, "至少设置一种解锁方式", http.StatusBadRequest)
		return
	}

	h.logger.Info("[VAULT] 开始初始化...")
	if err := h.vaultMgr.Initialize(req.Password, req.Pattern, req.PIN); err != nil {
		h.logger.Error("[VAULT] 初始化失败: %v", err)
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	h.logger.Info("[VAULT] 初始化成功")
	h.logger.Info("vault", "action", "加密空间已初始化")
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleVaultUnlock(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Password string `json:"password"`
		Pattern  string `json:"pattern"`
		PIN      string `json:"pin"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if err := h.vaultMgr.Unlock(req.Password, req.Pattern, req.PIN); err != nil {
		http.Error(w, err.Error(), http.StatusUnauthorized)
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleVaultLock(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	h.vaultMgr.Lock()
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleVaultFiles(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	fileType := r.URL.Query().Get("type")
	h.logger.Debug("[VAULT] 请求文件列表, type=%s, ip=%s", fileType, r.RemoteAddr)
	
	files := h.vaultMgr.ListFiles(fileType)
	if files == nil {
		h.logger.Warn("[VAULT] 文件列表请求失败: 加密空间已锁定, type=%s, 耗时=%v", fileType, time.Since(start))
		http.Error(w, "加密空间已锁定", http.StatusUnauthorized)
		return
	}
	
	h.logger.Info("[VAULT] 文件列表成功, type=%s, count=%d, 耗时=%v", fileType, len(files), time.Since(start))
	json.NewEncoder(w).Encode(map[string]interface{}{
		"files": files,
		"count": len(files),
		"type":  fileType,
	})
}

func (h *NASHandler) handleVaultUpload(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	r.ParseMultipartForm(100 << 20)
	secret := r.FormValue("secret")
	if secret == "" {
		secret = r.URL.Query().Get("secret")
	}
	h.logger.Debug("[VAULT] 开始上传文件, secret长度=%d, ip=%s", len(secret), r.RemoteAddr)
	
	file, header, err := r.FormFile("file")
	if err != nil {
		h.logger.Error("[VAULT] 上传文件获取失败: %v", err)
		http.Error(w, "No file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	h.logger.Info("[VAULT] 开始加密文件: %s, 大小=%d", header.Filename, header.Size)
	if err := h.vaultMgr.EncryptFile(header.Filename, file, secret); err != nil {
		h.logger.Error("[VAULT] 加密文件失败: %s, 错误=%v, 耗时=%v", header.Filename, err, time.Since(start))
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	h.logger.Info("[VAULT] 文件加密成功: %s, 耗时=%v", header.Filename, time.Since(start))
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleVaultDownload(w http.ResponseWriter, r *http.Request) {
	fileID := r.URL.Query().Get("id")
	secret := r.URL.Query().Get("secret")

	data, origName, err := h.vaultMgr.DecryptFile(fileID, secret)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", origName))
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Write(data)
}

func (h *NASHandler) handleVaultPreview(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	fileID := r.URL.Query().Get("id")
	secret := r.URL.Query().Get("secret")
	
	h.logger.Debug("[VAULT] 预览文件请求: id=%s, secret长度=%d, ip=%s", fileID, len(secret), r.RemoteAddr)

	data, origName, err := h.vaultMgr.DecryptFile(fileID, secret)
	if err != nil {
		h.logger.Error("[VAULT] 预览文件失败: id=%s, 错误=%v, 耗时=%v", fileID, err, time.Since(start))
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	ext := strings.ToLower(filepath.Ext(origName))
	contentType := "application/octet-stream"
	switch ext {
	case ".mp4", ".webm", ".ogg":
		contentType = "video/" + strings.TrimPrefix(ext, ".")
	case ".mp3", ".wav", ".flac", ".aac", ".m4a":
		contentType = "audio/" + strings.TrimPrefix(ext, ".")
	case ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp":
		contentType = "image/" + strings.TrimPrefix(ext, ".")
	case ".pdf":
		contentType = "application/pdf"
	case ".txt", ".md", ".csv":
		contentType = "text/plain; charset=utf-8"
	}

	h.logger.Info("[VAULT] 预览文件成功: %s, 大小=%d, 类型=%s, 耗时=%v", origName, len(data), contentType, time.Since(start))
	w.Header().Set("Content-Type", contentType)
	w.Header().Set("Content-Length", fmt.Sprintf("%d", len(data)))
	w.Header().Set("Content-Disposition", fmt.Sprintf("inline; filename=\"%s\"", origName))
	w.Write(data)
}

func (h *NASHandler) handleVaultRename(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		ID      string `json:"id"`
		NewName string `json:"new_name"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if err := h.vaultMgr.RenameFile(req.ID, req.NewName); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleVaultDeleteFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		ID string `json:"id"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if err := h.vaultMgr.DeleteFile(req.ID); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleVaultEncryptFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Path   string `json:"path"`
		Secret string `json:"secret"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if req.Path == "" {
		http.Error(w, "路径不能为空", http.StatusBadRequest)
		return
	}

	fullPath := filepath.Join(h.cfg.Storage.RootDir, req.Path)
	if !strings.HasPrefix(fullPath, h.cfg.Storage.RootDir) {
		http.Error(w, "非法路径", http.StatusForbidden)
		return
	}

	info, err := os.Stat(fullPath)
	if err != nil {
		http.Error(w, "文件不存在", http.StatusNotFound)
		return
	}

	if info.IsDir() {
		if err := h.vaultMgr.EncryptFolderFromPath(fullPath, req.Secret); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		h.logger.Info("文件夹已加密: %s", req.Path)
	} else {
		if err := h.vaultMgr.EncryptFileFromPath(fullPath, req.Secret); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		h.logger.Info("文件已加密: %s", req.Path)
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// handleVaultExportFile 导出加密文件到普通目录
func (h *NASHandler) handleVaultExportFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		FileID   string `json:"file_id"`
		Secret   string `json:"secret"`
		DestPath string `json:"dest_path"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if req.FileID == "" {
		http.Error(w, "文件ID不能为空", http.StatusBadRequest)
		return
	}

	// 解密文件
	data, origName, err := h.vaultMgr.DecryptFile(req.FileID, req.Secret)
	if err != nil {
		http.Error(w, "解密失败: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// 确定目标路径
	destDir := h.cfg.Storage.RootDir
	if req.DestPath != "" {
		destDir = filepath.Join(h.cfg.Storage.RootDir, req.DestPath)
		if !strings.HasPrefix(destDir, h.cfg.Storage.RootDir) {
			http.Error(w, "非法目标路径", http.StatusForbidden)
			return
		}
	}
	os.MkdirAll(destDir, 0755)

	// 处理重名
	destPath := filepath.Join(destDir, origName)
	if _, err := os.Stat(destPath); err == nil {
		ext := filepath.Ext(origName)
		base := strings.TrimSuffix(origName, ext)
		destPath = filepath.Join(destDir, base+"_decrypted"+ext)
	}

	// 写入文件
	if err := os.WriteFile(destPath, data, 0644); err != nil {
		http.Error(w, "写入失败: "+err.Error(), http.StatusInternalServerError)
		return
	}

	h.logger.Info("加密文件已导出: %s -> %s", origName, destPath)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"path":    strings.TrimPrefix(destPath, h.cfg.Storage.RootDir),
		"name":    origName,
	})
}

func (h *NASHandler) handleVaultFormats(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(GetSupportedFormats())
}

func (h *NASHandler) handleVaultReset(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if err := h.vaultMgr.Reset(); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	h.logger.Info("vault", "action", "加密空间已重置")
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// 分享链接 API
func (h *NASHandler) handleVaultShareCreate(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		FileID       string `json:"file_id"`
		Password     string `json:"password"`
		ExpireHours  int    `json:"expire_hours"`
		MaxDownloads int    `json:"max_downloads"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if req.ExpireHours == 0 {
		req.ExpireHours = 24
	}

	share, err := h.vaultMgr.CreateShare(req.FileID, req.Password, req.ExpireHours, req.MaxDownloads)
	if err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{"success": false, "error": err.Error()})
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success":  true,
		"share_id": share.Token,
		"share":    share,
	})
}

func (h *NASHandler) handleVaultShareList(w http.ResponseWriter, r *http.Request) {
	shares := h.vaultMgr.ListShares()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"shares": shares,
		"count":  len(shares),
	})
}

func (h *NASHandler) handleVaultShareDelete(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Token string `json:"token"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	h.vaultMgr.DeleteShare(req.Token)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleVaultShareAccess(w http.ResponseWriter, r *http.Request) {
	token := strings.TrimPrefix(r.URL.Path, "/share/")
	password := r.URL.Query().Get("password")

	data, filename, err := h.vaultMgr.AccessShare(token, password)
	if err != nil {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		fmt.Fprintf(w, "<html><body style='display:flex;align-items:center;justify-content:center;height:100vh;margin:0;font-family:sans-serif;background:#f5f5f5'><div style='text-align:center;background:#fff;padding:40px;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.1)'><div style='font-size:48px;margin-bottom:16px'>⚠️</div><h2>无法访问</h2><p style='color:#666'>%s</p><button onclick='history.back()' style='margin-top:16px;padding:10px 24px;background:#3d7eff;color:#fff;border:none;border-radius:8px;cursor:pointer'>返回</button></div></body></html>", err.Error())
		return
	}

	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", filename))
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Write(data)
}

// 文件详情
func (h *NASHandler) handleVaultFileDetail(w http.ResponseWriter, r *http.Request) {
	fileID := r.URL.Query().Get("id")
	entry, err := h.vaultMgr.GetFileDetail(fileID)
	if err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{"success": false, "error": err.Error()})
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{"success": true, "file": entry})
}

// 保存编辑后的文件
func (h *NASHandler) handleVaultSaveFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		FileID  string `json:"file_id"`
		Content string `json:"content"`
		Secret  string `json:"secret"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if err := h.vaultMgr.SaveEditedFile(req.FileID, []byte(req.Content), req.Secret); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{"success": false, "error": err.Error()})
		return
	}
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// 修复加密文件
func (h *NASHandler) handleVaultRepairFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		FileID string `json:"file_id"`
		Secret string `json:"secret"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	success, err := h.vaultMgr.RepairFile(req.FileID, req.Secret)
	if err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{"success": false, "error": err.Error()})
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": success,
		"message": "修复成功",
	})
}

// 创建临时链接（其他应用打开）
func (h *NASHandler) handleVaultTempLink(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		FileID         string `json:"file_id"`
		ExpireMinutes  int    `json:"expire_minutes"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if req.ExpireMinutes == 0 {
		req.ExpireMinutes = 10
	}

	token, err := h.vaultMgr.CreateTempLink(req.FileID, req.ExpireMinutes)
	if err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{"success": false, "error": err.Error()})
		return
	}

	scheme := "https"
	if r.TLS == nil {
		scheme = "http"
	}
	url := fmt.Sprintf("%s://%s/share/%s", scheme, r.Host, token)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"url":     "/share/" + token,
		"full_url": url,
	})
}
