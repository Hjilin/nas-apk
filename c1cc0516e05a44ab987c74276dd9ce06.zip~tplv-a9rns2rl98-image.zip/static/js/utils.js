/**
 * 工具函数模块
 */
const NAS_Utils = {
    /**
     * 格式化文件大小
     */
    formatSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },
    
    /**
     * 格式化时间
     */
    formatTime(seconds) {
        if (!seconds || isNaN(seconds)) return '00:00';
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    },
    
    /**
     * 格式化日期
     */
    formatDate(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        return d.getFullYear() + '/' + 
               String(d.getMonth() + 1).padStart(2, '0') + '/' + 
               String(d.getDate()).padStart(2, '0');
    },
    
    /**
     * 获取文件扩展名
     */
    getExt(name) {
        return name.split('.').pop().toLowerCase();
    },
    
    /**
     * 判断是否为视频文件
     */
    isVideoFile(path) {
        const ext = this.getExt(path);
        const videoExts = ['mp4', 'mkv', 'avi', 'mov', 'flv', 'webm', 'm4v', 'ts', 'mpg', 'mpeg', '3gp', 'wmv', 'rm', 'rmvb', 'vob', 'ogv', 'm2ts', 'mts', 'divx', 'xvid', 'f4v', 'f4p', 'f4a', 'f4b'];
        return videoExts.includes(ext);
    },
    
    /**
     * 判断是否为音频文件
     */
    isAudioFile(path) {
        const ext = this.getExt(path);
        const audioExts = ['mp3', 'wav', 'flac', 'aac', 'm4a', 'ogg', 'wma', 'ape', 'opus', 'aiff', 'alac', 'dsd', 'dsf', 'dff', 'wv', 'mka', 'tta', 'tak', 'mpc'];
        return audioExts.includes(ext);
    },
    
    /**
     * 判断是否为图片文件
     */
    isImageFile(path) {
        const ext = this.getExt(path);
        const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic', 'heif', 'avif', 'tiff', 'tif', 'svg', 'ico', 'raw', 'cr2', 'nef', 'arw', 'dng', 'psd', 'tga', 'jfif', 'pjpeg', 'pjp', 'apng', 'cur', 'dds', 'exr', 'hdr', 'jxl', 'pcx', 'pic', 'pix', 'pxr', 'sgi', 'tga', 'xbm', 'xpm'];
        return imageExts.includes(ext);
    },
    
    /**
     * 判断是否为文档文件
     */
    isDocumentFile(path) {
        const ext = this.getExt(path);
        const docExts = ['pdf', 'doc', 'docx', 'txt', 'md', 'ppt', 'pptx', 'xls', 'xlsx', 'csv', 'epub', 'mobi', 'rtf', 'odt', 'ods', 'odp', 'pages', 'numbers', 'key'];
        return docExts.includes(ext);
    },
    
    /**
     * 获取文件图标
     */
    getFileIcon(name) {
        const ext = this.getExt(name);
        if (this.isVideoFile(name)) return '🎬';
        if (this.isAudioFile(name)) return '🎵';
        if (this.isImageFile(name)) return '🖼️';
        if (this.isDocumentFile(name)) return '📄';
        if (['zip', 'rar', '7z', 'tar', 'gz', 'bz2'].includes(ext)) return '📦';
        if (['apk', 'exe', 'msi', 'dmg', 'pkg'].includes(ext)) return '⚙️';
        return '📄';
    },
    
    /**
     * 防抖
     */
    debounce(fn, delay = 300) {
        let timer = null;
        return function(...args) {
            clearTimeout(timer);
            timer = setTimeout(() => fn.apply(this, args), delay);
        };
    },
    
    /**
     * 节流
     */
    throttle(fn, delay = 300) {
        let last = 0;
        return function(...args) {
            const now = Date.now();
            if (now - last >= delay) {
                last = now;
                fn.apply(this, args);
            }
        };
    },
    
    /**
     * 显示Toast提示
     */
    toast(message, type = 'info', duration = 3000) {
        // 移除旧的toast
        const oldToast = document.getElementById('nas-toast');
        if (oldToast) oldToast.remove();
        
        const toast = document.createElement('div');
        toast.id = 'nas-toast';
        const colors = {
            info: '#667eea',
            success: '#43e97b',
            error: '#ff4757',
            warning: '#ffa502'
        };
        toast.style.cssText = `
            position: fixed;
            top: 80px;
            left: 50%;
            transform: translateX(-50%);
            background: ${colors[type] || colors.info};
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            z-index: 999999;
            font-size: 14px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            animation: toastIn 0.3s ease;
        `;
        toast.textContent = message;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'toastOut 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },
    
    /**
     * 确认对话框
     */
    confirm(message) {
        return new Promise((resolve) => {
            resolve(window.confirm(message));
        });
    }
};

// 添加toast动画
const toastStyle = document.createElement('style');
toastStyle.textContent = `
    @keyframes toastIn {
        from { opacity: 0; transform: translateX(-50%) translateY(-20px); }
        to { opacity: 1; transform: translateX(-50%) translateY(0); }
    }
    @keyframes toastOut {
        from { opacity: 1; transform: translateX(-50%) translateY(0); }
        to { opacity: 0; transform: translateX(-50%) translateY(-20px); }
    }
`;
document.head.appendChild(toastStyle);
