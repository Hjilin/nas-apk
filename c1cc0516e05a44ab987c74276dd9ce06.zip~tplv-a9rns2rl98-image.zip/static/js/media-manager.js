/**
 * 统一媒体管理器
 * 参考Android MediaManager架构设计
 * 管理视频/音乐/图片播放，音视频互斥，资源统一释放
 */
const MediaManager = {
    currentType: null, // 'video' | 'audio' | 'image' | null
    currentPath: null,
    videoPlayer: null, // ArtPlayer实例
    audioPlayer: null, // APlayer实例
    listeners: [],
    
    /**
     * 打开视频
     */
    openVideo(path, name) {
        this.releaseAll();
        this.currentType = 'video';
        this.currentPath = path;
        this._playVideo(path, name);
        this._notify('video', path);
    },
    
    /**
     * 打开音乐
     */
    openAudio(path, name) {
        this.releaseAll();
        this.currentType = 'audio';
        this.currentPath = path;
        this._playAudio(path, name);
        this._notify('audio', path);
    },
    
    /**
     * 打开图片
     */
    openImage(path) {
        this.releaseAll();
        this.currentType = 'image';
        this.currentPath = path;
        this._showImage(path);
        this._notify('image', path);
    },
    
    /**
     * 播放
     */
    play() {
        if (this.currentType === 'video' && this.videoPlayer) {
            this.videoPlayer.play();
        } else if (this.currentType === 'audio' && this.audioPlayer) {
            this.audioPlayer.play();
        }
    },
    
    /**
     * 暂停
     */
    pause() {
        if (this.currentType === 'video' && this.videoPlayer) {
            this.videoPlayer.pause();
        } else if (this.currentType === 'audio' && this.audioPlayer) {
            this.audioPlayer.pause();
        }
    },
    
    /**
     * 跳转
     */
    seekTo(seconds) {
        if (this.currentType === 'video' && this.videoPlayer) {
            this.videoPlayer.seek = seconds;
        } else if (this.currentType === 'audio' && this.audioPlayer) {
            this.audioPlayer.seek = seconds;
        }
    },
    
    /**
     * 获取时长
     */
    getDuration() {
        if (this.currentType === 'video' && this.videoPlayer) {
            return this.videoPlayer.duration;
        } else if (this.currentType === 'audio' && this.audioPlayer) {
            return this.audioPlayer.duration;
        }
        return 0;
    },
    
    /**
     * 获取当前位置
     */
    getCurrentTime() {
        if (this.currentType === 'video' && this.videoPlayer) {
            return this.videoPlayer.currentTime;
        } else if (this.currentType === 'audio' && this.audioPlayer) {
            return this.audioPlayer.currentTime;
        }
        return 0;
    },
    
    /**
     * 释放所有播放器（互斥关键）
     */
    releaseAll() {
        // 释放视频
        if (this.videoPlayer) {
            try { this.videoPlayer.destroy(); } catch (e) {}
            this.videoPlayer = null;
        }
        // 释放音乐
        if (this.audioPlayer) {
            try { this.audioPlayer.destroy(); } catch (e) {}
            this.audioPlayer = null;
        }
        // 关闭图片查看器
        const imgModal = document.getElementById('imageModal');
        if (imgModal) imgModal.classList.remove('active');
        // 关闭播放器弹窗
        const playerModal = document.getElementById('playerModal');
        if (playerModal) playerModal.classList.remove('active');
        
        this.currentType = null;
        this.currentPath = null;
        this._notify('release', null);
    },
    
    /**
     * 状态监听
     */
    onChange(callback) {
        this.listeners.push(callback);
    },
    
    _notify(type, path) {
        this.listeners.forEach(cb => {
            try { cb(type, path); } catch (e) {}
        });
    },
    
    /**
     * 内部：播放视频
     */
    _playVideo(path, name) {
        const modal = document.getElementById('playerModal');
        if (modal) modal.classList.add('active');
        
        const artContainer = document.getElementById('artplayerContainer');
        if (artContainer) artContainer.style.display = 'block';
        const apContainer = document.getElementById('aplayerContainer');
        if (apContainer) apContainer.style.display = 'none';
        
        setTimeout(() => {
            try {
                if (typeof ArtPlayer !== 'undefined') {
                    this.videoPlayer = new ArtPlayer({
                        container: artContainer,
                        url: '/webdav' + path,
                        title: name || '视频播放',
                        autoplay: true,
                        mutex: true,
                        theme: '#667eea',
                        setting: true,
                        hotkey: true,
                        pip: true,
                        fullscreen: true,
                        fullscreenWeb: true,
                        playbackRate: true,
                        aspectRatio: true,
                    });
                } else {
                    // 降级：原生video
                    if (artContainer) {
                        artContainer.innerHTML = '<video controls autoplay style="width:100%;max-height:70vh" src="/webdav' + path + '"></video>';
                    }
                }
            } catch (e) {
                console.error('视频播放失败:', e);
            }
        }, 100);
    },
    
    /**
     * 内部：播放音乐
     */
    _playAudio(path, name) {
        const modal = document.getElementById('playerModal');
        if (modal) modal.classList.add('active');
        
        const artContainer = document.getElementById('artplayerContainer');
        if (artContainer) artContainer.style.display = 'none';
        let apContainer = document.getElementById('aplayerContainer');
        if (!apContainer) {
            apContainer = document.createElement('div');
            apContainer.id = 'aplayerContainer';
            apContainer.style.cssText = 'width:100%;max-width:420px;margin:0 auto;padding:0 16px;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);';
            if (artContainer && artContainer.parentNode) {
                artContainer.parentNode.appendChild(apContainer);
            }
        }
        apContainer.style.display = 'block';
        
        setTimeout(() => {
            try {
                if (typeof APlayer !== 'undefined') {
                    this.audioPlayer = new APlayer({
                        container: apContainer,
                        audio: [{ name: name || '音乐播放', artist: 'NAS私有云', url: '/webdav' + path, cover: '' }],
                        theme: '#667eea',
                        loop: 'all',
                        order: 'list',
                        preload: 'auto',
                        volume: 0.7,
                        autoplay: true,
                        mutex: true,
                        lrcType: 0,
                        listFolded: true,
                        listMaxHeight: '150px',
                        storageName: 'nas-aplayer'
                    });
                } else {
                    // 降级：原生audio
                    apContainer.innerHTML = '<audio controls autoplay style="width:100%" src="/webdav' + path + '"></audio>';
                }
            } catch (e) {
                console.error('音乐播放失败:', e);
            }
        }, 100);
    },
    
    /**
     * 内部：显示图片
     */
    _showImage(path) {
        if (typeof openImage === 'function') {
            openImage(path);
        }
    }
};

// 兼容旧接口
function playVideo(path, name) { MediaManager.openVideo(path, name); }
function playMusic(path, name) { MediaManager.openAudio(path, name); }
function closePlayer() { MediaManager.releaseAll(); }
