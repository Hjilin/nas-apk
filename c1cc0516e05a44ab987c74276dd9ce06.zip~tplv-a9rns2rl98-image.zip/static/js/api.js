/**
 * NAS API 统一封装
 * 标准化所有API调用，统一返回格式
 */
const NAS_API = {
    baseUrl: '',
    
    /**
     * 统一请求方法
     * @param {string} url - API路径
     * @param {object} options - fetch选项
     * @returns {Promise<{success: boolean, data: any, error: string}>}
     */
    async request(url, options = {}) {
        try {
            const res = await fetch(this.baseUrl + url, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...(options.headers || {})
                }
            });
            
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                return {
                    success: false,
                    error: '响应格式错误: ' + text.substring(0, 100),
                    status: res.status
                };
            }
            
            // 统一处理返回格式
            if (data.success === false) {
                return {
                    success: false,
                    error: data.error || data.message || '未知错误',
                    data: data,
                    status: res.status
                };
            }
            
            return {
                success: true,
                data: data,
                status: res.status
            };
        } catch (e) {
            return {
                success: false,
                error: e.message || '网络错误',
                status: 0
            };
        }
    },
    
    // GET请求
    async get(url) {
        return this.request(url, { method: 'GET' });
    },
    
    // POST请求
    async post(url, body) {
        return this.request(url, {
            method: 'POST',
            body: JSON.stringify(body || {})
        });
    },
    
    // ========== 文件管理 API ==========
    
    // 获取文件列表
    async listFiles(path = '/') {
        return this.get('/api/list?path=' + encodeURIComponent(path));
    },
    
    // 创建文件夹
    async createFolder(path) {
        return this.post('/api/mkdir', { path });
    },
    
    // 删除文件
    async deleteFile(path) {
        return this.post('/api/delete', { path });
    },
    
    // 重命名
    async renameFile(oldPath, newName) {
        return this.post('/api/rename', { path: oldPath, name: newName });
    },
    
    // 复制文件
    async copyFile(src, dest) {
        return this.post('/api/copy', { src, dest });
    },
    
    // 移动文件
    async moveFile(src, dest) {
        return this.post('/api/move', { src, dest });
    },
    
    // 获取文件详情
    async fileInfo(path) {
        return this.get('/api/info?path=' + encodeURIComponent(path));
    },
    
    // ========== 系统 API ==========
    
    // 系统信息
    async systemInfo() {
        return this.get('/api/system/info');
    },
    
    // 存储大小
    async storageSize() {
        return this.get('/api/size');
    },
    
    // 通知列表
    async notifications() {
        return this.get('/api/notification/list');
    },
    
    // ========== 备份 API ==========
    
    // 备份列表
    async backupList() {
        return this.get('/api/backup/list');
    },
    
    // 创建备份
    async createBackup(sources) {
        return this.post('/api/backup/create', { sources });
    },
    
    // 恢复备份
    async restoreBackup(id, dest) {
        return this.post('/api/backup/restore', { id, dest });
    },
    
    // 删除备份
    async deleteBackup(id) {
        return this.post('/api/backup/delete', { id });
    },
    
    // ========== 加密空间 API ==========
    
    // 加密空间状态
    async vaultStatus() {
        return this.get('/api/vault/status');
    },
    
    // 初始化加密空间
    async vaultInit(data) {
        return this.post('/api/vault/init', data);
    },
    
    // 解锁加密空间
    async vaultUnlock(data) {
        return this.post('/api/vault/unlock', data);
    },
    
    // 加密空间文件列表
    async vaultList(path) {
        return this.get('/api/vault/list?path=' + encodeURIComponent(path || '/'));
    },
    
    // ========== 用户管理 API ==========
    
    // 用户列表
    async userList() {
        return this.get('/api/users/list');
    },
    
    // 创建用户
    async userCreate(data) {
        return this.post('/api/users/create', data);
    },
    
    // 删除用户
    async userDelete(username) {
        return this.post('/api/users/delete', { username });
    },
    
    // 更新用户权限
    async userUpdate(username, data) {
        return this.post('/api/users/update', { username, ...data });
    }
};
