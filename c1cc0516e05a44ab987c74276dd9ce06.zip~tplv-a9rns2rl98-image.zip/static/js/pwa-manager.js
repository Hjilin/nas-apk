/**
 * PWA 管理模块
 * 管理Service Worker、缓存、离线功能
 */
const PWAManager = {
    registration: null,
    isSupported: false,
    
    init() {
        this.isSupported = 'serviceWorker' in navigator;
        if (this.isSupported) {
            this.getRegistration();
        }
    },
    
    async getRegistration() {
        if (!this.isSupported) return null;
        try {
            this.registration = await navigator.serviceWorker.getRegistration('/static/sw.js');
            return this.registration;
        } catch (e) {
            console.error('获取SW注册失败:', e);
            return null;
        }
    },
    
    async register() {
        if (!this.isSupported) {
            return { success: false, error: '浏览器不支持Service Worker' };
        }
        try {
            this.registration = await navigator.serviceWorker.register('/static/sw.js');
            return { success: true };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },
    
    async unregister() {
        if (!this.registration) {
            return { success: false, error: '未找到Service Worker' };
        }
        try {
            const result = await this.registration.unregister();
            this.registration = null;
            return { success: result };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },
    
    async update() {
        if (!this.registration) {
            return { success: false, error: '未找到Service Worker' };
        }
        try {
            await this.registration.update();
            return { success: true, message: '正在更新...' };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },
    
    async getCacheList() {
        if (!('caches' in window)) {
            return { success: false, error: '浏览器不支持Cache API' };
        }
        try {
            const cacheNames = await caches.keys();
            const cachesInfo = [];
            for (const name of cacheNames) {
                const cache = await caches.open(name);
                const keys = await cache.keys();
                cachesInfo.push({
                    name: name,
                    itemCount: keys.length,
                    items: keys.map(k => k.url)
                });
            }
            return { success: true, caches: cachesInfo };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },
    
    async clearCache(cacheName) {
        if (!('caches' in window)) {
            return { success: false, error: '浏览器不支持Cache API' };
        }
        try {
            const result = await caches.delete(cacheName);
            return { success: result };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },
    
    async clearAllCaches() {
        if (!('caches' in window)) {
            return { success: false, error: '浏览器不支持Cache API' };
        }
        try {
            const cacheNames = await caches.keys();
            await Promise.all(cacheNames.map(name => caches.delete(name)));
            return { success: true, cleared: cacheNames.length };
        } catch (e) {
            return { success: false, error: e.message };
        }
    },
    
    async getStatus() {
        const status = {
            supported: this.isSupported,
            registered: !!this.registration,
            online: navigator.onLine,
            standalone: window.matchMedia('(display-mode: standalone)').matches,
            serviceWorker: null,
            caches: []
        };
        
        if (this.registration) {
            status.serviceWorker = {
                scope: this.registration.scope,
                active: !!this.registration.active,
                waiting: !!this.registration.waiting,
                installing: !!this.registration.installing
            };
        }
        
        const cacheResult = await this.getCacheList();
        if (cacheResult.success) {
            status.caches = cacheResult.caches;
        }
        
        return status;
    },
    
    async checkUpdate() {
        if (!this.registration) {
            return { success: false, error: '未注册Service Worker' };
        }
        try {
            await this.registration.update();
            await new Promise(resolve => setTimeout(resolve, 2000));
            const hasUpdate = !!this.registration.waiting;
            return { 
                success: true, 
                hasUpdate: hasUpdate,
                message: hasUpdate ? '发现新版本，刷新后生效' : '已是最新版本'
            };
        } catch (e) {
            return { success: false, error: e.message };
        }
    }
};

if (typeof window !== 'undefined') {
    PWAManager.init();
}
