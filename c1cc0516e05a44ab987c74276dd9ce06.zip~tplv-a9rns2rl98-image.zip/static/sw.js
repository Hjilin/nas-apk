/**
 * NAS PWA Service Worker
 * 支持离线缓存，为APK化做准备
 */

const CACHE_NAME = 'nas-cache-v1';
const STATIC_CACHE = 'nas-static-v1';

// 需要缓存的静态资源
const STATIC_ASSETS = [
    '/',
    '/static/js/api.js',
    '/static/js/media-manager.js',
    '/static/js/utils.js',
    '/static/css/base.css',
    '/static/css/components.css',
    '/static/artplayer.min.js',
    '/static/APlayer.min.js',
    '/static/APlayer.min.css',
    '/static/manifest.json',
];

// 安装时缓存静态资源
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(STATIC_CACHE).then((cache) => {
            return cache.addAll(STATIC_ASSETS).catch(() => {
                console.log('部分静态资源缓存失败');
            });
        })
    );
    self.skipWaiting();
});

// 激活时清理旧缓存
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames
                    .filter((name) => name !== CACHE_NAME && name !== STATIC_CACHE)
                    .map((name) => caches.delete(name))
            );
        })
    );
    self.clients.claim();
});

// 拦截请求，使用缓存策略
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    if (request.method !== 'GET') {
        return;
    }

    // API请求不缓存
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(
            fetch(request).catch(() => {
                return new Response(JSON.stringify({
                    success: false,
                    error: '网络连接失败，请检查网络'
                }), {
                    headers: { 'Content-Type': 'application/json' }
                });
            })
        );
        return;
    }

    // 静态资源：缓存优先
    if (url.pathname.startsWith('/static/')) {
        event.respondWith(
            caches.match(request).then((cached) => {
                const networkFetch = fetch(request).then((response) => {
                    if (response && response.status === 200) {
                        const responseClone = response.clone();
                        caches.open(STATIC_CACHE).then((cache) => {
                            cache.put(request, responseClone);
                        });
                    }
                    return response;
                }).catch(() => cached);
                return cached || networkFetch;
            })
        );
        return;
    }

    // 其他请求：网络优先，缓存兜底
    event.respondWith(
        fetch(request).then((response) => {
            if (response && response.status === 200) {
                const responseClone = response.clone();
                caches.open(CACHE_NAME).then((cache) => {
                    cache.put(request, responseClone);
                });
            }
            return response;
        }).catch(() => {
            return caches.match(request).then((cached) => {
                if (cached) return cached;
                return new Response('离线状态', { status: 503 });
            });
        })
    );
});
