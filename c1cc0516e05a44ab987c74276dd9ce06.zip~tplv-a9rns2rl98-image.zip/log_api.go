package main

import (
	"encoding/json"
	"net/http"
	"strconv"
)

// handleLogs 查询日志
func (h *NASHandler) handleLogs(w http.ResponseWriter, r *http.Request) {
	level := r.URL.Query().Get("level")
	module := r.URL.Query().Get("module")
	keyword := r.URL.Query().Get("keyword")
	limitStr := r.URL.Query().Get("limit")

	limit := 100
	if limitStr != "" {
		if l, err := strconv.Atoi(limitStr); err == nil && l > 0 {
			limit = l
		}
	}

	logs := h.logger.GetLogs(level, module, limit, keyword)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"logs":  logs,
		"count": len(logs),
	})
}

// handleLogStats 日志统计
func (h *NASHandler) handleLogStats(w http.ResponseWriter, r *http.Request) {
	stats := h.logger.GetLogStats()
	modules := h.logger.GetModules()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"stats":   stats,
		"modules": modules,
	})
}

// handleLogClear 清空日志
func (h *NASHandler) handleLogClear(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	h.logger.ClearLogs()
	h.logger.Info("system", "log", "日志已清空")
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}
