package main

import (
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"time"
)

// DebugInfo 调试信息
type DebugInfo struct {
	Timestamp   string         `json:"timestamp"`
	Version     string         `json:"version"`
	GoVersion   string         `json:"go_version"`
	OS          string         `json:"os"`
	Arch        string         `json:"arch"`
	Hostname    string         `json:"hostname"`
	Uptime      string         `json:"uptime"`
	Config      DebugConfig    `json:"config"`
	Network     DebugNetwork   `json:"network"`
	Storage     DebugStorage   `json:"storage"`
	Processes   []DebugProcess `json:"processes"`
	Environment []string       `json:"environment"`
	Warnings    []string       `json:"warnings"`
}

// DebugConfig 配置调试信息
type DebugConfig struct {
	StorageRoot  string `json:"storage_root"`
	StorageExists bool  `json:"storage_exists"`
	ListenAddr   string `json:"listen_addr"`
	HTTPS        bool   `json:"https"`
	CertFile     string `json:"cert_file"`
	CertExists   bool   `json:"cert_exists"`
	KeyFile      string `json:"key_file"`
	KeyExists    bool   `json:"key_exists"`
	Username     string `json:"username"`
	PasswordHash string `json:"password_hash"`
}

// DebugNetwork 网络调试信息
type DebugNetwork struct {
	Interfaces []DebugInterface `json:"interfaces"`
	OpenPorts  []string         `json:"open_ports"`
	DNS        []string         `json:"dns"`
}

// DebugInterface 网络接口
type DebugInterface struct {
	Name  string   `json:"name"`
	IPs   []string `json:"ips"`
	MAC   string   `json:"mac"`
	Up    bool     `json:"up"`
	MTU   int      `json:"mtu"`
}

// DebugStorage 存储调试信息
type DebugStorage struct {
	RootPath   string `json:"root_path"`
	TotalFiles int    `json:"total_files"`
	TotalDirs  int    `json:"total_dirs"`
	TotalSize  int64  `json:"total_size"`
	Writable   bool   `json:"writable"`
}

// DebugProcess 进程信息
type DebugProcess struct {
	PID     int    `json:"pid"`
	Name    string `json:"name"`
	CPU     string `json:"cpu"`
	Memory  string `json:"memory"`
	Status  string `json:"status"`
}

// HandleDebugInfo 处理调试信息请求
func (h *NASHandler) HandleDebugInfo(w http.ResponseWriter, r *http.Request) {
	info := &DebugInfo{
		Timestamp: time.Now().Format("2006-01-02 15:04:05"),
		Version:   "1.0.0",
		GoVersion: runtime.Version(),
		OS:        runtime.GOOS,
		Arch:      runtime.GOARCH,
	}

	// 主机名
	if hostname, err := os.Hostname(); err == nil {
		info.Hostname = hostname
	}

	// 配置信息
	info.Config = DebugConfig{
		StorageRoot:   h.cfg.Storage.RootDir,
		StorageExists: dirExists(h.cfg.Storage.RootDir),
		ListenAddr:    fmt.Sprintf("%s:%d", h.cfg.Server.Host, h.cfg.Server.Port),
		HTTPS:         h.cfg.Server.HTTPS,
		CertFile:      h.cfg.Server.CertFile,
		CertExists:    fileExists(h.cfg.Server.CertFile),
		KeyFile:       h.cfg.Server.KeyFile,
		KeyExists:     fileExists(h.cfg.Server.KeyFile),
		Username:      h.cfg.Auth.Username,
		PasswordHash:  h.cfg.Auth.PasswordHash[:20] + "...",
	}

	// 网络接口
	ifaces, _ := net.Interfaces()
	for _, iface := range ifaces {
		di := DebugInterface{
			Name: iface.Name,
			MAC:  iface.HardwareAddr.String(),
			Up:   iface.Flags&net.FlagUp != 0,
			MTU:  iface.MTU,
		}
		addrs, _ := iface.Addrs()
		for _, addr := range addrs {
			di.IPs = append(di.IPs, addr.String())
		}
		info.Network.Interfaces = append(info.Network.Interfaces, di)
	}

	// 存储信息
	info.Storage = DebugStorage{
		RootPath: h.cfg.Storage.RootDir,
		Writable: isWritable(h.cfg.Storage.RootDir),
	}
	countFiles(h.cfg.Storage.RootDir, &info.Storage.TotalFiles, &info.Storage.TotalDirs, &info.Storage.TotalSize)

	// 环境变量（过滤敏感信息）
	for _, env := range os.Environ() {
		if !strings.Contains(strings.ToLower(env), "password") &&
			!strings.Contains(strings.ToLower(env), "secret") &&
			!strings.Contains(strings.ToLower(env), "token") &&
			!strings.Contains(strings.ToLower(env), "key") {
			info.Environment = append(info.Environment, env)
		}
	}

	// 警告检查
	if !info.Config.CertExists && info.Config.HTTPS {
		info.Warnings = append(info.Warnings, "HTTPS 已启用但证书文件不存在")
	}
	if !info.Config.KeyExists && info.Config.HTTPS {
		info.Warnings = append(info.Warnings, "HTTPS 已启用但私钥文件不存在")
	}
	if !info.Storage.Writable {
		info.Warnings = append(info.Warnings, "存储目录不可写")
	}
	if h.cfg.Auth.PasswordHash == "" {
		info.Warnings = append(info.Warnings, "未设置密码哈希")
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(info)
}

// HandleDebugLogs 处理日志查看请求
func (h *NASHandler) HandleDebugLogs(w http.ResponseWriter, r *http.Request) {
	lines := 100
	if l := r.URL.Query().Get("lines"); l != "" {
		fmt.Sscanf(l, "%d", &lines)
	}

	// 读取日志文件
	logFile := h.cfg.Log.File
	if logFile == "" {
		// 尝试默认日志位置
		logFile = "nas.log"
	}

	var logs []string
	if data, err := os.ReadFile(logFile); err == nil {
		allLines := strings.Split(string(data), "\n")
		start := len(allLines) - lines
		if start < 0 {
			start = 0
		}
		logs = allLines[start:]
	} else {
		logs = []string{"日志文件不存在或无法读取: " + logFile}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"lines": logs,
		"total": len(logs),
		"file":  logFile,
	})
}

// HandleDebugTest 处理连接测试请求
func (h *NASHandler) HandleDebugTest(w http.ResponseWriter, r *http.Request) {
	target := r.URL.Query().Get("target")
	port := r.URL.Query().Get("port")
	if port == "" {
		port = "80"
	}

	result := map[string]interface{}{
		"target":    target,
		"port":      port,
		"timestamp": time.Now().Format("2006-01-02 15:04:05"),
	}

	if target != "" {
		// TCP 连接测试
		start := time.Now()
		conn, err := net.DialTimeout("tcp", net.JoinHostPort(target, port), 5*time.Second)
		elapsed := time.Since(start)
		if err != nil {
			result["tcp_connect"] = false
			result["error"] = err.Error()
			result["latency"] = elapsed.Milliseconds()
		} else {
			conn.Close()
			result["tcp_connect"] = true
			result["latency"] = elapsed.Milliseconds()
		}

		// DNS 解析测试
		dnsStart := time.Now()
		ips, err := net.LookupHost(target)
		dnsElapsed := time.Since(dnsStart)
		if err == nil {
			result["dns_resolved"] = ips
			result["dns_latency"] = dnsElapsed.Milliseconds()
		} else {
			result["dns_error"] = err.Error()
		}
	}

	// 本地端口监听测试
	localPorts := []string{"8443", "8080", "443", "80"}
	var listening []string
	for _, p := range localPorts {
		conn, err := net.DialTimeout("tcp", "127.0.0.1:"+p, 1*time.Second)
		if err == nil {
			listening = append(listening, p)
			conn.Close()
		}
	}
	result["local_listening"] = listening

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(result)
}

// HandleDebugCommand 处理命令执行请求（仅限安全命令）
func (h *NASHandler) HandleDebugCommand(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		Command string `json:"command"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}

	// 安全命令白名单
	allowedCommands := map[string][]string{
		"ifconfig":   {"ifconfig"},
		"ip_addr":    {"ip", "addr"},
		"ip_route":   {"ip", "route"},
		"ping":       {"ping", "-c", "3", "8.8.8.8"},
		"df":         {"df", "-h"},
		"free":       {"free", "-h"},
		"uptime":     {"uptime"},
		"uname":      {"uname", "-a"},
		"ps":         {"ps", "aux"},
		"top":        {"top", "-n", "1", "-b"},
		"netstat":    {"netstat", "-tlnp"},
		"ls_storage": {"ls", "-la", h.cfg.Storage.RootDir},
		"whoami":     {"whoami"},
		"date":       {"date"},
	}

	cmdArgs, ok := allowedCommands[req.Command]
	if !ok {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "不允许的命令",
			"allowed": getCommandList(allowedCommands),
		})
		return
	}

	cmd := exec.Command(cmdArgs[0], cmdArgs[1:]...)
	output, err := cmd.CombinedOutput()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": err == nil,
		"command": strings.Join(cmdArgs, " "),
		"output":  string(output),
		"error":   func() string { if err != nil { return err.Error() }; return "" }(),
	})
}

// HandleDebugConfig 处理配置检查请求
func (h *NASHandler) HandleDebugConfig(w http.ResponseWriter, r *http.Request) {
	checks := []map[string]interface{}{
		{
			"name":   "存储目录",
			"path":   h.cfg.Storage.RootDir,
			"exists": dirExists(h.cfg.Storage.RootDir),
			"status": checkStatus(dirExists(h.cfg.Storage.RootDir)),
		},
		{
			"name":   "证书文件",
			"path":   h.cfg.Server.CertFile,
			"exists": fileExists(h.cfg.Server.CertFile),
			"status": checkStatus(fileExists(h.cfg.Server.CertFile) || !h.cfg.Server.HTTPS),
		},
		{
			"name":   "私钥文件",
			"path":   h.cfg.Server.KeyFile,
			"exists": fileExists(h.cfg.Server.KeyFile),
			"status": checkStatus(fileExists(h.cfg.Server.KeyFile) || !h.cfg.Server.HTTPS),
		},
		{
			"name":   "密码哈希",
			"exists": h.cfg.Auth.PasswordHash != "",
			"status": checkStatus(h.cfg.Auth.PasswordHash != ""),
		},
		{
			"name":   "监听端口",
			"exists": true,
			"status": "info",
			"value":  fmt.Sprintf("%s:%d", h.cfg.Server.Host, h.cfg.Server.Port),
		},
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"checks": checks,
		"all_ok": allChecksPassed(checks),
	})
}

// 辅助函数
func dirExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.IsDir()
}

func fileExists(path string) bool {
	if path == "" {
		return false
	}
	info, err := os.Stat(path)
	return err == nil && !info.IsDir()
}

func isWritable(path string) bool {
	testFile := path + "/.write_test"
	if err := os.WriteFile(testFile, []byte("test"), 0644); err != nil {
		return false
	}
	os.Remove(testFile)
	return true
}

func countFiles(path string, files, dirs *int, size *int64) {
	entries, err := os.ReadDir(path)
	if err != nil {
		return
	}
	for _, entry := range entries {
		if strings.HasPrefix(entry.Name(), ".") {
			continue
		}
		fullPath := path + "/" + entry.Name()
		if entry.IsDir() {
			*dirs++
			countFiles(fullPath, files, dirs, size)
		} else {
			*files++
			if info, err := entry.Info(); err == nil {
				*size += info.Size()
			}
		}
	}
}

func checkStatus(ok bool) string {
	if ok {
		return "pass"
	}
	return "fail"
}

func allChecksPassed(checks []map[string]interface{}) bool {
	for _, c := range checks {
		if c["status"] == "fail" {
			return false
		}
	}
	return true
}

func getCommandList(cmds map[string][]string) []string {
	var list []string
	for k := range cmds {
		list = append(list, k)
	}
	return list
}
