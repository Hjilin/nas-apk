module nas-server

go 1.26.0

require (
	github.com/golang-jwt/jwt/v5 v5.2.1
	golang.org/x/crypto v0.31.0
	golang.org/x/image v0.46.0
	golang.org/x/net v0.33.0
	gopkg.in/yaml.v3 v3.0.1
)

require github.com/goftp/server v0.0.0-20200708154336-f64f7c2d8a42 // indirect
