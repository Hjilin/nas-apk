package main

import (
	"archive/zip"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"

	"golang.org/x/net/webdav"
)

// 前端热更新：从static目录读取HTML，支持不重新编译直接修改前端
var (
	customLoginHTML   string
	customFileMgrHTML string
)

func init() {
	// 启动时检查static目录下有没有自定义HTML
	workDir, _ := os.Getwd()
	if data, err := os.ReadFile(filepath.Join(workDir, "static", "login.html")); err == nil {
		customLoginHTML = string(data)
	}
	if data, err := os.ReadFile(filepath.Join(workDir, "static", "index.html")); err == nil {
		customFileMgrHTML = string(data)
	}
}

// getLoginHTML 获取登录页HTML（优先读文件，支持热更新）
func getLoginHTML() string {
	if customLoginHTML != "" {
		return customLoginHTML
	}
	return loginPageHTML
}

// getFileMgrHTML 获取主界面HTML（优先读文件，支持热更新）
func getFileMgrHTML() string {
	if customFileMgrHTML != "" {
		return customFileMgrHTML
	}
	return fileManagerHTML
}

// NASHandler NAS 服务处理器
type NASHandler struct {
	cfg          *Config
	auth         *AuthManager
	webdav       *webdav.Handler
	logger       *Logger
	mediaHandler *MediaHandler
	backupMgr    *BackupManager
	networkMgr   *NetworkManager
	thumbMgr     *ThumbnailManager
	sysMonitor   *SystemMonitor
	vpnMgr       *VPNManager
	noteMgr      *NoteManager
	appBackupMgr *AppBackupManager
	notifyMgr    *NotificationManager
	dlnaMgr      *DlnaManager
	encMgr       *EncryptionManager
	vaultMgr     *VaultManager
	staticDir    string // 静态文件目录（播放器库等）
}

// NewNASHandler 创建 NAS 处理器
func NewNASHandler(cfg *Config, auth *AuthManager, logger *Logger) *NASHandler {
	fs := webdav.Dir(cfg.Storage.RootDir)
	lockSystem := webdav.NewMemLS()
	notifyMgr := NewNotificationManager(cfg.Storage.RootDir)
	// 静态文件目录：优先使用可执行文件同目录下的static，其次使用当前目录
	staticDir := "static"
	if exePath, err := os.Executable(); err == nil {
		exeDir := filepath.Dir(exePath)
		if _, err := os.Stat(filepath.Join(exeDir, "static")); err == nil {
			staticDir = filepath.Join(exeDir, "static")
		}
	}
	return &NASHandler{
		cfg:          cfg,
		auth:         auth,
		logger:       logger,
		mediaHandler: NewMediaHandler(cfg, logger),
		backupMgr:    NewBackupManager(&cfg.Backup, logger, notifyMgr),
		networkMgr:   NewNetworkManager(&cfg.Network, logger),
		thumbMgr:     NewThumbnailManager(filepath.Join(cfg.Storage.RootDir, ".thumbs")),
		sysMonitor:   NewSystemMonitor(),
		vpnMgr:       NewVPNManager(filepath.Join(cfg.Storage.RootDir, ".vpn")),
		noteMgr:      NewNoteManager(cfg.Storage.RootDir),
		appBackupMgr: NewAppBackupManager(cfg.Storage.RootDir, logger),
		notifyMgr:    notifyMgr,
		dlnaMgr:      NewDlnaManager(cfg, logger, notifyMgr),
		encMgr:       NewEncryptionManager(cfg.Storage.RootDir, logger),
		vaultMgr:     NewVaultManager(cfg.Storage.RootDir, logger),
		staticDir:    staticDir,
		webdav: &webdav.Handler{
			FileSystem: fs,
			LockSystem: lockSystem,
			Prefix:     "/webdav",
		},
	}
}

// ServeHTTP 路由分发
func (h *NASHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Path

	switch {
	case path == "/api/login":
		h.handleLogin(w, r)
	case path == "/api/logout":
		h.handleLogout(w, r)
	case path == "/api/status":
		h.handleStatus(w, r)
	case path == "/api/list":
		h.handleFileList(w, r)
	case path == "/api/mkdir":
		h.handleMkdir(w, r)
	case path == "/api/create-file":
		h.handleCreateFile(w, r)
	case path == "/api/storage":
		h.handleStorage(w, r)
	case path == "/api/delete":
		h.handleDelete(w, r)
	case path == "/api/rename":
		h.handleRename(w, r)
	case path == "/api/move":
		h.handleMove(w, r)
	case path == "/api/copy":
		h.handleCopy(w, r)
	case path == "/api/thumb":
		h.HandleThumbnail(w, r)
	case path == "/api/search":
		h.handleSearch(w, r)
	case path == "/api/size":
		h.handleSize(w, r)
	case path == "/api/download/batch":
		h.handleBatchDownload(w, r)
	case path == "/api/compress":
		h.handleCompress(w, r)
	case path == "/api/extract":
		h.handleExtract(w, r)
	case path == "/api/zip/list":
		h.handleListZip(w, r)
	case path == "/api/compress/formats":
		h.handleSupportedFormats(w, r)
	case path == "/api/system/info":
		h.sysMonitor.HandleSystemInfo(w, r)
	case path == "/api/monitor/status":
		HandleMonitorStatus(w, r)
	case path == "/api/monitor/history":
		HandleMonitorHistory(w, r)
	case path == "/api/monitor/logs":
		HandleMonitorLogs(w, r)
	case path == "/api/vpn/status":
		h.vpnMgr.HandleVPNStatus(w, r)
	case path == "/api/vpn/config":
		h.vpnMgr.HandleVPNConfig(w, r)
	case path == "/api/vpn/clients":
		h.vpnMgr.HandleVPNClients(w, r)
	case path == "/api/vpn/client/config":
		h.vpnMgr.HandleVPNClientConfig(w, r)
	case path == "/api/vpn/client/delete":
		h.vpnMgr.HandleVPNClientDelete(w, r)
	case path == "/api/vpn/server/config":
		h.vpnMgr.HandleVPNServerConfig(w, r)
	case path == "/api/vpn/nas-client/config":
		h.vpnMgr.HandleVPNNASClientConfig(w, r)
	case path == "/api/debug/info":
		h.HandleDebugInfo(w, r)
	case path == "/api/debug/logs":
		h.HandleDebugLogs(w, r)
	case strings.HasPrefix(path, "/api/alist/"):
		alistAPIHandler(w, r)
	case strings.HasPrefix(path, "/alist/"):
		h.proxyAList(w, r)
	case strings.HasPrefix(path, "/static/"):
		h.handleStatic(w, r)
	case path == "/api/debug/test":
		h.HandleDebugTest(w, r)
	case path == "/api/debug/command":
		h.HandleDebugCommand(w, r)
	case path == "/api/debug/config":
		h.HandleDebugConfig(w, r)
	case path == "/api/notes/list":
		h.noteMgr.HandleNotesList(w, r)
	case path == "/api/notes/get":
		h.noteMgr.HandleNoteGet(w, r)
	case path == "/api/notes/create":
		h.noteMgr.HandleNoteCreate(w, r)
	case path == "/api/notes/update":
		h.noteMgr.HandleNoteUpdate(w, r)
	case path == "/api/notes/delete":
		h.noteMgr.HandleNoteDelete(w, r)
	case path == "/api/app/backup/list":
		h.handleAppBackupList(w, r)
	case path == "/api/app/backup/create":
		h.handleAppBackupCreate(w, r)
	case path == "/api/app/backup/detail":
		h.handleAppBackupDetail(w, r)
	case path == "/api/app/backup/delete":
		h.handleAppBackupDelete(w, r)
	case path == "/api/app/installed":
		h.handleAppInstalled(w, r)
	case path == "/api/app/download-links":
		h.handleAppDownloadLinks(w, r)
	case path == "/api/notification/list":
		h.handleNotificationList(w, r)
	case path == "/api/notification/read":
		h.handleNotificationRead(w, r)
	case path == "/api/notification/delete":
		h.handleNotificationDelete(w, r)
	case path == "/api/notification/test":
		h.handleNotificationTest(w, r)
	case path == "/api/dlna/status":
		h.handleDlnaStatus(w, r)
	case path == "/api/dlna/start":
		h.handleDlnaStart(w, r)
	case path == "/api/dlna/stop":
		h.handleDlnaStop(w, r)
	case path == "/api/dlna/media":
		h.handleDlnaMediaList(w, r)
	case path == "/api/encrypted/folders":
		h.handleEncryptedFolders(w, r)
	case path == "/api/encrypted/create":
		h.handleEncryptedCreate(w, r)
	case path == "/api/encrypted/delete":
		h.handleEncryptedDelete(w, r)
	case path == "/api/encrypted/unlock":
		h.handleEncryptedUnlock(w, r)
	case path == "/api/encrypted/files":
		h.handleEncryptedFiles(w, r)
	case path == "/api/encrypted/upload":
		h.handleEncryptedUpload(w, r)
	case path == "/api/encrypted/download":
		h.handleEncryptedDownload(w, r)
	case path == "/api/encrypted/delete-file":
		h.handleEncryptedDeleteFile(w, r)
	case path == "/api/vault/status":
		h.handleVaultStatus(w, r)
	case path == "/api/vault/init":
		h.handleVaultInit(w, r)
	case path == "/api/vault/unlock":
		h.handleVaultUnlock(w, r)
	case path == "/api/vault/lock":
		h.handleVaultLock(w, r)
	case path == "/api/vault/files":
		h.handleVaultFiles(w, r)
	case path == "/api/vault/upload":
		h.handleVaultUpload(w, r)
	case path == "/api/vault/download":
		h.handleVaultDownload(w, r)
	case path == "/api/vault/delete-file":
		h.handleVaultDeleteFile(w, r)
	case path == "/api/vault/reset":
		h.handleVaultReset(w, r)
	case path == "/api/vault/encrypt-file":
		h.handleVaultEncryptFile(w, r)
	case path == "/api/vault/export-file":
		h.handleVaultExportFile(w, r)
	case path == "/api/vault/formats":
		h.handleVaultFormats(w, r)
	case path == "/api/vault/preview":
		h.handleVaultPreview(w, r)
	case path == "/api/vault/rename":
		h.handleVaultRename(w, r)
	case path == "/api/vault/share/create":
		h.handleVaultShareCreate(w, r)
	case path == "/api/vault/share/list":
		h.handleVaultShareList(w, r)
	case path == "/api/vault/share/delete":
		h.handleVaultShareDelete(w, r)
	case strings.HasPrefix(path, "/share/"):
		h.handleVaultShareAccess(w, r)
	case path == "/api/vault/file-detail":
		h.handleVaultFileDetail(w, r)
	case path == "/api/vault/save-file":
		h.handleVaultSaveFile(w, r)
	case path == "/api/vault/repair-file":
		h.handleVaultRepairFile(w, r)
	case path == "/api/vault/temp-link":
		h.handleVaultTempLink(w, r)
	case path == "/api/logs":
		h.handleLogs(w, r)
	case path == "/api/logs/stats":
		h.handleLogStats(w, r)
	case path == "/api/logs/clear":
		h.handleLogClear(w, r)
	case path == "/api/media/scan":
		h.handleMediaScan(w, r)
	case path == "/api/media/list":
		h.handleMediaListStable(w, r)
	case path == "/api/media/refresh":
		h.handleMediaRefresh(w, r)
	case path == "/api/media/probe":
		h.handleMediaProbe(w, r)
	case path == "/api/media/transcode":
		h.handleMediaTranscode(w, r)
	case strings.HasPrefix(path, "/tmp-transcode/"):
		h.handleTranscodeFile(w, r)
	case path == "/api/media/audio-transcode":
		h.handleAudioTranscode(w, r)
	case path == "/api/backup/list":
		h.handleBackupList(w, r)
	case path == "/api/backup/create":
		h.handleBackupCreate(w, r)
	case path == "/api/backup/restore":
		h.handleBackupRestore(w, r)
	case path == "/api/backup/auto/status":
		h.handleBackupAutoStatus(w, r)
	case path == "/api/backup/auto/config":
		h.handleBackupAutoConfig(w, r)
	case path == "/api/backup/brand/preset":
		h.handleBackupBrandPreset(w, r)
	case path == "/api/backup/categories":
		h.handleBackupCategories(w, r)
	case path == "/api/backup/export":
		h.handleBackupExport(w, r)
	case path == "/api/backup/import":
		h.handleBackupImport(w, r)
	case path == "/api/users/list":
		h.handleUserList(w, r)
	case path == "/api/users/create":
		h.handleUserCreate(w, r)
	case path == "/api/users/update":
		h.handleUserUpdate(w, r)
	case path == "/api/users/delete":
		h.handleUserDelete(w, r)
	case path == "/api/users/permissions":
		h.handleUserPermissions(w, r)
	case path == "/api/users/set-permissions":
		h.handleUserSetPermissions(w, r)
	case strings.HasPrefix(path, "/api/backup/"):
		h.handleBackupDelete(w, r)
	case path == "/api/network/status":
		h.handleNetworkStatus(w, r)
	case path == "/api/network/join":
		h.handleNetworkJoin(w, r)
	case path == "/api/network/leave":
		h.handleNetworkLeave(w, r)
	case strings.HasPrefix(path, "/webdav/") || path == "/webdav":
		h.handleWebDAV(w, r)
	case strings.HasPrefix(path, "/static/"):
		h.handleStatic(w, r)
	case path == "/" || path == "/index.html":
		h.handleWebUI(w, r)
	default:
		http.NotFound(w, r)
	}
}

// handleStatic 静态文件服务（播放器库等）
func (h *NASHandler) handleStatic(w http.ResponseWriter, r *http.Request) {
	staticDir := "static"
	if _, err := os.Stat(staticDir); os.IsNotExist(err) {
		// 尝试从可执行文件目录查找
		if exe, err := os.Executable(); err == nil {
			staticDir = filepath.Join(filepath.Dir(exe), "static")
		}
	}
	fs := http.FileServer(http.Dir(staticDir))
	http.StripPrefix("/static/", fs).ServeHTTP(w, r)
}

// handleLogin 登录接口
func (h *NASHandler) handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	ip := GetClientIP(r, h.cfg.Security.TrustedProxy)
	if h.auth.IsLocked(ip) {
		http.Error(w, "Too many failed attempts, please try again later", http.StatusTooManyRequests)
		return
	}

	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}

	// 测试模式：直接内置账号密码，不用验证哈希
	if req.Username == "admin" && req.Password == "nas123456" {
		h.auth.RecordSuccessLogin(ip)
		token, err := h.auth.GenerateToken(req.Username)
		if err != nil {
			http.Error(w, "Failed to generate token", http.StatusInternalServerError)
			return
		}
		h.logger.Info("[测试模式登录成功] IP=%s 用户=%s", ip, req.Username)
		// 设置cookie（和正式模式一样）
		http.SetCookie(w, &http.Cookie{
			Name:     "nas_token",
			Value:    token,
			Path:     "/",
			HttpOnly: true,
			Secure:   h.cfg.Server.HTTPS,
			SameSite: http.SameSiteLaxMode,
			MaxAge:   h.cfg.Auth.TokenExpireHour * 3600,
		})
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": true,
			"token":   token,
		})
		return
	}

	// 正式模式：验证密码哈希
	if req.Username != h.cfg.Auth.Username || !h.auth.CheckPassword(req.Password) {
		h.auth.RecordFailedLogin(ip)
		h.logger.Warn("[登录失败] IP=%s 用户=%s", ip, req.Username)
		// 安全通知
		h.notifyMgr.Add("warning", "security", "登录失败",
			fmt.Sprintf("IP %s 使用用户名 %s 登录失败", ip, req.Username))
		http.Error(w, "Invalid username or password", http.StatusUnauthorized)
		return
	}

	h.auth.RecordSuccessLogin(ip)
	token, err := h.auth.GenerateToken(req.Username)
	if err != nil {
		http.Error(w, "Failed to generate token", http.StatusInternalServerError)
		return
	}

	h.logger.Info("[登录成功] IP=%s 用户=%s", ip, req.Username)

	// 设置 cookie
	http.SetCookie(w, &http.Cookie{
		Name:     "nas_token",
		Value:    token,
		Path:     "/",
		HttpOnly: true,
		Secure:   h.cfg.Server.HTTPS,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   h.cfg.Auth.TokenExpireHour * 3600,
	})

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"token":   token,
		"expires": h.cfg.Auth.TokenExpireHour,
	})
}

// handleLogout 登出接口
func (h *NASHandler) handleLogout(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:     "nas_token",
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		MaxAge:   -1,
	})
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// handleStatus 系统状态接口
// proxyAList 反向代理AList服务（解决HTTPS混合内容问题）
func (h *NASHandler) proxyAList(w http.ResponseWriter, r *http.Request) {
	target := "http://127.0.0.1:5244"
	proxy := &httputil.ReverseProxy{
		Rewrite: func(r *httputil.ProxyRequest) {
			r.SetURL(mustParseURL(target))
			r.Out.URL.Path = strings.TrimPrefix(r.In.URL.Path, "/alist")
			if r.Out.URL.Path == "" {
				r.Out.URL.Path = "/"
			}
			r.Out.Host = "127.0.0.1:5244"
			r.Out.Header.Set("X-Forwarded-Proto", "https")
			r.Out.Header.Set("X-Forwarded-Prefix", "/alist")
			// 关键：禁止AList返回压缩数据，方便重写HTML内容
			r.Out.Header.Set("Accept-Encoding", "identity")
		},
		ModifyResponse: func(resp *http.Response) error {
			// 移除Content-Encoding，因为我们已经要求不压缩
			resp.Header.Del("Content-Encoding")
			resp.Header.Del("Content-Length")

			// 重写Location头（重定向）
			if loc := resp.Header.Get("Location"); loc != "" {
				if strings.HasPrefix(loc, "http://127.0.0.1:5244/") {
					resp.Header.Set("Location", "/alist"+strings.TrimPrefix(loc, "http://127.0.0.1:5244"))
				} else if strings.HasPrefix(loc, "/") && !strings.HasPrefix(loc, "/alist/") && loc != "/" {
					resp.Header.Set("Location", "/alist"+loc)
				}
			}
			// 重写Set-Cookie的Path
			for i, cookie := range resp.Header.Values("Set-Cookie") {
				if strings.Contains(cookie, "Path=/") && !strings.Contains(cookie, "Path=/alist") {
					resp.Header.Values("Set-Cookie")[i] = strings.Replace(cookie, "Path=/", "Path=/alist", 1)
				}
			}
			// 重写HTML内容中的绝对路径
			contentType := resp.Header.Get("Content-Type")
			if strings.Contains(contentType, "text/html") {
				body, err := io.ReadAll(resp.Body)
				if err == nil {
					resp.Body.Close()
					html := string(body)
					// 替换各种绝对路径为 /alist/ 开头
					html = strings.ReplaceAll(html, `src="/`, `src="/alist/`)
					html = strings.ReplaceAll(html, `href="/`, `href="/alist/`)
					html = strings.ReplaceAll(html, `url(/`, `url(/alist/`)
					html = strings.ReplaceAll(html, `"/assets/`, `"/alist/assets/`)
					html = strings.ReplaceAll(html, `'/assets/`, `'/alist/assets/`)
					html = strings.ReplaceAll(html, `"/api/`, `"/alist/api/`)
					html = strings.ReplaceAll(html, `'/api/`, `'/alist/api/`)
					// 修复重复的 /alist/alist/
					html = strings.ReplaceAll(html, `/alist/alist/`, `/alist/`)
					resp.Body = io.NopCloser(strings.NewReader(html))
					resp.ContentLength = int64(len(html))
					resp.Header.Set("Content-Length", fmt.Sprintf("%d", len(html)))
				}
			}
			// 重写CSS和JS中的绝对路径（可选，可能影响性能）
			if strings.Contains(contentType, "text/css") || strings.Contains(contentType, "javascript") {
				body, err := io.ReadAll(resp.Body)
				if err == nil {
					resp.Body.Close()
					content := string(body)
					content = strings.ReplaceAll(content, `"/assets/`, `"/alist/assets/`)
					content = strings.ReplaceAll(content, `'/assets/`, `'/alist/assets/`)
					content = strings.ReplaceAll(content, `"/api/`, `"/alist/api/`)
					content = strings.ReplaceAll(content, `'/api/`, `'/alist/api/`)
					content = strings.ReplaceAll(content, `/alist/alist/`, `/alist/`)
					resp.Body = io.NopCloser(strings.NewReader(content))
					resp.ContentLength = int64(len(content))
					resp.Header.Set("Content-Length", fmt.Sprintf("%d", len(content)))
				}
			}
			return nil
		},
	}
	proxy.ErrorHandler = func(w http.ResponseWriter, r *http.Request, err error) {
		w.WriteHeader(http.StatusBadGateway)
		w.Write([]byte("AList服务未启动: " + err.Error()))
	}
	proxy.ServeHTTP(w, r)
}

func mustParseURL(s string) *url.URL {
	u, _ := url.Parse(s)
	return u
}

func (h *NASHandler) handleStatus(w http.ResponseWriter, r *http.Request) {
	// 统计存储使用
	var totalFiles int64
	var totalSize int64
	filepath.Walk(h.cfg.Storage.RootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		totalFiles++
		totalSize += info.Size()
		return nil
	})

	json.NewEncoder(w).Encode(map[string]interface{}{
		"storage_root": h.cfg.Storage.RootDir,
		"total_files":  totalFiles,
		"total_size":   totalSize,
		"read_only":    h.cfg.Storage.ReadOnly,
		"server_time":  time.Now().Format("2006-01-02 15:04:05"),
	})
}

// handleWebDAV WebDAV 文件服务
func (h *NASHandler) handleWebDAV(w http.ResponseWriter, r *http.Request) {
	// 只读模式下禁止写操作
	if h.cfg.Storage.ReadOnly {
		switch r.Method {
		case "PUT", "DELETE", "MKCOL", "COPY", "MOVE", "PROPPATCH":
			http.Error(w, "Read-only mode", http.StatusForbidden)
			return
		}
	}
	h.webdav.ServeHTTP(w, r)
}

// handleFileList 文件列表 API（供 Web UI 使用）
func (h *NASHandler) handleFileList(w http.ResponseWriter, r *http.Request) {
	dir := r.URL.Query().Get("path")
	if dir == "" {
		dir = "/"
	}
	// 防止路径遍历
	dir = filepath.Clean(dir)
	if strings.Contains(dir, "..") {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}

	fullPath := filepath.Join(h.cfg.Storage.RootDir, dir)
	entries, err := os.ReadDir(fullPath)
	if err != nil {
		http.Error(w, "Cannot read directory", http.StatusNotFound)
		return
	}

	type fileInfo struct {
		Name    string `json:"name"`
		Path    string `json:"path"`
		IsDir   bool   `json:"is_dir"`
		Size    int64  `json:"size"`
		ModTime string `json:"mod_time"`
	}

	var files []fileInfo
	for _, entry := range entries {
		info, err := entry.Info()
		if err != nil {
			continue
		}
		// 跳过隐藏扩展名
		ext := strings.ToLower(filepath.Ext(entry.Name()))
		hidden := false
		for _, he := range h.cfg.Storage.HiddenExt {
			if ext == strings.ToLower(he) {
				hidden = true
				break
			}
		}
		if hidden {
			continue
		}
		files = append(files, fileInfo{
			Name:    entry.Name(),
			Path:    filepath.Join(dir, entry.Name()),
			IsDir:   entry.IsDir(),
			Size:    info.Size(),
			ModTime: info.ModTime().Format("2006-01-02 15:04:05"),
		})
	}

	// 文件夹在前，按名称排序
	sort.Slice(files, func(i, j int) bool {
		if files[i].IsDir != files[j].IsDir {
			return files[i].IsDir
		}
		return files[i].Name < files[j].Name
	})

	json.NewEncoder(w).Encode(map[string]interface{}{
		"path":  dir,
		"files": files,
	})
}

// handleWebUI Web 管理界面
func (h *NASHandler) handleWebUI(w http.ResponseWriter, r *http.Request) {
	// 先检查URL参数里有没有token（从本地登录页跳转过来）
	urlToken := r.URL.Query().Get("token")
	if urlToken != "" {
		if _, err := h.auth.ValidateToken(urlToken); err == nil {
			// token有效，自动设置cookie
			http.SetCookie(w, &http.Cookie{
				Name:     "nas_token",
				Value:    urlToken,
				Path:     "/",
				MaxAge:   86400 * 7,
				HttpOnly: false,
				SameSite: http.SameSiteLaxMode,
			})
			// 跳转到主页面（去掉URL里的token参数）
			http.Redirect(w, r, "/", http.StatusFound)
			return
		}
	}

	// 检查是否已登录
	token := ExtractToken(r)
	if token == "" {
		// 显示登录页
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write([]byte(getLoginHTML()))
		return
	}
	if _, err := h.auth.ValidateToken(token); err != nil {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write([]byte(getLoginHTML()))
		return
	}

	// 显示文件管理页
	tmpl, err := template.New("ui").Parse(getFileMgrHTML())
	if err != nil {
		http.Error(w, "Template error", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	tmpl.Execute(w, map[string]interface{}{
		"UploadMax": h.cfg.Server.UploadMax,
		"ReadOnly":  h.cfg.Storage.ReadOnly,
	})
}

// safePath 安全路径拼接，防止路径遍历
func (h *NASHandler) safePath(relPath string) (string, bool) {
	relPath = filepath.Clean(relPath)
	if strings.Contains(relPath, "..") {
		return "", false
	}
	full := filepath.Join(h.cfg.Storage.RootDir, relPath)
	absRoot, _ := filepath.Abs(h.cfg.Storage.RootDir)
	absFull, _ := filepath.Abs(full)
	if !strings.HasPrefix(absFull, absRoot) {
		return "", false
	}
	return full, true
}

// handleMkdir 新建文件夹
func (h *NASHandler) handleMkdir(w http.ResponseWriter, r *http.Request) {
	if h.cfg.Storage.ReadOnly {
		http.Error(w, "Read-only mode", http.StatusForbidden)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Path string `json:"path"`
		Name string `json:"name"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	full, ok := h.safePath(filepath.Join(req.Path, req.Name))
	if !ok {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}
	if err := os.MkdirAll(full, 0755); err != nil {
		http.Error(w, "Failed to create directory", http.StatusInternalServerError)
		return
	}
	h.logger.Info("[新建文件夹] %s", full)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// handleCreateFile 新建文本文件
func (h *NASHandler) handleCreateFile(w http.ResponseWriter, r *http.Request) {
	if h.cfg.Storage.ReadOnly {
		http.Error(w, "Read-only mode", http.StatusForbidden)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Path    string `json:"path"`
		Content string `json:"content"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	full, ok := h.safePath(req.Path)
	if !ok {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}
	if err := os.WriteFile(full, []byte(req.Content), 0644); err != nil {
		http.Error(w, "Failed to create file: "+err.Error(), http.StatusInternalServerError)
		return
	}
	h.logger.Info("[新建文件] %s", full)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// handleStorage 获取存储信息
func (h *NASHandler) handleStorage(w http.ResponseWriter, r *http.Request) {
	var stat syscall.Statfs_t
	if err := syscall.Statfs(h.cfg.Storage.RootDir, &stat); err != nil {
		json.NewEncoder(w).Encode(map[string]interface{}{"success": false, "error": err.Error()})
		return
	}
	total := stat.Blocks * uint64(stat.Bsize)
	free := stat.Bfree * uint64(stat.Bsize)
	used := total - free
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"total":   total,
		"free":    free,
		"used":    used,
	})
}

// handleDelete 删除文件/文件夹
func (h *NASHandler) handleDelete(w http.ResponseWriter, r *http.Request) {
	if h.cfg.Storage.ReadOnly {
		http.Error(w, "Read-only mode", http.StatusForbidden)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Path string `json:"path"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	full, ok := h.safePath(req.Path)
	if !ok {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}
	if err := os.RemoveAll(full); err != nil {
		http.Error(w, "Failed to delete", http.StatusInternalServerError)
		return
	}
	h.logger.Warn("[删除] %s", full)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// handleRename 重命名
func (h *NASHandler) handleRename(w http.ResponseWriter, r *http.Request) {
	if h.cfg.Storage.ReadOnly {
		http.Error(w, "Read-only mode", http.StatusForbidden)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Path    string `json:"path"`
		NewName string `json:"new_name"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	oldFull, ok := h.safePath(req.Path)
	if !ok {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}
	newFull, ok := h.safePath(filepath.Join(filepath.Dir(req.Path), req.NewName))
	if !ok {
		http.Error(w, "Invalid new name", http.StatusBadRequest)
		return
	}
	if err := os.Rename(oldFull, newFull); err != nil {
		http.Error(w, "Failed to rename", http.StatusInternalServerError)
		return
	}
	h.logger.Info("[重命名] %s -> %s", oldFull, newFull)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// handleMove 移动文件
func (h *NASHandler) handleMove(w http.ResponseWriter, r *http.Request) {
	if h.cfg.Storage.ReadOnly {
		http.Error(w, "Read-only mode", http.StatusForbidden)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		From string `json:"from"`
		To   string `json:"to"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	fromFull, ok := h.safePath(req.From)
	if !ok {
		http.Error(w, "Invalid source path", http.StatusBadRequest)
		return
	}
	toFull, ok := h.safePath(req.To)
	if !ok {
		http.Error(w, "Invalid target path", http.StatusBadRequest)
		return
	}
	if err := os.MkdirAll(filepath.Dir(toFull), 0755); err != nil {
		http.Error(w, "Failed to create target directory", http.StatusInternalServerError)
		return
	}
	if err := os.Rename(fromFull, toFull); err != nil {
		http.Error(w, "Failed to move", http.StatusInternalServerError)
		return
	}
	h.logger.Info("[移动] %s -> %s", fromFull, toFull)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// handleCopy 复制文件/文件夹
func (h *NASHandler) handleCopy(w http.ResponseWriter, r *http.Request) {
	if h.cfg.Storage.ReadOnly {
		http.Error(w, "Read-only mode", http.StatusForbidden)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		From string `json:"from"`
		To   string `json:"to"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	fromFull, ok := h.safePath(req.From)
	if !ok {
		http.Error(w, "Invalid source path", http.StatusBadRequest)
		return
	}
	toFull, ok := h.safePath(req.To)
	if !ok {
		http.Error(w, "Invalid target path", http.StatusBadRequest)
		return
	}
	if err := os.MkdirAll(filepath.Dir(toFull), 0755); err != nil {
		http.Error(w, "Failed to create target directory", http.StatusInternalServerError)
		return
	}
	// 递归复制
	if err := copyRecursive(fromFull, toFull); err != nil {
		http.Error(w, "Failed to copy: "+err.Error(), http.StatusInternalServerError)
		return
	}
	h.logger.Info("[复制] %s -> %s", fromFull, toFull)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// copyRecursive 递归复制文件或目录
func copyRecursive(src, dst string) error {
	info, err := os.Stat(src)
	if err != nil {
		return err
	}
	if info.IsDir() {
		if err := os.MkdirAll(dst, info.Mode()); err != nil {
			return err
		}
		entries, err := os.ReadDir(src)
		if err != nil {
			return err
		}
		for _, entry := range entries {
			if err := copyRecursive(filepath.Join(src, entry.Name()), filepath.Join(dst, entry.Name())); err != nil {
				return err
			}
		}
		return nil
	}
	// 复制文件
	srcFile, err := os.Open(src)
	if err != nil {
		return err
	}
	defer srcFile.Close()
	dstFile, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer dstFile.Close()
	if _, err := io.Copy(dstFile, srcFile); err != nil {
		return err
	}
	return os.Chmod(dst, info.Mode())
}

// handleSearch 搜索文件
func (h *NASHandler) handleSearch(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query().Get("q")
	searchPath := r.URL.Query().Get("path")
	if query == "" {
		json.NewEncoder(w).Encode(map[string]interface{}{"files": []interface{}{}})
		return
	}
	if searchPath == "" {
		searchPath = "/"
	}
	rootFull, ok := h.safePath(searchPath)
	if !ok {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}
	var results []map[string]interface{}
	queryLower := strings.ToLower(query)
	filepath.Walk(rootFull, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		// 跳过隐藏目录和缓存目录
		if info.IsDir() && strings.HasPrefix(info.Name(), ".") {
			if path != rootFull {
				return filepath.SkipDir
			}
		}
		if strings.Contains(strings.ToLower(info.Name()), queryLower) {
			relPath, _ := filepath.Rel(h.cfg.Storage.RootDir, path)
			relPath = "/" + strings.ReplaceAll(relPath, "\\", "/")
			results = append(results, map[string]interface{}{
				"name":     info.Name(),
				"path":     relPath,
				"is_dir":   info.IsDir(),
				"size":     info.Size(),
				"mod_time": info.ModTime().Format("2006-01-02 15:04:05"),
			})
		}
		// 限制结果数量
		if len(results) >= 200 {
			return filepath.SkipDir
		}
		return nil
	})
	// 确保不为null
	if results == nil {
		results = []map[string]interface{}{}
	}
	json.NewEncoder(w).Encode(map[string]interface{}{"files": results, "count": len(results)})
}

// handleSize 获取文件夹大小
func (h *NASHandler) handleSize(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Query().Get("path")
	if path == "" {
		path = "/"
	}
	fullPath, ok := h.safePath(path)
	if !ok {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}
	var totalSize int64
	var fileCount int64
	filepath.Walk(fullPath, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if !info.IsDir() {
			totalSize += info.Size()
			fileCount++
		}
		return nil
	})
	json.NewEncoder(w).Encode(map[string]interface{}{
		"path":  path,
		"size":  totalSize,
		"count": fileCount,
	})
}

// handleBatchDownload 批量下载（打包成zip）
func (h *NASHandler) handleBatchDownload(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Paths []string `json:"paths"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	if len(req.Paths) == 0 {
		http.Error(w, "No files selected", http.StatusBadRequest)
		return
	}
	w.Header().Set("Content-Type", "application/zip")
	w.Header().Set("Content-Disposition", "attachment; filename=\"nas-download.zip\"")
	zw := zip.NewWriter(w)
	defer zw.Close()
	for _, p := range req.Paths {
		fullPath, ok := h.safePath(p)
		if !ok {
			continue
		}
		info, err := os.Stat(fullPath)
		if err != nil {
			continue
		}
		if info.IsDir() {
			// 递归添加目录
			baseName := filepath.Base(fullPath)
			filepath.Walk(fullPath, func(filePath string, fileInfo os.FileInfo, err error) error {
				if err != nil || fileInfo.IsDir() {
					return nil
				}
				relPath, _ := filepath.Rel(fullPath, filePath)
				zipPath := filepath.Join(baseName, relPath)
				addFileToZip(zw, filePath, zipPath)
				return nil
			})
		} else {
			addFileToZip(zw, fullPath, info.Name())
		}
	}
	h.logger.Info("[批量下载] %d 个文件", len(req.Paths))
}

func addFileToZip(zw *zip.Writer, filePath, zipPath string) {
	file, err := os.Open(filePath)
	if err != nil {
		return
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return
	}
	header, err := zip.FileInfoHeader(info)
	if err != nil {
		return
	}
	header.Name = zipPath
	header.Method = zip.Deflate
	writer, err := zw.CreateHeader(header)
	if err != nil {
		return
	}
	io.Copy(writer, file)
}

// 登录页 HTML
const loginPageHTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NAS 登录</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.login-box{background:#fff;padding:32px;border-radius:8px;box-shadow:0 20px 60px rgba(0,0,0,.3);width:100%;max-width:360px}
.logo-area{text-align:center;margin-bottom:32px}
.logo-icon{width:80px;height:80px;border-radius:16px;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:40px;color:#fff}
h1{text-align:center;color:#333;margin-bottom:8px;font-size:24px;font-weight:600}
.subtitle{text-align:center;color:#999;margin-bottom:0;font-size:16px}
.form-group{margin-bottom:16px}
label{display:block;color:#555;margin-bottom:8px;font-size:14px;font-weight:500}
input{width:100%;padding:0 16px;height:56px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;transition:border-color .2s}
input:focus{outline:none;border-color:#667eea}
button{width:100%;height:48px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;transition:opacity .2s;margin-top:8px}
button:hover{opacity:.9}
button:active{opacity:.8}
.error{color:#e74c3c;text-align:center;margin-top:16px;font-size:14px;min-height:20px}
.helper-links{display:flex;justify-content:space-between;margin-top:16px;font-size:14px}
.helper-links a{color:#667eea;text-decoration:none}
.helper-links a:hover{text-decoration:underline}
/* 响应式适配 */
@media screen and (max-width:359px){
body{padding:16px}
.login-box{padding:24px}
.logo-icon{width:64px;height:64px;font-size:32px}
h1{font-size:20px}
.subtitle{font-size:14px}
input{height:48px;font-size:14px}
button{height:44px;font-size:14px}
}
@media screen and (min-width:600px){
.login-box{max-width:400px;padding:40px}
}
@media screen and (orientation:landscape){
body{padding:24px}
.login-box{max-width:480px}
.logo-area{margin-bottom:24px}
}
</style>
</head>
<body>
<div class="login-box">
<div class="logo-area">
<div class="logo-icon">📁</div>
<h1>NAS 私有云</h1>
<p class="subtitle">安全文件管理系统</p>
</div>
<form id="loginForm">
<div class="form-group">
<label>用户名</label>
<input type="text" id="username" autocomplete="username" required>
</div>
<div class="form-group">
<label>密码</label>
<div style="position:relative">
<input type="password" id="password" autocomplete="current-password" required style="width:100%;padding-right:44px;box-sizing:border-box;height:48px;border:1px solid #ddd;border-radius:8px;padding-left:12px;font-size:16px">
<button type="button" id="pwdToggleBtn" onclick="togglePwd(this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;font-size:20px;cursor:pointer;padding:4px;line-height:1;z-index:10">👁️</button>
</div>
</div>
<button type="submit">登 录</button>
<div class="error" id="error"></div>
</form>
</div>
<script>
function togglePwd(btn){
const pwd=document.getElementById('password');
if(pwd.type==='password'){
pwd.type='text';
btn.textContent='🙈';
}else{
pwd.type='password';
btn.textContent='👁️';
}
}
document.getElementById('loginForm').addEventListener('submit',async function(e){
e.preventDefault();
const err=document.getElementById('error');
err.textContent='';
try{
const res=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:document.getElementById('username').value,password:document.getElementById('password').value})});
if(res.ok){
const data=await res.json().catch(()=>({}));
if(data.token)localStorage.setItem('token',data.token);
location.reload();
}else{err.textContent='用户名或密码错误';}
}catch(e){err.textContent='网络错误';}
});
</script>
</body>
</html>`

// 文件管理页 HTML（高级版：文件/媒体/备份/组网 四标签页）

// 文件管理页 HTML（高级版：网格/列表视图 + 多选 + 复制剪切粘贴删除移动）
const fileManagerHTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<title>NAS 私有云</title>
<script>
// ===== 全局错误捕获：最优先执行，禁用JS错误弹窗 =====
window.onerror=function(message,source,lineno,colno,error){
console.error('JS错误:',message,'行:',lineno);
return true; // 返回true阻止默认错误弹窗
};
window.addEventListener('unhandledrejection',function(event){
console.error('未处理Promise错误:',event.reason);
event.preventDefault();
});

// ===== 全局变量提前声明，避免暂时性死区 =====
var aplayer=null;
var artPlayer=null;
var currentPath='/';
var currentFilter='all';
var currentView='grid';
</script>
<style>
*{margin:0;padding:0;box-sizing:border-box;overscroll-behavior:none !important;-webkit-overflow-scrolling:auto !important}
*::-webkit-scrollbar{display:none !important}
:root{--icon-canvas:56px;--icon-body:40px;--icon-radius:12px;--safe-top:env(safe-area-inset-top,0px);--safe-bottom:env(safe-area-inset-bottom,0px)}
html,body{height:100%;overflow:hidden !important;position:fixed;width:100%;touch-action:manipulation;-webkit-user-select:none;user-select:none;background:#f5f5f5;margin:0;padding:0;left:0;top:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#f0f2f5}
/* 所有可滚动区域禁用皮筋效果 */
[style*="overflow-y:auto"],[style*="overflow-y:scroll"],[style*="overflow:auto"],[style*="overflow:scroll"]{
overscroll-behavior:none !important;
-webkit-overflow-scrolling:auto !important;
}
/* AppBar：56dp固定 */
.header{position:fixed;top:0;left:0;right:0;z-index:99999 !important;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:0 12px;height:48px;min-height:48px;display:none;justify-content:space-between;align-items:center;transition:transform .3s}
.header.show{display:flex !important}

/* 底部导航栏 */
.bottom-nav{
position:fixed;bottom:0;left:0;right:0;z-index:99998;
height:56px;background:#fff;border-top:1px solid #eee;
display:flex;padding-bottom:env(safe-area-inset-bottom);
}
.bottom-nav-item{
flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;
font-size:10px;color:#999;cursor:pointer;
}
.bottom-nav-item.active{color:#667eea}
.bottom-nav-item .icon{font-size:20px;margin-bottom:2px}
/* 内容区给底部导航留空间 */
.container{padding-bottom:56px !important}
.header h1{font-size:18px;font-weight:600;margin:0;display:block !important}
.header .btn{padding:6px 10px;font-size:12px;min-height:36px;display:inline-flex !important}
.header h1{font-size:18px;font-weight:600}
.header-btn{background:none;border:none;color:#fff;font-size:24px;cursor:pointer;width:48px;height:48px;min-width:48px;min-height:48px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:background .2s}
.header-btn:hover{background:rgba(255,255,255,.15)}
/* 标签页：56dp固定 */
.tabs{display:flex;background:#fff;border-bottom:1px solid #e8e8e8;overflow-x:auto;height:56px;min-height:56px}
.tab{padding:0 24px;height:56px;min-height:56px;cursor:pointer;font-size:14px;color:#666;border-bottom:3px solid transparent;white-space:nowrap;transition:all .2s;display:flex;align-items:center;justify-content:center}
.tab.active{color:#667eea;border-bottom-color:#667eea;font-weight:600}
/* 主界面 */
.home-panel{display:none !important;padding:20px 0}
.home-panel.active{display:block !important}
.home-header{text-align:center;padding:30px 20px 40px}
.home-header h2{font-size:24px;color:#333;margin-bottom:8px}
.home-header p{font-size:14px;color:#999}
.home-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px 8px;padding:16px 12px}
.home-card{background:#fff;border-radius:16px;padding:16px 8px;text-align:center;cursor:pointer;transition:all .25s;box-shadow:0 2px 10px rgba(0,0,0,.04);min-height:100px;display:flex;flex-direction:column;align-items:center;justify-content:center}
.home-card:hover{transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.1)}
.home-card:active{transform:scale(.95)}
.home-card.miui{background:#fff;border-radius:18px;padding:14px 6px}
.home-card.miui:hover{transform:scale(1.04)}
.miui-icon{width:var(--icon-canvas);height:var(--icon-canvas);border-radius:var(--icon-radius);display:flex;align-items:center;justify-content:center;margin:0 auto 6px;box-shadow:0 2px 8px rgba(0,0,0,.06)!important;transition:all .3s}
.miui-icon svg{filter:none;width:var(--icon-body)!important;height:var(--icon-body)!important;transition:all .3s}
/* 主界面图标颜色 */
.home-card:nth-child(1) .miui-icon svg{fill:#4facfe!important}
.home-card:nth-child(2) .miui-icon svg{fill:#fa709a!important}
.home-card:nth-child(3) .miui-icon svg{fill:#f093fb!important}
.home-card:nth-child(4) .miui-icon svg{fill:#43e97b!important}
.home-card:nth-child(5) .miui-icon svg{fill:#66a6ff!important}
.home-card:nth-child(6) .miui-icon svg{fill:#fcb69f!important}
.home-card:nth-child(7) .miui-icon svg{fill:#a18cd1!important}
.home-card:nth-child(8) .miui-icon svg{fill:#19547b!important}
.home-card:nth-child(9) .miui-icon svg{fill:#fff!important}
.home-card:nth-child(10) .miui-icon svg{fill:#fff!important}
.home-card:nth-child(11) .miui-icon svg{fill:#fff!important}
.home-card .card-icon{font-size:44px;margin-bottom:12px;line-height:1}
.home-card .card-title{font-size:12px;font-weight:600;color:#333;margin-bottom:0;margin-top:4px}
.home-card .card-subtitle{font-size:10px;color:#999;margin-top:2px}
.home-card .card-desc{font-size:10px;color:#999;line-height:1.3;margin-top:2px}
.home-card.files{background:linear-gradient(135deg,#667eea15,#764ba215)}
.home-card.media{background:linear-gradient(135deg,#f093fb15,#f5576c15)}
.home-card.backup{background:linear-gradient(135deg,#4facfe15,#00f2fe15)}
.home-card.network{background:linear-gradient(135deg,#43e97b15,#38f9d715)}
.home-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;padding:24px 16px 0}
.home-stat{background:#fff;border-radius:12px;padding:16px;text-align:center;border:1px solid #eee}
.home-stat .num{font-size:22px;font-weight:700;color:#667eea}
.home-stat .label{font-size:11px;color:#999;margin-top:4px}
/* 功能页返回栏 */
.page-header{display:flex;align-items:center;padding:12px 16px;padding-top:calc(12px + var(--safe-top));background:#fff;border-bottom:1px solid #eee;gap:12px;position:relative;z-index:10}
.back-btn{background:linear-gradient(135deg,#667eea,#764ba2);border:none;font-size:16px;cursor:pointer;color:#fff;padding:8px 16px;border-radius:20px;transition:all .2s;min-height:40px;display:flex;align-items:center;gap:6px;font-weight:500;box-shadow:0 2px 8px rgba(102,126,234,.3)}
.back-btn:hover{background:linear-gradient(135deg,#5a6fd6,#6a4190);transform:translateY(-1px)}
.back-btn:active{transform:translateY(0)}
.more-menu-item{padding:12px 16px;cursor:pointer;font-size:14px;color:#333;transition:background .15s;display:flex;align-items:center;gap:8px}
.more-menu-item:hover{background:#f5f5f5}
.more-menu-item:active{background:#e8e8e8}
/* Amaze原生布局样式 */
.native-appbar{display:flex;align-items:center;height:56px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:0 4px;padding-top:var(--safe-top);box-shadow:0 2px 8px rgba(0,0,0,.15);position:relative;z-index:20}
.appbar-btn{background:none;border:none;font-size:20px;cursor:pointer;padding:12px;border-radius:50%;min-width:48px;min-height:48px;display:flex;align-items:center;justify-content:center;color:#fff;transition:background .2s}
.appbar-btn:hover{background:rgba(255,255,255,.15)}
.appbar-btn:active{background:rgba(255,255,255,.25)}
.appbar-title{flex:1;font-size:16px;font-weight:500;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 8px}
.native-search{display:flex;align-items:center;padding:8px 16px;background:#fff;border-bottom:1px solid #eee;position:relative;z-index:9}
.native-search input{flex:1;padding:10px 16px;border:1px solid #ddd;border-radius:24px;font-size:14px;outline:none}
.native-search input:focus{border-color:#667eea}
.search-close{background:none;border:none;font-size:18px;cursor:pointer;padding:8px;margin-left:8px;color:#666}
.native-breadcrumb{padding:8px 16px;background:#fff;border-bottom:1px solid #f0f0f0;font-size:13px;color:#666;overflow-x:auto;white-space:nowrap}
.native-breadcrumb span{cursor:pointer;color:#667eea}
.native-breadcrumb span:hover{text-decoration:underline}
.file-stats{padding:6px 16px;font-size:12px;color:#999;background:#f5f5f5}
.native-file-content{background:#fff}
/* 原生列表项样式 */
.native-file-item{display:flex;align-items:center;padding:12px 16px;border-bottom:1px solid #f5f5f5;cursor:pointer;transition:background .15s;position:relative}
.native-file-item:hover{background:#f8f9fa}
.native-file-item.selected{background:#e8f0fe}
.native-file-icon{width:40px;height:40px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:24px;margin-right:16px;flex-shrink:0;background:#f0f0f0}
.native-file-icon.folder{background:linear-gradient(135deg,#ffeaa7,#fdcb6e)}
.native-file-icon.video{background:linear-gradient(135deg,#a29bfe,#6c5ce7)}
.native-file-icon.audio{background:linear-gradient(135deg,#81ecec,#00cec9)}
.native-file-icon.image{background:linear-gradient(135deg,#fab1a0,#e17055)}
.native-file-icon.doc{background:linear-gradient(135deg,#74b9ff,#0984e3)}
.native-file-icon.archive{background:linear-gradient(135deg,#dfe6e9,#b2bec3)}
.native-file-info{flex:1;min-width:0}
.native-file-name{font-size:15px;color:#333;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.native-file-meta{font-size:12px;color:#999;margin-top:2px}
.native-file-more{background:none;border:none;font-size:20px;cursor:pointer;padding:8px;border-radius:50%;color:#999;min-width:40px;min-height:40px;display:flex;align-items:center;justify-content:center}
.native-file-more:hover{background:#f0f0f0}
/* FAB按钮 */
.fab-btn{position:absolute;bottom:24px;right:24px;width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#ff4757,#ff6b81);color:#fff;border:none;font-size:28px;cursor:pointer;box-shadow:0 4px 12px rgba(255,71,87,.4);z-index:50;display:flex;align-items:center;justify-content:center;transition:transform .2s,box-shadow .2s}
.fab-btn:hover{transform:scale(1.05);box-shadow:0 6px 16px rgba(255,71,87,.5)}
.fab-btn:active{transform:scale(0.95)}
.fab-menu-item{padding:14px 20px;cursor:pointer;font-size:14px;color:#333;transition:background .15s;display:flex;align-items:center;gap:10px;white-space:nowrap}
.fab-menu-item:hover{background:#f5f5f5}
/* 底部操作栏 */
.native-bottom-bar{position:absolute;bottom:0;left:0;right:0;height:56px;background:#fff;box-shadow:0 -2px 8px rgba(0,0,0,.1);display:flex;align-items:center;padding:0 8px;z-index:90}
.bottom-nav-btn{background:none;border:none;font-size:20px;cursor:pointer;padding:12px;border-radius:50%;min-width:48px;min-height:48px;display:flex;align-items:center;justify-content:center;color:#333}
.bottom-nav-btn:hover{background:#f0f0f0}
.bottom-actions{display:flex;gap:4px;margin-left:auto}
.bottom-action-btn{background:none;border:none;font-size:18px;cursor:pointer;padding:10px;border-radius:50%;min-width:44px;min-height:44px;display:flex;align-items:center;justify-content:center;color:#555;transition:background .2s}
.bottom-action-btn:hover{background:#f0f0f0}
.bottom-action-btn.danger{color:#e74c3c}
.bottom-action-btn.danger:hover{background:#fde8e8}
/* 侧边栏 */
.sidebar-section{padding:8px 0}
.sidebar-title{padding:8px 20px;font-size:12px;color:#999;font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.sidebar-item{display:flex;align-items:center;gap:16px;padding:12px 20px;cursor:pointer;font-size:14px;color:#333;transition:background .15s}
.sidebar-item:hover{background:#f5f5f5}
.sidebar-item.active{background:#e8f0fe;color:#667eea;font-weight:500}
.sidebar-item span:first-child{font-size:20px;width:24px;text-align:center}
.page-title{font-size:16px;font-weight:600;color:#333;flex:1}
/* 音乐列表 - Android规范 */
.music-list{padding:0 16px 16px}
.music-item{display:flex;align-items:center;padding:8px 16px;min-height:56px;border-radius:8px;cursor:pointer;transition:background .2s;gap:16px}
.music-item:hover{background:#f5f5f5}
.music-item.playing{background:#e8f0fe}
.music-item .num{width:24px;color:#999;font-size:14px;text-align:center}
.music-item .cover{width:40px;height:40px;border-radius:8px;object-fit:cover;flex-shrink:0;background:#f0f0f0;display:flex;align-items:center;justify-content:center;font-size:20px}
.music-item .info{flex:1;min-width:0}
.music-item .name{font-size:16px;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500}
.music-item .artist{font-size:12px;color:#999;margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.music-item .size{color:#999;font-size:12px;flex-shrink:0}
.music-item .more{width:48px;height:48px;display:flex;align-items:center;justify-content:center;font-size:24px;color:#999;flex-shrink:0;cursor:pointer;border-radius:50%;transition:background .2s}
.music-item .more:hover{background:#e0e0e0}
/* 设置页面 - Android UI标准 */
.settings-menu{padding:16px}
.settings-group{margin-bottom:16px}
.settings-group-title{font-size:14px;color:#999;margin-bottom:8px;padding:0 4px;font-weight:500}
.settings-item{display:flex;align-items:center;padding:8px 16px;min-height:56px;background:#fff;border-radius:8px;margin-bottom:8px;cursor:pointer;transition:background .2s;border:1px solid #eee}
.settings-item:hover{background:#f8f9ff}
.settings-icon{font-size:24px;margin-right:16px;width:48px;height:48px;background:#f0f0f0;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.miui-settings-icon{width:48px;height:48px;border-radius:8px;background:#f5f6f8!important;box-shadow:0 1px 4px rgba(0,0,0,.06)!important}
.miui-settings-icon svg{filter:none;width:24px!important;height:24px!important}
/* 设置页图标颜色 */
.settings-item:nth-child(1) .miui-settings-icon svg{fill:#4facfe!important}
.settings-item:nth-child(2) .miui-settings-icon svg{fill:#43e97b!important}
.settings-item:nth-child(3) .miui-settings-icon svg{fill:#fa709a!important}
.settings-item:nth-child(4) .miui-settings-icon svg{fill:#a18cd1!important}
.settings-item:nth-child(5) .miui-settings-icon svg{fill:#66a6ff!important}
.settings-item:nth-child(6) .miui-settings-icon svg{fill:#19547b!important}
.settings-info{flex:1;min-width:0}
.settings-name{font-size:16px;font-weight:500;color:#333}
.settings-desc{font-size:12px;color:#999;margin-top:4px}
.settings-arrow{color:#ccc;font-size:24px;width:48px;height:48px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.toggle-switch{position:relative;width:52px;height:32px;background:#ccc;border-radius:16px;cursor:pointer;transition:background .3s;flex-shrink:0}
.toggle-switch.active{background:linear-gradient(135deg,#667eea,#764ba2)}
.toggle-switch::after{content:'';position:absolute;width:28px;height:28px;background:#fff;border-radius:50%;top:2px;left:2px;transition:left .3s;box-shadow:0 2px 6px rgba(0,0,0,.2)}
.toggle-switch.active::after{left:22px}
/* 在线笔记 */
.notes-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}
/* 自动备份 */
.auto-backup-card{background:#fff;border-radius:16px;padding:16px;margin:12px 16px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
.auto-backup-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.auto-backup-title{display:flex;align-items:center;gap:8px;font-size:16px;font-weight:600;color:#333}
.auto-backup-icon{font-size:22px}
.auto-backup-toggle{width:48px;height:26px;background:#ccc;border-radius:13px;position:relative;cursor:pointer;transition:background .3s}
.auto-backup-toggle.active{background:#3d7eff}
.auto-backup-toggle .toggle-circle{position:absolute;width:22px;height:22px;background:#fff;border-radius:50%;top:2px;left:2px;transition:left .3s;box-shadow:0 2px 4px rgba(0,0,0,.2)}
.auto-backup-toggle.active .toggle-circle{left:24px}
.auto-backup-info{background:#f8f9fa;border-radius:10px;padding:12px}
.auto-backup-row{display:flex;justify-content:space-between;padding:6px 0;font-size:13px;border-bottom:1px solid #eee}
.auto-backup-row:last-child{border-bottom:none}
.auto-backup-row span:first-child{color:#999}
.auto-backup-row span:last-child{color:#333;font-weight:500}
/* 应用备份入口 */
.app-backup-entry{display:flex;align-items:center;background:#fff;border-radius:16px;padding:16px;margin:0 16px 12px;cursor:pointer;transition:all .2s;box-shadow:0 2px 10px rgba(0,0,0,.05)}
.app-backup-entry:hover{transform:translateX(4px);box-shadow:0 4px 16px rgba(0,0,0,.1)}
.app-backup-icon{width:48px;height:48px;background:linear-gradient(135deg,#4facfe,#00f2fe);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;margin-right:14px;flex-shrink:0}
.app-backup-info{flex:1}
.app-backup-title{font-size:15px;font-weight:600;color:#333}
.app-backup-desc{font-size:12px;color:#999;margin-top:4px}
.app-backup-arrow{color:#ccc;font-size:24px;font-weight:300}
/* 应用备份弹窗 */
.app-list{max-height:50vh;overflow-y:auto;margin-top:12px}
.app-item{display:flex;align-items:center;padding:12px;border-bottom:1px solid #f0f0f0}
.app-item:last-child{border-bottom:none}
.app-item-icon{width:40px;height:40px;background:#f0f0f0;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;margin-right:12px;flex-shrink:0}
.app-item-info{flex:1;min-width:0}
.app-item-name{font-size:14px;font-weight:500;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.app-item-pkg{font-size:11px;color:#999;margin-top:2px}
.app-item-version{font-size:11px;color:#666}
.app-item-actions{display:flex;gap:6px;margin-left:8px}
.app-download-btn{padding:6px 10px;border-radius:8px;border:none;cursor:pointer;font-size:11px;font-weight:500;transition:all .2s}
.app-download-btn.play{background:#3d7eff;color:#fff}
.app-download-btn.browser{background:#f0f0f0;color:#333}
.app-download-btn:hover{opacity:.85}
/* 备份分类 */
.category-item{display:flex;align-items:center;padding:14px 12px;border-bottom:1px solid #f0f0f0;cursor:pointer;transition:background .2s}
.category-item:hover{background:#f8f9fa}
.category-item:last-child{border-bottom:none}
.category-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:22px;margin-right:14px;flex-shrink:0}
.category-info{flex:1;min-width:0}
.category-name{font-size:15px;font-weight:500;color:#333}
.category-meta{font-size:12px;color:#999;margin-top:4px}
.category-checkbox{width:22px;height:22px;border-radius:50%;border:2px solid #ccc;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s}
.category-item.selected .category-checkbox{background:#3d7eff;border-color:#3d7eff}
.category-item.selected .category-checkbox::after{content:'✓';color:#fff;font-size:14px;font-weight:bold}
.backup-tab.active{background:#fff;color:#333}
.backup-tab:not(.active){color:#999}
/* 通知 */
.notify-item{display:flex;gap:12px;padding:14px;border-radius:12px;margin-bottom:8px;background:#f8f9fa;cursor:pointer;transition:all .2s;border-left:4px solid transparent}
.notify-item:hover{background:#f0f0f0;transform:translateX(-2px)}
.notify-item.unread{background:#fff;border-left-color:#3d7eff;box-shadow:0 2px 8px rgba(61,126,255,.1)}
.notify-icon{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.notify-icon.info{background:#dbeafe;color:#3b82f6}
.notify-icon.success{background:#dcfce7;color:#22c55e}
.notify-icon.warning{background:#fef3c7;color:#f59e0b}
.notify-icon.error{background:#fee2e2;color:#ef4444}
.notify-content{flex:1;min-width:0}
.notify-title{font-size:14px;font-weight:600;color:#333;margin-bottom:4px}
.notify-message{font-size:12px;color:#666;line-height:1.4}
.notify-time{font-size:11px;color:#999;margin-top:6px}
.notify-empty{text-align:center;color:#999;padding:40px 20px}
.notify-empty-icon{font-size:48px;margin-bottom:12px;opacity:.5}
/* DLNA */
.dlna-status-card{display:flex;align-items:center;background:#fff;border-radius:16px;padding:20px;margin-bottom:16px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
.dlna-status-icon{width:56px;height:56px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:28px;margin-right:16px;flex-shrink:0}
.dlna-status-info{flex:1}
.dlna-status-title{font-size:16px;font-weight:600;color:#333}
.dlna-status-desc{font-size:12px;color:#999;margin-top:4px}
.dlna-info-section{background:#fff;border-radius:16px;padding:16px;margin-bottom:16px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
.dlna-info-title{font-size:14px;font-weight:600;color:#333;margin-bottom:12px}
.dlna-info-item{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f0f0f0;font-size:13px}
.dlna-info-item:last-child{border-bottom:none}
.dlna-info-item span:first-child{color:#999}
.dlna-info-item span:last-child{color:#333;font-weight:500}
.dlna-guide{background:#fff;border-radius:16px;padding:16px;margin-bottom:16px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
.dlna-guide-title{font-size:14px;font-weight:600;color:#333;margin-bottom:12px}
.dlna-guide-step{display:flex;align-items:flex-start;gap:12px;padding:8px 0;font-size:13px;color:#666;line-height:1.5}
.step-num{width:22px;height:22px;background:#667eea;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;flex-shrink:0}
.dlna-media-section{background:#fff;border-radius:16px;padding:16px;box-shadow:0 2px 10px rgba(0,0,0,.05)}
.dlna-media-item{display:flex;align-items:center;padding:12px 0;border-bottom:1px solid #f0f0f0}
.dlna-media-item:last-child{border-bottom:none}
.dlna-media-icon{width:36px;height:36px;background:#f0f0f0;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;margin-right:12px;flex-shrink:0}
.dlna-media-info{flex:1;min-width:0}
.dlna-media-name{font-size:13px;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dlna-media-size{font-size:11px;color:#999;margin-top:2px}
/* 加密存储 */
.enc-folder-card{display:flex;align-items:center;background:#fff;border-radius:16px;padding:16px;margin-bottom:12px;box-shadow:0 2px 10px rgba(0,0,0,.05);cursor:pointer;transition:all .2s}
.enc-folder-card:hover{transform:translateX(4px);box-shadow:0 4px 16px rgba(0,0,0,.1)}
.enc-folder-icon{width:48px;height:48px;background:linear-gradient(135deg,#f093fb,#f5576c);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;margin-right:14px;flex-shrink:0}
.enc-folder-info{flex:1;min-width:0}
.enc-folder-name{font-size:15px;font-weight:600;color:#333}
.enc-folder-meta{font-size:12px;color:#999;margin-top:4px}
.enc-folder-actions{display:flex;gap:6px}
.enc-file-item{display:flex;align-items:center;padding:12px;border-bottom:1px solid #f0f0f0}
.enc-file-item:last-child{border-bottom:none}
.enc-file-icon{width:36px;height:36px;background:#f0f0f0;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;margin-right:12px;flex-shrink:0}
.enc-file-info{flex:1;min-width:0}
.enc-file-name{font-size:13px;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.enc-file-meta{font-size:11px;color:#999;margin-top:2px}
/* 加密空间 */
.vault-stats{display:flex;gap:12px;margin-bottom:16px}
.vault-stat{flex:1;background:#fff;border-radius:12px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.vault-stat-num{font-size:20px;font-weight:700;color:#333}
.vault-stat-label{font-size:11px;color:#999;margin-top:4px}
.vault-unlock-tab{background:#f0f0f0;color:#666;border:none;padding:8px 16px;border-radius:8px;cursor:pointer;transition:all .2s}
.vault-unlock-tab.active{background:#3d7eff;color:#fff}
.vault-unlock-section{margin-top:16px}
/* 图案密码九宫格 */
.pattern-lock{display:grid;grid-template-columns:repeat(3,1fr);gap:32px;width:340px;max-width:90vw;margin:0 auto;padding:32px 24px;background:#f8f9fa;border-radius:20px;position:relative;touch-action:none;user-select:none;-webkit-user-select:none}
.pattern-dot{width:80px;height:80px;border-radius:50%;background:#fff;border:5px solid #ddd;display:flex;align-items:center;justify-content:center;transition:all .2s;position:relative;z-index:2;cursor:pointer}
.pattern-dot.active{background:#3d7eff;border-color:#3d7eff;transform:scale(1.15)}
.pattern-dot.active::after{content:'';width:28px;height:28px;background:#fff;border-radius:50%}
.pattern-line{position:absolute;background:#3d7eff;height:5px;transform-origin:left center;z-index:1;pointer-events:none}
.vault-file-item{display:flex;align-items:center;padding:12px;background:#fff;border-radius:12px;margin-bottom:8px;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.vault-file-icon{width:40px;height:40px;background:linear-gradient(135deg,#f093fb,#f5576c);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;margin-right:12px;flex-shrink:0}
.vault-file-info{flex:1;min-width:0}
.vault-file-name{font-size:13px;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vault-file-meta{font-size:11px;color:#999;margin-top:2px}
.vault-tabs{display:flex;gap:6px;margin-bottom:16px;overflow-x:auto;padding-bottom:4px}
.vault-tab{background:#f0f0f0;color:#666;border:none;padding:8px 14px;border-radius:20px;cursor:pointer;font-size:13px;white-space:nowrap;transition:all .2s}
.vault-tab.active{background:#3d7eff;color:#fff}
.vault-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.vault-grid-item{background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.05);cursor:pointer;position:relative}
.vault-grid-thumb{width:100%;aspect-ratio:1;background:#f5f5f5;display:flex;align-items:center;justify-content:center;font-size:32px}
.vault-grid-name{padding:8px;font-size:11px;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vault-grid-size{font-size:10px;color:#999}
.vault-features{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:24px;text-align:left}
.vault-feature{background:#fff;padding:12px;border-radius:12px;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.vault-feature-icon{font-size:20px;margin-bottom:6px}
.vault-feature-title{font-size:12px;font-weight:600;color:#333;margin-bottom:2px}
.vault-feature-desc{font-size:10px;color:#999}
/* Photok风格 */
.photok-dot{width:14px;height:14px;border-radius:50%;border:2px solid rgba(255,255,255,.5);transition:all .2s}
.photok-dot.filled{background:#fff;border-color:#fff}
.photok-dot.error{background:#ff6b6b;border-color:#ff6b6b}
.photok-keypad{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;width:280px}
.photok-keypad-small{width:240px;gap:12px}
.photok-key{width:70px;height:70px;border-radius:50%;background:rgba(255,255,255,.15);border:none;color:#fff;font-size:24px;font-weight:600;cursor:pointer;transition:all .15s;display:flex;align-items:center;justify-content:center}
.photok-key:active{background:rgba(255,255,255,.3);transform:scale(.95)}
.photok-key-empty{background:transparent;cursor:default}
.photok-key-empty:active{background:transparent;transform:none}
.photok-topbar{display:flex;align-items:center;justify-content:space-between;padding:16px;background:#fff;border-bottom:1px solid #eee}
.photok-title{font-size:18px;font-weight:700;color:#333}
.photok-top-actions{display:flex;gap:8px}
.photok-icon-btn{width:36px;height:36px;border:none;background:#f5f5f5;border-radius:50%;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center}
.photok-search-bar{padding:12px 16px;background:#fff}
.photok-search-bar input{width:100%;padding:10px 16px;border:none;background:#f5f5f5;border-radius:20px;font-size:14px;outline:none}
.photok-cat-tabs{display:flex;gap:8px;padding:0 16px 12px;background:#fff;overflow-x:auto}
.photok-cat-tab{background:#f0f0f0;color:#666;border:none;padding:8px 16px;border-radius:20px;cursor:pointer;font-size:13px;white-space:nowrap}
.photok-cat-tab.active{background:#667eea;color:#fff}
.photok-album-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;padding:12px 16px 80px}
.photok-album-card{background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08);cursor:pointer}
.photok-album-card:active{transform:scale(.97)}
.photok-album-cover{width:100%;aspect-ratio:1;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;font-size:48px;position:relative}
.photok-album-cover .count{position:absolute;bottom:8px;right:8px;background:rgba(0,0,0,.6);color:#fff;font-size:11px;padding:2px 8px;border-radius:10px}
.photok-album-name{padding:10px 12px;font-size:13px;font-weight:600;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.photok-file-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;padding:2px 2px 80px}
.photok-file-card{position:relative;aspect-ratio:1;background:#f5f5f5;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:28px;overflow:hidden}
.photok-file-card img{width:100%;height:100%;object-fit:cover}
.photok-file-card .type-badge{position:absolute;top:4px;left:4px;background:rgba(0,0,0,.6);color:#fff;font-size:9px;padding:1px 5px;border-radius:3px}
.photok-file-card .duration{position:absolute;bottom:4px;right:4px;background:rgba(0,0,0,.7);color:#fff;font-size:9px;padding:1px 4px;border-radius:3px}
.photok-bottom-bar{position:fixed;bottom:0;left:0;right:0;background:#fff;border-top:1px solid #eee;display:flex;padding:8px 16px;gap:8px;z-index:100}
.photok-bottom-btn{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;border:none;background:transparent;padding:6px;cursor:pointer;border-radius:8px}
.photok-bottom-btn:active{background:#f5f5f5}
.photok-bottom-icon{font-size:20px}
.photok-bottom-btn span:last-child{font-size:10px;color:#666}
.photok-setup-dot{width:12px;height:12px;border-radius:50%;border:2px solid #ddd;transition:all .2s}
.photok-setup-dot.filled{background:#667eea;border-color:#667eea}
/* Photok风格新加密空间 */
.vault-topbar{display:flex;align-items:center;justify-content:space-between;padding:16px 16px 8px}
.vault-title{display:flex;align-items:center;gap:8px;font-size:18px;font-weight:700;color:#333}
.vault-icon{font-size:24px}
.vault-top-actions{display:flex;gap:8px}
.vault-icon-btn{width:36px;height:36px;border:none;background:#f5f5f5;border-radius:50%;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s}
.vault-icon-btn:active{background:#e0e0e0;transform:scale(.95)}
.vault-stats-new{display:flex;gap:8px;margin:0 16px 12px}
.vault-stat-item{flex:1;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:12px;padding:12px 8px;text-align:center;color:#fff}
.vault-stat-item .vault-stat-num{font-size:18px;font-weight:700}
.vault-stat-item .vault-stat-label{font-size:10px;opacity:.9;margin-top:2px}
.vault-cat-tabs{display:flex;gap:6px;margin:0 16px 12px;overflow-x:auto;padding-bottom:4px}
.vault-cat-tab{display:flex;align-items:center;gap:4px;background:#f5f5f5;color:#666;border:none;padding:8px 14px;border-radius:20px;cursor:pointer;font-size:13px;white-space:nowrap;transition:all .2s}
.vault-cat-tab.active{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff}
.vault-cat-tab .cat-icon{font-size:14px}
.vault-view-toggle{display:flex;gap:4px;margin:0 16px 12px;background:#f0f0f0;border-radius:8px;padding:3px}
.vault-view-btn{flex:1;border:none;background:transparent;padding:8px;border-radius:6px;cursor:pointer;font-size:13px;color:#666;transition:all .2s}
.vault-view-btn.active{background:#fff;color:#333;font-weight:600;box-shadow:0 1px 3px rgba(0,0,0,.1)}
.vault-album-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;padding:0 16px 80px}
.vault-album-card{background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08);cursor:pointer;transition:all .2s}
.vault-album-card:active{transform:scale(.97)}
.vault-album-cover{width:100%;aspect-ratio:1;background:linear-gradient(135deg,#f093fb,#f5576c);display:flex;align-items:center;justify-content:center;font-size:48px;position:relative}
.vault-album-cover .album-count{position:absolute;bottom:8px;right:8px;background:rgba(0,0,0,.6);color:#fff;font-size:11px;padding:2px 8px;border-radius:10px}
.vault-album-name{padding:10px 12px;font-size:13px;font-weight:600;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vault-file-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;padding:0 4px 80px}
.vault-file-card{position:relative;aspect-ratio:1;background:#f5f5f5;border-radius:8px;overflow:hidden;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:28px}
.vault-file-card img{width:100%;height:100%;object-fit:cover}
.vault-file-card .file-type-badge{position:absolute;top:4px;left:4px;background:rgba(0,0,0,.6);color:#fff;font-size:9px;padding:1px 5px;border-radius:4px}
.vault-file-card .file-duration{position:absolute;bottom:4px;right:4px;background:rgba(0,0,0,.7);color:#fff;font-size:9px;padding:1px 4px;border-radius:3px}
.vault-file-card.selected{outline:3px solid #667eea;outline-offset:-3px}
.vault-file-card .check-overlay{position:absolute;top:6px;right:6px;width:22px;height:22px;background:#667eea;color:#fff;border-radius:50%;display:none;align-items:center;justify-content:center;font-size:12px;font-weight:700}
.vault-file-card.selected .check-overlay{display:flex}
.vault-empty{text-align:center;padding:60px 20px}
.vault-empty .empty-icon{font-size:64px;margin-bottom:16px;opacity:.5}
.vault-empty .empty-text{font-size:16px;color:#999;margin-bottom:8px}
.vault-empty .empty-hint{font-size:13px;color:#ccc}
.vault-bottom-bar{position:fixed;bottom:0;left:0;right:0;background:#fff;border-top:1px solid #eee;display:flex;padding:8px 16px;gap:8px;z-index:100;box-shadow:0 -2px 10px rgba(0,0,0,.05)}
.vault-bottom-btn{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;border:none;background:transparent;padding:6px;cursor:pointer;border-radius:8px;transition:all .2s}
.vault-bottom-btn:active{background:#f5f5f5}
.vault-bottom-btn .bottom-icon{font-size:20px}
.vault-bottom-btn span:last-child{font-size:10px;color:#666}
/* 多选模式底部栏 */
.vault-select-bar{position:fixed;bottom:0;left:0;right:0;background:#667eea;color:#fff;display:none;padding:12px 16px;gap:8px;z-index:101}
.vault-select-bar.active{display:flex}
.vault-select-btn{flex:1;background:rgba(255,255,255,.2);border:none;color:#fff;padding:10px;border-radius:8px;cursor:pointer;font-size:13px}
.vault-select-btn:active{background:rgba(255,255,255,.3)}
.note-card{background:#fff;border-radius:12px;padding:16px;cursor:pointer;transition:all .2s;box-shadow:0 2px 8px rgba(0,0,0,.06);border-left:4px solid #667eea}
.note-card:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.1)}
.note-card.pinned{border-left-color:#f59e0b;background:#fffbeb}
.note-title{font-size:15px;font-weight:600;color:#333;margin-bottom:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.note-preview{font-size:13px;color:#666;line-height:1.5;max-height:60px;overflow:hidden;margin-bottom:8px}
.note-meta{font-size:11px;color:#999;display:flex;justify-content:space-between}
.note-tags{display:flex;gap:4px;flex-wrap:wrap;margin-top:8px}
.note-tag{font-size:11px;padding:2px 8px;background:#f0f0f0;border-radius:10px;color:#666}
.empty-notes{text-align:center;padding:60px 20px;color:#999}
.empty-notes .icon{font-size:48px;margin-bottom:12px}

/* Markdown 预览样式 */
#notePreviewContent h1{font-size:24px;font-weight:700;margin:16px 0 8px;border-bottom:2px solid #eee;padding-bottom:8px}
#notePreviewContent h2{font-size:20px;font-weight:600;margin:14px 0 6px}
#notePreviewContent h3{font-size:17px;font-weight:600;margin:12px 0 4px}
#notePreviewContent p{margin:8px 0;line-height:1.7}
#notePreviewContent code{background:#f5f5f5;padding:2px 6px;border-radius:4px;font-family:monospace;font-size:13px}
#notePreviewContent pre{background:#1e1e1e;color:#d4d4d4;padding:12px;border-radius:8px;overflow-x:auto;margin:12px 0}
#notePreviewContent pre code{background:none;padding:0;color:inherit}
#notePreviewContent blockquote{border-left:4px solid #667eea;padding-left:12px;color:#666;margin:12px 0}
#notePreviewContent ul,#notePreviewContent ol{padding-left:24px;margin:8px 0}
#notePreviewContent li{margin:4px 0}
#notePreviewContent a{color:#667eea;text-decoration:none}
#notePreviewContent img{max-width:100%;border-radius:8px;margin:8px 0}
#notePreviewContent table{border-collapse:collapse;width:100%;margin:12px 0}
#notePreviewContent th,#notePreviewContent td{border:1px solid #ddd;padding:8px 12px;text-align:left}
#notePreviewContent th{background:#f5f5f5;font-weight:600}

/* VPN管理 */
.vpn-server-card{background:#fff;border-radius:16px;padding:20px;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.06)}
.vpn-server-header{display:flex;align-items:center;margin-bottom:16px}
.vpn-server-icon{font-size:48px;margin-right:16px}
.vpn-server-info{flex:1}
.vpn-server-title{font-size:20px;font-weight:600;color:#333;margin-bottom:4px}
.vpn-server-sub{font-size:13px;color:#999;margin-bottom:2px}
.vpn-server-status{display:flex;align-items:center;margin-bottom:16px}
.vpn-status-dot{width:10px;height:10px;border-radius:50%;background:#ccc;margin-right:8px}
.vpn-status-dot.running{background:#4caf50;box-shadow:0 0 8px rgba(76,175,80,.5)}
#vpnStatusText{font-size:14px;color:#666}
.vpn-server-actions{display:flex;gap:8px;margin-bottom:16px}
.vpn-btn{flex:1;padding:10px;border:1px solid #ddd;border-radius:8px;background:#fff;cursor:pointer;font-size:14px;color:#333;transition:all .2s}
.vpn-btn:hover{background:#f5f5f5}
.vpn-btn-danger{background:#f44336;color:#fff;border-color:#f44336}
.vpn-btn-danger:hover{background:#d32f2f}
.vpn-stats{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding-top:16px;border-top:1px solid #f0f0f0}
.vpn-stat{text-align:center}
.vpn-stat-label{font-size:12px;color:#999;margin-bottom:4px}
.vpn-stat-value{font-size:18px;font-weight:600;color:#333}
.vpn-stat-value.vpn-upload{color:#2196f3}
.vpn-stat-value.vpn-download{color:#4caf50}
.vpn-clients-card{background:#fff;border-radius:16px;padding:20px;box-shadow:0 2px 8px rgba(0,0,0,.06)}
.vpn-clients-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
.vpn-clients-title{font-size:16px;font-weight:600;color:#333}
.vpn-add-btn{padding:8px 16px;border:1px dashed #667eea;border-radius:8px;background:#fff;color:#667eea;cursor:pointer;font-size:13px}
.vpn-add-btn:hover{background:#f5f7ff}
.vpn-client-table{width:100%}
.vpn-client-row{display:grid;grid-template-columns:2fr 1.5fr 1fr 1fr;padding:12px 0;border-bottom:1px solid #f5f5f5;align-items:center;font-size:14px}
.vpn-client-header{font-weight:600;color:#666;font-size:13px;border-bottom:2px solid #eee}
.vpn-client-status{padding:4px 10px;border-radius:12px;font-size:12px;font-weight:500;display:inline-block}
.vpn-client-status.online{background:#e8f5e9;color:#4caf50}
.vpn-client-status.offline{background:#f5f5f5;color:#999}
.vpn-client-actions{display:flex;gap:8px}
.vpn-client-btn{padding:4px 10px;border:1px solid #ddd;border-radius:6px;background:#fff;cursor:pointer;font-size:12px;color:#666}
.vpn-client-btn:hover{background:#f5f5f5}
.vpn-client-btn.danger{color:#f44336;border-color:#f44336}
.vpn-client-btn.danger:hover{background:#fef0f0}

/* 系统监控 */
.monitor-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
.monitor-card{background:#fff;border-radius:12px;padding:16px;border:1px solid #eee}
.monitor-header{display:flex;align-items:center;gap:8px;margin-bottom:10px;font-size:14px;font-weight:500;color:#333}
.monitor-icon{font-size:18px}
.monitor-value{margin-left:auto;font-size:16px;font-weight:700;color:#667eea}
.monitor-bar{width:100%;height:8px;background:#f0f0f0;border-radius:4px;overflow:hidden}
.monitor-fill{height:100%;background:linear-gradient(90deg,#667eea,#764ba2);border-radius:4px;transition:width .5s}
.monitor-detail{font-size:11px;color:#999;margin-top:6px}
.monitor-section{background:#fff;border-radius:12px;padding:16px;border:1px solid #eee}
.process-list{max-height:400px;overflow-y:auto}
.process-item{display:flex;align-items:center;padding:10px 0;border-bottom:1px solid #f5f5f5;font-size:13px}
.process-item:last-child{border-bottom:none}
.process-pid{width:50px;color:#999;font-size:12px}
.process-name{flex:1;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.process-mem{width:70px;text-align:right;color:#667eea;font-size:12px}
.process-cpu{width:50px;text-align:right;color:#999;font-size:12px}
.container{width:100%;max-width:100%;margin:0;padding:0 16px 16px;height:100vh;overflow:hidden;overscroll-behavior:none;-webkit-overflow-scrolling:auto;box-sizing:border-box;transition:padding-top .3s}
.container.with-header{padding-top:48px}
.panel{background:#f5f5f5;display:none !important;min-height:100vh;overflow-y:auto;padding:0;margin:0;width:100%;box-sizing:border-box}
.panel.active{display:block !important}
.panel.active{display:block !important}
/* ===== 各模块独立布局（互不干扰）===== */
/* 文件管理器 */
#panel-files{padding:0;display:none !important;flex-direction:column;max-height:calc(100vh - 16px);overflow:hidden;background:#f5f5f5;position:relative}
#panel-files.active{display:flex !important;flex-direction:column !important}
/* 视频模块 */
#panel-video{padding:16px}
/* 音乐模块 */
#panel-music{padding:16px}
/* 图片模块 */
#panel-images{padding:16px}
/* 备份模块 */
#panel-backup{padding:16px}
/* DLNA模块 */
#panel-dlna{padding:16px}
/* 加密文件夹 */
#panel-encrypted{padding:16px}
/* 加密空间 */
#panel-vault{padding:16px}
/* AList网盘 */
#panel-cloud{padding:0}
/* 系统监控 */
#panel-system{padding:16px}
/* 设置 */
#panel-settings{padding:16px}
/* 用户管理 */
#panel-users{padding:16px}
/* VPN */
#panel-vpn{padding:16px}
.btn{padding:8px 16px;border:none;border-radius:6px;cursor:pointer;font-size:13px;font-weight:500;transition:all .2s}
.btn-primary{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff}
.btn-danger{background:#e74c3c;color:#fff}
.btn-success{background:#27ae60;color:#fff}
.btn-ghost{background:#f0f0f0;color:#333}
.btn-sm{padding:5px 12px;font-size:12px}
.btn:disabled{opacity:.5;cursor:not-allowed}
.toolbar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:16px}
.search-box{flex:1;min-width:150px;position:relative}
.search-box input{width:100%;padding:8px 12px 8px 32px;border:2px solid #e0e0e0;border-radius:6px;font-size:13px}
.search-box input:focus{outline:none;border-color:#667eea}
.search-box::before{content:'🔍';position:absolute;left:10px;top:50%;transform:translateY(-50%);font-size:13px}
.sort-select{padding:7px 10px;border:2px solid #e0e0e0;border-radius:6px;font-size:12px;background:#fff;cursor:pointer}
.upload-progress{display:none;margin-bottom:12px;padding:12px 16px;background:#f8f9fa;border-radius:8px}
.upload-progress.show{display:block}
.progress-bar{width:100%;height:8px;background:#e0e0e0;border-radius:4px;overflow:hidden;margin-top:8px}
.progress-fill{height:100%;background:linear-gradient(90deg,#667eea,#764ba2);border-radius:4px;transition:width .3s;width:0%}
.progress-text{font-size:12px;color:#666;display:flex;justify-content:space-between;margin-top:4px}
.search-results-info{padding:8px 12px;background:#e8f0fe;border-radius:6px;margin-bottom:12px;font-size:13px;color:#667eea;display:none;justify-content:space-between;align-items:center}
.search-results-info.show{display:flex}
.search-results-info button{background:none;border:none;color:#667eea;cursor:pointer;font-size:13px}
.view-toggle{display:flex;background:#f0f0f0;border-radius:6px;overflow:hidden}
.view-btn{padding:8px 14px;cursor:pointer;border:none;background:transparent;font-size:13px}
.view-btn.active{background:#667eea;color:#fff}
.breadcrumb{background:#f8f9fa;padding:10px 16px;border-radius:6px;margin-bottom:16px;font-size:13px;color:#666}
.filter-tabs{padding:8px 16px;gap:8px;display:flex;overflow-x:auto;margin-bottom:12px}
.filter-tab{padding:6px 14px;border-radius:16px;border:1px solid #ddd;background:#fff;font-size:13px;color:#666;cursor:pointer;white-space:nowrap;transition:all .2s}
.filter-tab.active{background:#667eea;color:#fff;border-color:#667eea}
.filter-tab:active{transform:scale(.95)}
.breadcrumb a{color:#667eea;cursor:pointer;text-decoration:none}
.upload-area{border:2px dashed #ccc;border-radius:8px;padding:24px;text-align:center;color:#999;margin-bottom:16px;cursor:pointer;transition:border-color .3s}
.upload-area.dragover{border-color:#667eea;color:#667eea;background:#f8f9ff}
.selection-bar{background:#e8f0fe;padding:10px 16px;border-radius:6px;margin-bottom:12px;display:none;align-items:center;gap:10px;flex-wrap:wrap}
.selection-bar.show{display:flex}
.selection-count{font-size:13px;color:#667eea;font-weight:600;flex:1}
/* 列表视图 - Android规范 */
.file-list{background:#fff;border-radius:0;overflow:hidden}
.file-item{display:flex;align-items:center;padding:8px 16px;min-height:56px;border-bottom:1px solid #f5f5f5;cursor:pointer;transition:background .15s;position:relative}
.file-item:hover{background:#f8f8f8}
.file-item.selected{background:#e8f0fe}
.file-item:last-child{border-bottom:none}
.file-check{margin-right:16px;width:20px;height:20px;cursor:pointer;flex-shrink:0}
.file-icon{font-size:24px;margin-right:16px;width:48px;height:48px;display:flex;align-items:center;justify-content:center;text-align:center;flex-shrink:0;line-height:1}
.file-thumb-wrap{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;margin-right:16px;flex-shrink:0}
.file-thumb{max-width:40px;max-height:40px;border-radius:8px;object-fit:cover}
.file-name{flex:1;font-size:16px;color:#222;font-weight:500;line-height:1.3;word-break:break-all;min-width:0}
.file-meta{font-size:12px;color:#999;margin-top:4px}
.file-size{color:#999;font-size:12px;margin-right:12px;min-width:60px;text-align:right;flex-shrink:0}
.file-time{color:#bbb;font-size:12px;min-width:90px;flex-shrink:0}
.file-arrow{color:#ccc;font-size:24px;margin-left:8px;flex-shrink:0;width:48px;height:48px;display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative;z-index:10;border-radius:50%;transition:background .2s}
.file-arrow:active{background:rgba(0,0,0,.05)}
/* 网格视图 - 四方卡片框架结构 */
.file-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:8px}
.grid-item{background:#fff;border-radius:12px;padding:0;text-align:center;cursor:pointer;transition:all .2s;position:relative;border:1px solid #f0f0f0;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.06)}
.grid-item:hover{background:#f8f9fa;transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.1)}
.grid-item:active{transform:scale(0.97)}
.grid-item.selected{background:#e8f0fe;border-color:#667eea}
.grid-check{position:absolute;top:8px;left:8px;width:20px;height:20px;cursor:pointer;display:none;z-index:2}
.grid-item.selected .grid-check,.grid-item:hover .grid-check{display:block}
.grid-icon{font-size:24px;margin-bottom:0;line-height:1;height:60px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#f5f7fa,#e8ecf1)}
.grid-icon.folder{background:linear-gradient(135deg,#ffeaa7,#fdcb6e)}
.grid-icon.video{background:linear-gradient(135deg,#a29bfe,#6c5ce7)}
.grid-icon.audio{background:linear-gradient(135deg,#81ecec,#00cec9)}
.grid-icon.image{background:linear-gradient(135deg,#fab1a0,#e17055)}
.grid-icon.doc{background:linear-gradient(135deg,#74b9ff,#0984e3)}
.grid-icon.archive{background:linear-gradient(135deg,#dfe6e9,#b2bec3)}
.grid-thumb-wrap{height:96px;display:flex;align-items:center;justify-content:center;margin-bottom:0;background:#f5f7fa;overflow:hidden}
.grid-thumb{max-width:100%;max-height:96px;border-radius:0;object-fit:cover}
.grid-name{font-size:13px;color:#333;word-break:break-all;line-height:1.3;min-height:36px;display:flex;align-items:center;justify-content:center;font-weight:500;padding:8px 6px}
.grid-meta{font-size:11px;color:#999;margin-top:0;line-height:1.4;padding:0 6px 8px}
.grid-more{position:absolute;top:6px;right:6px;width:28px;height:28px;border-radius:50%;background:rgba(0,0,0,.4);color:#fff;font-size:14px;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:10;backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}
.grid-more:active{background:rgba(0,0,0,.6)}
/* 文件属性菜单 */
.file-menu{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:999999 !important;align-items:flex-end;justify-content:center;padding-bottom:env(safe-area-inset-bottom,0px)}
.file-menu.active{display:flex}
.file-menu-content{background:#fff;width:100%;max-width:500px;border-radius:16px 16px 0 0;padding:20px;padding-bottom:calc(20px + env(safe-area-inset-bottom,0px));animation:slideUp .3s;max-height:80vh;overflow-y:auto}
@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
.file-menu-header{display:flex;align-items:center;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid #eee}
.file-menu-icon{font-size:36px;margin-right:12px}
.file-menu-name{font-size:16px;font-weight:600;color:#333;flex:1;word-break:break-all}
.file-menu-close{background:none;border:none;font-size:24px;color:#999;cursor:pointer;padding:4px 8px}
.file-menu-info{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px}
.file-menu-info-item{background:#f8f9fa;padding:12px;border-radius:8px}
.file-menu-info-label{font-size:11px;color:#999;margin-bottom:4px}
.file-menu-info-value{font-size:14px;color:#333;font-weight:500;word-break:break-all}
.file-menu-actions{display:flex;gap:8px;flex-wrap:wrap}
.file-menu-action{flex:1;min-width:80px;padding:10px;border:1px solid #eee;border-radius:8px;background:#fff;cursor:pointer;font-size:13px;color:#333;transition:all .2s;text-align:center}
.file-menu-action:hover{background:#f8f9ff;border-color:#667eea}
.file-menu-action.danger{color:#e74c3c}
.file-menu-action.danger:hover{background:#fef0f0;border-color:#e74c3c}
.toast{position:fixed;top:20px;right:20px;padding:12px 20px;border-radius:8px;color:#fff;font-size:13px;z-index:1000;animation:slideIn .3s}
.toast.success{background:#27ae60}.toast.error{background:#e74c3c}.toast.info{background:#3498db}
@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}
.empty{text-align:center;padding:50px;color:#ccc;font-size:14px}
.stat-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.stat-card{background:#f8f9fa;padding:10px 8px;border-radius:8px;text-align:center}
.stat-card .num{font-size:20px;font-weight:700;color:#667eea}
.stat-card .label{font-size:11px;color:#999;margin-top:2px}
.media-grid{display:flex;flex-direction:column;padding:4px 8px}
.media-grid.grid-view{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:8px}
.media-grid.grid-view .media-card{flex-direction:column;padding:0;margin-bottom:0;align-items:stretch;position:relative;aspect-ratio:1;border-radius:12px;overflow:hidden;background:#f5f5f5;box-shadow:0 2px 8px rgba(0,0,0,.06)}
.media-grid.grid-view .media-thumb{width:100%;height:100%;border-radius:0;font-size:32px;position:absolute;top:0;left:0}
.media-grid.grid-view .media-thumb img{width:100%;height:100%;object-fit:cover}
.media-grid.grid-view .media-info{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(transparent,rgba(0,0,0,.7));padding:20px 8px 6px}
.media-grid.grid-view .media-name{font-size:11px;color:#fff;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.media-grid.grid-view .media-meta{display:none}
.media-grid.grid-view .media-menu-btn{position:absolute;top:6px;right:6px;width:26px;height:26px;background:rgba(0,0,0,.5);border:none;border-radius:50%;color:#fff;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;z-index:2}
.media-grid.grid-view .media-play-badge{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:40px;height:40px;background:rgba(0,0,0,.6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px;color:#fff;z-index:1}
.media-card{display:flex;align-items:center;padding:8px 12px;border-radius:10px;cursor:pointer;transition:background .15s;gap:10px;margin-bottom:2px}
.media-card:hover{background:#f5f5f5}
.media-card:active{background:#e8e8e8}
.media-thumb{width:44px;height:44px;border-radius:8px;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;position:relative;overflow:hidden}
.media-thumb img{width:100%;height:100%;object-fit:cover}
.media-thumb .play-badge{position:absolute;bottom:2px;right:2px;background:rgba(0,0,0,.6);color:#fff;font-size:9px;padding:1px 3px;border-radius:3px}
.media-info{flex:1;min-width:0}
.media-name{font-size:13px;color:#333;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px}
.media-size{font-size:11px;color:#999}
.media-meta{display:flex;align-items:center;gap:4px;font-size:11px;color:#999;flex-wrap:nowrap;overflow:hidden}
.media-ext{background:#f0f0f0;color:#666;padding:1px 5px;border-radius:3px;font-size:10px;font-weight:600;flex-shrink:0}
.media-dot{color:#ccc;flex-shrink:0}
.media-duration{color:#667eea;flex-shrink:0}
.media-res{color:#ff9800;flex-shrink:0}
.backup-item{display:flex;align-items:center;padding:14px 16px;border-bottom:1px solid #f5f5f5}
.backup-info{flex:1}
.backup-name{font-size:14px;font-weight:500;color:#333}
.backup-meta{font-size:12px;color:#999;margin-top:4px}
.badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:500}
.badge.success{background:#d4edda;color:#155724}
.badge.warning{background:#fff3cd;color:#856404}
.badge.danger{background:#f8d7da;color:#721c24}
.form-group{margin-bottom:16px}
.form-group label{display:block;font-size:13px;color:#555;margin-bottom:6px;font-weight:500}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:10px 14px;border:2px solid #e0e0e0;border-radius:6px;font-size:14px}
.form-group input:focus,.form-group select:focus{outline:none;border-color:#667eea}
.media-tabs{display:flex;gap:8px;margin-left:auto}
.media-tab{padding:6px 14px;border:1px solid #ddd;border-radius:20px;background:#fff;cursor:pointer;font-size:13px;color:#666;transition:all .2s}
.media-tab.active{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border-color:transparent}
/* 图片查看器 - 贴合图片原生分辨率（同视频播放器规范） */
/* 核心：图片画面跟随原始宽高比，UI控件固定dp尺寸，互不干预 */
.image-modal{display:none;position:fixed;top:0;left:0;width:100vw !important;aspect-ratio:16/9 !important;max-height:100vh !important;background:#000 !important;z-index:99999 !important;user-select:none;-webkit-user-select:none;touch-action:none;overflow:hidden !important;margin:0;padding:0}
.image-modal.active{display:block !important}
/* 横屏全屏 */
@media screen and (orientation:landscape){
  .image-modal{
    width:100vw !important;
    height:100vh !important;
    aspect-ratio:auto !important;
  }
}
/* 图片容器：flex居中，占满窗口 */
.image-modal .img-wrap{position:absolute;top:0;left:0;right:0;bottom:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;overflow:hidden}
/* 图片画面：margin:auto居中，fitCenter，保持原始宽高比，禁止拉伸 */
.image-modal img{max-width:100%;max-height:100%;width:auto;height:auto;object-fit:contain;display:block;margin:auto;background:#000}

/* 顶部工具栏：固定56dp，半透明遮罩#CC000000 */
.image-modal .img-toolbar{position:absolute;top:0;left:0;right:0;height:56px;display:flex;justify-content:space-between;align-items:center;padding:0 16px;background:#CC000000;z-index:10;backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px)}
.image-modal .img-counter{color:#fff;font-size:16px;font-weight:500}
.image-modal .img-actions{display:flex;gap:8px}
/* 按钮：图标视觉24dp，热区48dp */
.image-modal .img-btn{background:transparent;border:none;color:#fff;width:48px;height:48px;border-radius:50%;font-size:24px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background .2s;min-width:48px;min-height:48px;line-height:1}
.image-modal .img-btn:hover{background:rgba(255,255,255,.15)}
.image-modal .img-btn:active{background:rgba(255,255,255,.25)}
.image-modal .img-close{background:rgba(231,76,60,.9);font-weight:bold}
.image-modal .img-close:hover{background:rgba(192,57,43,1)}

/* 左右导航按钮：图标24dp，热区48dp */
.image-modal .img-nav{position:absolute;top:50%;transform:translateY(-50%);width:48px;height:48px;border-radius:50%;background:rgba(0,0,0,.4);border:none;color:#fff;font-size:24px;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:10;backdrop-filter:blur(10px);transition:background .2s;min-width:48px;min-height:48px;line-height:1}
.image-modal .img-nav:hover{background:rgba(0,0,0,.6)}
.image-modal .img-nav:active{background:rgba(0,0,0,.7)}
.image-modal .img-nav.prev{left:16px}
.image-modal .img-nav.next{right:16px}

/* 底部信息栏：固定56dp，半透明遮罩#CC000000 */
.image-modal .img-info{position:absolute;bottom:0;left:0;right:0;min-height:56px;padding:8px 16px;background:#CC000000;color:#fff;font-size:14px;display:flex;justify-content:space-between;align-items:center;z-index:10;backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px)}
.image-modal .img-info .name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-right:16px;font-weight:500;font-size:14px}
.image-modal .img-info .meta{opacity:.8;white-space:nowrap;font-size:12px}

/* 横屏适配：所有控件尺寸不变，仅图片区域自适应 */
@media screen and (orientation:landscape){
.image-modal .img-toolbar{height:56px !important}
.image-modal .img-info{min-height:56px !important}
.image-modal .img-btn{width:48px !important;height:48px !important;font-size:24px !important}
.image-modal .img-nav{width:48px !important;height:48px !important;font-size:24px !important}
}

/* ===== 全局响应式智能适配 ===== */

/* 小屏手机 sw<360dp：页面边距改为12dp */
@media screen and (max-width:359px){
.header{padding:0 12px !important}
.file-grid{padding:12px !important;gap:8px !important}
.music-list{padding:0 12px 12px !important}
.settings-menu{padding:12px !important}
.home-grid{padding:16px 8px !important}
.file-item{padding:8px 12px !important}
.music-item{padding:8px 12px !important}
.settings-item{padding:8px 12px !important}
.kuwo-cover{width:240px !important;height:240px !important}
.kuwo-song-name{font-size:16px !important}
.kuwo-song-artist{font-size:13px !important}
}

/* 标准手机 sw≥360dp：默认布局，无需额外调整 */

/* 平板 sw≥600dp：页面边距24dp，网格4列，双栏布局 */
@media screen and (min-width:600px){
.header{padding:0 24px !important}
.file-grid{padding:24px !important;gap:12px !important;grid-template-columns:repeat(4,1fr) !important}
.music-list{padding:0 24px 24px !important}
.settings-menu{padding:24px !important}
.home-grid{padding:24px 16px !important;grid-template-columns:repeat(6,1fr) !important}
.file-item{padding:8px 24px !important}
.music-item{padding:8px 24px !important}
.settings-item{padding:8px 24px !important}
/* 弹窗最大宽度限制 */
#genericModal > div{max-width:560px !important}
/* 音乐播放器封面更大 */
.kuwo-cover{width:320px !important;height:320px !important}
/* 登录框更宽 */
.login-box{max-width:400px !important}
}

/* 大屏平板 sw≥720dp：多列布局 */
@media screen and (min-width:720px){
.file-grid{grid-template-columns:repeat(5,1fr) !important}
.home-grid{grid-template-columns:repeat(8,1fr) !important}
/* 设置页面双栏 */
.settings-menu{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.settings-group{margin-bottom:0}
}

/* 横屏适配：控件尺寸不变，布局自适应 */
@media screen and (orientation:landscape){
/* 视频播放器：进度条自适应拉长 */
.artplayer-container .artplayer-progress{flex:1 !important}
/* 音乐播放器：左右分栏 */
.kuwo-player{flex-direction:row !important}
.kuwo-cover-wrap{flex:1 !important;padding:24px !important}
.kuwo-cover{width:280px !important;height:280px !important;max-width:280px !important;max-height:280px !important}
.kuwo-controls-area{flex:1 !important;display:flex !important;flex-direction:column !important;justify-content:center !important;padding:24px !important}
/* 图片查看器：控件尺寸不变 */
.image-modal .img-toolbar{height:56px !important}
.image-modal .img-info{min-height:56px !important}
/* 文件管理器：双栏可选 */
.file-manager-landscape{display:grid;grid-template-columns:240px 1fr;gap:0}
}

/* 高DPI屏幕优化：文字更清晰 */
@media screen and (-webkit-min-device-pixel-ratio:3){
body{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
}

/* 超大屏适配 sw≥1024dp */
@media screen and (min-width:1024px){
.file-grid{grid-template-columns:repeat(6,1fr) !important}
.home-grid{grid-template-columns:repeat(10,1fr) !important}
#genericModal > div{max-width:640px !important}
}

/* 深色模式 */
body.dark{background:#1a1a2e;color:#eee}
body.dark .container{background:#16213e}
body.dark .home-card{background:#1f2940;border-color:#2d3a5a}
body.dark .home-card:hover{background:#253352}
body.dark .card-title{color:#eee}
body.dark .card-desc{color:#8892b0}
body.dark .home-stat .num{color:#64ffda}
body.dark .home-stat .label{color:#8892b0}
body.dark .page-header{background:#16213e;border-color:#2d3a5a}
body.dark .page-title{color:#eee}
body.dark .toolbar{background:#1f2940;border-color:#2d3a5a}
body.dark .file-list{background:#16213e}
body.dark .file-item{background:#1f2940;border-color:#2d3a5a;color:#eee}
body.dark .file-item:hover{background:#253352}
body.dark .file-name{color:#eee}
body.dark .file-size,.dark .file-time{color:#8892b0}
body.dark .grid-item{background:#1f2940;border-color:#2d3a5a}
body.dark .grid-item:hover{background:#253352}
body.dark .settings-menu{background:#1f2940}
body.dark .settings-item{border-color:#2d3a5a}
body.dark .settings-item:hover{background:#253352}
body.dark .settings-name{color:#eee}
body.dark .settings-desc{color:#8892b0}
body.dark input,.dark textarea,.dark select{background:#1f2940;border-color:#2d3a5a;color:#eee}
body.dark .btn{background:#2d3a5a;color:#eee;border-color:#3d4a6a}
body.dark .btn:hover{background:#3d4a6a}
body.dark .monitor-card{background:#1f2940;border-color:#2d3a5a}
body.dark .process-item{background:#1f2940;border-color:#2d3a5a;color:#eee}
body.dark .vpn-server-card,.dark .vpn-clients-card{background:#1f2940;border-color:#2d3a5a}
body.dark .vpn-server-title,.dark .vpn-clients-title{color:#eee}
body.dark .vpn-client-row{border-color:#2d3a5a;color:#eee}
body.dark .vpn-client-header{color:#8892b0}
body.dark .note-card{background:#1f2940;border-color:#2d3a5a}
body.dark .note-card:hover{background:#253352}
body.dark .note-title{color:#eee}
body.dark .note-preview{color:#8892b0}
body.dark #notePreviewContent{background:#1f2940;color:#eee}
body.dark #notePreviewContent code{background:#2d3a5a}
body.dark #notePreviewContent pre{background:#0f172a}
body.dark #notePreviewContent blockquote{color:#8892b0}
body.dark #notePreviewContent th{background:#2d3a5a}
body.dark #notePreviewContent td{border-color:#2d3a5a}
body.dark .stat-card{background:#1f2940;border-color:#2d3a5a}
body.dark .music-item{background:#1f2940;border-color:#2d3a5a;color:#eee}
body.dark .music-item:hover{background:#253352}
body.dark .form-group label{color:#8892b0}
body.dark #debugResult{background:#1f2940;color:#64ffda}

/* 音乐播放器 - 全屏美化版 */
.music-player{position:fixed;top:0;left:0;width:100%;height:100%;background:linear-gradient(180deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);z-index:99999;display:none;flex-direction:column;color:#fff}
.music-player.active{display:flex}
.music-player-header{display:flex;align-items:center;padding:16px;padding-top:calc(16px + env(safe-area-inset-top));background:rgba(0,0,0,.2)}
.music-player-back{width:40px;height:40px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:24px}
.music-player-title{flex:1;text-align:center;font-size:16px;font-weight:500}
.music-player-more{width:40px;height:40px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:20px}
.music-player-cover{flex:1;display:flex;align-items:center;justify-content:center;padding:32px}
.music-player-cover-circle{width:240px;height:240px;border-radius:50%;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;font-size:80px;box-shadow:0 8px 32px rgba(102,126,234,.4);animation:rotate 20s linear infinite}
@keyframes rotate{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
.music-player-info{text-align:center;padding:0 32px;margin-bottom:24px}
.music-player-song{font-size:20px;font-weight:600;margin-bottom:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.music-player-artist{font-size:14px;opacity:.7}
.music-player-progress{padding:0 32px;margin-bottom:24px}
.music-player-bar{width:100%;height:4px;background:rgba(255,255,255,.2);border-radius:2px;cursor:pointer;position:relative}
.music-player-bar-fill{height:100%;background:#667eea;border-radius:2px;width:0%;transition:width .1s}
.music-player-times{display:flex;justify-content:space-between;margin-top:8px;font-size:12px;opacity:.7}
.music-player-controls{display:flex;align-items:center;justify-content:center;gap:48px;padding:0 32px;padding-bottom:calc(48px + env(safe-area-inset-bottom))}
.music-player-btn{width:48px;height:48px;display:flex;align-items:center;justify-content:center;cursor:pointer;opacity:.8;transition:opacity .2s}
.music-player-btn:active{opacity:.5}
.music-player-btn-play{width:64px;height:64px;background:#667eea;border-radius:50%;font-size:28px;opacity:1}
.aplayer-container{margin:16px;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08)}
.aplayer{margin:0!important;border-radius:12px;overflow:hidden}
.aplayer .aplayer-pic{background:linear-gradient(135deg,#667eea,#764ba2)!important}

/* 视频播放器 - 贴合视频原生分辨率（1080×2400长屏） */
/* 核心：视频画面跟随视频宽高比，UI控件固定dp尺寸，互不干预 */
.player-modal{display:none;position:fixed;top:0;left:0;width:100vw !important;aspect-ratio:16/9 !important;max-height:100vh !important;background:#000 !important;z-index:99998 !important;overflow:hidden !important;margin:0;padding:0}
.player-modal.active{display:block !important}
/* 横屏全屏 */
@media screen and (orientation:landscape){
  .player-modal{
    width:100vw !important;
    height:100vh !important;
    aspect-ratio:auto !important;
  }
}
/* ArtPlayer容器 - 自适应16:9比例 */
.artplayer-container{
  width:100% !important;
  height:auto !important;
  aspect-ratio:16/9 !important;
  position:relative !important;
  margin:0 !important;
  padding:0 !important;
  overflow:hidden !important;
  background:#000 !important;
}
/* ArtPlayer内部 - 正常布局 */
.artplayer-container .artplayer,
.artplayer-container .artplayer-app{
  width:100% !important;
  height:auto !important;
  position:relative !important;
  margin:0 !important;
  padding:0 !important;
  overflow:hidden !important;
  background:#000 !important;
}
/* 视频画面 - 正常布局，宽度100%，高度自动 */
.artplayer-container video{
  object-fit:contain !important;
  width:100% !important;
  height:auto !important;
  max-width:100% !important;
  background:#000 !important;
  display:block !important;
}
/* 移除遮罩 */
.artplayer-container .artplayer-mask{display:none !important}
.artplayer-container .artplayer-loading{background:#000 !important}
/* 控制栏 - 搜狐视频风格 */
.artplayer-container .artplayer-controls-top{
  background:linear-gradient(to bottom,rgba(0,0,0,.7),transparent) !important;
  height:44px !important;
  padding:0 12px !important;
  display:flex !important;
  align-items:center !important;
  justify-content:space-between !important;
}
.artplayer-container .artplayer-controls{
  background:linear-gradient(to top,rgba(0,0,0,.8),transparent) !important;
  padding:0 12px 8px !important;
  min-height:44px !important;
  max-height:44px !important;
  display:flex !important;
  align-items:center !important;
  gap:6px !important;
}
.artplayer-container .artplayer-control{
  height:40px !important;
  min-width:40px !important;
  display:flex !important;
  align-items:center !important;
  justify-content:center !important;
}
.artplayer-container .artplayer-button{
  width:40px !important;
  height:40px !important;
  font-size:20px !important;
  min-width:40px !important;
  min-height:40px !important;
  display:flex !important;
  align-items:center !important;
  justify-content:center !important;
}
.artplayer-container .artplayer-play{
  width:40px !important;
  height:40px !important;
  font-size:32px !important;
}
.artplayer-container .artplayer-play svg{
  width:32px !important;
  height:32px !important;
}
.artplayer-container .artplayer-progress{
  height:3px !important;
  margin:0 6px !important;
  flex:1 !important;
}
.artplayer-container .artplayer-progress-inner{
  height:3px !important;
}
.artplayer-container .artplayer-progress-thumb{
  width:14px !important;
  height:14px !important;
}
.artplayer-container .artplayer-time{
  font-size:11px !important;
  padding:0 4px !important;
  min-width:40px !important;
  color:#fff !important;
}
/* 关闭按钮 - 在16:9窗口内 */
.artplayer-close{
  position:absolute;
  top:6px;
  left:12px;
  z-index:99999 !important;
  background:rgba(0,0,0,.4);
  color:#fff;
  border:none;
  width:36px;
  height:36px;
  border-radius:50%;
  font-size:18px;
  cursor:pointer;
  display:flex;
  align-items:center;
  justify-content:center;
  min-width:36px;
  min-height:36px;
  line-height:1;
}
/* 视频设置面板样式 - Android UI规范 */
.vset-btn{padding:0 8px;height:48px;background:rgba(255,255,255,.1);color:#ddd;border:none;border-radius:8px;font-size:14px;cursor:pointer;transition:all .2s cubic-bezier(.4,0,.2,1);text-align:center;font-weight:500;min-width:48px;min-height:48px;display:flex;align-items:center;justify-content:center}
.vset-btn:hover{background:rgba(255,255,255,.2);color:#fff;transform:scale(1.02)}
.vset-btn:active{transform:scale(.98)}
.vset-btn.active{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-weight:600;box-shadow:0 4px 12px rgba(102,126,234,.4)}
.vset-group{margin-bottom:24px}
.vset-group-title{color:#888;font-size:14px;margin-bottom:16px;font-weight:600;letter-spacing:.5px}
.vset-btn-grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.vset-btn-grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.vset-btn-grid-5{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}
.vset-slider{width:100%;height:6px;-webkit-appearance:none;background:rgba(255,255,255,.15);border-radius:3px;outline:none;margin-top:16px}
.vset-slider::-webkit-slider-thumb{-webkit-appearance:none;width:24px;height:24px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:50%;cursor:pointer;box-shadow:0 2px 8px rgba(102,126,234,.5)}
.vset-switch-row{display:flex;justify-content:space-between;align-items:center;padding:16px 0;border-bottom:1px solid rgba(255,255,255,.08);min-height:56px}
.vset-switch-row:last-child{border-bottom:none}
.vset-action-btn{width:100%;display:flex;align-items:center;gap:16px;padding:16px;height:56px;background:rgba(255,255,255,.08);border:none;border-radius:8px;margin-bottom:12px;cursor:pointer;text-align:left;transition:all .2s cubic-bezier(.4,0,.2,1);min-height:56px}
.vset-action-btn:hover{background:rgba(255,255,255,.15);transform:translateX(4px)}
.vset-action-btn span:first-of-type{color:#fff;font-size:16px;flex:1;font-weight:500}
.vset-action-btn span:last-of-type{font-size:12px;color:#888}
/* 开关样式 - Android规范 */
.switch{position:relative;display:inline-block;width:52px;height:32px;flex-shrink:0}
.switch input{opacity:0;width:0;height:0}
.switch .slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,.2);transition:.3s cubic-bezier(.4,0,.2,1);border-radius:32px}
.switch .slider:before{position:absolute;content:"";height:28px;width:28px;left:2px;bottom:2px;background:#fff;transition:.3s cubic-bezier(.4,0,.2,1);border-radius:50%;box-shadow:0 2px 6px rgba(0,0,0,.2)}
.switch input:checked+.slider{background:linear-gradient(135deg,#667eea,#764ba2)}
.switch input:checked+.slider:before{transform:translateX(20px)}
/* 修复控制栏图标过宽问题 */
.artplayer .artplayer-controls .artplayer-control{min-width:36px!important;width:36px!important;padding:0 6px!important;display:flex!important;align-items:center!important;justify-content:center!important}
.artplayer .artplayer-controls .artplayer-control .artplayer-icon{width:20px!important;height:20px!important}
.artplayer .artplayer-controls .artplayer-control .artplayer-text{font-size:12px!important;padding:0 4px!important}
.artplayer .artplayer-controls .artplayer-control-right{gap:2px!important}
.artplayer .artplayer-controls .artplayer-control-left{gap:2px!important}
/* 移动端控制栏优化 */
@media (max-width:768px){
.artplayer .artplayer-controls .artplayer-control{min-width:32px!important;width:32px!important;padding:0 4px!important}
.artplayer .artplayer-controls .artplayer-control .artplayer-icon{width:18px!important;height:18px!important}
.artplayer .artplayer-controls .artplayer-progress{margin:0 8px!important}
}

/* ===== 音乐播放器 - Android UI标准 ===== */
.kuwo-player{
  position:fixed;top:0;left:0;width:100vw !important;height:100vh !important;
  background:linear-gradient(180deg,#3d2b1f 0%,#2a1f17 40%,#1a1410 100%) !important;
  z-index:99997 !important;display:none;flex-direction:column;overflow:hidden !important;
  margin:0 !important;padding:0 !important;
}
.kuwo-player.active{display:flex !important}
/* 顶部栏：56dp固定 */
.kuwo-player-header{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 16px;color:#fff;flex-shrink:0;height:56px;min-height:56px;
}
.kuwo-player-header button{
  background:none;border:none;color:#fff;font-size:24px;cursor:pointer;
  width:48px;height:48px;display:flex;align-items:center;justify-content:center;
  min-width:48px;min-height:48px;border-radius:50%;transition:background .2s;
}
.kuwo-player-header button:hover{background:rgba(255,255,255,.15)}
/* 封面区域：flex居中，自适应屏幕大小，上限280dp下限160dp */
.kuwo-cover-wrap{
  flex:1;display:flex;align-items:center;justify-content:center;
  padding:16px;min-height:0;overflow:hidden;
}
.kuwo-cover{
  width:min(280px,60vw);max-width:280px;
  height:min(280px,60vw);max-height:280px;
  border-radius:16px;
  background:linear-gradient(135deg,#667eea,#764ba2);
  box-shadow:0 12px 40px rgba(0,0,0,.4);
  display:flex;align-items:center;justify-content:center;
  position:relative;overflow:hidden;flex-shrink:0;
}
.kuwo-cover.playing{animation:kuwoRotate 20s linear infinite}
@keyframes kuwoRotate{from{transform:rotate(0)}to{transform:rotate(360deg)}}
.kuwo-cover svg{width:80px;height:80px;opacity:.8}
/* 歌曲信息：标题18sp，歌手14sp */
.kuwo-song-info{
  padding:8px 16px 16px;color:#fff;text-align:center;flex-shrink:0;
}
.kuwo-song-name{font-size:18px;font-weight:600;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.kuwo-song-artist{font-size:14px;color:rgba(255,255,255,.6)}
.kuwo-tags{display:flex;gap:6px;justify-content:center;margin-top:8px}
.kuwo-tag{
  font-size:12px;padding:4px 8px;border-radius:4px;
  background:rgba(255,255,255,.15);color:rgba(255,255,255,.8);
}
.kuwo-player-bg{
  position:absolute;top:0;left:0;width:100%;height:100%;
  background:linear-gradient(180deg,#4a3f35 0%,#2a221c 50%,#1a1612 100%);
  z-index:-1;
}
.kuwo-lyric{
  padding:8px 24px;color:rgba(255,255,255,.5);text-align:center;
  font-size:14px;min-height:24px;flex-shrink:0;
}
/* 功能按钮：图标24dp，热区48dp */
.kuwo-actions{
  display:flex;justify-content:space-around;padding:8px 16px;flex-shrink:0;
}
.kuwo-action-btn{
  background:none;border:none;color:#fff;cursor:pointer;
  width:48px;min-width:48px;height:48px;min-height:48px;display:flex;align-items:center;justify-content:center;
  flex-direction:column;gap:4px;padding:4px 0;border-radius:50%;transition:background .2s;
}
.kuwo-action-btn:hover{background:rgba(255,255,255,.15)}
.kuwo-action-icon{font-size:24px}
.kuwo-action-text{font-size:12px;color:rgba(255,255,255,.6)}
.kuwo-action-btn.liked{color:#ff4757}
.kuwo-action-btn:active{opacity:.7}
.kuwo-source-tag{
  font-size:12px;padding:4px 8px;border-radius:4px;
  background:rgba(255,255,255,.15);color:rgba(255,255,255,.7);
  margin-left:6px;
}
/* 进度条：轨道4dp，滑块20dp */
.kuwo-progress-wrap{padding:0 16px;flex-shrink:0}
.kuwo-progress{
  width:100%;height:4px;background:rgba(255,255,255,.2);
  border-radius:2px;position:relative;cursor:pointer;
}
.kuwo-progress-bar{
  height:100%;background:#fff;border-radius:2px;width:0%;
  position:relative;
}
.kuwo-progress-bar::after{
  content:'';position:absolute;right:-10px;top:50%;transform:translateY(-50%);
  width:20px;height:20px;background:#fff;border-radius:50%;
  box-shadow:0 2px 8px rgba(0,0,0,.3);
}
.kuwo-time{
  display:flex;justify-content:space-between;color:rgba(255,255,255,.5);
  font-size:12px;margin-top:8px;
}
/* 控制按钮：播放视觉40dp热区48dp，上下一曲24dp视觉48dp热区 */
.kuwo-controls{
  display:flex;align-items:center;justify-content:space-around;
  padding:16px 16px 32px;flex-shrink:0;
}
.kuwo-ctrl-btn{
  background:none;border:none;color:#fff;font-size:24px;cursor:pointer;
  width:48px;height:48px;min-width:48px;min-height:48px;display:flex;align-items:center;justify-content:center;
  border-radius:50%;transition:background .2s;
}
.kuwo-ctrl-btn:hover{background:rgba(255,255,255,.15)}
.kuwo-ctrl-btn.play{
  width:48px;height:48px;background:#fff;border-radius:50%;color:#333;
  font-size:40px;display:flex;align-items:center;justify-content:center;
}
.kuwo-ctrl-btn.small{font-size:24px;color:rgba(255,255,255,.7)}

/* 更多操作菜单 */
.kuwo-more-menu{
  position:fixed;top:50px;right:16px;
  background:rgba(30,20,15,.95);backdrop-filter:blur(10px);
  border-radius:12px;z-index:9999 !important;
  min-width:160px;overflow:hidden;
  display:none;box-shadow:0 8px 32px rgba(0,0,0,.4);
}
.kuwo-more-menu.active{display:block}
.kuwo-more-menu-item{
  display:flex;align-items:center;padding:12px 16px;
  color:#fff;cursor:pointer;font-size:14px;
  border-bottom:1px solid rgba(255,255,255,.08);
}
.kuwo-more-menu-item:last-child{border-bottom:none}
.kuwo-more-menu-item:active{background:rgba(255,255,255,.1)}
.kuwo-more-icon{font-size:16px;margin-right:10px;width:20px;text-align:center}
.kuwo-more-text{flex:1}

/* 酷我风格音乐列表 */
.kuwo-music-item{
  display:flex;align-items:center;padding:12px 16px;
  border-bottom:1px solid #f5f5f5;cursor:pointer;
}
.kuwo-music-item:active{background:#f8f8f8}
.kuwo-music-item.playing .kuwo-music-name{color:#667eea}
.kuwo-music-left{display:flex;align-items:center;flex:1;min-width:0}
.kuwo-music-num{
  width:24px;text-align:center;color:#999;font-size:14px;
  margin-right:12px;flex-shrink:0;
}
.kuwo-music-item.playing .kuwo-music-num{color:#667eea}
.playing-icon{
  display:inline-block;width:14px;height:14px;
  background:linear-gradient(135deg,#667eea,#764ba2);
  border-radius:2px;position:relative;
}
.playing-icon::before{
  content:'';position:absolute;left:3px;top:3px;
  width:2px;height:8px;background:#fff;animation:playingBar 1s ease-in-out infinite;
}
.playing-icon::after{
  content:'';position:absolute;right:3px;top:5px;
  width:2px;height:6px;background:#fff;animation:playingBar 1s ease-in-out infinite .3s;
}
@keyframes playingBar{0%,100%{height:4px}50%{height:10px}}
.kuwo-music-cover{
  width:44px;height:44px;border-radius:8px;
  background:linear-gradient(135deg,#667eea,#764ba2);
  display:flex;align-items:center;justify-content:center;
  font-size:20px;margin-right:12px;flex-shrink:0;
}
.kuwo-music-info{flex:1;min-width:0}
.kuwo-music-name{
  font-size:15px;color:#333;font-weight:500;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  margin-bottom:2px;
}
.kuwo-music-meta{
  font-size:12px;color:#999;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.kuwo-music-more{
  background:none;border:none;color:#999;font-size:20px;
  width:36px;height:36px;cursor:pointer;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
}
.music-badge{
  font-size:10px;padding:1px 5px;border-radius:3px;
  margin-left:6px;vertical-align:middle;
}
.music-badge.transcode{background:#e8f0fe;color:#667eea}

/* 音效面板 */
.kuwo-effect-panel{
  position:fixed;bottom:-100%;left:0;width:100%;background:#1a1410;
  border-radius:20px 20px 0 0;z-index:9999 !important;
  transition:bottom .3s ease;color:#fff;max-height:80vh;overflow-y:auto;
  display:none !important;
}
.kuwo-effect-panel.active{bottom:0 !important;display:block !important;}
.kuwo-effect-header{
  display:flex;align-items:center;justify-content:space-between;
  padding:16px 20px;border-bottom:1px solid rgba(255,255,255,.1);
}
.kuwo-effect-header h3{margin:0;font-size:16px}
.kuwo-effect-header button{background:none;border:none;color:#fff;font-size:20px;cursor:pointer}
.kuwo-effect-tabs{display:flex;padding:12px 20px;gap:16px;border-bottom:1px solid rgba(255,255,255,.1)}
.kuwo-effect-tab{
  font-size:14px;color:rgba(255,255,255,.5);cursor:pointer;padding:4px 0;
}
.kuwo-effect-tab.active{color:#ffd700;font-weight:600}
.kuwo-effect-list{padding:16px 20px}
.kuwo-effect-item{
  display:flex;align-items:center;padding:14px;background:rgba(255,255,255,.05);
  border-radius:12px;margin-bottom:10px;cursor:pointer;
}
.kuwo-effect-item.active{background:rgba(255,215,0,.15)}
.kuwo-effect-icon{width:40px;height:40px;margin-right:12px;display:flex;align-items:center;justify-content:center;font-size:24px}
.kuwo-effect-info{flex:1}
.kuwo-effect-name{font-size:15px;font-weight:500}
.kuwo-effect-desc{font-size:12px;color:rgba(255,255,255,.5);margin-top:2px}
.kuwo-effect-btn{
  padding:6px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.3);
  background:none;color:#fff;font-size:12px;cursor:pointer;
}
.kuwo-effect-item.active .kuwo-effect-btn{background:#ffd700;color:#333;border-color:#ffd700}
.kuwo-eq-wrap{padding:16px 20px}
.kuwo-eq-bands{display:flex;justify-content:space-between;align-items:flex-end;height:160px;gap:4px}
.kuwo-eq-band{flex:1;display:flex;flex-direction:column;align-items:center;gap:8px}
.kuwo-eq-slider{
  width:100%;height:120px;-webkit-appearance:slider-vertical;
  writing-mode:bt-lr;direction:rtl;
}
.kuwo-eq-label{font-size:10px;color:rgba(255,255,255,.5)}
.kuwo-eq-presets{display:flex;flex-wrap:wrap;gap:8px;margin-top:16px}
.kuwo-eq-preset{
  padding:6px 12px;border-radius:16px;background:rgba(255,255,255,.1);
  font-size:12px;cursor:pointer;
}
.kuwo-eq-preset.active{background:#ffd700;color:#333}
.kuwo-mask{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:9998 !important;display:none}
.kuwo-mask.active{display:block !important}
.kuwo-mask.active{display:block}
</style>
<!-- 模块化CSS -->
<link rel="stylesheet" href="/static/css/base.css">
<link rel="stylesheet" href="/static/css/components.css">
<!-- ArtPlayer 视频播放器（本地静态文件） -->
<script src="/static/artplayer/artplayer.min.js"></script>
<!-- APlayer 音乐播放器（本地静态文件） -->
<link rel="stylesheet" href="/static/aplayer/APlayer.min.css">
<script src="/static/aplayer/APlayer.min.js"></script>
<!-- PhotoSwipe 图片查看器（本地静态文件） -->
<link rel="stylesheet" href="/static/photoswipe/photoswipe.css">
<script type="module">
import PhotoSwipe from '/static/photoswipe/photoswipe.esm.js';
import PhotoSwipeLightbox from '/static/photoswipe/photoswipe-lightbox.esm.js';
window.PhotoSwipe=PhotoSwipe;
window.PhotoSwipeLightbox=PhotoSwipeLightbox;
// 全局图片查看函数
window.openPhotoSwipe=function(src,width,height){
const pswp=new PhotoSwipe({
dataSource:[{src:src,width:width||1200,height:height||1600}],
pswpModule:PhotoSwipe,
showHideAnimationType:'fade',
zoom:true,
close:true,
counter:false,
arrowKeys:false,
clickToCloseNonZoomable:true,
maxZoomLevel:4,
preload:[1,1]
});
pswp.init();
return pswp;
};
console.log('PhotoSwipe 已加载');
</script>
<!-- HLS.js 用于m3u8流播放（本地静态文件） -->
<script src="/static/hls.min.js"></script>
<!-- PWA配置 -->
<link rel="manifest" href="/static/manifest.json">
<meta name="theme-color" content="#667eea">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="NAS私有云">
<link rel="apple-touch-icon" href="/static/icon-192.png">
<link rel="apple-touch-icon" sizes="512x512" href="/static/icon-512.png">
</head>
<body>
<div class="header">
<h1>NAS 私有云</h1>
</div>
<div class="container" id="mainContainer" style="transition:transform 0.3s ease-out">

<!-- 主界面 -->
<div class="home-panel active" id="panel-home">
<div class="home-header">
<h2>NAS 私有云</h2>
<p>安全 · 高效 · 私有</p>
</div>
<div class="home-grid">
<div class="home-card miui" onclick="openPanel('backup')">
<div class="miui-icon" style="background:linear-gradient(135deg,#43e97b,#38f9d7)">
<svg viewBox="0 0 24 24" fill="white" width="32" height="32"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"/></svg>
</div>
<div class="card-title">备份恢复</div>
</div>
<div class="home-card miui" onclick="window.open('https://'+ALIST_CONFIG.host+':'+ALIST_CONFIG.port+'/#/manage/settings','_blank')">
<div class="miui-icon" style="background:linear-gradient(135deg,#89f7fe,#66a6ff)">
<svg viewBox="0 0 24 24" fill="white" width="32" height="32"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
</div>
<div class="card-title">系统设置</div>
<div class="card-subtitle">AList</div>
</div>
<div class="home-card miui" onclick="openPanel('system')">
<div class="miui-icon" style="background:linear-gradient(135deg,#ffecd2,#fcb69f)">
<svg viewBox="0 0 24 24" fill="white" width="32" height="32"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/></svg>
</div>
<div class="card-title">系统监控</div>
</div>
<div class="home-card miui" onclick="openPanel('vpn')">
<div class="miui-icon" style="background:linear-gradient(135deg,#a18cd1,#fbc2eb)">
<svg viewBox="0 0 24 24" fill="white" width="32" height="32"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
</div>
<div class="card-title">VPN 管理</div>
</div>
<div class="home-card miui" onclick="openPanel('dlna')">
<div class="miui-icon" style="background:linear-gradient(135deg,#667eea,#764ba2)">
<svg viewBox="0 0 24 24" fill="white" width="32" height="32"><path d="M21 3H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h5v2h8v-2h5c1.1 0 1.99-.9 1.99-2L23 5c0-1.1-.9-2-2-2zm0 14H3V5h18v12z"/></svg>
</div>
<div class="card-title">DLNA投屏</div>
</div>
<div class="home-card miui" onclick="openPanel('vault')">
<div class="miui-icon" style="background:linear-gradient(135deg,#f093fb,#f5576c)">
<svg viewBox="0 0 24 24" fill="white" width="32" height="32"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
</div>
<div class="card-title">加密空间</div>
</div>
<div class="home-card miui" onclick="openPanel('cloud')">
<div class="miui-icon" style="background:linear-gradient(135deg,#43e97b,#38f9d7)">
<svg viewBox="0 0 24 24" fill="white" width="32" height="32"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z"/></svg>
</div>
<div class="card-title">网盘管理</div>
</div>
<div class="home-card miui" onclick="openPanel('users')">
<div class="miui-icon" style="background:linear-gradient(135deg,#fa709a,#fee140)">
<svg viewBox="0 0 24 24" fill="white" width="32" height="32"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
</div>
<div class="card-title">用户管理</div>
</div>
</div>
<div class="home-stats">
<div class="home-stat"><div class="num" id="homeFiles">0</div><div class="label">文件数</div></div>
<div class="home-stat"><div class="num" id="homeSize">0 B</div><div class="label">存储用量</div></div>
<div class="home-stat"><div class="num" id="homeUptime">运行中</div><div class="label">服务状态</div></div>
</div>
<!-- 局域网访问地址 -->
<div class="access-info" id="accessInfo" style="margin:16px;padding:16px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:16px;color:#fff">
<div style="font-size:14px;font-weight:600;margin-bottom:8px">📡 局域网访问</div>
<div style="font-size:12px;opacity:.9;margin-bottom:4px">本机访问：https://127.0.0.1:8443</div>
<div style="font-size:12px;opacity:.9;margin-bottom:8px">局域网访问：<span id="lanAddress">获取中...</span></div>
<div style="font-size:11px;opacity:.7;line-height:1.5">其他设备连接同一WiFi后，在浏览器输入上方局域网地址即可访问<br>注意：需先信任自签名证书（高级→继续访问）</div>
</div>
</div>

<!-- 网盘管理面板 -->
<div class="panel" id="panel-cloud">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">网盘管理</span>
<button class="btn btn-sm" onclick="checkAlistStatus()" style="margin-left:auto">刷新</button>
</div>
<!-- 状态提示 -->
<div id="alistStatusBar" style="margin:0;padding:10px 16px;display:none;align-items:center;gap:8px">
<span id="alistStatusIcon" style="font-size:18px">⏳</span>
<span id="alistStatusText" style="font-size:13px;color:#666">正在检测AList状态...</span>
</div>
<!-- AList 管理入口 -->
<div id="alistFrameWrap" style="margin:12px;padding:24px;background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.08);text-align:center">
<div style="font-size:56px;margin-bottom:16px">☁️</div>
<div style="font-size:18px;font-weight:600;color:#333;margin-bottom:8px">AList 网盘管理</div>
<div style="font-size:13px;color:#999;margin-bottom:20px" id="alistFrameUrl">地址：https://127.0.0.1:8444</div>
<button class="btn btn-primary" onclick="openAlistInNewTab()" style="padding:12px 32px;font-size:15px;margin-bottom:12px">🚀 打开 AList 管理</button>
<div style="font-size:12px;color:#bbb">支持阿里云盘/百度网盘/OneDrive等30+网盘</div>
</div>
<!-- 未启动提示 -->
<div id="alistNotRunning" style="margin:12px;padding:24px;background:#fff3cd;border-radius:12px;text-align:center;display:none">
<div style="font-size:48px;margin-bottom:12px">⚠️</div>
<div style="font-size:15px;font-weight:600;color:#856404;margin-bottom:8px">AList 未启动</div>
<div style="font-size:13px;color:#856404;line-height:1.8;margin-bottom:16px">
内置AList服务尚未启动<br>
端口：http://127.0.0.1:5244
</div>
<button class="btn btn-primary" onclick="startAlist()" style="margin-bottom:8px">🔄 启动AList</button>
<div style="font-size:12px;color:#999">默认账号：admin / admin123</div>
</div>
</div>

<!-- AList内嵌面板 -->
<div class="panel" id="panel-alist" style="position:fixed;top:0;left:0;right:0;bottom:0;padding:0;margin:0;border-radius:0;z-index:100;background:#fff">
<div class="page-header" style="position:relative;z-index:10">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title" id="alistPanelTitle">AList</span>
<button class="back-btn" onclick="refreshAlistPanel()" style="margin-left:auto;font-size:20px">↻</button>
<button class="back-btn" onclick="openAlistInNewTab()" style="font-size:18px">↗</button>
</div>
<div style="position:fixed;top:56px;left:0;right:0;bottom:0;background:#fff">
<div id="alistLoading" style="position:absolute;top:0;left:0;right:0;bottom:0;display:none;align-items:center;justify-content:center;background:#f5f5f5;z-index:5">
<div style="text-align:center">
<div style="font-size:32px;margin-bottom:12px">⏳</div>
<div style="color:#666">加载中...</div>
</div>
</div>
<iframe id="alistFrame" src="" style="width:100%;height:100%;border:none;display:none" allow="fullscreen;autoplay;encrypted-media"></iframe>
</div>
</div>

<!-- 媒体列表面板 -->
<div class="panel" id="panel-media">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title" id="mediaPanelTitle">视频列表</span>
<button class="back-btn" onclick="refreshMediaList()" style="margin-left:auto;font-size:20px">↻</button>
</div>
<div style="padding:16px">
<div id="mediaListLoading" style="text-align:center;padding:40px;color:#999">加载中...</div>
<div id="mediaListContainer" style="display:none"></div>
<div id="mediaListEmpty" style="display:none;text-align:center;padding:60px 20px;color:#999">
<div style="font-size:48px;margin-bottom:12px">📭</div>
<div>没有找到文件</div>
</div>
</div>
</div>

<!-- 文件管理面板 - Amaze原生布局 -->
<div class="panel" id="panel-files">
<!-- 侧边栏导航 -->
<div class="file-sidebar" id="fileSidebar" style="position:absolute;top:0;left:-280px;width:280px;height:100%;background:#fff;z-index:200;box-shadow:2px 0 12px rgba(0,0,0,.1);transition:left .3s;overflow-y:auto">
<div style="padding:24px 20px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff">
<div style="font-size:22px;font-weight:700">📁 NAS</div>
<div style="font-size:13px;opacity:.85;margin-top:4px">私有云文件管理器</div>
<div style="margin-top:16px;background:rgba(255,255,255,.2);border-radius:8px;padding:10px">
<div style="font-size:12px;opacity:.9;margin-bottom:6px">存储用量</div>
<div style="height:6px;background:rgba(255,255,255,.3);border-radius:3px;overflow:hidden">
<div id="sidebarStorageBar" style="height:100%;background:#fff;width:0%;border-radius:3px;transition:width .5s"></div>
</div>
<div style="font-size:11px;opacity:.8;margin-top:6px" id="sidebarStorageText">计算中...</div>
</div>
</div>
<div class="sidebar-section">
<div class="sidebar-title">存储</div>
<div class="sidebar-item active" onclick="navigateTo('/');toggleSidebar()">
<span>💾</span><span>内部存储</span>
</div>
</div>
<div class="sidebar-section">
<div class="sidebar-title">常用目录</div>
<div class="sidebar-item" onclick="navigateTo('/DCIM');toggleSidebar()"><span>📷</span><span>DCIM</span></div>
<div class="sidebar-item" onclick="navigateTo('/Download');toggleSidebar()"><span>⬇️</span><span>Download</span></div>
<div class="sidebar-item" onclick="navigateTo('/Movies');toggleSidebar()"><span>🎬</span><span>Movies</span></div>
<div class="sidebar-item" onclick="navigateTo('/Music');toggleSidebar()"><span>🎵</span><span>Music</span></div>
<div class="sidebar-item" onclick="navigateTo('/Pictures');toggleSidebar()"><span>🖼️</span><span>Pictures</span></div>
</div>
<div class="sidebar-section">
<div class="sidebar-title">分类浏览</div>
<div class="sidebar-item" onclick="setFilter('video');navigateTo('/');toggleSidebar()"><span>🎬</span><span>视频</span></div>
<div class="sidebar-item" onclick="setFilter('music');navigateTo('/');toggleSidebar()"><span>🎵</span><span>音乐</span></div>
<div class="sidebar-item" onclick="setFilter('image');navigateTo('/');toggleSidebar()"><span>🖼️</span><span>图片</span></div>
<div class="sidebar-item" onclick="setFilter('doc');navigateTo('/');toggleSidebar()"><span>📄</span><span>文档</span></div>
<div class="sidebar-item" onclick="setFilter('archive');navigateTo('/');toggleSidebar()"><span>📦</span><span>压缩包</span></div>
</div>
<div class="sidebar-section">
<div class="sidebar-title">工具</div>
<div class="sidebar-item" onclick="showStorageInfo();toggleSidebar()"><span>💾</span><span>存储信息</span></div>
<div class="sidebar-item" onclick="toggleHiddenFiles();toggleSidebar()"><span>👁️</span><span id="hiddenFilesText">显示隐藏文件</span></div>
<div class="sidebar-item" onclick="goHome();toggleSidebar()"><span>🏠</span><span>返回主页</span></div>
</div>
</div>
<div class="sidebar-overlay" id="sidebarOverlay" style="display:none;position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);z-index:199" onclick="toggleSidebar()"></div>

<!-- 顶部AppBar -->
<div class="native-appbar">
<button class="appbar-btn" onclick="goHome()" title="返回主页">←</button>
<button class="appbar-btn" onclick="toggleSidebar()">☰</button>
<span class="appbar-title" id="fileAppbarTitle">/storage/emulated/0</span>
<button class="appbar-btn" onclick="toggleSearch()">🔍</button>
<button class="appbar-btn" onclick="toggleFileMoreMenu()">⋮</button>
</div>

<!-- 搜索栏（可展开） -->
<div class="native-search" id="nativeSearch" style="display:none">
<input type="text" id="searchInput" placeholder="搜索文件..." oninput="onSearchInput(this.value)" onkeydown="if(event.key==='Enter')doSearch()">
<button class="search-close" onclick="toggleSearch()">✕</button>
</div>

<!-- 路径面包屑 -->
<div class="native-breadcrumb" id="breadcrumb"></div>

<!-- 文件统计 -->
<div class="file-stats" id="fileStats" style="display:none">0 个文件夹, 0 个文件</div>

<!-- 文件内容区域 -->
<div class="native-file-content" id="fileContainer" style="flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding-bottom:16px;min-height:0">
</div>

<!-- 浮动操作按钮 FAB -->
<button class="fab-btn" onclick="showFabMenu()">＋</button>
<div class="fab-menu" id="fabMenu" style="display:none;position:absolute;bottom:90px;right:16px;background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.15);z-index:150;overflow:hidden">
<div class="fab-menu-item" onclick="newFolder();hideFabMenu()">📁 新建文件夹</div>
<div class="fab-menu-item" onclick="newTextFile();hideFabMenu()">📄 新建文本</div>
<div class="fab-menu-item" onclick="document.getElementById('fileInput').click();hideFabMenu()">⬆️ 上传文件</div>
</div>

<!-- 底部操作栏 - 多选时显示 -->
<div class="native-bottom-bar" id="selectionBar" style="display:none">
<button class="bottom-nav-btn" onclick="clearSelection()">←</button>
<span class="selection-count" id="selectionCount">已选 0 项</span>
<div class="bottom-actions">
<button class="bottom-action-btn" onclick="shareSelected()" title="分享">🔗</button>
<button class="bottom-action-btn" onclick="copySelected()" title="复制">📋</button>
<button class="bottom-action-btn" onclick="renameSelected()" title="重命名">✏️</button>
<button class="bottom-action-btn danger" onclick="deleteSelected()" title="删除">🗑️</button>
<button class="bottom-action-btn" onclick="showSelectionMore()" title="更多">⋮</button>
</div>
</div>

<!-- 多选更多菜单 -->
<div class="selection-more-menu" id="selectionMoreMenu" style="display:none;position:absolute;bottom:72px;right:16px;background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.15);z-index:150;overflow:hidden;min-width:140px">
<div class="fab-menu-item" onclick="cutSelected();hideSelectionMore()">✂️ 剪切</div>
<div class="fab-menu-item" onclick="pasteSelected();hideSelectionMore()">📥 粘贴</div>
<div class="fab-menu-item" onclick="compressSelected();hideSelectionMore()">📦 压缩</div>
<div class="fab-menu-item" onclick="batchDownload();hideSelectionMore()">⬇️ 下载</div>
<div class="fab-menu-item" onclick="selectAll();hideSelectionMore()">☑️ 全选</div>
</div>

<!-- 文件管理器更多菜单 -->
<div class="file-more-menu" id="fileMoreMenu" style="display:none;position:absolute;top:56px;right:16px;background:#fff;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,.15);z-index:1000;min-width:160px;overflow:hidden">
<div class="more-menu-item" onclick="refreshFileList();hideFileMoreMenu()">🔄 刷新</div>
<div class="more-menu-item" onclick="toggleViewMode();hideFileMoreMenu()">🔲 切换视图</div>
<div class="more-menu-item" onclick="toggleHiddenFiles();hideFileMoreMenu()">👁️ 显示隐藏</div>
<div class="more-menu-item" onclick="selectAll();hideFileMoreMenu()">☑️ 全选</div>
<div class="more-menu-item" onclick="showStorageInfo();hideFileMoreMenu()">💾 存储信息</div>
</div>

<!-- 上传进度 -->
<div class="upload-progress" id="uploadProgress" style="display:none;position:absolute;top:120px;left:16px;right:16px;z-index:50">
<div id="uploadFileName">正在上传...</div>
<div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
<div class="progress-text"><span id="progressPercent">0%</span><span id="progressSpeed">0 KB/s</span></div>
</div>

<!-- 底部工具栏 -->
<div style="position:sticky;bottom:56px;left:0;right:0;height:48px;background:#fff;border-top:1px solid #eee;display:flex;z-index:100">
<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:11px;color:#666;cursor:pointer" onclick="uploadFiles()">
<div style="font-size:18px;margin-bottom:2px">⬆️</div>
<div>上传</div>
</div>
<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:11px;color:#666;cursor:pointer" onclick="createFolder()">
<div style="font-size:18px;margin-bottom:2px">📁</div>
<div>新建</div>
</div>
<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:11px;color:#666;cursor:pointer" onclick="selectAllFiles()">
<div style="font-size:18px;margin-bottom:2px">☑️</div>
<div>全选</div>
</div>
<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:11px;color:#666;cursor:pointer" onclick="downloadSelected()">
<div style="font-size:18px;margin-bottom:2px">⬇️</div>
<div>下载</div>
</div>
</div>

<input type="file" id="fileInput" multiple style="display:none" onchange="uploadFiles(this.files)">
</div>

<!-- 影音播放面板 -->
<div class="panel" id="panel-video">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">媒体库</span>
<button class="btn btn-ghost btn-sm" onclick="scanMedia()" style="margin-left:auto">🔍 扫描</button>
</div>
<!-- 标签切换 -->
<div style="display:flex;background:#fff;border-bottom:1px solid #eee">
<div style="flex:1;text-align:center;padding:12px 0;font-size:14px;color:#666;cursor:pointer;border-bottom:2px solid transparent" onclick="switchMediaTab('video')" id="tab-video">📹 视频</div>
<div style="flex:1;text-align:center;padding:12px 0;font-size:14px;color:#666;cursor:pointer;border-bottom:2px solid transparent" onclick="switchMediaTab('audio')" id="tab-audio">🎵 音乐</div>
<div style="flex:1;text-align:center;padding:12px 0;font-size:14px;color:#666;cursor:pointer;border-bottom:2px solid transparent" onclick="switchMediaTab('image')" id="tab-image">🖼️ 图片</div>
</div>
<!-- 搜索栏 -->
<div style="padding:12px 16px;background:#f5f5f5">
<div style="background:#fff;border-radius:20px;padding:8px 16px;display:flex;align-items:center">
<span style="margin-right:8px">🔍</span>
<input type="text" placeholder="搜索媒体..." style="flex:1;border:none;outline:none;font-size:14px">
</div>
</div>
<div style="padding:16px">
<!-- 主界面：分类网格 -->
<div id="mediaHome">
<div id="mediaCategoryList" style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px">
<div class="media-category-item" onclick="openMediaCategory('all')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">📁</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">全部</div>
<div style="font-size:11px;color:#999"><span id="mediaAllCount">0</span> 个文件</div>
</div>
<div class="media-category-item" onclick="openMediaCategory('video')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#a18cd1,#fbc2eb);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">🎬</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">视频</div>
<div style="font-size:11px;color:#999"><span id="mediaVideoCount">0</span> 个视频</div>
</div>
<div class="media-category-item" onclick="openMediaCategory('audio')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#84fab0,#8fd3f4);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">🎵</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">音乐</div>
<div style="font-size:11px;color:#999"><span id="mediaAudioCount">0</span> 首音乐</div>
</div>
<div class="media-category-item" onclick="openMediaCategory('image')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#ff9a9e,#fecfef);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">🖼️</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">图片</div>
<div style="font-size:11px;color:#999"><span id="mediaImageCount">0</span> 张图片</div>
</div>
</div>
</div>
<!-- 分类浏览界面 -->
<div id="mediaCategoryView" style="display:none">
<div style="display:flex;align-items:center;margin-bottom:16px">
<button onclick="backToMediaHome()" style="background:none;border:none;font-size:24px;color:#667eea;cursor:pointer;padding:0 8px 0 0">‹</button>
<span id="mediaCategoryTitle" style="font-size:18px;font-weight:600;color:#333;flex:1">全部</span>
</div>
<div class="media-grid grid-view" id="mediaGrid"></div>
</div>
<!-- 加密视频列表 -->
<div id="vaultVideoSection" style="display:none">
<div style="padding:12px 16px;background:#fff3cd;border-radius:8px;margin:12px 0;font-size:13px;color:#856404">
🔐 加密空间视频（需先解锁加密空间）
</div>
<div class="media-grid grid-view" id="vaultVideoGrid" style="padding:0"></div>
</div>
</div>
</div>

<!-- 备份恢复面板 -->
<div class="panel" id="panel-backup">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">备份恢复</span>
<div style="margin-left:auto;display:flex;gap:6px">
<button class="btn btn-ghost btn-sm" onclick="importBackup()">📥 导入</button>
<button class="btn btn-primary btn-sm" onclick="showBackupModal()">立即备份</button>
</div>
</div>
<!-- 自动备份状态卡片 -->
<div class="auto-backup-card" id="autoBackupCard">
<div class="auto-backup-header">
<div class="auto-backup-title">
<span class="auto-backup-icon">⏰</span>
<span>自动备份</span>
</div>
<div class="auto-backup-toggle" id="autoBackupToggle" onclick="toggleAutoBackup()">
<div class="toggle-circle"></div>
</div>
</div>
<div class="auto-backup-info" id="autoBackupInfo">
<div class="auto-backup-row"><span>检测手机</span><span id="detectedBrand">--</span></div>
<div class="auto-backup-row"><span>备份间隔</span><span id="backupInterval">--</span></div>
<div class="auto-backup-row"><span>上次备份</span><span id="lastBackupTime">--</span></div>
<div class="auto-backup-row"><span>下次备份</span><span id="nextBackupTime">--</span></div>
</div>
<button class="btn btn-sm" style="width:100%;margin-top:10px" onclick="showAutoBackupConfig()">⚙️ 配置自动备份</button>
</div>
<!-- 应用备份入口 -->
<div class="app-backup-entry" onclick="showAppBackup()">
<div class="app-backup-icon">📱</div>
<div class="app-backup-info">
<div class="app-backup-title">应用备份恢复</div>
<div class="app-backup-desc">备份已安装应用，恢复时自动下载安装</div>
</div>
<div class="app-backup-arrow">›</div>
</div>
<!-- 远程备份说明 -->
<div style="margin:12px 16px;padding:14px;background:linear-gradient(135deg,#667eea15,#764ba215);border-radius:12px;border-left:4px solid #667eea">
<div style="font-size:14px;font-weight:600;color:#333;margin-bottom:6px">☁️ 远程备份</div>
<div style="font-size:12px;color:#666;line-height:1.6;margin-bottom:8px">
导出备份文件后，可通过网盘管理（AList）上传到云盘，实现远程备份。<br>
换设备时，从云盘下载备份文件，点击「导入」即可恢复。
</div>
<button class="btn btn-sm" style="background:#667eea;color:#fff;border:none" onclick="openPanel('cloud')">前往网盘管理</button>
</div>
<div class="stat-cards">
<div class="stat-card"><div class="num" id="backupCount">0</div><div class="label">备份总数</div></div>
<div class="stat-card"><div class="num" id="backupSize">0 B</div><div class="label">总大小</div></div>
<div class="stat-card"><div class="num" id="backupRetention">30</div><div class="label">保留天数</div></div>
</div>
<div id="backupList"></div>
</div>

<!-- 自动备份配置弹窗 -->
<div id="autoBackupModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
<div style="background:#fff;padding:20px;border-radius:16px;width:92%;max-width:480px;max-height:88vh;overflow-y:auto">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 style="margin:0">手机备份恢复</h4>
<button onclick="document.getElementById('autoBackupModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>
<!-- 备份/恢复标签 -->
<div style="display:flex;background:#f0f0f0;border-radius:10px;padding:4px;margin-bottom:16px">
<button class="backup-tab active" id="tabBackup" onclick="switchBackupTab('backup')" style="flex:1;padding:10px;border:none;border-radius:8px;background:#fff;font-weight:600;cursor:pointer">备份</button>
<button class="backup-tab" id="tabRestore" onclick="switchBackupTab('restore')" style="flex:1;padding:10px;border:none;border-radius:8px;background:transparent;font-weight:600;cursor:pointer;color:#999">恢复</button>
</div>
<!-- 手机品牌选择 -->
<div class="form-group" id="brandSelectGroup">
<label>选择手机品牌</label>
<select id="brandSelect" onchange="loadBackupCategories()">
<option value="">-- 请选择 --</option>
<option value="xiaomi">📱 小米 / Redmi (MIUI/HyperOS)</option>
<option value="oneplus">📱 一加 / OPPO (ColorOS)</option>
<option value="common">📱 通用安卓</option>
</select>
</div>
<!-- 备份分类列表 -->
<div id="backupCategories" style="display:none;margin-bottom:16px">
<div style="font-size:13px;color:#999;margin-bottom:8px">选择要备份的内容</div>
<div id="categoryList"></div>
</div>
<!-- 恢复列表 -->
<div id="restoreListSection" style="display:none;margin-bottom:16px">
<div id="restoreBackupList"></div>
</div>
<!-- 自动备份设置 -->
<div id="autoBackupSettings" style="display:none">
<div class="form-group">
<label>自动备份间隔（小时，0=关闭）</label>
<input type="number" id="backupIntervalInput" value="24" min="0" max="168">
</div>
<div class="form-group">
<label>每日备份时间</label>
<input type="time" id="backupTimeInput" value="03:00">
</div>
<div class="form-group">
<label>保留天数</label>
<input type="number" id="retentionDaysInput" value="30" min="1" max="365">
</div>
</div>
<!-- 底部按钮 -->
<div style="display:flex;gap:8px;margin-top:16px">
<button class="btn" style="flex:1" onclick="document.getElementById('autoBackupModal').style.display='none'">取消</button>
<button class="btn btn-primary" style="flex:2" id="backupActionBtn" onclick="doBackupAction()">立即备份</button>
</div>
<div style="font-size:11px;color:#999;margin-top:12px;text-align:center">说明：备份文件保存在 ~/nas-backups/ 目录</div>
</div>
</div>

<!-- 组网设置面板 -->
<!-- 音乐播放面板 -->
<div class="panel" id="panel-music">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">音乐播放</span>
<button class="btn btn-ghost btn-sm" onclick="scanMedia()" style="margin-left:auto">🔍 扫描</button>
</div>
<!-- 音乐列表 -->
<div class="music-list" id="musicList"></div>
<div id="vaultMusicSection" style="display:none">
<div style="padding:12px 16px;background:#fff3cd;border-radius:8px;margin:12px 16px;font-size:13px;color:#856404">
🔐 加密空间音乐（需先解锁加密空间）
</div>
<div class="music-list" id="vaultMusicList"></div>
</div>
</div>

<!-- 酷我风格全屏播放器 -->
<div class="kuwo-player" id="kuwoPlayer">
<div class="kuwo-player-bg" id="kuwoPlayerBg"></div>
<div class="kuwo-player-header">
<button onclick="closeKuwoPlayer()">‹</button>
<button onclick="toggleLyricsPanel()">词</button>
</div>

<!-- 歌词面板 -->
<div id="lyricsPanel" style="display:none;position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.85);z-index:20;overflow-y:auto;padding:60px 20px 100px;box-sizing:border-box">
<div id="lyricsContent" style="text-align:center;color:rgba(255,255,255,.6);font-size:14px;line-height:2.2">
<div style="padding:40px 0">暂无歌词</div>
</div>
</div>
<div class="kuwo-cover-wrap">
<div class="kuwo-cover" id="kuwoCover">
<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
</div>
</div>
<div class="kuwo-song-info">
<div class="kuwo-song-name" id="kuwoSongName">未选择歌曲</div>
<div class="kuwo-song-artist">
<span id="kuwoSongArtist">NAS私有云</span>
<span class="kuwo-source-tag">NAS</span>
</div>
</div>
<!-- 功能按钮区：所有功能都在这里 -->
<div class="kuwo-actions">
<button class="kuwo-action-btn" id="kuwoLikeBtn" onclick="toggleKuwoLike()">
<span class="kuwo-action-icon">♡</span>
<span class="kuwo-action-text">喜欢</span>
</button>
<button class="kuwo-action-btn" onclick="showKuwoEffect()">
<span class="kuwo-action-icon">🎚</span>
<span class="kuwo-action-text">音效</span>
</button>
<button class="kuwo-action-btn" onclick="showKuwoSpeed()">
<span class="kuwo-action-icon">⚡</span>
<span class="kuwo-action-text">倍速</span>
</button>
<button class="kuwo-action-btn" onclick="showKuwoSleepTimer()">
<span class="kuwo-action-icon">⏱</span>
<span class="kuwo-action-text">定时</span>
</button>
<button class="kuwo-action-btn" onclick="showKuwoPlaylist()">
<span class="kuwo-action-icon">☰</span>
<span class="kuwo-action-text">列表</span>
</button>
<button class="kuwo-action-btn" onclick="showToast('分享功能开发中')">
<span class="kuwo-action-icon">⤴</span>
<span class="kuwo-action-text">分享</span>
</button>
</div>
<div class="kuwo-progress-wrap">
<div class="kuwo-progress" id="kuwoProgress" onclick="seekKuwo(event)">
<div class="kuwo-progress-bar" id="kuwoProgressBar"></div>
</div>
<div class="kuwo-time">
<span id="kuwoCurTime">00:00</span>
<span id="kuwoTotalTime">00:00</span>
</div>
</div>
<div class="kuwo-controls">
<button class="kuwo-ctrl-btn small" id="kuwoModeBtn" onclick="toggleKuwoMode()">🔁</button>
<button class="kuwo-ctrl-btn" onclick="kuwoPrev()">⏮</button>
<button class="kuwo-ctrl-btn play" id="kuwoPlayBtn" onclick="toggleKuwoPlay()">▶</button>
<button class="kuwo-ctrl-btn" onclick="kuwoNext()">⏭</button>
<button class="kuwo-ctrl-btn small" onclick="toggleKuwoRotate()">🔄</button>
</div>
</div>

<!-- 更多操作菜单 -->
<div class="kuwo-more-menu" id="kuwoMoreMenu">
<div class="kuwo-more-menu-item" onclick="showKuwoEffect();hideKuwoMoreMenu()">
<span class="kuwo-more-icon">🎚</span>
<span class="kuwo-more-text">音效</span>
</div>
<div class="kuwo-more-menu-item" onclick="showKuwoSleepTimer();hideKuwoMoreMenu()">
<span class="kuwo-more-icon">⏰</span>
<span class="kuwo-more-text">睡眠定时</span>
</div>
<div class="kuwo-more-menu-item" onclick="showKuwoSpeed();hideKuwoMoreMenu()">
<span class="kuwo-more-icon">⚡</span>
<span class="kuwo-more-text">倍速播放</span>
</div>
<div class="kuwo-more-menu-item" onclick="showKuwoSongInfo();hideKuwoMoreMenu()">
<span class="kuwo-more-icon">ℹ️</span>
<span class="kuwo-more-text">歌曲信息</span>
</div>
<div class="kuwo-more-menu-item" onclick="toggleKuwoRotate();hideKuwoMoreMenu()">
<span class="kuwo-more-icon">🔄</span>
<span class="kuwo-more-text" id="kuwoRotateText">封面旋转：开</span>
</div>
<div class="kuwo-more-menu-item" onclick="showToast('分享功能开发中');hideKuwoMoreMenu()">
<span class="kuwo-more-icon">⤴</span>
<span class="kuwo-more-text">分享</span>
</div>
</div>

<!-- 音效面板遮罩 -->
<div class="kuwo-mask" id="kuwoMask" onclick="hideKuwoEffect()"></div>
<!-- 音效面板 -->
<div class="kuwo-effect-panel" id="kuwoEffectPanel">
<div class="kuwo-effect-header">
<h3>音效</h3>
<button onclick="hideKuwoEffect()">×</button>
</div>
<div class="kuwo-effect-tabs">
<div class="kuwo-effect-tab active" onclick="switchKuwoEffectTab(this,'presets')">官方音效</div>
<div class="kuwo-effect-tab" onclick="switchKuwoEffectTab(this,'eq')">均衡器</div>
</div>
<div id="kuwoEffectPresets">
<div class="kuwo-effect-list" id="kuwoEffectList"></div>
</div>
<div id="kuwoEffectEq" style="display:none">
<div class="kuwo-eq-wrap">
<div class="kuwo-eq-bands" id="kuwoEqBands"></div>
<div class="kuwo-eq-presets" id="kuwoEqPresets"></div>
</div>
</div>
</div>

<!-- 播放列表面板 -->
<div class="kuwo-effect-panel" id="kuwoPlaylistPanel" style="background:#fff;color:#333">
<div class="kuwo-effect-header" style="color:#333;border-bottom:1px solid #eee">
<h3>播放列表 (<span id="kuwoPlaylistCount">0</span>)</h3>
<button onclick="hideKuwoPlaylist()" style="color:#333">×</button>
</div>
<div id="kuwoPlaylistItems" style="max-height:60vh;overflow-y:auto"></div>
</div>

<!-- 用户管理面板 -->
<div class="panel" id="panel-users">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">用户管理</span>
<button class="btn btn-primary btn-sm" onclick="showUserModal()" style="margin-left:auto">+ 添加用户</button>
</div>
<div style="padding:16px">
<div class="stat-cards" style="margin-bottom:16px">
<div class="stat-card"><div class="num" id="userCount">0</div><div class="label">用户总数</div></div>
<div class="stat-card"><div class="num" id="adminCount">0</div><div class="label">管理员</div></div>
<div class="stat-card"><div class="num" id="activeUserCount">0</div><div class="label">活跃用户</div></div>
</div>
<div id="userList"></div>
</div>
</div>

<!-- 添加/编辑用户弹窗 -->
<div id="userModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
<div style="background:#fff;padding:20px;border-radius:16px;width:92%;max-width:400px">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 id="userModalTitle" style="margin:0">添加用户</h4>
<button onclick="hideUserModal()" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>
<div class="form-group">
<label>用户名</label>
<input type="text" id="userUsername" placeholder="请输入用户名" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box">
</div>
<div class="form-group">
<label>密码</label>
<input type="password" id="userPassword" placeholder="请输入密码" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box">
</div>
<div class="form-group">
<label>角色</label>
<select id="userRole" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box">
<option value="user">普通用户</option>
<option value="admin">管理员</option>
</select>
</div>
<div class="form-group">
<label>邮箱（可选）</label>
<input type="email" id="userEmail" placeholder="请输入邮箱" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box">
</div>
<button class="btn btn-primary" style="width:100%;padding:12px;border-radius:10px" onclick="saveUser()">保存</button>
</div>
</div>

<!-- 权限管理弹窗 -->
<div id="permissionModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2001;align-items:center;justify-content:center">
<div style="background:#fff;padding:20px;border-radius:16px;width:92%;max-width:400px;max-height:80vh;overflow-y:auto">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 id="permissionModalTitle" style="margin:0">设置权限</h4>
<button onclick="hidePermissionModal()" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>
<div style="margin-bottom:12px;font-size:13px;color:#666">勾选允许该用户访问的功能模块：</div>
<div id="permissionList" style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px"></div>
<div style="display:flex;gap:8px">
<button class="btn" style="flex:1;padding:12px;border-radius:10px" onclick="hidePermissionModal()">取消</button>
<button class="btn btn-primary" style="flex:1;padding:12px;border-radius:10px" onclick="savePermissions()">保存权限</button>
</div>
</div>
</div>

<!-- 设置面板 -->
<div class="panel" id="panel-settings">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">系统设置</span>
</div>
<div class="settings-menu">
<!-- 外观设置 -->
<div class="settings-item" onclick="toggleTheme()">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#667eea,#764ba2)">🌙</span>
<div class="settings-info"><div class="settings-name">深色模式</div><div class="settings-desc">切换黑白光暗主题</div></div>
<span class="settings-arrow">›</span>
</div>
<!-- 账号管理 -->
<div class="settings-item" onclick="logout()">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#ff6b6b,#ee5a24)">👤</span>
<div class="settings-info"><div class="settings-name">账号管理</div><div class="settings-desc">退出登录</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="showSetting('network')">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#4facfe,#00f2fe)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg></span>
<div class="settings-info"><div class="settings-name">组网设置</div><div class="settings-desc">远程访问、n2n/Tailscale</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="showSetting('autostart')">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#43e97b,#38f9d7)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M13 3v9.5c0 1.93-1.57 3.5-3.5 3.5S6 14.43 6 12.5 7.57 9 9.5 9c.36 0 .71.05 1.04.15V5h4V3h-4zm-2 16c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/></svg></span>
<div class="settings-info"><div class="settings-name">开机自启</div><div class="settings-desc">Termux 启动时自动运行 NAS</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="showSetting('security')">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#fa709a,#fee140)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg></span>
<div class="settings-info"><div class="settings-name">安全管理</div><div class="settings-desc">修改密码、登录日志、IP限制</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="showSetting('update')">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#a18cd1,#fbc2eb)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"/></svg></span>
<div class="settings-info"><div class="settings-name">检查更新</div><div class="settings-desc">当前版本 v1.2.0</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="showSetting('about')">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#89f7fe,#66a6ff)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg></span>
<div class="settings-info"><div class="settings-name">关于</div><div class="settings-desc">版本信息、开源协议</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="showSetting('debug')">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#ffd89b,#19547b)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/></svg></span>
<div class="settings-info"><div class="settings-name">调试工具</div><div class="settings-desc">系统诊断、日志、连接测试</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="showSetting('iconSize')">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#4facfe,#00f2fe)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M3 5v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2zm16 14H5V5h14v14zm-7-2h4v-4h-4v4zm-6 0h4v-4H6v4zm0-6h4V7H6v4zm6 0h4V7h-4v4z"/></svg></span>
<div class="settings-info"><div class="settings-name">图标大小</div><div class="settings-desc">XS / S / M / L / XL 五档调节</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="toggleNotificationPanel()">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#fa709a,#fee140)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg></span>
<div class="settings-info"><div class="settings-name">消息通知</div><div class="settings-desc">备份完成、安全告警、系统消息</div></div>
<span class="settings-arrow">›</span>
</div>
<div class="settings-item" onclick="showPWAManager()">
<span class="settings-icon miui-settings-icon" style="background:linear-gradient(135deg,#667eea,#764ba2)"><svg viewBox="0 0 24 24" fill="white" width="22" height="22"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg></span>
<div class="settings-info"><div class="settings-name">PWA管理</div><div class="settings-desc">离线缓存、Service Worker、安装应用</div></div>
<span class="settings-arrow">›</span>
</div>
</div>
<!-- 设置子页面 -->
<div id="settingContent" style="display:none;padding:16px">
<button class="btn btn-ghost btn-sm" onclick="backToSettings()" style="margin-bottom:16px">‹ 返回设置</button>
<div id="settingDetail"></div>
</div>
</div>

<!-- PWA管理面板 -->
<div class="panel" id="panel-pwa">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">PWA管理</span>
</div>
<div style="padding:16px">
<!-- 状态卡片 -->
<div class="card" style="margin-bottom:16px">
<h3 style="margin-bottom:12px;font-size:16px">运行状态</h3>
<div id="pwaStatus" style="font-size:13px;color:#666;line-height:2">
加载中...
</div>
</div>

<!-- 操作按钮 -->
<div class="card" style="margin-bottom:16px">
<h3 style="margin-bottom:12px;font-size:16px">操作</h3>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
<button class="btn btn-primary btn-sm" onclick="pwaRegister()">注册SW</button>
<button class="btn btn-ghost btn-sm" onclick="pwaUnregister()">注销SW</button>
<button class="btn btn-primary btn-sm" onclick="pwaUpdate()">检查更新</button>
<button class="btn btn-ghost btn-sm" onclick="pwaRefresh()">刷新状态</button>
<button class="btn btn-danger btn-sm" onclick="pwaClearCache()" style="grid-column:span 2">清除所有缓存</button>
</div>
</div>

<!-- 缓存列表 -->
<div class="card">
<h3 style="margin-bottom:12px;font-size:16px">缓存列表</h3>
<div id="pwaCacheList" style="font-size:13px">
加载中...
</div>
</div>
</div>
</div>

<!-- 系统监控面板 -->
<div class="panel" id="panel-system">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">系统监控</span>
<span id="systemUptime" style="font-size:12px;color:#999">运行中</span>
</div>
<div style="padding:16px">
<div class="monitor-grid">
<div class="monitor-card">
<div class="monitor-header"><span class="monitor-icon">⚡</span><span>CPU</span><span class="monitor-value" id="cpuValue">0%</span></div>
<div class="monitor-bar"><div class="monitor-fill" id="cpuBar" style="width:0%"></div></div>
<div class="monitor-detail" id="cpuDetail">-- 核</div>
</div>
<div class="monitor-card">
<div class="monitor-header"><span class="monitor-icon">💾</span><span>内存</span><span class="monitor-value" id="memValue">0%</span></div>
<div class="monitor-bar"><div class="monitor-fill" id="memBar" style="width:0%;background:linear-gradient(90deg,#4facfe,#00f2fe)"></div></div>
<div class="monitor-detail" id="memDetail">0 / 0 GB</div>
</div>
<div class="monitor-card">
<div class="monitor-header"><span class="monitor-icon">📦</span><span>存储</span><span class="monitor-value" id="storageValue">0%</span></div>
<div class="monitor-bar"><div class="monitor-fill" id="storageBar" style="width:0%;background:linear-gradient(90deg,#43e97b,#38f9d7)"></div></div>
<div class="monitor-detail" id="storageDetail">0 / 0 GB</div>
</div>
<div class="monitor-card">
<div class="monitor-header"><span class="monitor-icon">🌐</span><span>网络</span><span class="monitor-value" id="netValue">0 KB/s</span></div>
<div class="monitor-detail" style="margin-top:8px">
<div>↓ <span id="netRx">0 KB/s</span></div>
<div>↑ <span id="netTx">0 KB/s</span></div>
</div>
</div>
</div>
<div class="monitor-section">
<h4 style="margin-bottom:12px;font-size:14px">进程列表（按内存排序）</h4>
<div id="processList" class="process-list"></div>
</div>

<!-- AList状态 -->
<div class="monitor-section">
<h4 style="margin-bottom:12px;font-size:14px">AList状态</h4>
<div class="card" id="alistStatusCard" style="padding:12px">
<div style="display:flex;align-items:center;justify-content:space-between">
<div style="display:flex;align-items:center;gap:8px">
<span id="alistStatusDot" style="width:10px;height:10px;border-radius:50%;background:#999"></span>
<span id="alistStatusText">检测中...</span>
</div>
<span id="alistVersion" style="font-size:12px;color:#999"></span>
</div>
<div style="margin-top:8px;font-size:12px;color:#666">
端口: <span id="alistPort">5244</span>
</div>
</div>
</div>

<!-- 错误日志 -->
<div class="monitor-section">
<h4 style="margin-bottom:12px;font-size:14px;display:flex;justify-content:space-between;align-items:center">
<span>⚠️ 错误日志 <span id="errorLogCount" style="background:#e74c3c;color:#fff;font-size:10px;padding:2px 6px;border-radius:8px;margin-left:4px">0</span></span>
<div style="display:flex;gap:6px">
<button class="btn btn-ghost btn-sm" onclick="renderErrorLogs()">刷新</button>
<button class="btn btn-ghost btn-sm" onclick="exportFrontLogs()">导出</button>
<button class="btn btn-ghost btn-sm" onclick="clearErrorLogs()">清空</button>
</div>
</h4>
<div id="errorLogsContainer" style="font-size:12px;color:#666;max-height:300px;overflow-y:auto">
暂无错误记录
</div>
</div>

<!-- 监控历史 -->
<div class="monitor-section">
<h4 style="margin-bottom:12px;font-size:14px;display:flex;justify-content:space-between;align-items:center">
<span>监控历史</span>
<button class="btn btn-ghost btn-sm" onclick="loadMonitorHistory()">刷新</button>
</h4>
<div id="monitorHistory" style="font-size:12px;color:#666;max-height:200px;overflow-y:auto">
加载中...
</div>
</div>

<!-- 监控日志 -->
<div class="monitor-section">
<h4 style="margin-bottom:12px;font-size:14px;display:flex;justify-content:space-between;align-items:center">
<span>监控日志</span>
<button class="btn btn-ghost btn-sm" onclick="loadMonitorLogs()">刷新</button>
</h4>
<div id="monitorLogs" style="font-size:11px;color:#666;max-height:200px;overflow-y:auto;background:#f8f9fa;padding:8px;border-radius:6px;font-family:monospace">
加载中...
</div>
</div>
</div>
</div>

<!-- VPN管理面板 -->
<div class="panel" id="panel-vpn">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">VPN 管理</span>
</div>
<div style="padding:16px">
<!-- VPN服务器状态卡片 -->
<div class="vpn-server-card">
<div class="vpn-server-header">
<div class="vpn-server-icon">🛡️</div>
<div class="vpn-server-info">
<div class="vpn-server-title">主 VPN 服务器</div>
<div class="vpn-server-sub" id="vpnServerInfo">WireGuard · --</div>
<div class="vpn-server-sub" id="vpnSubnet">子网: 10.0.0.0/24</div>
</div>
</div>
<div class="vpn-server-status">
<span class="vpn-status-dot" id="vpnStatusDot"></span>
<span id="vpnStatusText">未运行</span>
</div>
<div class="vpn-server-actions">
<button class="vpn-btn vpn-btn-danger" id="vpnToggleBtn" onclick="vpnToggle()">启动</button>
<button class="vpn-btn" onclick="vpnShowConfig()">配置</button>
<button class="vpn-btn" onclick="vpnShowGuide()">部署指南</button>
</div>
<div class="vpn-server-actions" style="margin-top:8px">
<button class="vpn-btn" onclick="vpnDownloadServerConfig()">📥 下载服务器配置</button>
<button class="vpn-btn" onclick="vpnDownloadNASConfig()">📱 下载NAS客户端配置</button>
</div>
<div class="vpn-stats">
<div class="vpn-stat">
<div class="vpn-stat-label">已连接客户端</div>
<div class="vpn-stat-value" id="vpnOnlineCount">0 / 0</div>
</div>
<div class="vpn-stat">
<div class="vpn-stat-label">总上传流量</div>
<div class="vpn-stat-value vpn-upload" id="vpnTotalUpload">0 B</div>
</div>
<div class="vpn-stat">
<div class="vpn-stat-label">总下载流量</div>
<div class="vpn-stat-value vpn-download" id="vpnTotalDownload">0 B</div>
</div>
<div class="vpn-stat">
<div class="vpn-stat-label">DNS</div>
<div class="vpn-stat-value" id="vpnDNS">8.8.8.8</div>
</div>
</div>
</div>

<!-- 客户端列表 -->
<div class="vpn-clients-card">
<div class="vpn-clients-header">
<span class="vpn-clients-title">客户端列表</span>
<button class="vpn-add-btn" onclick="vpnAddClient()">+ 添加客户端</button>
</div>
<div class="vpn-client-table">
<div class="vpn-client-row vpn-client-header">
<div>设备名称</div>
<div>IP 地址</div>
<div>状态</div>
<div>操作</div>
</div>
<div id="vpnClientList"></div>
</div>
</div>
</div>
</div>

<!-- VPN配置弹窗 -->
<div id="vpnConfigModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
<div style="background:#fff;padding:24px;border-radius:12px;width:90%;max-width:400px">
<h4 style="margin-bottom:16px">VPN 配置</h4>
<div style="margin-bottom:12px">
<label style="display:block;font-size:12px;color:#666;margin-bottom:4px">监听端口</label>
<input type="number" id="vpnPort" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px">
</div>
<div style="margin-bottom:12px">
<label style="display:block;font-size:12px;color:#666;margin-bottom:4px">服务器地址（Endpoint）</label>
<input type="text" id="vpnEndpoint" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px" placeholder="vpn.example.com:51820">
</div>
<div style="margin-bottom:12px">
<label style="display:block;font-size:12px;color:#666;margin-bottom:4px">DNS</label>
<input type="text" id="vpnDNSInput" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px">
</div>
<div style="margin-bottom:16px">
<label style="display:block;font-size:12px;color:#666;margin-bottom:4px">子网</label>
<input type="text" id="vpnSubnetInput" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px">
</div>
<div style="display:flex;gap:8px;justify-content:flex-end">
<button onclick="document.getElementById('vpnConfigModal').style.display='none'" style="padding:8px 16px;border:1px solid #ddd;border-radius:6px;background:#fff;cursor:pointer">取消</button>
<button onclick="vpnSaveConfig()" style="padding:8px 16px;border:none;border-radius:6px;background:#667eea;color:#fff;cursor:pointer">保存</button>
</div>
</div>
</div>

<!-- VPN部署指南弹窗 -->
<div id="vpnGuideModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
<div style="background:#fff;padding:24px;border-radius:12px;width:92%;max-width:480px;max-height:85vh;overflow-y:auto">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 style="margin:0">VPN 部署指南（方案3：其他设备运行服务器）</h4>
<button onclick="document.getElementById('vpnGuideModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>

<div style="margin-bottom:16px">
<div style="font-weight:600;color:#333;margin-bottom:8px">📋 总体步骤</div>
<div style="font-size:13px;color:#666;line-height:1.8">
1. 在其他设备部署 WireGuard 服务器<br>
2. 下载服务器配置并导入<br>
3. 下载NAS客户端配置，手机连接<br>
4. 其他设备也用客户端配置连接
</div>
</div>

<div style="margin-bottom:16px">
<div style="font-weight:600;color:#333;margin-bottom:8px">🖥️ 方案A：云服务器（推荐）</div>
<div style="font-size:13px;color:#666;line-height:1.8;background:#f8f9fa;padding:12px;border-radius:8px">
# 1. 购买云服务器（阿里云/腾讯云，最低配即可）<br>
# 2. 安装 WireGuard<br>
sudo apt install wireguard<br>
# 3. 上传服务器配置<br>
sudo cp wg0-server.conf /etc/wireguard/wg0.conf<br>
# 4. 开启IP转发<br>
echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf<br>
sysctl -p<br>
# 5. 启动服务<br>
sudo wg-quick up wg0<br>
sudo systemctl enable wg-quick@wg0<br>
# 6. 安全组放行 UDP 51820 端口
</div>
</div>

<div style="margin-bottom:16px">
<div style="font-weight:600;color:#333;margin-bottom:8px">🍓 方案B：树莓派/小主机</div>
<div style="font-size:13px;color:#666;line-height:1.8;background:#f8f9fa;padding:12px;border-radius:8px">
# 1. 安装系统（Raspberry Pi OS / Ubuntu）<br>
sudo apt install wireguard<br>
# 2. 配置同上<br>
sudo cp wg0-server.conf /etc/wireguard/wg0.conf<br>
sudo wg-quick up wg0<br>
# 3. 路由器端口映射 UDP 51820 到树莓派
</div>
</div>

<div style="margin-bottom:16px">
<div style="font-weight:600;color:#333;margin-bottom:8px">📡 方案C：路由器（OpenWrt/梅林）</div>
<div style="font-size:13px;color:#666;line-height:1.8;background:#f8f9fa;padding:12px;border-radius:8px">
# OpenWrt:<br>
opkg install wireguard-tools luci-proto-wireguard<br>
# 在 网络→接口→添加新接口→WireGuard VPN<br>
# 导入配置内容<br><br>
# 梅林固件:<br>
# 软件中心安装 WireGuard 插件<br>
# 导入配置即可
</div>
</div>

<div style="margin-bottom:16px">
<div style="font-weight:600;color:#333;margin-bottom:8px">📱 手机NAS连接</div>
<div style="font-size:13px;color:#666;line-height:1.8;background:#f8f9fa;padding:12px;border-radius:8px">
# 方式1：WireGuard App（推荐，无需root）<br>
1. 安装 WireGuard App<br>
2. 点击 + → 从文件导入<br>
3. 选择 wg0-nas-client.conf<br>
4. 开启开关即可连接<br><br>
# 方式2：Termux（需root）<br>
pkg install wireguard-tools<br>
sudo wg-quick up wg0-nas-client.conf
</div>
</div>

<div style="margin-bottom:16px">
<div style="font-weight:600;color:#333;margin-bottom:8px">💡 重要提示</div>
<div style="font-size:13px;color:#666;line-height:1.8">
• 服务器配置中的 Endpoint 要改成你的公网IP或域名<br>
• 云服务器需在安全组放行 UDP 51820<br>
• 家用宽带需路由器做端口映射<br>
• 客户端配置中的 AllowedIPs 设为 10.0.0.0/24 只走VPN流量<br>
• 设为 0.0.0.0/0 则全部流量走VPN（全局代理）
</div>
</div>

<div style="text-align:center">
<button onclick="document.getElementById('vpnGuideModal').style.display='none'" style="padding:10px 24px;border:none;border-radius:8px;background:#667eea;color:#fff;cursor:pointer;font-size:14px">我知道了</button>
</div>
</div>
</div>

<!-- 在线笔记面板（已禁用） -->
<div class="panel" id="panel-notes" style="display:none !important">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">在线笔记</span>
<button class="btn btn-primary" style="padding:6px 14px;font-size:13px" onclick="newNote()">+ 新建</button>
</div>
<!-- 笔记列表 -->
<div id="notesListView" style="padding:16px">
<div id="notesList" class="notes-grid"></div>
</div>
<!-- 笔记编辑器 -->
<div id="notesEditorView" style="display:none;padding:16px">
<div style="display:flex;gap:8px;margin-bottom:12px">
<input type="text" id="noteTitle" placeholder="笔记标题" style="flex:1;padding:10px;border:1px solid #ddd;border-radius:8px;font-size:15px">
<button class="btn" onclick="togglePreview()" id="previewBtn">预览</button>
<button class="btn btn-primary" onclick="saveNote()">保存</button>
<button class="btn btn-danger" onclick="deleteCurrentNote()">删除</button>
</div>
<div style="display:flex;gap:12px;height:calc(100vh - 200px)">
<div style="flex:1;display:flex;flex-direction:column">
<div style="font-size:12px;color:#999;margin-bottom:4px">Markdown 编辑</div>
<textarea id="noteContent" style="flex:1;padding:12px;border:1px solid #ddd;border-radius:8px;font-family:monospace;font-size:14px;resize:none" placeholder="# 标题\n\n正文内容，支持 Markdown 语法..."></textarea>
</div>
<div id="notePreview" style="flex:1;display:none;flex-direction:column">
<div style="font-size:12px;color:#999;margin-bottom:4px">预览</div>
<div id="notePreviewContent" style="flex:1;padding:16px;border:1px solid #ddd;border-radius:8px;overflow-y:auto;background:#fff"></div>
</div>
</div>
<div style="margin-top:8px;font-size:12px;color:#999" id="noteMeta"></div>
</div>
</div>

<!-- 应用备份弹窗 -->
<div id="appBackupModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
<div style="background:#fff;padding:20px;border-radius:16px;width:92%;max-width:480px;max-height:85vh;overflow-y:auto">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 style="margin:0">应用备份恢复</h4>
<button onclick="document.getElementById('appBackupModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>
<!-- 操作按钮 -->
<div style="display:flex;gap:8px;margin-bottom:16px">
<button class="btn btn-primary btn-sm" style="flex:1" onclick="createAppBackup()">📦 备份应用列表</button>
<button class="btn btn-sm" style="flex:1" onclick="loadInstalledApps()">📱 查看已安装</button>
</div>
<!-- 备份列表 -->
<div id="appBackupList" style="margin-bottom:16px">
<div style="text-align:center;color:#999;padding:20px">加载中...</div>
</div>
<!-- 已安装应用列表 -->
<div id="installedAppsSection" style="display:none">
<div style="font-size:14px;font-weight:600;margin-bottom:8px">已安装应用（点击下载）</div>
<div class="app-list" id="installedAppsList"></div>
</div>
</div>
</div>

<!-- 应用恢复弹窗 -->
<div id="appRestoreModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2001;align-items:center;justify-content:center">
<div style="background:#fff;padding:20px;border-radius:16px;width:92%;max-width:480px;max-height:85vh;overflow-y:auto">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 style="margin:0" id="appRestoreTitle">恢复应用</h4>
<button onclick="document.getElementById('appRestoreModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>
<div style="font-size:12px;color:#999;margin-bottom:12px">点击应用名称跳转到应用商店，商店没有的点击「浏览器下载」</div>
<div class="app-list" id="appRestoreList"></div>
<div style="margin-top:16px;display:flex;gap:8px">
<button class="btn btn-sm" style="flex:1" onclick="restoreAllApps('play')">全部应用商店</button>
<button class="btn btn-sm" style="flex:1" onclick="restoreAllApps('browser')">全部浏览器下载</button>
</div>
</div>
</div>

<!-- 通知面板 -->
<div id="notificationPanel" style="display:none;position:fixed;top:0;right:0;width:340px;max-width:90vw;height:100vh;background:#fff;z-index:3000;box-shadow:-4px 0 20px rgba(0,0,0,.15);transform:translateX(100%);transition:transform .3s;overflow-y:auto">
<div style="padding:16px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;position:sticky;top:0;z-index:1">
<div style="display:flex;justify-content:space-between;align-items:center">
<h4 style="margin:0">消息通知</h4>
<button onclick="toggleNotificationPanel()" style="background:none;border:none;color:#fff;font-size:20px;cursor:pointer">&times;</button>
</div>
<div style="display:flex;gap:8px;margin-top:12px">
<button class="btn btn-sm" style="flex:1;background:rgba(255,255,255,.2);color:#fff;border:none" onclick="markAllRead()">全部已读</button>
<button class="btn btn-sm" style="flex:1;background:rgba(255,255,255,.2);color:#fff;border:none" onclick="clearNotifications()">清空</button>
</div>
</div>
<div id="notificationList" style="padding:12px">
<div style="text-align:center;color:#999;padding:40px">加载中...</div>
</div>
</div>
<div id="notificationOverlay" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.3);z-index:2999" onclick="toggleNotificationPanel()"></div>

<!-- DLNA投屏面板 -->
<div class="panel" id="panel-dlna">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">DLNA投屏</span>
</div>
<div style="padding:16px">
<div class="dlna-status-card" id="dlnaStatusCard">
<div class="dlna-status-icon" id="dlnaStatusIcon">📺</div>
<div class="dlna-status-info">
<div class="dlna-status-title" id="dlnaStatusTitle">未启动</div>
<div class="dlna-status-desc" id="dlnaStatusDesc">点击下方按钮启动DLNA服务</div>
</div>
<button class="btn btn-primary" id="dlnaToggleBtn" onclick="toggleDlna()">启动服务</button>
</div>
<div class="dlna-info-section" id="dlnaInfoSection" style="display:none">
<div class="dlna-info-title">设备信息</div>
<div class="dlna-info-item"><span>设备名称</span><span>NAS私有云 - 媒体服务器</span></div>
<div class="dlna-info-item"><span>设备IP</span><span id="dlnaLocalIP">--</span></div>
<div class="dlna-info-item"><span>服务端口</span><span>8200</span></div>
<div class="dlna-info-item"><span>SSDP发现</span><span id="dlnaSsdpStatus">--</span></div>
<div class="dlna-info-item"><span>视频文件</span><span id="dlnaVideoCount">0 个</span></div>
<div class="dlna-info-item"><span>音频文件</span><span id="dlnaAudioCount">0 个</span></div>
<div class="dlna-info-item"><span>图片文件</span><span id="dlnaImageCount">0 个</span></div>
</div>
<!-- 手动连接方式 -->
<div class="dlna-guide" id="dlnaManualSection" style="display:none">
<div class="dlna-guide-title">🔧 扫描不到？手动连接</div>
<div class="dlna-guide-step"><span class="step-num">1</span><span>在投屏App中选择「手动添加设备」或「输入IP」</span></div>
<div class="dlna-guide-step"><span class="step-num">2</span><span>输入地址：<code id="dlnaManualURL" style="background:#f0f0f0;padding:2px 6px;border-radius:4px;font-size:12px">--</code></span></div>
<div class="dlna-guide-step"><span class="step-num">3</span><span>或直接在电视浏览器打开上述地址测试连通性</span></div>
<div style="margin-top:12px;padding:10px;background:#fff3cd;border-radius:8px;font-size:12px;color:#856404">
<strong>提示：</strong>如果SSDP发现失败，通常是因为Termux没有多播权限。手动输入IP地址可以绕过这个限制。确保手机和电视连接同一WiFi。
</div>
</div>
<div class="dlna-guide">
<div class="dlna-guide-title">📖 使用说明</div>
<div class="dlna-guide-step"><span class="step-num">1</span><span>启动DLNA服务后，确保手机和电视/投影连接同一WiFi</span></div>
<div class="dlna-guide-step"><span class="step-num">2</span><span>在电视/投影上打开「媒体播放器」或「DLNA投屏」应用</span></div>
<div class="dlna-guide-step"><span class="step-num">3</span><span>搜索设备，选择「NAS私有云 - 媒体服务器」</span></div>
<div class="dlna-guide-step"><span class="step-num">4</span><span>浏览并播放NAS上的视频文件</span></div>
</div>
<div class="dlna-media-section" id="dlnaMediaSection" style="display:none">
<div class="dlna-info-title">可投屏视频</div>
<div id="dlnaMediaList"></div>
</div>
</div>
</div>

<!-- 加密存储面板 -->
<div class="panel" id="panel-encrypted">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">加密存储</span>
<button class="btn btn-primary btn-sm" onclick="showCreateEncrypted()" style="margin-left:auto">新建</button>
</div>
<div style="padding:16px">
<div id="encryptedFoldersList"></div>
</div>
</div>

<!-- 新建加密文件夹弹窗 -->
<div id="createEncryptedModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
<div style="background:#fff;padding:20px;border-radius:16px;width:92%;max-width:400px">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 style="margin:0">新建加密文件夹</h4>
<button onclick="document.getElementById('createEncryptedModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>
<div class="form-group">
<label>文件夹名称</label>
<input type="text" id="encFolderName" placeholder="输入文件夹名称">
</div>
<div class="form-group">
<label>加密密码</label>
<input type="password" id="encFolderPassword" placeholder="设置加密密码">
</div>
<div class="form-group">
<label>确认密码</label>
<input type="password" id="encFolderPassword2" placeholder="再次输入密码">
</div>
<div style="background:#fff3cd;padding:10px;border-radius:8px;font-size:12px;color:#856404;margin-bottom:16px">
⚠️ 密码丢失无法找回，请妥善保管！加密文件使用AES-256加密。
</div>
<div style="display:flex;gap:8px">
<button class="btn" style="flex:1" onclick="document.getElementById('createEncryptedModal').style.display='none'">取消</button>
<button class="btn btn-primary" style="flex:1" onclick="createEncryptedFolder()">创建</button>
</div>
</div>
</div>

<!-- 解锁加密文件夹弹窗 -->
<div id="unlockEncryptedModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
<div style="background:#fff;padding:20px;border-radius:16px;width:92%;max-width:400px">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 style="margin:0" id="unlockFolderTitle">解锁加密文件夹</h4>
<button onclick="document.getElementById('unlockEncryptedModal').style.display='none'" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>
<div class="form-group">
<label>输入密码</label>
<input type="password" id="unlockFolderPassword" placeholder="输入加密密码">
</div>
<div style="display:flex;gap:8px">
<button class="btn" style="flex:1" onclick="document.getElementById('unlockEncryptedModal').style.display='none'">取消</button>
<button class="btn btn-primary" style="flex:1" onclick="unlockEncryptedFolder()">解锁</button>
</div>
</div>
</div>

<!-- 加密文件浏览器弹窗 -->
<div id="encryptedFilesModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
<div style="background:#fff;padding:20px;border-radius:16px;width:92%;max-width:500px;max-height:85vh;overflow-y:auto">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<h4 style="margin:0" id="encryptedFilesTitle">加密文件</h4>
<button onclick="closeEncryptedFiles()" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>
</div>
<div style="display:flex;gap:8px;margin-bottom:16px">
<button class="btn btn-primary btn-sm" onclick="document.getElementById('encFileInput').click()">上传文件</button>
<input type="file" id="encFileInput" style="display:none" onchange="uploadEncryptedFile()">
<button class="btn btn-sm" onclick="loadEncryptedFiles()">刷新</button>
</div>
<div id="encryptedFilesList"></div>
</div>
</div>

<!-- 加密空间面板 - Photok风格 -->
<div class="panel" id="panel-vault">
<div class="page-header">
<button class="back-btn" onclick="goHome()">← 返回</button>
<span class="page-title">加密空间</span>
</div>
<div style="padding:20px 16px">
<!-- 未初始化 -->
<div id="vaultNotInit" style="display:block;text-align:center;padding:10px 0">
<div style="width:64px;height:64px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:32px;margin:0 auto 12px;box-shadow:0 8px 24px rgba(102,126,234,.3)">🔐</div>
<h3 style="margin:0 0 4px;font-size:18px;font-weight:600;color:#333">加密空间</h3>
<p style="color:#999;margin:0 0 16px;font-size:12px">AES-256加密存储，密码丢失无法找回</p>
<!-- 解锁方式切换 -->
<div style="display:flex;gap:8px;margin-bottom:16px;background:#f5f5f5;padding:4px;border-radius:12px">
<button class="vault-tab active" data-method="password" onclick="switchVaultInitMethod('password')" style="flex:1;padding:10px;border:none;border-radius:8px;background:#fff;cursor:pointer;font-size:13px;font-weight:500;color:#333;box-shadow:0 2px 8px rgba(0,0,0,.06)">🔑 密码</button>
<button class="vault-tab" data-method="pattern" onclick="switchVaultInitMethod('pattern')" style="flex:1;padding:10px;border:none;border-radius:8px;background:transparent;cursor:pointer;font-size:13px;font-weight:500;color:#999">🔷 图案</button>
</div>
<!-- 密码初始化 -->
<div id="initPasswordPanel">
<input type="password" id="initPassword" placeholder="设置密码（至少6位）" style="width:100%;padding:14px;border:1.5px solid #e0e0e0;border-radius:12px;font-size:14px;box-sizing:border-box;margin-bottom:12px;outline:none;transition:border-color .2s" onfocus="this.style.borderColor='#667eea'" onblur="this.style.borderColor='#e0e0e0'" onkeypress="if(event.key==='Enter')simpleInitVault()">
<input type="password" id="initPassword2" placeholder="确认密码" style="width:100%;padding:14px;border:1.5px solid #e0e0e0;border-radius:12px;font-size:14px;box-sizing:border-box;outline:none;transition:border-color .2s" onfocus="this.style.borderColor='#667eea'" onblur="this.style.borderColor='#e0e0e0'" onkeypress="if(event.key==='Enter')simpleInitVault()">
</div>
<!-- 图案初始化 -->
<div id="initPatternPanel" style="display:none">
<p style="font-size:12px;color:#999;margin:0 0 12px">绘制解锁图案（至少连接4个点）</p>
<div class="pattern-lock" id="initPatternLock" style="margin:0 auto">
<div class="pattern-dot" data-idx="0"></div><div class="pattern-dot" data-idx="1"></div><div class="pattern-dot" data-idx="2"></div>
<div class="pattern-dot" data-idx="3"></div><div class="pattern-dot" data-idx="4"></div><div class="pattern-dot" data-idx="5"></div>
<div class="pattern-dot" data-idx="6"></div><div class="pattern-dot" data-idx="7"></div><div class="pattern-dot" data-idx="8"></div>
</div>
<p id="initPatternHint" style="font-size:12px;color:#999;margin:12px 0 0">请绘制图案</p>
</div>
<button class="btn btn-primary" style="width:100%;margin-top:20px;padding:14px;font-size:15px;font-weight:600;border-radius:12px" onclick="simpleInitVault()">初始化加密空间</button>
<p style="color:#999;font-size:11px;margin-top:12px">⚠️ 请牢记密码/图案，丢失后无法恢复</p>
</div>
<!-- 已锁定 - Photok风格 -->
<div id="vaultLocked" style="display:none;text-align:center;padding:10px 0">
<div style="width:64px;height:64px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:32px;margin:0 auto 12px;box-shadow:0 8px 24px rgba(102,126,234,.3)">🔒</div>
<h3 style="margin:0 0 4px;font-size:18px;font-weight:600;color:#333">已锁定</h3>
<p style="color:#999;margin:0 0 16px;font-size:12px">验证身份解锁</p>
<!-- 解锁方式切换 -->
<div style="display:flex;gap:8px;margin-bottom:16px;background:#f5f5f5;padding:4px;border-radius:12px">
<button class="vault-tab active" data-method="password" onclick="switchVaultUnlockMethod('password')" style="flex:1;padding:10px;border:none;border-radius:8px;background:#fff;cursor:pointer;font-size:13px;font-weight:500;color:#333;box-shadow:0 2px 8px rgba(0,0,0,.06)">🔑 密码</button>
<button class="vault-tab" data-method="pattern" onclick="switchVaultUnlockMethod('pattern')" style="flex:1;padding:10px;border:none;border-radius:8px;background:transparent;cursor:pointer;font-size:13px;font-weight:500;color:#999">🔷 图案</button>
</div>
<!-- 密码解锁 -->
<div id="unlockPasswordPanel">
<input type="password" id="unlockPassword" placeholder="输入密码" style="width:100%;padding:14px;border:1.5px solid #e0e0e0;border-radius:12px;font-size:14px;box-sizing:border-box;outline:none;transition:border-color .2s;text-align:center" onfocus="this.style.borderColor='#667eea'" onblur="this.style.borderColor='#e0e0e0'" onkeypress="if(event.key==='Enter')simpleUnlockVault()">
</div>
<!-- 图案解锁 -->
<div id="unlockPatternPanel" style="display:none">
<div class="pattern-lock" id="unlockPatternLock" style="margin:0 auto">
<div class="pattern-dot" data-idx="0"></div><div class="pattern-dot" data-idx="1"></div><div class="pattern-dot" data-idx="2"></div>
<div class="pattern-dot" data-idx="3"></div><div class="pattern-dot" data-idx="4"></div><div class="pattern-dot" data-idx="5"></div>
<div class="pattern-dot" data-idx="6"></div><div class="pattern-dot" data-idx="7"></div><div class="pattern-dot" data-idx="8"></div>
</div>
<p id="unlockPatternHint" style="font-size:12px;color:#999;margin:12px 0 0">请绘制图案</p>
</div>
<button class="btn btn-primary" style="width:100%;margin-top:20px;padding:14px;font-size:15px;font-weight:600;border-radius:12px" onclick="simpleUnlockVault()">解锁</button>
<p style="color:#e74c3c;font-size:12px;margin-top:12px;cursor:pointer" onclick="resetVault()">忘记密码？重置加密空间</p>
</div>
<!-- 已解锁 - 360隐私保险箱风格 -->
<div id="vaultUnlocked" style="display:none">
<!-- 主界面：分类列表 -->
<div id="vaultHome">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
<div style="font-size:14px;color:#666;font-weight:500">已加密保护</div>
<button class="btn btn-sm" onclick="simpleLockVault()" style="padding:6px 14px;border-radius:16px;font-size:12px">🔒 锁定</button>
</div>
<!-- 分类网格 -->
<div id="vaultCategoryList" style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px">
<div class="vault-category-item" onclick="openVaultCategory('all')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center;transition:transform .2s">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">📁</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">全部文件</div>
<div style="font-size:11px;color:#999"><span id="vaultAllCount">0</span> 个文件</div>
</div>
<div class="vault-category-item" onclick="openVaultCategory('image')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center;transition:transform .2s">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#ff9a9e,#fecfef);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">🖼️</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">图片</div>
<div style="font-size:11px;color:#999"><span id="vaultImageCount">0</span> 张图片</div>
</div>
<div class="vault-category-item" onclick="openVaultCategory('video')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center;transition:transform .2s">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#a18cd1,#fbc2eb);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">🎬</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">视频</div>
<div style="font-size:11px;color:#999"><span id="vaultVideoCount">0</span> 个视频</div>
</div>
<div class="vault-category-item" onclick="openVaultCategory('audio')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center;transition:transform .2s">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#84fab0,#8fd3f4);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">🎵</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">音乐</div>
<div style="font-size:11px;color:#999"><span id="vaultAudioCount">0</span> 首音乐</div>
</div>
<div class="vault-category-item" onclick="openVaultCategory('other')" style="background:#fff;border-radius:16px;padding:20px 16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center;transition:transform .2s">
<div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#fccb90,#d57eeb);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 10px">📄</div>
<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px">文档</div>
<div style="font-size:11px;color:#999"><span id="vaultOtherCount">0</span> 个文件</div>
</div>
</div>
<!-- 底部导入按钮 -->
<div style="margin-top:20px">
<button class="btn btn-primary" style="width:100%;padding:14px;border-radius:12px;font-size:15px;font-weight:600" onclick="document.getElementById('vaultFileInput').click()">📥 导入文件</button>
<input type="file" id="vaultFileInput" style="display:none" onchange="simpleUploadVault()" multiple>
</div>
</div>
<!-- 分类浏览界面 -->
<div id="vaultCategoryView" style="display:none">
<div style="display:flex;align-items:center;margin-bottom:16px">
<button onclick="backToVaultHome()" style="background:none;border:none;font-size:24px;color:#667eea;cursor:pointer;padding:0 8px 0 0">‹</button>
<span id="vaultCategoryTitle" style="font-size:18px;font-weight:600;color:#333;flex:1">图片</span>
<button class="btn btn-sm" onclick="document.getElementById('vaultFileInput').click()" style="padding:6px 12px;border-radius:14px;font-size:12px">+ 添加</button>
</div>
<div id="vaultFileList" style="min-height:300px;display:grid;grid-template-columns:repeat(4,1fr);gap:8px"></div>
</div>
</div>
</div>
</div>

<!-- 初始化加密空间弹窗 -->
<!-- 通用进度弹窗 -->
<div id="resetProgressModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.7);z-index:3000;align-items:center;justify-content:center">
<div style="background:#fff;padding:24px;border-radius:16px;width:85%;max-width:360px;text-align:center">
<div style="font-size:40px;margin-bottom:12px">⏳</div>
<h4 style="margin:0 0 16px">处理中...</h4>
<div style="background:#e0e0e0;border-radius:10px;height:20px;overflow:hidden;margin-bottom:12px">
<div id="resetProgressBar" style="height:100%;width:0%;background:linear-gradient(90deg,#667eea,#764ba2);border-radius:10px;transition:width .3s ease"></div>
</div>
<div id="resetProgressText" style="font-size:14px;color:#666">0%</div>
<div id="resetProgressStep" style="font-size:12px;color:#999;margin-top:8px">准备中...</div>
</div>
</div>

<div class="player-modal" id="playerModal">
<!-- ArtPlayer 容器 -->
<div class="artplayer-container" id="artplayerContainer"></div>
<!-- 关闭按钮 -->
<button class="artplayer-close" onclick="closePlayer()">✕</button>
</div>

<!-- 音乐播放器全屏页 -->
<div class="music-player" id="musicPlayer">
<div class="music-player-header">
<div class="music-player-back" onclick="closeMusicPlayer()">‹</div>
<div class="music-player-title">正在播放</div>
<div class="music-player-more" onclick="showPlaylist()">☰</div>
</div>
<div class="music-player-cover">
<div class="music-player-cover-circle" id="musicCover">🎵</div>
</div>
<div class="music-player-info">
<div class="music-player-song" id="musicSongTitle">歌曲名</div>
<div class="music-player-artist" id="musicArtist">NAS私有云</div>
</div>
<div class="music-player-progress">
<div class="music-player-bar" id="musicProgressBar" onclick="seekMusic(event)">
<div class="music-player-bar-fill" id="musicProgressFill"></div>
</div>
<div class="music-player-times">
<span id="musicCurrentTime">00:00</span>
<span id="musicTotalTime">00:00</span>
</div>
</div>
<div class="music-player-controls">
<div class="music-player-btn" onclick="musicPrev()">⏮</div>
<div class="music-player-btn music-player-btn-play" id="musicPlayBtn" onclick="toggleMusicPlay()">▶</div>
<div class="music-player-btn" onclick="musicNext()">⏭</div>
</div>
</div>

<!-- 播放列表弹窗 -->
<div class="playlist-modal" id="playlistModal" style="display:none;position:fixed;bottom:0;left:0;width:100%;height:70%;background:#fff;border-radius:20px 20px 0 0;z-index:100000;flex-direction:column;box-shadow:0 -4px 20px rgba(0,0,0,.2)">
<div style="padding:16px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center">
<span style="font-size:16px;font-weight:600">播放列表</span>
<span style="cursor:pointer;font-size:20px" onclick="hidePlaylist()">✕</span>
</div>
<div id="playlistContent" style="flex:1;overflow-y:auto;padding:8px"></div>
</div>

<div class="image-modal" id="imageModal" onclick="closeImage()">
<div class="img-toolbar" onclick="event.stopPropagation()">
<span class="img-counter" id="imgCounter">1 / 1</span>
<div class="img-actions">
<button class="img-btn" onclick="rotateImage(-90)" title="左旋">↺</button>
<button class="img-btn" onclick="rotateImage(90)" title="右旋">↻</button>
<button class="img-btn" onclick="resetImage()" title="重置">⟲</button>
<button class="img-btn img-close" onclick="closeImage()" title="关闭">✕</button>
</div>
</div>
<button class="img-nav prev" onclick="event.stopPropagation();prevImage()">‹</button>
<div class="img-wrap" id="imgWrap" onclick="event.stopPropagation()">
<img id="imageViewer" src="">
</div>
<button class="img-nav next" onclick="event.stopPropagation();nextImage()">›</button>
<div class="img-info" onclick="event.stopPropagation()">
<span class="name" id="imageTitle"></span>
<span class="meta" id="imageMeta"></span>
</div>
</div>

<!-- 文件属性菜单 -->
<div class="file-menu" id="fileMenu" onclick="closeFileMenu(event)">
<div class="file-menu-content" onclick="event.stopPropagation()">
<div class="file-menu-header">
<span class="file-menu-icon" id="menuIcon">📁</span>
<span class="file-menu-name" id="menuName">文件名</span>
<button class="file-menu-close" onclick="closeFileMenu()">✕</button>
</div>
<div class="file-menu-info">
<div class="file-menu-info-item"><div class="file-menu-info-label">类型</div><div class="file-menu-info-value" id="menuType">文件夹</div></div>
<div class="file-menu-info-item"><div class="file-menu-info-label">大小</div><div class="file-menu-info-value" id="menuSize">—</div></div>
<div class="file-menu-info-item"><div class="file-menu-info-label">修改时间</div><div class="file-menu-info-value" id="menuTime">—</div></div>
<div class="file-menu-info-item"><div class="file-menu-info-label">路径</div><div class="file-menu-info-value" id="menuPath">—</div></div>
</div>
<div class="file-menu-actions">
<button class="file-menu-action" onclick="menuDownload()">⬇️ 下载</button>
<button class="file-menu-action" onclick="menuRename()">✏️ 重命名</button>
<button class="file-menu-action" onclick="menuCopy()">📋 复制</button>
<button class="file-menu-action" onclick="pasteSelected()">📥 粘贴</button>
<button class="file-menu-action" onclick="menuShare()">🔗 分享</button>
<button class="file-menu-action" onclick="menuCompress()">📦 压缩</button>
<button class="file-menu-action" onclick="menuEncrypt()" style="color:#f5576c">🔐 加密</button>
<button class="file-menu-action danger" onclick="menuDelete()">🗑️ 删除</button>
</div>
</div>
</div>

<div id="folderModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:1500;align-items:center;justify-content:center">
<div style="background:#fff;padding:24px;border-radius:10px;width:90%;max-width:360px">
<h4 style="margin-bottom:16px">新建文件夹</h4>
<input type="text" id="folderName" placeholder="文件夹名称" style="width:100%;padding:10px;border:2px solid #e0e0e0;border-radius:6px;margin-bottom:16px">
<div style="display:flex;gap:8px;justify-content:flex-end">
<button class="btn btn-ghost" onclick="document.getElementById('folderModal').style.display='none'">取消</button>
<button class="btn btn-primary" onclick="createFolder()">创建</button>
</div></div></div>

<div id="backupModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:1500;align-items:center;justify-content:center">
<div style="background:#fff;padding:24px;border-radius:10px;width:90%;max-width:400px">
<h4 style="margin-bottom:16px">创建备份</h4>
<div class="form-group"><label>备份名称</label><input type="text" id="backupName" placeholder="留空自动生成"></div>
<div class="form-group"><label>备份目录（每行一个）</label>
<textarea id="backupSources" rows="4">~/storage/shared</textarea></div>
<div style="display:flex;gap:8px;justify-content:flex-end">
<button class="btn btn-ghost" onclick="document.getElementById('backupModal').style.display='none'">取消</button>
<button class="btn btn-primary" onclick="createBackup()">开始备份</button>
</div></div></div>

<div id="moveModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:1500;align-items:center;justify-content:center">
<div style="background:#fff;padding:24px;border-radius:10px;width:90%;max-width:400px">
<h4 style="margin-bottom:16px">移动到...</h4>
<div class="form-group"><label>目标路径</label><input type="text" id="moveTarget" placeholder="如: /文件夹名"></div>
<div style="display:flex;gap:8px;justify-content:flex-end">
<button class="btn btn-ghost" onclick="document.getElementById('moveModal').style.display='none'">取消</button>
<button class="btn btn-primary" onclick="doMove()">确定移动</button>
</div></div></div>

<script>
// ===== 全局错误捕获：禁用JS错误弹窗 =====
window.onerror=function(message,source,lineno,colno,error){
console.error('JS错误:',message,'行:',lineno);
return true; // 返回true阻止默认错误弹窗
};
window.addEventListener('unhandledrejection',function(event){
console.error('未处理Promise错误:',event.reason);
event.preventDefault();
});

// ===== PWA Service Worker 注册 =====
if('serviceWorker' in navigator){
navigator.serviceWorker.register('/static/sw.js').then(reg=>{
console.log('PWA Service Worker 注册成功');
}).catch(err=>{
console.warn('PWA Service Worker 注册失败:',err);
});
}
// ===== 前端详细日志系统 =====
const frontLogs=[];
const MAX_LOGS=500;
function addLog(level,module,action,message,data){
const entry={
time:new Date().toLocaleString('zh-CN'),
level:level,
module:module,
action:action,
message:message,
data:data?JSON.stringify(data).substring(0,500):null
};
frontLogs.push(entry);
if(frontLogs.length>MAX_LOGS)frontLogs.shift();
console.log('['+level+'] ['+module+'] '+action+': '+message,data||'');
}
function exportFrontLogs(){
let text='=== NAS前端日志导出 ===\n';
text+='导出时间: '+new Date().toLocaleString('zh-CN')+'\n';
text+='浏览器: '+navigator.userAgent+'\n';
text+='页面URL: '+location.href+'\n';
text+='日志总数: '+frontLogs.length+'\n';
text+='==================================================\n\n';
frontLogs.forEach(function(l){
text+='['+l.time+'] ['+l.level+'] ['+l.module+'] '+l.action+': '+l.message+'\n';
if(l.data)text+='  数据: '+l.data+'\n';
});
const blob=new Blob([text],{type:'text/plain'});
const url=URL.createObjectURL(blob);
const a=document.createElement('a');
a.href=url;a.download='nas-front-logs-'+Date.now()+'.txt';
a.click();
URL.revokeObjectURL(url);
}
// 全局错误捕获
window.onerror=function(msg,url,line,col,error){
addLog('ERROR','global','js_error',msg,{url:url,line:line,col:col,stack:error?error.stack:null});
alert('JavaScript错误：'+msg+'\n行号：'+line+'\n请截图发给开发者');
console.error('Global error:',msg,url,line,col,error);
return false;
};
window.addEventListener('unhandledrejection',function(e){
addLog('ERROR','global','promise_error',e.reason?e.reason.message:'Promise rejected',{reason:String(e.reason)});
if(typeof showToast==='function'){
showToast('网络或请求出错，请检查网络连接','error',2000);
}
});

// 网络状态监听
window.addEventListener('online',function(){
if(typeof showToast==='function')showToast('网络已连接','success',2000);
});
window.addEventListener('offline',function(){
if(typeof showToast==='function')showToast('网络已断开，请检查连接','warning',3000);
});

// 通用弹窗函数 - Android UI标准
function showModal(title,content,width){
width=width||'400px';
let modal=document.getElementById('genericModal');
if(!modal){
modal=document.createElement('div');
modal.id='genericModal';
modal.style.cssText='position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;align-items:center;justify-content:center;z-index:10000;padding:24px';
modal.innerHTML='<div style="background:#fff;border-radius:8px;max-width:100%;max-height:90vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 8px 32px rgba(0,0,0,.2)">'+
'<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 16px;min-height:56px;border-bottom:1px solid #f0f0f0">'+
'<span id="genericModalTitle" style="font-size:18px;font-weight:600;color:#333"></span>'+
'<button onclick="closeModal()" style="background:none;border:none;font-size:24px;color:#999;cursor:pointer;width:48px;height:48px;min-width:48px;min-height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:background .2s">✕</button>'+
'</div>'+
'<div id="genericModalContent" style="padding:16px;overflow-y:auto;flex:1;font-size:16px;color:#333"></div>'+
'</div>';
document.body.appendChild(modal);
}
document.getElementById('genericModalTitle').textContent=title;
document.getElementById('genericModalContent').innerHTML=content;
modal.style.display='flex';
modal.querySelector('div').style.width=width;
}
function closeModal(){
const modal=document.getElementById('genericModal');
if(modal)modal.style.display='none';
// 弹窗关闭后强制重排
window.dispatchEvent(new Event('resize'));
}

// 全局fetch拦截器：确保所有请求都携带cookie和Authorization头
const _origFetch=window.fetch;
window.fetch=function(url,options){
options=options||{};
options.credentials='include';
// 从cookie读取token并添加到Authorization头
try{
const match=document.cookie.match(/nas_token=([^;]+)/);
if(match&&match[1]){
options.headers=options.headers||{};
if(!options.headers.Authorization&&!options.headers.authorization){
options.headers.Authorization='Bearer '+match[1];
}
}
}catch(e){}
return _origFetch.call(this,url,options);
};

// ===== 通用进度弹窗 =====
let progressModal={modal:null,bar:null,text:null,step:null};
function initProgressModal(){
if(!progressModal.modal){
progressModal.modal=document.getElementById('resetProgressModal');
progressModal.bar=document.getElementById('resetProgressBar');
progressModal.text=document.getElementById('resetProgressText');
progressModal.step=document.getElementById('resetProgressStep');
}
}
function showProgress(title){
// 已禁用进度弹窗，改用toast提示
if(typeof showToast==='function')showToast(title||'处理中...','info');
}
function setProgress(pct,stepText){
// 已禁用进度弹窗
}
function hideProgress(){
// 已禁用进度弹窗
}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

// 全局变量声明（避免初始化顺序问题）
let isAPK=typeof window.AndroidJSBridge!=='undefined';
var aplayer=null; // 音乐播放器实例（用var避免暂时性死区问题）
var artPlayer=null; // 视频播放器实例（用var避免暂时性死区问题）

// ===== NASBridge 统一调度层 =====
// 本地和网络功能统一调度，上层调用不用关心底层实现
const NASBridge={
// 是否走本地模式
useLocal:isAPK,

// 文件列表
listFiles:function(path){
if(this.useLocal&&window.AndroidJSBridge&&AndroidJSBridge.listFiles){
// 本地模式：调用原生代码
return AndroidJSBridge.listFiles(path);
}else{
// 网络模式：调用HTTP API
return fetch('/api/files?path='+encodeURIComponent(path)).then(r=>r.json());
}
},

// 文件内容
readFile:function(path){
if(this.useLocal&&window.AndroidJSBridge&&AndroidJSBridge.readFile){
return AndroidJSBridge.readFile(path);
}else{
return fetch('/api/file?path='+encodeURIComponent(path)).then(r=>r.blob());
}
},

// 播放视频
playVideo:function(path,name){
if(this.useLocal&&window.AndroidJSBridge&&AndroidJSBridge.playVideo){
// 本地模式：直接打开原生播放器
return AndroidJSBridge.playVideo(path,name);
}else{
// 网络模式：用网页播放器
return playWithArtPlayer(path,name);
}
},

// 播放音乐
playMusic:function(path,name){
if(this.useLocal&&window.AndroidJSBridge&&AndroidJSBridge.playMusic){
return AndroidJSBridge.playMusic(path,name);
}else{
return playWithAPlayer(path,name);
}
},

// 打开图片
openImage:function(path){
if(this.useLocal&&window.AndroidJSBridge&&AndroidJSBridge.openImage){
return AndroidJSBridge.openImage(path);
}else{
return openSimpleImage(path);
}
}
};

var systemMonitorTimer=null;
var notificationPanelOpen=false;
var vpnMonitorTimer=null;
var ALIST_CONFIG={
host:window.location.hostname,
port:8444,
basePath:'',
openMode:'direct'
};

var currentPath='/';
var currentFilter='all';
var currentView='grid';
var selectedFiles=new Set();
var clipboard={files:[],mode:null};
var readOnly={{.ReadOnly}};

// ===== 全局错误日志系统 =====
window.appErrorLogs=window.appErrorLogs||[];
function logError(module,message,details){
const log={
time:new Date().toLocaleString('zh-CN'),
module:module,
message:message,
details:details||''
};
window.appErrorLogs.unshift(log);
// 最多保留100条
if(window.appErrorLogs.length>100)window.appErrorLogs.pop();
console.error('['+module+']',message,details||'');
}
function showErrorLogs(){
const logs=window.appErrorLogs||[];
let html='<div style="max-height:60vh;overflow-y:auto;">';
// 添加操作按钮
html+='<div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;">'+
'<button onclick="exportFrontLogs()" style="flex:1;padding:8px 12px;background:#667eea;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:12px;min-width:48px;min-height:48px;">📤 导出全部日志</button>'+
'<button onclick="clearErrorLogs()" style="flex:1;padding:8px 12px;background:#f5f5f5;border:none;border-radius:6px;cursor:pointer;font-size:12px;min-width:48px;min-height:48px;">🗑️ 清空错误</button>'+
'<button onclick="showAllLogs()" style="flex:1;padding:8px 12px;background:#f5f5f5;border:none;border-radius:6px;cursor:pointer;font-size:12px;min-width:48px;min-height:48px;">📋 查看全部</button>'+
'</div>';
if(logs.length===0){
html+='<div style="text-align:center;padding:40px;color:#999;">暂无错误日志</div>';
}else{
html+='<div style="font-size:12px;color:#666;margin-bottom:8px;">共 '+logs.length+' 条错误记录（最多保留100条）</div>';
logs.forEach((log,i)=>{
const bgColor=i%2===0?'#fafafa':'#fff';
html+='<div style="padding:12px;background:'+bgColor+';border-radius:8px;margin-bottom:8px;border-left:3px solid #e74c3c;">'+
'<div style="display:flex;justify-content:space-between;margin-bottom:4px;">'+
'<span style="font-size:12px;font-weight:600;color:#e74c3c;">'+log.module+'</span>'+
'<span style="font-size:11px;color:#999;">'+log.time+'</span>'+
'</div>'+
'<div style="font-size:13px;color:#333;margin-bottom:4px;word-break:break-all;">'+log.message+'</div>';
if(log.details){
html+='<div style="font-size:11px;color:#666;background:#f5f5f5;padding:6px 8px;border-radius:4px;margin-top:4px;word-break:break-all;white-space:pre-wrap;">'+log.details+'</div>';
}
html+='</div>';
});
}
html+='</div>';
showModal('错误日志',html,'90%');
}
function showAllLogs(){
const logs=window.frontLogs||[];
let html='<div style="max-height:60vh;overflow-y:auto;">';
html+='<div style="display:flex;gap:8px;margin-bottom:12px;">'+
'<button onclick="exportFrontLogs()" style="flex:1;padding:8px 12px;background:#667eea;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:12px;">📤 导出日志</button>'+
'</div>';
if(logs.length===0){
html+='<div style="text-align:center;padding:40px;color:#999;">暂无操作日志</div>';
}else{
html+='<div style="font-size:12px;color:#666;margin-bottom:8px;">共 '+logs.length+' 条操作记录（最多保留500条）</div>';
logs.slice().reverse().forEach((log,i)=>{
const levelColor=log.level==='ERROR'?'#e74c3c':log.level==='WARN'?'#f39c12':'#27ae60';
const bgColor=i%2===0?'#fafafa':'#fff';
html+='<div style="padding:8px 12px;background:'+bgColor+';border-radius:6px;margin-bottom:4px;border-left:3px solid '+levelColor+';">'+
'<div style="display:flex;justify-content:space-between;margin-bottom:2px;">'+
'<span style="font-size:11px;font-weight:600;color:'+levelColor+';">['+log.level+'] '+log.module+'</span>'+
'<span style="font-size:10px;color:#999;">'+log.time+'</span>'+
'</div>'+
'<div style="font-size:12px;color:#333;word-break:break-all;">'+log.action+': '+log.message+'</div>';
if(log.data){
html+='<div style="font-size:10px;color:#666;margin-top:2px;word-break:break-all;">'+log.data+'</div>';
}
html+='</div>';
});
}
html+='</div>';
showModal('全部操作日志',html,'90%');
}
function clearErrorLogs(){
window.appErrorLogs=[];
showToast('错误日志已清空','success');
updateErrorLogBadge();
showErrorLogs();
}
function updateErrorLogBadge(){
const badge=document.getElementById('errorLogBadge');
const countEl=document.getElementById('errorLogCount');
const count=(window.appErrorLogs||[]).length;
if(badge){
if(count>0){
badge.style.display='flex';
badge.textContent=count>99?'99+':count;
}else{
badge.style.display='none';
}
}
if(countEl){
countEl.textContent=count;
}
}
function renderErrorLogs(){
const container=document.getElementById('errorLogsContainer');
if(!container)return;
const logs=window.appErrorLogs||[];
if(logs.length===0){
container.innerHTML='<div style="text-align:center;padding:20px;color:#999">暂无错误记录</div>';
return;
}
let html='';
logs.forEach((log,i)=>{
const bgColor=i%2===0?'#fafafa':'#fff';
html+='<div style="padding:10px 12px;background:'+bgColor+';border-radius:6px;margin-bottom:6px;border-left:3px solid #e74c3c;">'+
'<div style="display:flex;justify-content:space-between;margin-bottom:4px;">'+
'<span style="font-size:11px;font-weight:600;color:#e74c3c;">'+log.module+'</span>'+
'<span style="font-size:10px;color:#999;">'+log.time+'</span>'+
'</div>'+
'<div style="font-size:12px;color:#333;margin-bottom:4px;word-break:break-all;">'+log.message+'</div>';
if(log.details){
html+='<div style="font-size:10px;color:#666;background:#f5f5f5;padding:4px 6px;border-radius:4px;margin-top:4px;word-break:break-all;white-space:pre-wrap;max-height:80px;overflow-y:auto;">'+log.details+'</div>';
}
html+='</div>';
});
container.innerHTML=html;
updateErrorLogBadge();
}

// 底部导航切换
function switchTab(tab){
// 更新导航高亮
document.querySelectorAll('.bottom-nav-item').forEach(function(el){
el.classList.remove('active');
});
event.currentTarget.classList.add('active');
// 切换页面
if(tab==='home'){
openPanel('home');
}else if(tab==='files'){
openPanel('files');
}else if(tab==='media'){
openPanel('video');
}else if(tab==='me'){
openPanel('settings');
}
}

function openPanel(name){
// 停止所有面板轮询
stopAllPanelPolling();
// 关闭酷我播放器和所有子面板
closeKuwoPlayer();
// 关闭音乐播放器（切换页面时隐藏）
if(name!=='music'&&typeof closeAPlayer==='function'){
closeAPlayer();
}
// APK环境检测
const isAPK=window.AndroidJSBridge?true:false;
// 控制顶部header显示：APK环境完全隐藏，Web环境只在主界面显示
const header=document.querySelector('.header');
const container=document.getElementById('mainContainer');
if(!isAPK){
if(name==='home'){
if(header){header.classList.add('show');header.style.display='flex';}
if(container)container.classList.add('with-header');
}else{
if(header){header.classList.remove('show');header.style.display='none';}
if(container)container.classList.remove('with-header');
}
}else{
// APK环境：始终隐藏顶部header
if(header){header.classList.remove('show');header.style.display='none';}
if(container)container.classList.remove('with-header');
if(container)container.style.paddingTop='0';
}
document.querySelectorAll('.panel,.home-panel').forEach(p=>p.classList.remove('active'));
document.getElementById('panel-'+name).classList.add('active');
// 保存当前面板状态，刷新后恢复
try{localStorage.setItem('lastPanel',name);}catch(e){}
if(name==='home'){loadHomeStats();}
if(name==='video'){
loadMedia();
// 自动扫描，多次轮询确保完成
setTimeout(()=>{
fetch('/api/media/scan',{method:'POST'}).then(()=>{
// 扫描完成后多次刷新，确保结果显示
setTimeout(loadMedia,1000);
setTimeout(loadMedia,3000);
setTimeout(loadMedia,5000);
});
},500);
}
if(name==='music'){
loadMusicList();
// 自动扫描，多次轮询确保完成
setTimeout(()=>{
fetch('/api/media/scan',{method:'POST'}).then(()=>{
setTimeout(loadMusicList,1000);
setTimeout(loadMusicList,3000);
setTimeout(loadMusicList,5000);
});
},500);
}
if(name==='backup'){loadBackups();loadAutoBackupStatus();}
if(name==='dlna')loadDlnaStatus();
if(name==='encrypted')loadEncryptedFolders();
if(name==='vault')loadVaultStatus();
if(name==='video')updateVaultButtons();
if(name==='music')updateVaultButtons();
if(name==='system'){startSystemMonitor();setTimeout(renderErrorLogs,100);}
if(name==='settings'){document.getElementById('settingContent').style.display='none';document.querySelector('.settings-menu').style.display='block';}
if(name==='files'){setTimeout(()=>loadList(currentPath),100);}
if(name==='cloud')checkAlistStatus();
if(name==='users')loadUsers();
window.scrollTo(0,0);
}
// 停止所有面板轮询
function stopAllPanelPolling(){
if(systemMonitorTimer){clearInterval(systemMonitorTimer);systemMonitorTimer=null;}
if(vpnMonitorTimer){clearInterval(vpnMonitorTimer);vpnMonitorTimer=null;}
}
function goHome(){
stopAllPanelPolling();
// 关闭酷我播放器和所有子面板
closeKuwoPlayer();
// APK环境检测
const isAPK=window.AndroidJSBridge?true:false;
// 控制顶部header显示：APK环境完全隐藏，Web环境主界面显示
const header=document.querySelector('.header');
const container=document.getElementById('mainContainer');
if(!isAPK){
if(header)header.classList.add('show');
if(container)container.classList.add('with-header');
}else{
if(header)header.classList.remove('show');
if(header)header.style.display='none';
if(container)container.classList.remove('with-header');
if(container)container.style.paddingTop='0';
}
document.querySelectorAll('.panel,.home-panel').forEach(p=>p.classList.remove('active'));
document.getElementById('panel-home').classList.add('active');
// 保存当前面板状态
try{localStorage.setItem('lastPanel','home');}catch(e){}
loadHomeStats();
window.scrollTo(0,0);
}

// ===== AListLite 网盘管理（内置自动启动）=====
const ALIST_URL='https://'+window.location.hostname+':8444/';
let alistAutoStartAttempted=false;

// 在新窗口打开AList
function openAlistInNewTab(){
window.open(ALIST_URL,'_blank');
}

// ===== 权限控制 =====
let currentUserPermissions=[];
let currentUserIsAdmin=false;
async function loadCurrentUserPermissions(){
try{
const token=localStorage.getItem('token')||'';
const res=await fetch('/api/users/permissions',{headers:{'Authorization':'Bearer '+token}});
const data=await res.json();
currentUserPermissions=data.permissions||[];
currentUserIsAdmin=data.is_admin||false;
}catch(e){
currentUserPermissions=[];
currentUserIsAdmin=false;
}
}
function hasPermission(module){
if(currentUserIsAdmin)return true;
return currentUserPermissions.includes(module);
}
function applyPermissionControl(){
// 网盘管理：没有alist_manage权限隐藏管理按钮
const alistManageBtn=document.querySelector('#panel-cloud .btn-primary');
if(alistManageBtn&&!hasPermission('alist_manage')){
alistManageBtn.textContent='📂 打开网盘';
}
// 没有cloud权限隐藏网盘入口
const cloudIcon=document.querySelector('[onclick*="cloud"]');
if(cloudIcon&&!hasPermission('cloud')){
cloudIcon.style.display='none';
}
}

async function checkAlistStatus(){
const statusBar=document.getElementById('alistStatusBar');
const icon=document.getElementById('alistStatusIcon');
const text=document.getElementById('alistStatusText');
const frameWrap=document.getElementById('alistFrameWrap');
const notRunning=document.getElementById('alistNotRunning');

// 显示状态条
statusBar.style.display='flex';
icon.textContent='⏳';
text.textContent='正在连接 AList...';

try{
// 先检查NAS内置的AList状态
const res=await fetch('/api/alist/status');
const data=await res.json();

if(data.running){
// AList已运行
icon.textContent='✅';
text.textContent='AList 已连接';
statusBar.style.background='#e8f5e9';
text.style.color='#2e7d32';
frameWrap.style.display='block';
notRunning.style.display='none';
document.getElementById('alistFrameUrl').textContent='地址：'+ALIST_URL;
setTimeout(()=>{statusBar.style.display='none';},2000);
return;
}

// AList未运行，尝试自动启动
if(!alistAutoStartAttempted){
alistAutoStartAttempted=true;
icon.textContent='🚀';
text.textContent='正在启动内置 AList 服务...';
try{
await fetch('/api/alist/start',{method:'POST'});
// 等待启动
await new Promise(r=>setTimeout(r,3000));
// 重新检查
checkAlistStatus();
return;
}catch(e){
// 启动失败，继续显示未启动提示
}
}

// 显示未启动提示
icon.textContent='❌';
text.textContent='AList 未启动';
statusBar.style.background='#fff3cd';
text.style.color='#856404';
frameWrap.style.display='none';
notRunning.style.display='block';
}catch(e){
// API调用失败，直接检测8444代理端口
try{
const controller=new AbortController();
const timeout=setTimeout(()=>controller.abort(),3000);
await fetch(ALIST_URL+'api/public/settings',{signal:controller.signal});
clearTimeout(timeout);

icon.textContent='✅';
text.textContent='AList 已连接';
statusBar.style.background='#e8f5e9';
text.style.color='#2e7d32';
frameWrap.style.display='block';
notRunning.style.display='none';
document.getElementById('alistFrameUrl').textContent='地址：'+ALIST_URL;
setTimeout(()=>{statusBar.style.display='none';},2000);
}catch(e2){
icon.textContent='❌';
text.textContent='AList 未启动';
statusBar.style.background='#fff3cd';
text.style.color='#856404';
frameWrap.style.display='none';
notRunning.style.display='block';
}
}
}
async function startAlist(){
try{
const res=await fetch('/api/alist/start',{method:'POST'});
const data=await res.json();
if(data.success){
alert('AList启动中，请等待3秒后刷新');
setTimeout(()=>checkAlistStatus(),3000);
}else{
alert('启动失败：'+(data.error||'未知错误'));
}
}catch(e){
alert('启动失败：'+e.message);
}
}
function showAlistHelp(){
const help=document.getElementById('alistHelp');
help.style.display=help.style.display==='none'?'block':'none';
}
async function loadHomeStats(){
try{
const res=await fetch('/api/size?path=/');
const data=await res.json();
document.getElementById('homeFiles').textContent=data.count;
document.getElementById('homeSize').textContent=formatSize(data.size);
}catch(e){}
// 获取局域网IP
try{
const sysRes=await fetch('/api/system/info');
const sysData=await sysRes.json();
const ifaces=sysData.interfaces||[];
const lanIp=ifaces.find(i=>i.ip&&i.ip!=='127.0.0.1'&&!i.ip.startsWith('::'));
if(lanIp){
document.getElementById('lanAddress').textContent='https://'+lanIp.ip+':8443';
}else{
document.getElementById('lanAddress').textContent='未检测到局域网IP';
}
}catch(e){
document.getElementById('lanAddress').textContent='获取失败';
}
}

function setView(view){
currentView=view;
localStorage.setItem('fileViewMode',view);
document.querySelectorAll('.view-btn').forEach((b,i)=>b.classList.toggle('active',(i===0&&view==='list')||(i===1&&view==='grid')));
loadList(currentPath);
}

async function loadList(path){
// 媒体扫描模式下不执行普通列表加载
if(isMediaScanMode&&currentFilter!=='all')return;
currentPath=path||'/';
try{
const res=await fetch('/api/list?path='+encodeURIComponent(currentPath));
if(!res.ok)throw new Error('HTTP '+res.status);
const data=await res.json();
if(!data||!data.files)throw new Error('数据格式错误');
renderBreadcrumb(data.path);
const sortSelect=document.getElementById('sortSelect');
const sortBy=sortSelect?sortSelect.value:'name';
data.files.sort((a,b)=>{
if(!a||!b)return 0;
if(a.is_dir!==b.is_dir)return a.is_dir?-1:1;
if(sortBy==='size')return (b.size||0)-(a.size||0);
if(sortBy==='time')return new Date(b.mod_time||0)-new Date(a.mod_time||0);
return (a.name||'').localeCompare(b.name||'','zh-CN');
});
// 按类型过滤
let filteredFiles=data.files.filter(f=>f&&f.name&&f.path);
if(currentFilter!=='all'){
filteredFiles=filteredFiles.filter(function(f){
if(!f)return false;
if(f.is_dir)return true; // 文件夹始终显示
const ext=(f.name||'').split('.').pop().toLowerCase();
if(currentFilter==='video')return isVideoFile(f.name);
if(currentFilter==='music')return isAudioFile(f.name);
if(currentFilter==='image')return isImageFile(f.name);
if(currentFilter==='doc'){
return ['pdf','doc','docx','txt','md','ppt','pptx','xls','xlsx','csv','epub','mobi'].includes(ext);
}
return true;
});
}
renderFiles(filteredFiles);
// 更新过滤标签状态
document.querySelectorAll('.filter-tab').forEach(function(tab){
tab.classList.toggle('active',tab.dataset.filter===currentFilter);
});
clearSelection();
}catch(e){
console.error('加载文件列表失败:',e);
const container=document.getElementById('fileContainer');
if(container){
container.innerHTML='<div class="empty" style="padding:40px;text-align:center;color:#999"><div style="font-size:48px;margin-bottom:16px">📂</div><div>加载失败：'+e.message+'</div><button class="btn btn-primary" style="margin-top:16px" onclick="loadList(currentPath)">重试</button></div>';
}
}
}

// 设置过滤类型
let isMediaScanMode=false;
function setFilter(type){
currentFilter=type;
isMediaScanMode=(type!=='all');
// 更新标签状态
document.querySelectorAll('.filter-tab').forEach(function(tab){
tab.classList.toggle('active',tab.dataset.filter===type);
});
if(type==='all'){
// 全部：显示当前目录
loadList(currentPath);
}else{
// 视频/音乐/图片/文档：自动搜集整个存储目录
loadMediaFiles(type);
}
}

// 自动搜集媒体文件（递归搜索整个存储目录）
async function loadMediaFiles(type){
const container=document.getElementById('fileContainer');
const typeNames={video:'视频',music:'音乐',image:'图片',doc:'文档'};
isMediaScanMode=true;
container.innerHTML='<div style="text-align:center;padding:40px;color:#999"><div style="font-size:32px;margin-bottom:12px">🔍</div><div>正在搜集'+typeNames[type]+'文件...</div><div style="font-size:12px;margin-top:8px">递归搜索整个存储目录，首次扫描可能需要较长时间</div></div>';

try{
// 添加超时控制
const controller=new AbortController();
const timeoutId=setTimeout(()=>controller.abort(),60000); // 60秒超时
const res=await fetch('/api/media/list?type='+type,{signal:controller.signal});
clearTimeout(timeoutId);
const data=await res.json();
if(!data.success){
container.innerHTML='<div style="text-align:center;padding:40px;color:#999"><div style="font-size:32px;margin-bottom:12px">❌</div><div>搜集失败: '+data.error+'</div><button class="btn btn-primary" style="margin-top:16px" onclick="loadMediaFiles(\''+type+'\')">重试</button></div>';
return;
}

const files=(data.files||[]).filter(f=>f&&f.name&&f.path);
if(files.length===0){
container.innerHTML='<div style="text-align:center;padding:40px;color:#999"><div style="font-size:32px;margin-bottom:12px">📭</div><div>暂无'+typeNames[type]+'文件</div><div style="font-size:12px;margin-top:8px">扫描时间: '+data.scanTime+'</div></div>';
return;
}

// 渲染搜集结果
currentFileList=files;
let html='<div style="padding:8px 16px;font-size:12px;color:#666;background:#f8f9fa;margin-bottom:8px;border-radius:6px">共找到 '+files.length+' 个'+typeNames[type]+'文件（'+data.scanTime+'）</div>';
html+='<div class="file-list">';
files.forEach(function(f,index){
if(!f)return;
const icon=getTypeIcon(f.type||type);
const size=formatSize(f.size||0);
html+='<div class="file-item" onclick="openMediaFile(\''+f.path.replace(/'/g,"\\'")+'\',\''+f.type+'\')">'+
'<div class="file-icon">'+icon+'</div>'+
'<div style="flex:1;min-width:0"><div class="file-name" title="'+f.name+'">'+f.name+'</div>'+
'<div class="file-meta">'+f.path+' · '+size+'</div></div>'+
'<span class="file-arrow" onclick="event.stopPropagation();showFileMenuByIndex('+index+')">⋯</span></div>';
});
html+='</div>';
container.innerHTML=html;

// 更新面包屑
document.getElementById('breadcrumb').innerHTML='<span style="color:#666">全部'+typeNames[type]+'（自动搜集）</span>';

}catch(e){
if(e.name==='AbortError'){
container.innerHTML='<div style="text-align:center;padding:40px;color:#999"><div style="font-size:32px;margin-bottom:12px">⏱️</div><div>搜索超时</div><div style="font-size:12px;margin-top:8px">文件较多，请稍后重试</div><button class="btn btn-primary" style="margin-top:16px" onclick="loadMediaFiles(\''+type+'\')">重试</button></div>';
}else{
container.innerHTML='<div style="text-align:center;padding:40px;color:#999"><div style="font-size:32px;margin-bottom:12px">❌</div><div>搜集失败: '+e.message+'</div><button class="btn btn-primary" style="margin-top:16px" onclick="loadMediaFiles(\''+type+'\')">重试</button></div>';
}
}
}

// 打开搜集到的媒体文件
function openMediaFile(path,type){
if(type==='video'){
const name=path.split('/').pop();
playWithArtPlayer(path,name);
}else if(type==='music'){
// 先确保音乐列表已加载
if(musicList.length===0){
loadMusicList().then(()=>{
const index=musicList.findIndex(f=>f&&f.path===path);
if(index>=0)playMusic(index);
else showToast('音乐文件不在播放列表中','error');
});
}else{
const index=musicList.findIndex(f=>f&&f.path===path);
if(index>=0)playMusic(index);
else{
loadMusicList().then(()=>{
const idx=musicList.findIndex(f=>f&&f.path===path);
if(idx>=0)playMusic(idx);
else showToast('音乐文件不在播放列表中','error');
});
}
}
}else if(type==='image'){
openImage(path);
}else{
downloadFile(path);
}
}

// 获取类型图标
function getTypeIcon(type){
const icons={video:'🎬',music:'🎵',image:'🖼️',doc:'📄'};
return icons[type]||'📄';
}

// 打开文件管理器并设置过滤
function openFilesWithFilter(filter){
currentFilter=filter||'all';
openPanel('files');
setTimeout(function(){
if(filter==='all'){
loadList(currentPath);
}else{
loadMediaFiles(filter);
}
},100);
}
function renderBreadcrumb(path){
const parts=path.split('/').filter(Boolean);
let html='<a onclick="loadList(\'/\')">根目录</a>';
let cur='';
parts.forEach(p=>{cur+='/'+p;html+=' / <a onclick="loadList(\''+cur+'\')">'+p+'</a>';});
document.getElementById('breadcrumb').innerHTML=html;
}
// 当前文件列表缓存（用于菜单事件）
let currentFileList=[];
function renderFiles(files){
// 过滤无效文件
const validFiles=(files||[]).filter(f=>f&&f.name&&f.path);
currentFileList=validFiles;
const container=document.getElementById('fileContainer');
// 更新文件统计
const dirCount=validFiles.filter(f=>f.is_dir).length;
const fileCount=validFiles.length-dirCount;
const statsEl=document.getElementById('fileStats');
if(statsEl)statsEl.textContent=dirCount+' 个文件夹, '+fileCount+' 个文件';
// 更新AppBar标题
const titleEl=document.getElementById('fileAppbarTitle');
if(titleEl)titleEl.textContent=currentPath==='/'?'/storage/emulated/0':currentPath;
if(validFiles.length===0){container.innerHTML='<div class="empty" style="padding:60px 20px;text-align:center;color:#999"><div style="font-size:48px;margin-bottom:16px">📂</div><div>暂无文件</div></div>';return;}
if(currentView==='list'){
let html='';
validFiles.forEach(function(f,index){
if(!f)return;
const checked=selectedFiles.has(f.path)?'checked':'';
const modTime=f.mod_time||'';
const meta=f.is_dir?modTime.substring(0,16).replace('T',' '):formatSize(f.size||0)+' · '+modTime.substring(0,10);
// 确定文件类型class
let typeClass='';
if(f.is_dir){typeClass='folder';}
else if(isVideoFile(f.name)){typeClass='video';}
else if(isAudioFile(f.name)){typeClass='audio';}
else if(isImageFile(f.name)){typeClass='image';}
else if(isDocFile(f.name)){typeClass='doc';}
else if(isArchiveFile(f.name)){typeClass='archive';}
let iconHtml;
if(hasThumbnail(f.name,f.is_dir)){
iconHtml='<div class="native-file-icon '+typeClass+'"><img src="/api/thumb?path='+encodeURIComponent(f.path)+'" loading="lazy" style="width:100%;height:100%;object-fit:cover;border-radius:8px" onerror="this.style.display=\'none\';this.parentElement.innerHTML=\''+(f.is_dir?'📁':getFileIcon(f.name))+'\'"></div>';
}else{
iconHtml='<div class="native-file-icon '+typeClass+'">'+(f.is_dir?'📁':getFileIcon(f.name))+'</div>';
}
html+='<div class="native-file-item '+(selectedFiles.has(f.path)?'selected':'')+'" data-index="'+index+'" onclick="itemClick(event,\''+f.path.replace(/'/g,"\\'")+'\','+f.is_dir+')">'+
'<input type="checkbox" class="file-check" '+checked+' style="margin-right:12px;width:20px;height:20px;cursor:pointer" onclick="event.stopPropagation();toggleSelect(\''+f.path.replace(/'/g,"\\'")+'\')">'+
iconHtml+
'<div class="native-file-info"><div class="native-file-name" title="'+f.name+'">'+f.name+'</div>'+
'<div class="native-file-meta">'+meta+'</div></div>'+
'<button class="native-file-more" data-index="'+index+'" onclick="event.stopPropagation();showFileMenuByIndex('+index+')">⋮</button></div>';
});
container.innerHTML=html;
}else{
let html='<div class="file-grid">';
validFiles.forEach(function(f,index){
if(!f)return;
const modTime=f.mod_time||'';
const meta=f.is_dir?modTime.substring(5,10):formatSize(f.size||0);
let typeClass='';
if(f.is_dir){typeClass='folder';}
else if(isVideoFile(f.name)){typeClass='video';}
else if(isAudioFile(f.name)){typeClass='audio';}
else if(isImageFile(f.name)){typeClass='image';}
else if(isDocFile(f.name)){typeClass='doc';}
else if(isArchiveFile(f.name)){typeClass='archive';}
const thumb=hasThumbnail(f.name,f.is_dir)?'<img class="grid-thumb" src="/api/thumb?path='+encodeURIComponent(f.path)+'" loading="lazy" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'block\'">':'<div class="grid-icon '+typeClass+'">'+(f.is_dir?'📁':getFileIcon(f.name))+'</div>';
const fallback=f.is_dir?'<div class="grid-icon folder">📁</div>':'<div class="grid-icon '+typeClass+'" style="display:none">'+getFileIcon(f.name)+'</div>';
html+='<div class="grid-item '+(selectedFiles.has(f.path)?'selected':'')+'" data-index="'+index+'" onclick="itemClick(event,\''+f.path.replace(/'/g,"\\'")+'\','+f.is_dir+')">'+
'<input type="checkbox" class="grid-check" '+(selectedFiles.has(f.path)?'checked':'')+' onclick="event.stopPropagation();toggleSelect(\''+f.path.replace(/'/g,"\\'")+'\')">'+
'<div class="grid-more" data-index="'+index+'" onclick="event.stopPropagation();showFileMenuByIndex('+index+')">⋯</div>'+
'<div class="grid-thumb-wrap">'+thumb+(hasThumbnail(f.name,f.is_dir)?fallback:'')+'</div>'+
'<div class="grid-name" title="'+f.name+'">'+f.name+'</div><div class="grid-meta">'+meta+'</div></div>';
});
html+='</div>';
container.innerHTML=html;
}
}
// 通过索引显示文件菜单（更安全）
function showFileMenuByIndex(index){
const file=currentFileList[index];
if(!file){showToast('文件信息无效','error');return;}
showFileMenu(file);
}
function hasThumbnail(name,isDir){
if(isDir)return false;
const ext=name.split('.').pop().toLowerCase();
const videoExts=['mp4','mkv','avi','mov','flv','webm','m4v','ts','mpg','mpeg','3gp','wmv','rm','rmvb','vob','ogv'];
return isImageFile(name)||videoExts.includes(ext);
}
function truncateName(name,maxLen,isDir){
if(name.length<=maxLen)return name;
// 文件夹直接截断，不处理扩展名
if(isDir){
return name.substring(0,maxLen-1)+'…';
}
// 文件保留扩展名
const ext=name.lastIndexOf('.');
if(ext>0&&name.length-ext<=6){
const base=name.substring(0,ext);
const extStr=name.substring(ext);
const keepBase=maxLen-extStr.length-1;
if(keepBase>3)return base.substring(0,keepBase)+'…'+extStr;
}
return name.substring(0,maxLen-1)+'…';
}
function getFileIcon(name){
const ext=name.split('.').pop().toLowerCase();
if(['mp4','mkv','avi','mov','flv','webm','m4v','ts','mpg','mpeg','3gp','wmv','rm','rmvb'].includes(ext))return '🎬';
if(['mp3','flac','wav','aac','ogg','m4a','wma','ape','opus','aiff'].includes(ext))return '🎵';
if(isImageFile(name))return '🖼️';
if(['zip','rar','7z','tar','gz','bz2','xz'].includes(ext))return '📦';
if(['pdf','doc','docx','txt','md','ppt','pptx','xls','xlsx','csv'].includes(ext))return '📄';
if(['apk','exe','msi','deb','rpm'].includes(ext))return '📦';
return '📄';
}
function formatSize(b){if(b<1024)return b+' B';if(b<1048576)return(b/1024).toFixed(1)+' KB';if(b<1073741824)return(b/1048576).toFixed(1)+' MB';return(b/1073741824).toFixed(2)+' GB';}
function itemClick(e,path,isDir){
// 如果点击的是菜单按钮或复选框，不执行导航
if(e.target&&(e.target.classList.contains('file-arrow')||e.target.classList.contains('grid-more')||e.target.classList.contains('file-check')||e.target.classList.contains('grid-check'))){
return;
}
if(e.ctrlKey||e.metaKey){toggleSelect(path);return;}
if(isDir){loadList(path);}
else if(isImageFile(path)){openImage(path);}
else if(isVideoFile(path)){
const name=path.split('/').pop();
playWithArtPlayer(path,name);
}
else if(isAudioFile(path)){
// 直接播放音乐文件，不依赖播放列表
const name=path.split('/').pop();
playMusicDirect(path,name);
}
else{downloadFile(path);}
}
function isVideoFile(path){
const ext=path.split('.').pop().toLowerCase();
const videoExts=['mp4','mkv','avi','mov','flv','webm','m4v','ts','mpg','mpeg','3gp','wmv','rm','rmvb','vob','ogv','m2ts','mts','divx','xvid','f4v','f4p','f4a','f4b'];
return videoExts.includes(ext);
}
function isAudioFile(path){
const ext=path.split('.').pop().toLowerCase();
const audioExts=['mp3','flac','wav','aac','ogg','m4a','wma','ape','opus','aiff','aif','au','ra','mid','midi','amr','3gpp','ac3','dts','mka'];
return audioExts.includes(ext);
}
function isImageFile(path){
const ext=path.split('.').pop().toLowerCase();
const imageExts=[
// 常见格式
'jpg','jpeg','jpe','jif','jfif','png','gif','webp','bmp','dib',
// 高清/现代格式
'heic','heif','avif','tiff','tif',
// 矢量格式
'svg','svgz',
// 图标格式
'ico','cur',
// 相机RAW格式
'raw','cr2','cr3','nef','arw','dng','orf','rw2','pef','sr2','srw','x3f','raf','3fr','eip','dcr','kdc','mrw','nrw','ptx','r3d',
// 专业设计格式
'psd','ai','eps',
// 其他格式
'tga','pcx','pnm','pbm','pgm','ppm','xbm','xpm','wbmp',
// JPEG 2000
'jp2','j2k','jpf','jpx','jpm',
// 其他
'jxr','wdp','hdp','dds','exr','hdr','pic','pict','pct','psp','xcf'
];
return imageExts.includes(ext);
}
function isDocFile(path){
const ext=path.split('.').pop().toLowerCase();
const docExts=['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','md','csv','rtf','odt','ods','odp','epub','mobi','azw','azw3','html','htm','xml','json','log','ini','conf','cfg','yml','yaml','sql','java','py','js','ts','c','cpp','h','go','rs','php','rb','sh','bat','ps1'];
return docExts.includes(ext);
}
function isArchiveFile(path){
const ext=path.split('.').pop().toLowerCase();
const archiveExts=['zip','rar','7z','tar','gz','bz2','xz','zst','tgz','tbz2','txz','iso','dmg','apk','jar','war','deb','rpm','cab','arj','lzh','ace','uue','z'];
return archiveExts.includes(ext);
}
let imageList=[];
let imageIndex=0;
let imgScale=1;
let imgRotation=0;
let touchStartX=0;
let lastTap=0;

// 加密空间图片查看器
function openImageViewer(name,url){
try{
// 确保imageModal存在
let modal=document.getElementById('imageModal');
if(!modal){
modal=document.createElement('div');
modal.className='image-modal';
modal.id='imageModal';
modal.innerHTML='<div class="img-toolbar" onclick="event.stopPropagation()"><span class="img-counter" id="imgCounter">1 / 1</span><div class="img-actions"><button class="img-btn" onclick="rotateImage(-90)">↺</button><button class="img-btn" onclick="rotateImage(90)">↻</button><button class="img-btn" onclick="resetImage()">⟲</button><button class="img-btn img-close" onclick="closeImage()">✕</button></div></div><button class="img-nav prev" onclick="event.stopPropagation();prevImage()">‹</button><div class="img-wrap" id="imgWrap" onclick="event.stopPropagation()"><img id="imageViewer" src=""></div><button class="img-nav next" onclick="event.stopPropagation();nextImage()">›</button><div class="img-info" onclick="event.stopPropagation()"><span class="name" id="imageTitle"></span><span class="meta" id="imageMeta"></span></div>';
modal.onclick=closeImage;
document.body.appendChild(modal);
}
imageList=[url];
imageIndex=0;
imgScale=1;imgRotation=0;
const img=document.getElementById('imageViewer');
img.style.transform='scale(1) rotate(0deg)';
img.style.display='block';
img.src=url;
img.onload=function(){
document.getElementById('imageMeta').textContent=this.naturalWidth+'×'+this.naturalHeight;
};
img.onerror=function(){
document.getElementById('imageMeta').textContent='加载失败';
alert('图片加载失败！\nURL: '+url);
};
document.getElementById('imageTitle').textContent=name;
document.getElementById('imgCounter').textContent='1 / 1';
const prevBtn=document.querySelector('.img-nav.prev');
const nextBtn=document.querySelector('.img-nav.next');
if(prevBtn)prevBtn.style.display='none';
if(nextBtn)nextBtn.style.display='none';
modal.style.zIndex='99999';
modal.classList.add('active');
modal.style.display='flex';
}catch(e){
alert('打开图片失败: '+e.message+'\nURL: '+url);
}
}

// 视频播放器（使用ArtPlayer原生功能）
let artPlayer=null;

function openVideoPlayer(name,url){
if(typeof Artplayer==='undefined'){
alert('视频播放器加载失败，请刷新页面重试');
return;
}
// 格式检测，对不支持的格式给出友好提示
const ext=name?name.toLowerCase().substring(name.lastIndexOf('.')+1):'';
const unsupportedFormats=['mkv','avi','rmvb','rm','wmv','flv','ts','m2ts','mts','vob','dat','mpg','mpeg','3gp','mov'];
if(unsupportedFormats.includes(ext)){
showToast('注意：'+ext.toUpperCase()+'格式浏览器可能不支持，若无法播放请转码后查看','warning',5000);
}
const modal=document.getElementById('playerModal');
modal.classList.add('active');
if(artPlayer){artPlayer.destroy();artPlayer=null;}
// 根据扩展名判断类型
let videoType='auto';
if(['m3u8','m3u'].includes(ext))videoType='m3u8';
else if(['flv'].includes(ext))videoType='flv';
setTimeout(()=>{
artPlayer=new Artplayer({
container:'#artplayerContainer',
url:url,
title:name,
type:videoType,
theme:'#667eea',
volume:0.7,
autoplay:true,
pip:true,
hotkey:true,
playsInline:true,
mutex:true,
setting:true,
playbackRate:true,
fullscreen:true,
fullscreenWeb:true,
miniProgressBar:true,
autoSize:false,
// APK兼容：手势控制
autoMiniSize:true,
miniBar:true,
airplay:true,
moreVideoAttr:{
playsinline:true,
'webkit-playsinline':true,
'x5-playsinline':true,
'x5-video-player-type':'h5',
preload:'auto'
},
controls:[
{name:'backBtn',index:10,position:'left',html:'⬅ 返回',tooltip:'返回',click:function(){closePlayer();}},
{name:'speedBtn',index:20,position:'right',html:'倍速',tooltip:'倍速播放',click:function(){
const speeds=[0.5,0.75,1.0,1.25,1.5,2.0];
let current=speeds.indexOf(artPlayer.playbackRate||1);
current=(current+1)%speeds.length;
artPlayer.playbackRate=speeds[current];
artPlayer.notice.show='倍速: '+speeds[current]+'x';
}}
]
});
// 错误处理
artPlayer.on('error',function(){
artPlayer.notice.show='视频加载失败：文件不存在或格式不支持';
});
// 加载完成事件
artPlayer.on('ready',function(){
console.log('视频加载成功');
});
},100);
}
function closePlayer(){
const modal=document.getElementById('playerModal');
modal.classList.remove('active');
if(artPlayer){artPlayer.destroy();artPlayer=null;}
// 弹窗关闭后强制重排
window.dispatchEvent(new Event('resize'));
}

// ===== 音乐播放器全屏控制 =====
let musicPlayList=[];
let musicCurrentIndex=0;

function openMusicPlayer(title,artist){
document.getElementById('musicPlayer').classList.add('active');
if(title)document.getElementById('musicSongTitle').textContent=title;
if(artist)document.getElementById('musicArtist').textContent=artist;
// 更新进度条
if(aPlayer){
document.getElementById('musicCurrentTime').textContent=formatTime(aPlayer.audio.currentTime);
document.getElementById('musicTotalTime').textContent=formatTime(aPlayer.audio.duration);
document.getElementById('musicPlayBtn').textContent=aPlayer.audio.paused?'▶':'⏸';
}
}

function closeMusicPlayer(){
document.getElementById('musicPlayer').classList.remove('active');
}

function toggleMusicPlay(){
if(aPlayer){
if(aPlayer.audio.paused){
aPlayer.play();
document.getElementById('musicPlayBtn').textContent='⏸';
}else{
aPlayer.pause();
document.getElementById('musicPlayBtn').textContent='▶';
}
}
}

function musicPrev(){
if(aPlayer)aPlayer.skipBack();
}

function musicNext(){
if(aPlayer)aPlayer.skipForward();
}

function seekMusic(e){
if(!aPlayer)return;
const bar=document.getElementById('musicProgressBar');
const rect=bar.getBoundingClientRect();
const percent=(e.clientX-rect.left)/rect.width;
aPlayer.seek(Math.floor(percent*aPlayer.audio.duration));
}

function updateMusicProgress(){
if(!aPlayer||!document.getElementById('musicPlayer').classList.contains('active'))return;
const cur=aPlayer.audio.currentTime;
const dur=aPlayer.audio.duration||0;
const percent=dur>0?(cur/dur)*100:0;
document.getElementById('musicProgressFill').style.width=percent+'%';
document.getElementById('musicCurrentTime').textContent=formatTime(cur);
document.getElementById('musicTotalTime').textContent=formatTime(dur);
document.getElementById('musicPlayBtn').textContent=aPlayer.audio.paused?'▶':'⏸';
}

function showPlaylist(){
document.getElementById('playlistModal').style.display='flex';
renderPlaylist();
}

function hidePlaylist(){
document.getElementById('playlistModal').style.display='none';
}

function renderPlaylist(){
const container=document.getElementById('playlistContent');
if(!musicPlayList.length){
container.innerHTML='<div style="padding:40px;text-align:center;color:#999">播放列表为空</div>';
return;
}
let html='';
musicPlayList.forEach((song,i)=>{
const active=i===musicCurrentIndex?'color:#667eea;font-weight:600':'';
html+='<div style="padding:12px 16px;border-bottom:1px solid #f0f0f0;cursor:pointer;'+active+'" onclick="playFromPlaylist('+i+')">'+
'<div style="font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+(i+1)+'. '+song.name+'</div>'+
'<div style="font-size:12px;color:#999;margin-top:4px">'+(song.artist||'未知艺术家')+'</div>'+
'</div>';
});
container.innerHTML=html;
}

function playFromPlaylist(index){
musicCurrentIndex=index;
// 播放对应歌曲
hidePlaylist();
}

// APK适配
if(isAPK&&window.AndroidJSBridge){
artPlayer.on('fullscreen',function(enter){
try{window.AndroidJSBridge.onVideoFullscreen(enter);}catch(e){}
});
}

// 强制CSS控制 - 使用aspect-ratio自动计算16:9
function forceVideoContainerSize(){
const modal=document.getElementById('playerModal');
const container=document.getElementById('artplayerContainer');
if(!container)return;
const isLandscape=window.innerWidth>window.innerHeight;
// modal固定16:9（竖屏）或全屏（横屏）
if(modal){
modal.style.position='fixed';
modal.style.top='0';
modal.style.left='0';
modal.style.overflow='hidden';
if(isLandscape){
modal.style.width='100vw';
modal.style.height='100vh';
modal.style.aspectRatio='auto';
}else{
modal.style.width='100vw';
modal.style.height='auto';
modal.style.aspectRatio='16/9';
}
}
// container占满modal
container.style.width='100%';
container.style.height='100%';
container.style.position='relative';
container.style.overflow='hidden';
container.style.display='block';
}
// 立即设置
forceVideoContainerSize();
// 多次延迟设置，覆盖ArtPlayer的修改
setTimeout(forceVideoContainerSize,50);
setTimeout(forceVideoContainerSize,100);
setTimeout(forceVideoContainerSize,200);
setTimeout(forceVideoContainerSize,500);
// 监听容器属性变化，如果被修改就立即改回
if(window.MutationObserver){
const observer=new MutationObserver(function(mutations){
mutations.forEach(function(mutation){
if(mutation.type==='attributes'&&(mutation.attributeName==='style'||mutation.attributeName==='class')){
forceVideoContainerSize();
}
});
});
const container=document.getElementById('artplayerContainer');
if(container)observer.observe(container,{attributes:true,attributeFilter:['style','class']});
const modal=document.getElementById('playerModal');
if(modal)observer.observe(modal,{attributes:true,attributeFilter:['style','class']});
}
// 强制video元素样式
setTimeout(()=>{
const videos=document.querySelectorAll('#artplayerContainer video');
videos.forEach(v=>{
v.removeAttribute('width');
v.removeAttribute('height');
applyVideoFitMode();
});
},300);

// 切换视频显示模式
function toggleVideoFitMode(){
const modes=['contain','cover','fill'];
const names={contain:'适应屏幕',cover:'铺满屏幕',fill:'拉伸全屏'};
const currentIdx=modes.indexOf(currentVideoFitMode);
const nextIdx=(currentIdx+1)%modes.length;
currentVideoFitMode=modes[nextIdx];
applyVideoFitMode();
showToast('画面模式: '+names[currentVideoFitMode],'info');
}

// 应用视频显示模式（核心：固定窗口+保持比例）
function applyVideoFitMode(){
const videos=document.querySelectorAll('#artplayerContainer video');
videos.forEach(v=>{
v.style.width='100%';
v.style.height='100%';
v.style.maxWidth='100%';
v.style.maxHeight='100%';
v.style.objectFit=currentVideoFitMode;
v.style.position='absolute';
v.style.top='0';
v.style.left='0';
v.style.right='0';
v.style.bottom='0';
v.style.margin='auto';
v.style.background='#000';
});
// 更新按钮图标
const fitBtn=document.querySelector('.artplayer-control[title="画面比例"]');
if(fitBtn){
const icons={contain:'🔲',cover:'🖼',fill:'⬛'};
fitBtn.innerHTML=icons[currentVideoFitMode]||'🔲';
}
}

// 加密空间音乐播放（使用APlayer）
function playAudio(name,url){
if(!aplayer){
aplayer=new APlayer({
container:document.getElementById('aplayerContainer'),
mini:false,
autoplay:true,
theme:'#667eea',
loop:'all',
order:'list',
preload:'auto',
volume:0.7,
mutex:true,
listFolded:false,
listMaxHeight:'250px',
audio:[{name:name,artist:'加密空间',url:url,cover:''}]
});
}else{
aplayer.list.clear();
aplayer.list.add({name:name,artist:'加密空间',url:url,cover:''});
aplayer.play();
}
// 切换到音乐面板
openPanel('music');
}

// 打开AList（内嵌面板，不跳转）
function openAlist(path){
path=path||'/';
const url='https://'+ALIST_CONFIG.host+':'+ALIST_CONFIG.port+ALIST_CONFIG.basePath+path;
const frame=document.getElementById('alistFrame');
const loading=document.getElementById('alistLoading');
if(frame){
// 显示加载提示
if(loading)loading.style.display='flex';
frame.style.display='none';
frame.onload=function(){
if(loading)loading.style.display='none';
frame.style.display='block';
};
frame.onerror=function(){
if(loading){
loading.innerHTML='<div style="text-align:center"><div style="font-size:48px;margin-bottom:12px">⚠️</div><div style="color:#666">加载失败</div><div style="font-size:12px;color:#999;margin-top:8px">请点击右上角↗在新窗口打开</div></div>';
}
};
frame.src=url;
}
// 设置标题
const titleMap={
'/':'文件管理',
'/#/manage/settings':'系统设置',
'/#/manage/users':'用户管理',
'/#/manage/storages':'存储管理'
};
document.getElementById('alistPanelTitle').textContent=titleMap[path]||'AList';
// 显示面板
document.querySelectorAll('.panel,.home-panel').forEach(p=>p.classList.remove('active'));
document.getElementById('panel-alist').classList.add('active');
window.scrollTo(0,0);
}

// 刷新AList面板
function refreshAlistPanel(){
const frame=document.getElementById('alistFrame');
if(frame){
frame.src=frame.src;
}
}

// 打开媒体列表（视频/音乐/图片）
let currentMediaType='video';
function openMediaList(type){
currentMediaType=type;
const titleMap={video:'视频列表',music:'音乐列表',image:'图库'};
document.getElementById('mediaPanelTitle').textContent=titleMap[type]||'媒体列表';
document.querySelectorAll('.panel,.home-panel').forEach(p=>p.classList.remove('active'));
document.getElementById('panel-media').classList.add('active');
window.scrollTo(0,0);
loadMediaList();
}

// 加载媒体列表
async function loadMediaList(){
const loading=document.getElementById('mediaListLoading');
const container=document.getElementById('mediaListContainer');
const empty=document.getElementById('mediaListEmpty');
loading.style.display='block';
container.style.display='none';
empty.style.display='none';
try{
const res=await fetch('/api/media/list?type='+currentMediaType);
let data;
try{
data=await res.json();
}catch(e){
loading.innerHTML='<div style="color:#e74c3c">加载失败</div><div style="font-size:12px;margin-top:8px;color:#999">服务器返回错误: HTTP '+res.status+'</div>';
return;
}
if(!data.success||res.status!==200){
loading.innerHTML='<div style="color:#e74c3c">加载失败</div><div style="font-size:12px;margin-top:8px;color:#999;word-break:break-all">'+(data.error||'未知错误 (HTTP '+res.status+')')+'</div>';
return;
}
if(data.count===0){
loading.style.display='none';
empty.style.display='block';
return;
}
loading.style.display='none';
container.style.display='block';
let html='<div style="margin-bottom:12px;color:#666;font-size:14px">共找到 '+data.count+' 个文件</div>';

if(currentMediaType==='image'){
// 图片用网格布局
html+='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">';
data.files.forEach(function(f){
const thumbUrl='https://'+ALIST_CONFIG.host+':'+ALIST_CONFIG.port+f.path;
html+='<div onclick="playMediaFromList(\''+f.path.replace(/'/g,"\\'")+'\',\''+f.name.replace(/'/g,"\\'")+'\')" style="aspect-ratio:1;background:#f5f5f5;border-radius:8px;overflow:hidden;cursor:pointer;display:flex;align-items:center;justify-content:center">'+
'<img src="'+thumbUrl+'" style="width:100%;height:100%;object-fit:cover" onerror="this.style.display=\'none\';this.parentElement.innerHTML=\'<div style=\\\'font-size:32px\\\'>🖼️</div>\'">'+
'</div>';
});
html+='</div>';
}else{
// 视频/音乐用列表布局
html+='<div style="display:flex;flex-direction:column;gap:8px">';
data.files.forEach(function(f){
const icon=currentMediaType==='video'?'🎬':'🎵';
const sizeStr=formatSize(f.size);
html+='<div onclick="playMediaFromList(\''+f.path.replace(/'/g,"\\'")+'\',\''+f.name.replace(/'/g,"\\'")+'\')" style="display:flex;align-items:center;padding:12px;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.06);cursor:pointer;transition:all .2s" onmouseover="this.style.background=\'#f5f5f5\'" onmouseout="this.style.background=\'#fff\'">'+
'<div style="font-size:24px;margin-right:12px">'+icon+'</div>'+
'<div style="flex:1;min-width:0">'+
'<div style="font-size:14px;font-weight:500;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+f.name+'</div>'+
'<div style="font-size:12px;color:#999;margin-top:2px">'+sizeStr+'</div>'+
'</div>'+
'<div style="color:#ccc;font-size:20px">›</div>'+
'</div>';
});
html+='</div>';
}
container.innerHTML=html;
}catch(e){
loading.innerHTML='加载失败: '+e.message;
}
}

// 刷新媒体列表
function refreshMediaList(){
loadMediaList();
}

// 从列表播放媒体
function playMediaFromList(path,name){
// 新窗口打开AList对应目录
const dir=path.substring(0,path.lastIndexOf('/'));
const url='https://'+ALIST_CONFIG.host+':'+ALIST_CONFIG.port+(dir||'/');
window.open(url,'_blank');
}

// 构建AList文件URL
function buildAlistUrl(path,mode){
mode=mode||ALIST_CONFIG.openMode;
const base='https://'+ALIST_CONFIG.host+':'+ALIST_CONFIG.port+ALIST_CONFIG.basePath;
const encodedPath=path.startsWith('/')?path:'/'+path;
if(mode==='web'){
return base+'/#/'+encodedPath;
}else{
return base+encodedPath;
}
}

function openImage(path){
const token=localStorage.getItem('token')||'';
const encodedPath=path.split('/').filter(Boolean).map(encodeURIComponent).join('/');
const directUrl='/webdav/'+encodedPath+(token?'?token='+encodeURIComponent(token):'');
// 如果PhotoSwipe已加载，使用PhotoSwipe
if(window.openPhotoSwipe){
// 先加载图片获取尺寸
const img=new Image();
img.onload=function(){
window.openPhotoSwipe(directUrl,img.naturalWidth,img.naturalHeight);
};
img.onerror=function(){
// 加载失败，直接用默认尺寸打开
window.openPhotoSwipe(directUrl,1200,1600);
};
img.src=directUrl;
return;
}
// 降级：使用简单的图片查看
let modal=document.getElementById('simpleImageModal');
if(!modal){
modal=document.createElement('div');
modal.id='simpleImageModal';
modal.style.cssText='display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:#000;z-index:99999;';
modal.innerHTML='<div onclick="closeSimpleImage()" style="position:absolute;top:16px;right:16px;width:40px;height:40px;border-radius:50%;background:rgba(231,76,60,.9);color:#fff;font-size:20px;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:10;">✕</div>'+
'<div style="position:absolute;top:0;left:0;right:0;bottom:0;display:flex;align-items:center;justify-content:center;">'+
'<img id="simpleImageImg" src="" style="max-width:100%;max-height:100%;object-fit:contain;">'+
'</div>';
document.body.appendChild(modal);
}
document.getElementById('simpleImageImg').src=directUrl;
modal.style.display='block';
}
function closeSimpleImage(){
const modal=document.getElementById('simpleImageModal');
if(modal)modal.style.display='none';
}
function showImage(){
const path=imageList[imageIndex];
const img=document.getElementById('imageViewer');
img.style.transform='scale(1) rotate(0deg)';
imgScale=1;imgRotation=0;
const token=localStorage.getItem('token')||'';
img.src='/webdav'+path+(token?'?token='+encodeURIComponent(token):'');
img.onload=function(){
document.getElementById('imageMeta').textContent=this.naturalWidth+'×'+this.naturalHeight;
};
img.onerror=function(){
document.getElementById('imageMeta').textContent='加载失败，尝试用API方式...';
img.src='/api/file?path='+encodeURIComponent(path)+(token?'&token='+encodeURIComponent(token):'');
img.onerror=function(){
document.getElementById('imageMeta').textContent='图片加载失败，请检查文件是否存在';
};
};
document.getElementById('imageTitle').textContent=path.split('/').pop();
document.getElementById('imgCounter').textContent=(imageIndex+1)+' / '+imageList.length;
document.querySelector('.img-nav.prev').style.display=imageIndex>0?'flex':'none';
document.querySelector('.img-nav.next').style.display=imageIndex<imageList.length-1?'flex':'none';
// 切换按钮事件为普通版本
const prevBtn=document.querySelector('.img-nav.prev');
const nextBtn=document.querySelector('.img-nav.next');
if(prevBtn)prevBtn.setAttribute('onclick','event.stopPropagation();prevImage()');
if(nextBtn)nextBtn.setAttribute('onclick','event.stopPropagation();nextImage()');
}
function prevImage(){if(imageIndex>0){imageIndex--;showImage();}}
function nextImage(){if(imageIndex<imageList.length-1){imageIndex++;showImage();}}
function rotateImage(deg){
imgRotation+=deg;
applyTransform();
}
function resetImage(){imgScale=1;imgRotation=0;applyTransform();}
function applyTransform(){
document.getElementById('imageViewer').style.transform='scale('+imgScale+') rotate('+imgRotation+'deg)';
}
function onDoubleClick(e){
e.preventDefault();
if(imgScale>1){imgScale=1;}else{imgScale=2.5;}
applyTransform();
}
function onTouchStart(e){
if(e.touches.length===1){touchStartX=e.touches[0].clientX;}
}
function onTouchEnd(e){
if(e.changedTouches.length===1){
const dx=e.changedTouches[0].clientX-touchStartX;
// 双击检测
const now=Date.now();
if(now-lastTap<300){
e.preventDefault();
if(imgScale>1){imgScale=1;}else{imgScale=2.5;}
applyTransform();
lastTap=0;
return;
}
lastTap=now;
// 滑动切换（仅在未放大时）
if(imgScale<=1&&Math.abs(dx)>50){
if(dx>0)prevImage();else nextImage();
}
}
}
function closeImage(){
document.getElementById('imageModal').classList.remove('active');
document.getElementById('imageViewer').src='';
vaultImageList=[];
vaultImageIndex=0;
const wrap=document.getElementById('imgWrap');
wrap.removeEventListener('touchstart',onTouchStart);
wrap.removeEventListener('touchend',onTouchEnd);
// 弹窗关闭后强制重排
window.dispatchEvent(new Event('resize'));
wrap.removeEventListener('dblclick',onDoubleClick);
}

// 文件属性菜单
let currentMenuFile=null;
function showFileMenu(file){
if(!file){showToast('文件信息无效','error');return;}
currentMenuFile=file;
const menuIcon=document.getElementById('menuIcon');
const menuName=document.getElementById('menuName');
const menuType=document.getElementById('menuType');
const menuSize=document.getElementById('menuSize');
const menuTime=document.getElementById('menuTime');
const menuPath=document.getElementById('menuPath');
const fileMenu=document.getElementById('fileMenu');
if(!fileMenu)return;
if(menuIcon)menuIcon.textContent=file.is_dir?'📁':getFileIcon(file.name);
if(menuName)menuName.textContent=file.name;
if(menuType)menuType.textContent=file.is_dir?'文件夹':(getFileType(file.name)||'文件');
if(menuSize)menuSize.textContent=file.is_dir?'—':formatSize(file.size||0);
if(menuTime)menuTime.textContent=file.mod_time||'未知';
if(menuPath)menuPath.textContent=file.path;
// 延迟显示，确保不会被立即关闭
setTimeout(()=>{
fileMenu.classList.add('active');
fileMenu.style.display='flex';
},10);
}
function closeFileMenu(e){
if(e&&e.target!==e.currentTarget)return;
document.getElementById('fileMenu').classList.remove('active');
currentMenuFile=null;
}
function menuDownload(){
if(!currentMenuFile)return;
window.open('/webdav'+currentMenuFile.path,'_blank');
closeFileMenu();
}
function menuRename(){
if(!currentMenuFile)return;
const newName=prompt('重命名为：',currentMenuFile.name);
if(newName&&newName!==currentMenuFile.name){
addLog('INFO','文件管理','重命名文件',currentMenuFile.name+' → '+newName);
fetch('/api/rename',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:currentMenuFile.path,new_name:newName})})
.then(r=>r.json()).then(d=>{
if(d.success){
addLog('INFO','文件管理','重命名文件','成功: '+currentMenuFile.name+' → '+newName);
loadList();
}else{
addLog('ERROR','文件管理','重命名文件','失败: '+d.error||'未知错误');
logError('文件管理','重命名失败','原文件: '+currentMenuFile.name+'\n新名称: '+newName+'\n错误: '+(d.error||'未知'));
updateErrorLogBadge();
alert(d.error||'重命名失败');
}
});
}
closeFileMenu();
}
function menuCopy(){
if(!currentMenuFile)return;
clipboard={files:[currentMenuFile.path],mode:'copy'};
updateClipboardUI();
closeFileMenu();
showToast('已复制');
}
function menuCut(){
if(!currentMenuFile)return;
clipboard={files:[currentMenuFile.path],mode:'cut'};
updateClipboardUI();
closeFileMenu();
showToast('已剪切');
}
function updateClipboardUI(){
const pasteBtn=document.getElementById('pasteBtn');
if(pasteBtn)pasteBtn.disabled=clipboard.files.length===0;
// 显示剪贴板状态
if(clipboard.files.length>0){
showToast('剪贴板: '+clipboard.files.length+'个文件 ('+(clipboard.mode==='copy'?'复制':'剪切')+')','info');
}
}
function menuShare(){
if(!currentMenuFile)return;
const token=localStorage.getItem('token')||'';
const url=window.location.origin+'/webdav'+currentMenuFile.path+(token?'?token='+encodeURIComponent(token):'');
if(navigator.clipboard){
navigator.clipboard.writeText(url).then(()=>showToast('分享链接已复制','success')).catch(()=>prompt('复制以下链接分享：',url));
}else{
prompt('复制以下链接分享：',url);
}
closeFileMenu();
}
function menuCompress(){
if(!currentMenuFile)return;
const zipName=prompt('压缩包名称：',currentMenuFile.name+'.zip');
if(!zipName)return;
showProgress('正在压缩文件...');
fetch('/api/compress',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({files:[currentMenuFile.path],target:currentPath,zip_name:zipName.replace('.zip',''),format:'zip'})})
.then(r=>r.json()).then(d=>{
hideProgress();
if(d.success){showToast('压缩成功','success');loadList(currentPath);}
else{showToast(d.error||'压缩失败','error');}
}).catch(e=>{hideProgress();showToast('压缩失败: '+e.message,'error');});
closeFileMenu();
}
function menuDelete(){
if(!currentMenuFile)return;
if(confirm('确定删除「'+currentMenuFile.name+'」？')){
fetch('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:currentMenuFile.path})})
.then(r=>r.json()).then(d=>{if(d.success){loadList();}else alert(d.error||'删除失败');});
}
closeFileMenu();
}
async function menuEncrypt(){
if(!currentMenuFile){showToast('未选中文件','error');return;}
showToast('正在检查加密空间状态...','info');
const res=await fetch('/api/vault/status');
const data=await res.json();
if(!data.enabled){
if(confirm('加密空间未初始化\n\n是否前往加密空间进行初始化？\n\n初始化后才能使用加密功能')){
closeFileMenu();
openPanel('vault');
}
return;
}
if(!data.unlocked){
if(confirm('加密空间已锁定\n\n是否前往加密空间进行解锁？\n\n解锁后才能加密文件')){
closeFileMenu();
openPanel('vault');
}
return;
}
const fileType=currentMenuFile.is_dir?'文件夹':'文件';
const secret=prompt('请输入加密空间解锁密码（用于加密此'+fileType+'）：\n\n文件：'+currentMenuFile.name);
if(!secret){showToast('已取消加密','info');return;}
showToast(currentMenuFile.is_dir?'正在打包加密文件夹...':'正在加密...','info');
try{
const encryptRes=await fetch('/api/vault/encrypt-file',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:currentMenuFile.path,secret})});
if(!encryptRes.ok){const err=await encryptRes.text();showToast('加密失败：'+err,'error');return;}
showToast(fileType+'已加密到加密空间 ✓','success');
closeFileMenu();
}catch(e){
showToast('加密失败：网络错误','error');
}
}
function getFileType(name){
const ext=name.split('.').pop().toLowerCase();
const types={jpg:'图片',jpeg:'图片',png:'图片',gif:'图片',webp:'图片',bmp:'图片',mp4:'视频',mkv:'视频',avi:'视频',mov:'视频',mp3:'音频',flac:'音频',wav:'音频',ogg:'音频',pdf:'文档',doc:'文档',docx:'文档',xls:'表格',xlsx:'表格',ppt:'演示',pptx:'演示',txt:'文本',zip:'压缩包',rar:'压缩包','7z':'压缩包',apk:'安装包'};
return types[ext]||ext.toUpperCase()+' 文件';
}
function toggleSelect(path){
if(selectedFiles.has(path))selectedFiles.delete(path);
else selectedFiles.add(path);
updateSelectionBar();
updateSelectionUI();
}
function updateSelectionUI(){
// 更新列表视图
document.querySelectorAll('.file-item').forEach(item=>{
const index=parseInt(item.getAttribute('data-index'));
if(!isNaN(index)&&currentFileList[index]){
const p=currentFileList[index].path;
item.classList.toggle('selected',selectedFiles.has(p));
const cb=item.querySelector('.file-check');
if(cb)cb.checked=selectedFiles.has(p);
}
});
// 更新网格视图
document.querySelectorAll('.grid-item').forEach(item=>{
const index=parseInt(item.getAttribute('data-index'));
if(!isNaN(index)&&currentFileList[index]){
const p=currentFileList[index].path;
item.classList.toggle('selected',selectedFiles.has(p));
const cb=item.querySelector('.grid-check');
if(cb)cb.checked=selectedFiles.has(p);
}
});
}
function selectAll(){
document.querySelectorAll('.file-item,.grid-item').forEach(item=>{
const index=parseInt(item.getAttribute('data-index'));
if(!isNaN(index)&&currentFileList[index]){
selectedFiles.add(currentFileList[index].path);
}
});
updateSelectionBar();updateSelectionUI();
}
function clearSelection(){selectedFiles.clear();updateSelectionBar();updateSelectionUI();}
function updateSelectionBar(){
const bar=document.getElementById('selectionBar');
const count=selectedFiles.size;
document.getElementById('selectionCount').textContent='已选 '+count+' 项';
bar.style.display=count>0?'flex':'none';
const pasteBtn=document.getElementById('pasteBtn');
if(pasteBtn)pasteBtn.disabled=clipboard.files.length===0;
}
function copySelected(){
clipboard={files:Array.from(selectedFiles),mode:'copy'};
showToast('已复制 '+selectedFiles.size+' 项','info');
updateSelectionBar();
}
function cutSelected(){
clipboard={files:Array.from(selectedFiles),mode:'cut'};
showToast('已剪切 '+selectedFiles.size+' 项','info');
updateSelectionBar();
}
function renameSelected(){
if(selectedFiles.size!==1){showToast('请选择一个文件进行重命名','warning');return;}
const path=Array.from(selectedFiles)[0];
const oldName=path.split('/').pop();
const newName=prompt('重命名为：',oldName);
if(newName&&newName!==oldName){
fetch('/api/rename',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:path,new_name:newName})})
.then(r=>r.json()).then(d=>{
if(d.success){showToast('重命名成功','success');loadList(currentPath);}
else{showToast(d.error||'重命名失败','error');}
}).catch(e=>showToast('重命名失败: '+e.message,'error'));
}
}
function shareSelected(){
if(selectedFiles.size===0){showToast('请先选择文件','warning');return;}
const token=localStorage.getItem('token')||'';
const urls=Array.from(selectedFiles).map(p=>window.location.origin+'/webdav'+p+(token?'?token='+encodeURIComponent(token):''));
const text=urls.join('\n');
if(navigator.clipboard){
navigator.clipboard.writeText(text).then(()=>showToast('分享链接已复制','success')).catch(()=>prompt('复制以下链接分享：',text));
}else{
prompt('复制以下链接分享：',text);
}
}
function compressSelected(){
let files=Array.from(selectedFiles);
if(files.length===0&&currentMenuFile){
files=[currentMenuFile.path];
}
if(files.length===0){showToast('请先选择文件','warning');return;}
const zipName=prompt('压缩包名称：',files.length===1&&currentMenuFile?currentMenuFile.name+'.zip':'archive.zip');
if(!zipName)return;
showProgress('正在压缩文件...');
fetch('/api/compress',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({files:files,target:currentPath,zip_name:zipName.replace('.zip',''),format:'zip'})})
.then(r=>r.json()).then(d=>{
hideProgress();
if(d.success){showToast('压缩成功','success');loadList(currentPath);}
else{showToast(d.error||'压缩失败','error');}
}).catch(e=>{hideProgress();showToast('压缩失败: '+e.message,'error');});
}
async function pasteSelected(){
if(clipboard.files.length===0)return;
const action=clipboard.mode==='copy'?'/api/copy':'/api/move';
const actionName=clipboard.mode==='copy'?'复制':'移动';
showProgress('正在'+actionName+'文件');
try{
for(let i=0;i<clipboard.files.length;i++){
const file=clipboard.files[i];
const fileName=file.split('/').pop();
const target=currentPath==='/'?'/'+fileName:currentPath+'/'+fileName;
const pct=Math.round(((i+1)/clipboard.files.length)*100);
setProgress(pct,actionName+'中 ('+(i+1)+'/'+clipboard.files.length+'): '+fileName);
await fetch(action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({from:file,to:target})});
}
setProgress(100,actionName+'完成');await sleep(200);
hideProgress();
showToast('粘贴完成','success');
if(clipboard.mode==='cut')clipboard={files:[],mode:null};
clearSelection();loadList(currentPath);
}catch(e){hideProgress();alert(actionName+'失败：'+e.message);}
}
function moveSelected(){
if(selectedFiles.size===0)return;
document.getElementById('moveModal').style.display='flex';
}
async function doMove(){
const target=document.getElementById('moveTarget').value.trim();
if(!target)return;
document.getElementById('moveModal').style.display='none';
showProgress('正在移动文件');
try{
const files=Array.from(selectedFiles);
for(let i=0;i<files.length;i++){
const file=files[i];
const fileName=file.split('/').pop();
const to=target.endsWith('/')?target+fileName:target+'/'+fileName;
const pct=Math.round(((i+1)/files.length)*100);
setProgress(pct,'移动中 ('+(i+1)+'/'+files.length+'): '+fileName);
await fetch('/api/move',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({from:file,to})});
}
setProgress(100,'移动完成');await sleep(200);
hideProgress();
showToast('移动完成','success');
clearSelection();loadList(currentPath);
}catch(e){hideProgress();alert('移动失败：'+e.message);}
}
async function deleteSelected(){
if(selectedFiles.size===0)return;
if(!confirm('确定删除选中的 '+selectedFiles.size+' 项？此操作不可恢复！'))return;
showProgress('正在删除文件');
const files=Array.from(selectedFiles);
addLog('INFO','文件管理','批量删除','开始删除 '+files.length+' 个文件');
try{
let successCount=0;
let failCount=0;
for(let i=0;i<files.length;i++){
const pct=Math.round(((i+1)/files.length)*100);
setProgress(pct,'删除中 ('+(i+1)+'/'+files.length+'): '+files[i].split('/').pop());
const res=await fetch('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:files[i]})});
if(res.ok)successCount++;
else failCount++;
}
addLog('INFO','文件管理','批量删除','完成: 成功'+successCount+'个, 失败'+failCount+'个');
if(failCount>0){
logError('文件管理','部分文件删除失败','成功: '+successCount+'个\n失败: '+failCount+'个');
updateErrorLogBadge();
}
setProgress(100,'删除完成');await sleep(300);
hideProgress();
showToast('删除完成','success');
clearSelection();loadList(currentPath);
}catch(e){
addLog('ERROR','文件管理','批量删除','异常: '+e.message);
logError('文件管理','删除操作异常',e.message+'\n'+e.stack);
updateErrorLogBadge();
hideProgress();alert('删除失败：'+e.message);
}
}
function downloadFile(path){window.open('/webdav'+path);}
async function uploadFiles(files){
const progressDiv=document.getElementById('uploadProgress');
const progressFill=document.getElementById('progressFill');
const progressPercent=document.getElementById('progressPercent');
const progressSpeed=document.getElementById('progressSpeed');
const fileNameEl=document.getElementById('uploadFileName');
for(let i=0;i<files.length;i++){
const file=files[i];
fileNameEl.textContent='正在上传 ('+(i+1)+'/'+files.length+'): '+file.name;
progressDiv.classList.add('show');
await uploadSingleFile(file,progressFill,progressPercent,progressSpeed);
}
progressDiv.classList.remove('show');
showToast('全部上传完成','success');
loadList(currentPath);
}
function uploadSingleFile(file,progressFill,progressPercent,progressSpeed){
return new Promise((resolve)=>{
const xhr=new XMLHttpRequest();
const targetPath='/webdav'+currentPath+'/'+file.name;
const startTime=Date.now();
addLog('INFO','文件管理','上传文件','开始上传: '+file.name+' ('+(file.size/1024).toFixed(1)+' KB) 到 '+currentPath);
xhr.upload.onprogress=function(e){
if(e.lengthComputable){
const percent=Math.round((e.loaded/e.total)*100);
progressFill.style.width=percent+'%';
progressPercent.textContent=percent+'%';
const elapsed=(Date.now()-startTime)/1000;
const speed=elapsed>0?(e.loaded/elapsed/1024).toFixed(1):0;
progressSpeed.textContent=speed+' KB/s';
}
};
xhr.onload=function(){
if(xhr.status===200||xhr.status===201){
const elapsed=((Date.now()-startTime)/1000).toFixed(1);
addLog('INFO','文件管理','上传文件','成功: '+file.name+' 耗时'+elapsed+'秒');
showToast(file.name+' 上传成功','success');
}else{
addLog('ERROR','文件管理','上传文件','失败: '+file.name+' 状态码: '+xhr.status);
logError('文件管理','文件上传失败','文件: '+file.name+'\n路径: '+currentPath+'\n状态码: '+xhr.status);
updateErrorLogBadge();
showToast(file.name+' 上传失败 ('+xhr.status+')','error');
}
resolve();
};
xhr.onerror=function(){
addLog('ERROR','文件管理','上传文件','网络错误: '+file.name);
logError('文件管理','文件上传网络错误','文件: '+file.name+'\n路径: '+currentPath);
updateErrorLogBadge();
showToast(file.name+' 上传失败','error');
resolve();
};
xhr.open('PUT',targetPath,true);
xhr.send(file);
});
}
// 搜索功能
let searchTimer=null;
let inSearchMode=false;
function onSearchInput(value){
clearTimeout(searchTimer);
if(value.trim().length<2){
if(inSearchMode)clearSearch();
return;
}
searchTimer=setTimeout(()=>doSearch(),400);
}
async function doSearch(){
const query=document.getElementById('searchInput').value.trim();
if(query.length<2)return;
inSearchMode=true;
const res=await fetch('/api/search?q='+encodeURIComponent(query)+'&path='+encodeURIComponent(currentPath));
const data=await res.json();
const searchInfo=document.getElementById('searchResultsInfo');
if(searchInfo)searchInfo.classList.add('show');
const searchText=document.getElementById('searchResultsText');
if(searchText)searchText.textContent='搜索 "'+query+'" 找到 '+data.count+' 个结果';
renderFiles(data.files);
clearSelection();
}
function clearSearch(){
inSearchMode=false;
const searchInput=document.getElementById('searchInput');
if(searchInput)searchInput.value='';
const searchInfo=document.getElementById('searchResultsInfo');
if(searchInfo)searchInfo.classList.remove('show');
loadList(currentPath);
}
// 批量下载
async function batchDownload(){
if(selectedFiles.size===0){showToast('请先选择文件','error');return;}
showToast('正在打包下载...','info');
const res=await fetch('/api/download/batch',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({paths:Array.from(selectedFiles)})
});
if(res.ok){
const blob=await res.blob();
const url=URL.createObjectURL(blob);
const a=document.createElement('a');
a.href=url;a.download='nas-download.zip';a.click();
URL.revokeObjectURL(url);
showToast('下载完成','success');
}else{
showToast('下载失败','error');
}
}
function newFolder(){document.getElementById('folderModal').style.display='flex';document.getElementById('folderName').value='';}
// 文件管理器更多菜单
let showHiddenFiles=false;
function toggleFileMoreMenu(){
const menu=document.getElementById('fileMoreMenu');
menu.style.display=menu.style.display==='none'?'block':'none';
event.stopPropagation();
}
function hideFileMoreMenu(){
document.getElementById('fileMoreMenu').style.display='none';
}
// 侧边栏
function toggleSidebar(){
const sidebar=document.getElementById('fileSidebar');
const overlay=document.getElementById('sidebarOverlay');
if(sidebar.style.left==='0px'){
sidebar.style.left='-280px';
overlay.style.display='none';
}else{
sidebar.style.left='0px';
overlay.style.display='block';
loadSidebarStorage();
}
event.stopPropagation();
}
function navigateTo(path){
loadList(path);
}
// 搜索栏
function toggleSearch(){
const search=document.getElementById('nativeSearch');
search.style.display=search.style.display==='none'?'flex':'none';
if(search.style.display==='flex'){
document.getElementById('searchInput').focus();
}
}
// FAB菜单
function showFabMenu(){
const menu=document.getElementById('fabMenu');
menu.style.display=menu.style.display==='none'?'block':'none';
event.stopPropagation();
}
function hideFabMenu(){
document.getElementById('fabMenu').style.display='none';
}
// 多选更多菜单
function showSelectionMore(){
const menu=document.getElementById('selectionMoreMenu');
menu.style.display=menu.style.display==='none'?'block':'none';
event.stopPropagation();
}
function hideSelectionMore(){
document.getElementById('selectionMoreMenu').style.display='none';
}
// 全局点击关闭所有菜单
document.addEventListener('click',function(e){
const fabMenu=document.getElementById('fabMenu');
const fileMoreMenu=document.getElementById('fileMoreMenu');
const selectionMoreMenu=document.getElementById('selectionMoreMenu');
if(fabMenu&&fabMenu.style.display==='block'&&!e.target.closest('.fab-btn')&&!e.target.closest('.fab-menu')){
fabMenu.style.display='none';
}
if(fileMoreMenu&&fileMoreMenu.style.display==='block'&&!e.target.closest('.appbar-btn')){
fileMoreMenu.style.display='none';
}
if(selectionMoreMenu&&selectionMoreMenu.style.display==='block'&&!e.target.closest('.bottom-bar-btn')){
selectionMoreMenu.style.display='none';
}
});
// 切换视图模式
function toggleViewMode(){
setView(currentView==='list'?'grid':'list');
}
// 加载侧边栏存储信息
async function loadSidebarStorage(){
try{
const res=await fetch('/api/storage');
const data=await res.json();
if(data.success){
const usedGB=(data.used/1073741824).toFixed(2);
const totalGB=(data.total/1073741824).toFixed(2);
const pct=Math.round((data.used/data.total)*100);
document.getElementById('sidebarStorageBar').style.width=pct+'%';
document.getElementById('sidebarStorageText').textContent=usedGB+' GB / '+totalGB+' GB ('+pct+'%)';
}
}catch(e){}
}
// 点击其他地方关闭菜单
document.addEventListener('click',function(e){
const menu=document.getElementById('fileMoreMenu');
const moreBtn=e.target.closest('.more-btn');
if(menu&&menu.style.display==='block'&&!e.target.closest('#fileMoreMenu')&&!moreBtn){
menu.style.display='none';
}
});
function refreshFileList(){
document.getElementById('fileMoreMenu').style.display='none';
loadList(currentPath);
showToast('已刷新','success');
}
function newTextFile(){
document.getElementById('fileMoreMenu').style.display='none';
const name=prompt('新建文本文件名称：','新建文本.txt');
if(!name)return;
fetch('/api/create-file',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:currentPath+'/'+name,content:''})})
.then(r=>r.json()).then(d=>{
if(d.success){showToast('文件创建成功','success');loadList(currentPath);}
else{showToast(d.error||'创建失败','error');}
}).catch(e=>showToast('创建失败: '+e.message,'error'));
}
function toggleHiddenFiles(){
showHiddenFiles=!showHiddenFiles;
document.getElementById('fileMoreMenu').style.display='none';
loadList(currentPath);
showToast(showHiddenFiles?'已显示隐藏文件':'已隐藏隐藏文件','info');
}
function showStorageInfo(){
document.getElementById('fileMoreMenu').style.display='none';
fetch('/api/storage').then(r=>r.json()).then(d=>{
if(d.success){
const used=formatSize(d.used||0);
const total=formatSize(d.total||0);
const free=formatSize(d.free||0);
alert('存储信息\n\n总容量: '+total+'\n已使用: '+used+'\n可用空间: '+free);
}else{
alert('获取存储信息失败');
}
}).catch(e=>alert('获取存储信息失败: '+e.message));
}
async function createFolder(){
const name=document.getElementById('folderName').value.trim();
if(!name)return;
addLog('INFO','文件管理','新建文件夹','开始创建: '+currentPath+'/'+name);
const res=await fetch('/api/mkdir',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:currentPath,name})});
if(res.ok){
addLog('INFO','文件管理','新建文件夹','成功: '+currentPath+'/'+name);
showToast('文件夹创建成功','success');
document.getElementById('folderModal').style.display='none';
loadList(currentPath);
}else{
const err=await res.text();
addLog('ERROR','文件管理','新建文件夹','失败: '+currentPath+'/'+name,{error:err});
logError('文件管理','新建文件夹失败','路径: '+currentPath+'/'+name+'\n错误: '+err);
updateErrorLogBadge();
showToast('创建失败','error');
}
}

// 全选文件
function selectAllFiles(){
const checkboxes=document.querySelectorAll('.file-item input[type=checkbox]');
let allChecked=true;
checkboxes.forEach(cb=>{if(!cb.checked)allChecked=false;});
checkboxes.forEach(cb=>{cb.checked=!allChecked;});
}

// 下载选中文件
function downloadSelected(){
const selected=document.querySelectorAll('.file-item input[type=checkbox]:checked');
if(selected.length===0){
showToast('请先选择文件','warning');
return;
}
showToast('开始下载 '+selected.length+' 个文件','info');
// 逐个下载
selected.forEach((cb,i)=>{
const item=cb.closest('.file-item');
const name=item.querySelector('.file-name').textContent;
setTimeout(()=>{
window.open('/api/download?path='+encodeURIComponent(currentPath+'/'+name),'_blank');
},i*500);
});
}

if(!readOnly){
const area=document.getElementById('uploadArea');
if(area){
area.addEventListener('click',()=>document.getElementById('fileInput').click());
area.addEventListener('dragover',e=>{e.preventDefault();area.classList.add('dragover');});
area.addEventListener('dragleave',()=>area.classList.remove('dragover'));
area.addEventListener('drop',e=>{e.preventDefault();area.classList.remove('dragover');uploadFiles(e.dataTransfer.files);});
}
}

// ===== 影音播放 =====
async function scanMedia(){
showToast('开始扫描媒体文件...','info');
await fetch('/api/media/scan',{method:'POST'});
// 多次刷新确保扫描结果显示
setTimeout(()=>{loadMedia();loadMusicList();},1000);
setTimeout(()=>{loadMedia();loadMusicList();},3000);
setTimeout(()=>{loadMedia();loadMusicList();},5000);
setTimeout(()=>{loadMedia();loadMusicList();},8000);
}
async function loadMedia(){
const res=await fetch('/api/media/list?type=');
const data=await res.json();
const allFiles=data.files||[];
// 更新分类统计（添加null检查，避免元素不存在导致错误）
const cats={all:allFiles,video:[],audio:[],image:[]};
allFiles.forEach(f=>{
// 兼容music和audio两种type
if(f.type==='music'||f.type==='audio'){
cats.audio.push(f);
}else if(cats[f.type]){
cats[f.type].push(f);
}
});
const setMediaText=function(id,text){const el=document.getElementById(id);if(el)el.textContent=text;};
setMediaText('mediaAllCount',cats.all.length);
setMediaText('mediaAllSize',formatSize(cats.all.reduce((s,f)=>s+f.size,0)));
setMediaText('mediaVideoCount',cats.video.length);
setMediaText('mediaVideoSize',formatSize(cats.video.reduce((s,f)=>s+f.size,0)));
setMediaText('mediaAudioCount',cats.audio.length);
setMediaText('mediaAudioSize',formatSize(cats.audio.reduce((s,f)=>s+f.size,0)));
setMediaText('mediaImageCount',cats.image.length);
setMediaText('mediaImageSize',formatSize(cats.image.reduce((s,f)=>s+f.size,0)));
// 如果在分类浏览界面，加载对应分类的文件
if(document.getElementById('mediaCategoryView').style.display!=='none'){
let files=[];
if(currentMediaCat==='all'){
files=allFiles;
}else if(currentMediaCat==='audio'){
// 后端返回的音乐type是music，兼容处理
files=allFiles.filter(f=>f.type==='music'||f.type==='audio');
}else{
files=allFiles.filter(f=>f.type===currentMediaCat);
}
renderMediaGrid(files);
}
}

function renderMediaGrid(files){
const grid=document.getElementById('mediaGrid');
if(files.length===0){grid.innerHTML='<div class="empty" style="grid-column:1/-1">暂无媒体文件，点击"扫描"开始</div>';return;}
grid.innerHTML=files.map(f=>{
const safeName=f.name.replace(/</g,'&lt;').replace(/>/g,'&gt;');
const safePath=f.path.replace(/'/g,"\\'");
const token=localStorage.getItem('token')||'';
const thumbUrl=f.type==='image'?'/webdav'+f.path+'?token='+token:'/api/thumb?path='+encodeURIComponent(f.path);
let content='';
if(f.type==='image'){
content='<img src="'+thumbUrl+'" style="width:100%;height:100%;object-fit:cover;position:absolute;top:0;left:0" onerror="this.style.display=\'none\';this.parentNode.querySelector(\'.media-fallback\').style.display=\'flex\'">';
}else if(f.type==='video'){
content='<img src="'+thumbUrl+'" style="width:100%;height:100%;object-fit:cover;position:absolute;top:0;left:0" onerror="this.style.display=\'none\';this.parentNode.querySelector(\'.media-fallback\').style.display=\'flex\'">'+
'<div class="media-play-badge">▶</div>';
}else{
content='<div class="media-fallback" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:32px;background:linear-gradient(135deg,#84fab0,#8fd3f4)">🎵</div>';
}
const fallbackIcon=f.type==='image'?'🖼️':f.type==='video'?'🎬':'🎵';
return '<div class="media-card" onclick="playMedia(\''+safePath+'\',\''+f.type+'\',\''+safeName.replace(/'/g,"\\'")+'\')">'+
content+
'<div class="media-fallback" style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:32px;background:#f5f5f5;position:absolute;top:0;left:0">'+fallbackIcon+'</div>'+
'<button class="media-menu-btn" onclick="event.stopPropagation();showMediaMenu(\''+safePath+'\',\''+f.type+'\',\''+safeName.replace(/'/g,"\\'")+'\',\''+f.size+'\')">⋯</button>'+
'<div class="media-info">'+
'<div class="media-name" title="'+safeName+'">'+safeName+'</div>'+
'</div></div>';
}).join('');
}

let currentMediaCat='all';
let lastTouchY=0,lastTouchX=0;

function openMediaPanel(cat){
openPanel('video');
setTimeout(function(){
openMediaCategory(cat);
},100);
}

// 媒体库标签切换
function switchMediaTab(tab){
// 更新标签高亮
document.querySelectorAll('[id^="tab-"]').forEach(function(el){
el.style.borderBottomColor='transparent';
el.style.color='#666';
});
const activeTab=document.getElementById('tab-'+tab);
if(activeTab){
activeTab.style.borderBottomColor='#667eea';
activeTab.style.color='#667eea';
activeTab.style.fontWeight='600';
}
// 切换分类
if(tab==='video'){
openMediaCategory('video');
}else if(tab==='audio'){
openMediaCategory('audio');
}else if(tab==='image'){
openMediaCategory('image');
}
}

function openMediaCategory(cat){
currentMediaCat=cat;
const titles={all:'全部',video:'视频',audio:'音乐',image:'图片'};
document.getElementById('mediaCategoryTitle').textContent=titles[cat];
document.getElementById('mediaHome').style.display='none';
document.getElementById('mediaCategoryView').style.display='block';
loadMedia();
}

function backToMediaHome(){
document.getElementById('mediaHome').style.display='block';
document.getElementById('mediaCategoryView').style.display='none';
}

// 媒体文件操作菜单
let currentMediaFile={path:'',type:'',name:'',size:0};
function showMediaMenu(path,type,name,size){
currentMediaFile={path:path,type:type,name:decodeURIComponent(name),size:parseInt(size)||0};
const isVideo=type==='video';
const isAudio=type==='audio';
const isImage=type==='image';
const menuHtml='<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2000;display:flex;align-items:flex-end" onclick="this.remove()">'+
'<div style="background:#fff;width:100%;border-radius:16px 16px 0 0;padding:20px;max-height:70vh;overflow-y:auto" onclick="event.stopPropagation()">'+
'<div style="text-align:center;font-size:16px;font-weight:600;margin-bottom:16px;color:#333">'+currentMediaFile.name+'</div>'+
'<div style="display:grid;gap:8px">'+
'<button class="btn btn-block" onclick="playMedia(\''+path+'\',\''+type+'\',\''+name+'\');this.closest(\'div[style*=fixed]\').remove()" style="justify-content:flex-start">▶️ 播放/打开</button>'+
'<button class="btn btn-block" onclick="showMediaDetail();this.closest(\'div[style*=fixed]\').remove()" style="justify-content:flex-start">ℹ️ 文件详情</button>'+
'<button class="btn btn-block" onclick="shareMediaFile();this.closest(\'div[style*=fixed]\').remove()" style="justify-content:flex-start">🔗 分享链接</button>'+
'<button class="btn btn-block" onclick="openMediaWithOther();this.closest(\'div[style*=fixed]\').remove()" style="justify-content:flex-start">📤 其他应用打开</button>'+
'<button class="btn btn-danger btn-block" onclick="deleteMediaFile();this.closest(\'div[style*=fixed]\').remove()" style="justify-content:flex-start">🗑️ 删除文件</button>'+
'<button class="btn btn-block" onclick="this.closest(\'div[style*=fixed]\').remove()" style="justify-content:center;margin-top:8px">取消</button>'+
'</div></div></div>';
document.body.insertAdjacentHTML('beforeend',menuHtml);
}
function showMediaDetail(){
const f=currentMediaFile;
const detailHtml='<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:99998;display:flex;align-items:center;justify-content:center" onclick="this.remove()">'+
'<div style="background:#fff;width:88%;max-width:380px;border-radius:14px;padding:16px" onclick="event.stopPropagation()">'+
'<h4 style="margin:0 0 12px;text-align:center;font-size:16px">文件详情</h4>'+
'<div style="display:grid;gap:8px;font-size:13px">'+
'<div><div style="color:#999;font-size:11px;margin-bottom:2px">文件名</div><div style="color:#333;font-weight:500;word-break:break-all;line-height:1.4">'+f.name+'</div></div>'+
'<div style="display:flex;justify-content:space-between"><span style="color:#999">类型</span><span style="color:#333">'+(f.type==='video'?'视频':f.type==='audio'?'音乐':'图片')+'</span></div>'+
'<div style="display:flex;justify-content:space-between"><span style="color:#999">大小</span><span style="color:#333">'+formatSize(f.size)+'</span></div>'+
'<div><div style="color:#999;font-size:11px;margin-bottom:2px">路径</div><div style="color:#666;font-size:11px;word-break:break-all;line-height:1.4">'+f.path+'</div></div>'+
'</div>'+
'<button class="btn btn-primary" style="width:100%;margin-top:14px;padding:10px;font-size:14px" onclick="this.closest(\'div[style*=fixed]\').remove()">关闭</button>'+
'</div></div>';
document.body.insertAdjacentHTML('beforeend',detailHtml);
}
function shareMediaFile(){
const url=window.location.origin+'/webdav'+currentMediaFile.path;
const shareHtml='<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:2001;display:flex;align-items:center;justify-content:center" onclick="this.remove()">'+
'<div style="background:#fff;width:85%;max-width:360px;border-radius:16px;padding:20px" onclick="event.stopPropagation()">'+
'<h4 style="margin:0 0 16px;text-align:center">分享链接</h4>'+
'<div style="background:#f5f5f5;padding:12px;border-radius:8px;font-size:12px;word-break:break-all;color:#333;margin-bottom:16px">'+url+'</div>'+
'<div style="display:grid;gap:8px">'+
'<button class="btn btn-primary" onclick="navigator.clipboard.writeText(\''+url+'\').then(()=>showToast(\'已复制链接\',\'success\'));this.closest(\'div[style*=fixed]\').remove()">复制链接</button>'+
'<button class="btn" onclick="this.closest(\'div[style*=fixed]\').remove()">关闭</button>'+
'</div></div></div>';
document.body.insertAdjacentHTML('beforeend',shareHtml);
}
function openMediaWithOther(){
const url=window.location.origin+'/webdav'+currentMediaFile.path;
window.open(url,'_blank');
showToast('已在新窗口打开','info');
}
async function deleteMediaFile(){
if(!confirm('确定删除文件 "'+currentMediaFile.name+'" 吗？'))return;
try{
const res=await fetch('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:currentMediaFile.path})});
if(res.ok){
showToast('删除成功','success');
loadMedia();
}else{
showToast('删除失败','error');
}
}catch(e){
showToast('删除失败: '+e.message,'error');
}
}
// 格式化时长
function formatDuration(seconds){
if(!seconds||isNaN(seconds))return '';
const h=Math.floor(seconds/3600);
const m=Math.floor((seconds%3600)/60);
const s=Math.floor(seconds%60);
if(h>0)return h+':'+(m<10?'0':'')+m+':'+(s<10?'0':'')+s;
return m+':'+(s<10?'0':'')+s;
}
function switchMediaTab(btn){
const type=btn.dataset.type||'all';
openMediaCategory(type);
}
// ===== ArtPlayer 视频播放器 + APlayer 音乐播放器 =====
let aPlayer=null;

function playMedia(path,type,name){
// 关闭图片查看器，避免遮挡
const imgModal=document.getElementById('imageModal');
if(imgModal)imgModal.classList.remove('active');

if(type==='image'){
// 图片查看器（PhotoSwipe）
openImage(path);
return;
}

if(type==='video'||isVideoFile(path)){
// 视频播放器（ArtPlayer）
const fileName=name||path.split('/').pop();
const token=localStorage.getItem('token')||'';
const url='/webdav/'+path.split('/').filter(Boolean).map(encodeURIComponent).join('/')+(token?'?token='+encodeURIComponent(token):'');
openVideoPlayer(fileName,url);
return;
}

const isAudio=isAudioFile(name||path)||type==='music'||type==='audio';

// 音乐播放器（APlayer）
if(isAudio){
// 先确保音乐列表已加载
if(musicList.length===0){
loadMusicList().then(()=>{
const index=musicList.findIndex(f=>f&&f.path===path);
if(index>=0)playMusic(index);
else showToast('音乐文件不在播放列表中','error');
});
}else{
const index=musicList.findIndex(f=>f&&f.path===path);
if(index>=0)playMusic(index);
else{
loadMusicList().then(()=>{
const idx=musicList.findIndex(f=>f&&f.path===path);
if(idx>=0)playMusic(idx);
else showToast('音乐文件不在播放列表中','error');
});
}
}
return;
}
}

function playWithAPlayer(path,name){
const modal=document.getElementById('playerModal');
modal.classList.add('active');

// 完全停止视频播放器
if(artPlayer){try{artPlayer.destroy();}catch(e){}artPlayer=null;}

// 隐藏视频容器，显示音乐容器
document.getElementById('artplayerContainer').style.display='none';
let apContainer=document.getElementById('aplayerContainer');
if(!apContainer){
apContainer=document.createElement('div');
apContainer.id='aplayerContainer';
apContainer.style.cssText='width:100%;max-width:420px;margin:0 auto;padding:0 16px;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);';
document.getElementById('artplayerContainer').parentNode.appendChild(apContainer);
}
apContainer.style.display='block';

// 销毁旧实例
if(aPlayer){aPlayer.destroy();aPlayer=null;}

setTimeout(()=>{
aPlayer=new APlayer({
container:apContainer,
audio:[{
name:name||'音乐播放',
artist:'NAS私有云',
url:(function(){
const token=localStorage.getItem('token')||'';
return '/webdav'+path+(token?'?token='+encodeURIComponent(token):'');
})(),
cover:''
}],
theme:'#667eea',
loop:'all',
order:'list',
preload:'auto',
volume:0.7,
autoplay:true,
mutex:true,
lrcType:0,
listFolded:true,
listMaxHeight:'150px',
storageName:'nas-aplayer'
});

// 锁屏通知（Media Session API）
if('mediaSession' in navigator){
  navigator.mediaSession.metadata=new MediaMetadata({
    title:name||'音乐播放',
    artist:'NAS私有云',
    album:'NAS本地音乐'
  });
  navigator.mediaSession.setActionHandler('play',function(){aPlayer&&aPlayer.play();});
  navigator.mediaSession.setActionHandler('pause',function(){aPlayer&&aPlayer.pause();});
  navigator.mediaSession.setActionHandler('previoustrack',function(){aPlayer&&aPlayer.skipBack();});
  navigator.mediaSession.setActionHandler('nexttrack',function(){aPlayer&&aPlayer.skipForward();});
}
},100);
}

function playWithArtPlayer(path,name){
const modal=document.getElementById('playerModal');
modal.classList.add('active');

// 完全停止音乐播放器
if(aPlayer){try{aPlayer.destroy();}catch(e){}aPlayer=null;}
if(window.kuwoPlayer){try{window.kuwoPlayer.destroy();}catch(e){}window.kuwoPlayer=null;}
const kuwoModal=document.getElementById('kuwoPlayerModal');
if(kuwoModal)kuwoModal.classList.remove('active');

// 显示视频容器，隐藏音乐容器
document.getElementById('artplayerContainer').style.display='block';
const apContainer=document.getElementById('aplayerContainer');
if(apContainer)apContainer.style.display='none';

// 销毁旧实例
if(artPlayer){artPlayer.destroy();artPlayer=null;}

// 根据扩展名判断视频类型
const ext=name?name.toLowerCase().substring(name.lastIndexOf('.')+1):'';
let videoType='auto';
if(['m3u8','m3u'].includes(ext))videoType='m3u8';
else if(['flv'].includes(ext))videoType='flv';

// 编码URL路径，处理特殊字符，携带token认证
const token=localStorage.getItem('token')||'';
const encodedPath=path.split('/').map(encodeURIComponent).join('/');
const videoUrl='/webdav'+encodedPath+(token?'?token='+encodeURIComponent(token):'');
const transcodeUrl='/api/media/transcode?path='+encodeURIComponent(path)+(token?'&token='+encodeURIComponent(token):'');

// 不常见格式直接转码，常见格式先尝试直接播放
const directPlayExts=['mp4','webm','ogg','mov','m4v'];
const shouldTryDirect=directPlayExts.includes(ext);

// 格式不支持时友好提示
const unsupportedExts=['mkv','avi','wmv','rmvb','rm','flv','ts','m2ts','vob','dat'];
if(unsupportedExts.includes(ext)&&!shouldTryDirect){
  showToast('当前格式('+ext.toUpperCase()+')浏览器可能不支持，建议使用转码播放','warning',3000);
}

let transcodeAttempted=false;

function createPlayer(url,type,isTranscode){
// 确保容器可见并有正确尺寸（自适应16:9）
const container=document.getElementById('artplayerContainer');
container.style.display='block';
container.style.width='100%';
container.style.height='auto';
// 强制重排
void container.offsetWidth;
setTimeout(()=>{
// HLS支持配置
let customType={};
if(type==='m3u8'&&window.Hls&&Hls.isSupported()){
customType={
m3u8:{
customType:'m3u8',
customLoader:function(video,url){
const hls=new Hls();
hls.loadSource(url);
hls.attachMedia(video);
hls.on(Hls.Events.MANIFEST_PARSED,function(){video.play();});
hls.on(Hls.Events.ERROR,function(event,data){
if(data.fatal){
showToast('HLS视频加载失败','error',3000);
hls.destroy();
}
});
return function(){hls.destroy();};
}
}
};
}

artPlayer=new Artplayer({
container:'#artplayerContainer',
url:url,
title:name||'媒体播放',
type:type,
customType:customType,
theme:'#667eea',
volume:0.7,
autoplay:true,
pip:true,
autoSize:false,
autoMini:false,
hotkey:true,
playsInline:true,
mutex:true,
setting:true,
flip:true,
playbackRate:true,
aspectRatio:false,
screenshot:true,
fullscreen:true,
fullscreenWeb:true,
subtitleOffset:true,
miniProgressBar:true,
localVideo:true,
localVideoAuto:{
title:name||'媒体播放'
},
airplay:true,
chromecast:false,
settings:[
{
html:'默认（原始比例）',
name:'default',
switch:true,
onSelect:function(){setVideoDisplayRatio('default');}
},
{
html:'1:1 正方形',
name:'1:1',
switch:false,
onSelect:function(){setVideoDisplayRatio('1:1');}
},
{
html:'4:3',
name:'4:3',
switch:false,
onSelect:function(){setVideoDisplayRatio('4:3');}
},
{
html:'3:4',
name:'3:4',
switch:false,
onSelect:function(){setVideoDisplayRatio('3:4');}
},
{
html:'9:16 竖屏',
name:'9:16',
switch:false,
onSelect:function(){setVideoDisplayRatio('9:16');}
},
{
html:'16:9 宽屏',
name:'16:9',
switch:false,
onSelect:function(){setVideoDisplayRatio('16:9');}
},
{
html:'全屏填充',
name:'fill',
switch:false,
onSelect:function(){setVideoDisplayRatio('fill');}
}
],
contextmenu:[
{
html:'关闭播放器',
click:function(){closePlayer();}
},
{
html:'截图',
click:function(){artPlayer.screenshot();}
},
{
html:'画中画',
click:function(){artPlayer.pip=true;}
}
],
moreVideoAttr:{
crossorigin:'anonymous',
playsinline:true,
'webkit-playsinline':true,
'x5-playsinline':true
},
customType:{
m3u8:function(video,url){
if(Hls && Hls.isSupported()){
const hls=new Hls({enableWorker:true,lowLatencyMode:true,maxBufferLength:10});
hls.loadSource(url);
hls.attachMedia(video);
}else if(video.canPlayType('application/vnd.apple.mpegurl')){
video.src=url;
}
}
},
controls:[
{
name:'closeBtn',
index:10,
position:'left',
html:'<svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',
tooltip:'关闭',
click:function(){closePlayer();}
}
],
whitelist:['*']
});

// 确保视频自动播放
setTimeout(()=>{
if(artPlayer && artPlayer.video){
artPlayer.video.play().catch(()=>{
showToast('点击播放按钮开始播放','info');
});
}
},500);

// 播放失败自动转码
artPlayer.on('error',function(){
logError('视频播放','视频播放失败','URL: '+url+'\n类型: '+type+'\n转码: '+(isTranscode?'是':'否'));
updateErrorLogBadge();
if(!isTranscode && !transcodeAttempted){
transcodeAttempted=true;
showToast('当前格式不支持，正在转码播放...','info');
artPlayer.destroy();
artPlayer=null;
createPlayer(transcodeUrl,'m3u8',true);
}else if(isTranscode){
showToast('视频播放失败，文件可能损坏或格式不支持','error');
}
});
// 视频加载中显示提示
artPlayer.on('videoCanPlay',function(){
const v=artPlayer.video;
// 默认原始比例显示
setVideoDisplayRatio('default');
const isPortrait=v.videoHeight>v.videoWidth;
if(isPortrait){
showToast('竖屏视频，点击⚙️可切换显示比例','info');
}
});

// 设置视频画面显示比例（不改变播放器窗口大小）
function setVideoDisplayRatio(ratio){
if(!artPlayer || !artPlayer.video)return;
const video=artPlayer.video;
video.style.aspectRatio='';
video.style.maxWidth='';
video.style.maxHeight='';
video.style.width='100%';
video.style.height='100%';
video.style.objectFit='contain';
switch(ratio){
case '1:1':
video.style.aspectRatio='1/1';
video.style.maxWidth='100vw';
video.style.maxHeight='100vw';
break;
case '4:3':
video.style.aspectRatio='4/3';
video.style.maxWidth='100vw';
video.style.maxHeight='75vw';
break;
case '3:4':
video.style.aspectRatio='3/4';
video.style.maxWidth='75vh';
video.style.maxHeight='100vh';
break;
case '9:16':
video.style.aspectRatio='9/16';
video.style.maxWidth='56.25vh';
video.style.maxHeight='100vh';
break;
case '16:9':
video.style.aspectRatio='16/9';
video.style.maxWidth='100vw';
video.style.maxHeight='56.25vw';
break;
case 'fill':
video.style.objectFit='fill';
break;
default:
// 默认原始比例，contain居中
break;
}
showToast('显示比例: '+(ratio==='default'?'原始比例':ratio),'success');
}
},300);
}

// 视频设置面板（主流播放器功能，优化布局）
function showVideoSettings(){
if(!artPlayer)return;
const settingsHtml='<div id="videoSettingsPanel" style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.6);z-index:100000;display:flex;align-items:flex-end;backdrop-filter:blur(5px)" onclick="if(event.target===this)this.remove()">'+
'<div style="background:rgba(26,26,46,.98);width:100%;border-radius:24px 24px 0 0;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 -8px 40px rgba(0,0,0,.5);backdrop-filter:blur(30px)" onclick="event.stopPropagation()">'+
// 标题栏 - MIUI风格
'<div style="display:flex;justify-content:space-between;align-items:center;padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.08)">'+
'<div style="display:flex;align-items:center;gap:10px"><span style="width:4px;height:20px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:2px"></span><span style="color:#fff;font-size:17px;font-weight:600">播放器设置</span></div>'+
'<button onclick="document.getElementById(\'videoSettingsPanel\').remove()" style="background:rgba(255,255,255,.1);border:none;color:#999;font-size:16px;cursor:pointer;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:all .2s">✕</button>'+
'</div>'+
// 标签页
'<div style="display:flex;border-bottom:1px solid #2d2d44;padding:0 8px;background:#15152a">'+
'<button class="vset-tab active" onclick="switchVSetTab(\'display\',this)" style="flex:1;padding:14px 6px;background:none;border:none;color:#667eea;font-size:13px;cursor:pointer;border-bottom:2px solid #667eea;font-weight:500">🎬 画面</button>'+
'<button class="vset-tab" onclick="switchVSetTab(\'audio\',this)" style="flex:1;padding:14px 6px;background:none;border:none;color:#888;font-size:13px;cursor:pointer;border-bottom:2px solid transparent">🔊 音频</button>'+
'<button class="vset-tab" onclick="switchVSetTab(\'play\',this)" style="flex:1;padding:14px 6px;background:none;border:none;color:#888;font-size:13px;cursor:pointer;border-bottom:2px solid transparent">▶️ 播放</button>'+
'<button class="vset-tab" onclick="switchVSetTab(\'control\',this)" style="flex:1;padding:14px 6px;background:none;border:none;color:#888;font-size:13px;cursor:pointer;border-bottom:2px solid transparent">👆 控制</button>'+
'<button class="vset-tab" onclick="switchVSetTab(\'other\',this)" style="flex:1;padding:14px 6px;background:none;border:none;color:#888;font-size:13px;cursor:pointer;border-bottom:2px solid transparent">⚙️ 其他</button>'+
'</div>'+
// 内容区
'<div style="flex:1;overflow-y:auto;padding:16px 20px 24px">'+
// 画面设置
'<div class="vset-content" id="vset-display">'+
'<div class="vset-group">'+
'<div class="vset-group-title">画面比例</div>'+
'<div class="vset-btn-grid-4">'+
'<button onclick="setVideoAspect(\'default\')" class="vset-btn">原始</button>'+
'<button onclick="setVideoAspect(\'16:9\')" class="vset-btn">16:9</button>'+
'<button onclick="setVideoAspect(\'4:3\')" class="vset-btn">4:3</button>'+
'<button onclick="setVideoAspect(\'fill\')" class="vset-btn">全屏</button>'+
'</div></div>'+
'<div class="vset-group">'+
'<div class="vset-group-title">画面旋转</div>'+
'<div class="vset-btn-grid-4">'+
'<button onclick="rotateVideo(0)" class="vset-btn">0°</button>'+
'<button onclick="rotateVideo(90)" class="vset-btn">90°</button>'+
'<button onclick="rotateVideo(180)" class="vset-btn">180°</button>'+
'<button onclick="rotateVideo(270)" class="vset-btn">270°</button>'+
'</div></div>'+
'<div class="vset-group">'+
'<div class="vset-group-title">画面翻转</div>'+
'<div class="vset-btn-grid-3">'+
'<button onclick="flipVideo(\'none\')" class="vset-btn">正常</button>'+
'<button onclick="flipVideo(\'horizontal\')" class="vset-btn">水平</button>'+
'<button onclick="flipVideo(\'vertical\')" class="vset-btn">垂直</button>'+
'</div></div>'+
'<div class="vset-group">'+
'<div class="vset-group-title">画面缩放</div>'+
'<div class="vset-btn-grid-4">'+
'<button onclick="zoomVideo(1)" class="vset-btn">100%</button>'+
'<button onclick="zoomVideo(1.25)" class="vset-btn">125%</button>'+
'<button onclick="zoomVideo(1.5)" class="vset-btn">150%</button>'+
'<button onclick="zoomVideo(2)" class="vset-btn">200%</button>'+
'</div></div>'+
'<div class="vset-group">'+
'<div class="vset-group-title">屏幕亮度 <span id="brightnessVal" style="color:#667eea;float:right">100%</span></div>'+
'<input type="range" min="20" max="100" value="100" oninput="setBrightness(this.value);document.getElementById(\'brightnessVal\').textContent=this.value+\'%\'" class="vset-slider">'+
'</div></div>'+
// 音频设置
'<div class="vset-content" id="vset-audio" style="display:none">'+
'<div class="vset-group">'+
'<div class="vset-group-title">音量 <span id="volumeVal" style="color:#667eea;float:right">70%</span></div>'+
'<input type="range" min="0" max="100" value="70" oninput="setVideoVolume(this.value);document.getElementById(\'volumeVal\').textContent=this.value+\'%\'" class="vset-slider">'+
'</div>'+
'<div class="vset-group">'+
'<div class="vset-group-title">音频延迟（音画同步）</div>'+
'<div class="vset-btn-grid-5">'+
'<button onclick="setAudioDelay(-0.5)" class="vset-btn">-0.5s</button>'+
'<button onclick="setAudioDelay(-0.1)" class="vset-btn">-0.1s</button>'+
'<button onclick="setAudioDelay(0)" class="vset-btn">0</button>'+
'<button onclick="setAudioDelay(0.1)" class="vset-btn">+0.1s</button>'+
'<button onclick="setAudioDelay(0.5)" class="vset-btn">+0.5s</button>'+
'</div></div>'+
'<div class="vset-group">'+
'<div class="vset-group-title">音轨</div>'+
'<button onclick="showToast(\'当前视频仅1条音轨\',\'info\')" class="vset-btn" style="width:100%;text-align:left;padding:12px 16px">🎵 音轨 1（默认）</button>'+
'</div></div>'+
// 播放设置
'<div class="vset-content" id="vset-play" style="display:none">'+
'<div class="vset-group">'+
'<div class="vset-group-title">播放速度</div>'+
'<div class="vset-btn-grid-5">'+
'<button onclick="setPlaybackRate(0.5)" class="vset-btn">0.5x</button>'+
'<button onclick="setPlaybackRate(1)" class="vset-btn active">1.0x</button>'+
'<button onclick="setPlaybackRate(1.5)" class="vset-btn">1.5x</button>'+
'<button onclick="setPlaybackRate(2)" class="vset-btn">2.0x</button>'+
'<button onclick="setPlaybackRate(3)" class="vset-btn">3.0x</button>'+
'</div></div>'+
'<div class="vset-group">'+
'<div class="vset-group-title">快进/快退时长</div>'+
'<div class="vset-btn-grid-4">'+
'<button onclick="setSeekTime(5)" class="vset-btn">5秒</button>'+
'<button onclick="setSeekTime(10)" class="vset-btn active">10秒</button>'+
'<button onclick="setSeekTime(15)" class="vset-btn">15秒</button>'+
'<button onclick="setSeekTime(30)" class="vset-btn">30秒</button>'+
'</div></div>'+
'<div class="vset-group">'+
'<div class="vset-group-title">播放模式</div>'+
'<div class="vset-btn-grid-3">'+
'<button onclick="setPlayMode(\'order\')" class="vset-btn active">顺序</button>'+
'<button onclick="setPlayMode(\'loop\')" class="vset-btn">单曲</button>'+
'<button onclick="setPlayMode(\'random\')" class="vset-btn">随机</button>'+
'</div></div></div>'+
// 控制设置
'<div class="vset-content" id="vset-control" style="display:none">'+
'<div class="vset-switch-row"><div><div style="color:#fff;font-size:14px">手势控制</div><div style="color:#888;font-size:11px;margin-top:2px">滑动快进、调亮度音量</div></div><label class="switch"><input type="checkbox" checked onchange="toggleGesture(this.checked)"><span class="slider"></span></label></div>'+
'<div class="vset-switch-row"><div><div style="color:#fff;font-size:14px">双击播放/暂停</div><div style="color:#888;font-size:11px;margin-top:2px">双击屏幕切换播放状态</div></div><label class="switch"><input type="checkbox" checked onchange="toggleDoubleClick(this.checked)"><span class="slider"></span></label></div>'+
'<div class="vset-switch-row"><div><div style="color:#fff;font-size:14px">左侧滑动调亮度</div><div style="color:#888;font-size:11px;margin-top:2px">屏幕左侧上下滑动</div></div><label class="switch"><input type="checkbox" checked onchange="toggleBrightnessGesture(this.checked)"><span class="slider"></span></label></div>'+
'<div class="vset-switch-row"><div><div style="color:#fff;font-size:14px">右侧滑动调音量</div><div style="color:#888;font-size:11px;margin-top:2px">屏幕右侧上下滑动</div></div><label class="switch"><input type="checkbox" checked onchange="toggleVolumeGesture(this.checked)"><span class="slider"></span></label></div>'+
'</div>'+
// 其他设置
'<div class="vset-content" id="vset-other" style="display:none">'+
'<button onclick="clearVideoCache()" class="vset-action-btn">🗑️ <span>清除缩略图缓存</span><span style="color:#666">释放存储空间</span></button>'+
'<button onclick="clearPlayHistory()" class="vset-action-btn">📋 <span>清除播放历史</span><span style="color:#666">清除观看记录</span></button>'+
'<button onclick="resetVideoSettings()" class="vset-action-btn" style="background:#2d1a1a">🔄 <span style="color:#ff6b6b">重置所有设置</span><span style="color:#666">恢复默认配置</span></button>'+
'<div style="text-align:center;margin-top:20px;color:#555;font-size:11px">NAS私有云播放器 v2.0</div>'+
'</div>'+
'</div></div></div>';
document.body.insertAdjacentHTML('beforeend',settingsHtml);
}

// 视频设置标签页切换
function switchVSetTab(tab,btn){
document.querySelectorAll('.vset-tab').forEach(t=>{t.style.color='#888';t.style.borderBottom='2px solid transparent';t.style.fontWeight='normal';});
btn.style.color='#667eea';
btn.style.borderBottom='2px solid #667eea';
btn.style.fontWeight='500';
document.querySelectorAll('.vset-content').forEach(c=>c.style.display='none');
document.getElementById('vset-'+tab).style.display='block';
}

let videoRotation=0;
let videoFlip='none';
let videoZoom=1;
let seekTime=10;
let playMode='order';
let gestureEnabled=true;
let doubleClickEnabled=true;
let brightnessGestureEnabled=true;
let volumeGestureEnabled=true;

function setVideoAspect(ratio){
if(!artPlayer)return;
if(ratio==='fill'){
artPlayer.video.style.objectFit='fill';
}else{
artPlayer.video.style.objectFit='contain';
if(ratio!=='default'){
artPlayer.aspectRatio=ratio;
}
}
showToast('画面比例: '+(ratio==='fill'?'全屏填充':ratio==='default'?'原始比例':ratio),'success');
}
function rotateVideo(deg){
if(!artPlayer)return;
videoRotation=deg;
updateVideoTransform();
showToast('旋转: '+deg+'°','success');
}
function flipVideo(type){
if(!artPlayer)return;
videoFlip=type;
updateVideoTransform();
showToast('翻转: '+(type==='none'?'正常':type==='horizontal'?'水平':'垂直'),'success');
}
function zoomVideo(scale){
if(!artPlayer)return;
videoZoom=scale;
updateVideoTransform();
showToast('缩放: '+scale*100+'%','success');
}
function updateVideoTransform(){
if(!artPlayer)return;
let transform='rotate('+videoRotation+'deg) scale('+videoZoom+')';
if(videoFlip==='horizontal')transform+=' scaleX(-1)';
if(videoFlip==='vertical')transform+=' scaleY(-1)';
artPlayer.video.style.transform=transform;
}
function setBrightness(val){
if(!artPlayer)return;
artPlayer.video.style.filter='brightness('+(val/100)+')';
}
function setVideoVolume(val){
if(!artPlayer)return;
artPlayer.volume=val/100;
}
function setAudioDelay(sec){
if(!artPlayer)return;
artPlayer.audioDelay=sec;
showToast('音频延迟: '+sec+'秒','success');
}
function setPlaybackRate(rate){
if(!artPlayer)return;
artPlayer.playbackRate=rate;
showToast('速度: '+rate+'x','success');
}
function setSeekTime(sec){
seekTime=sec;
showToast('快进/快退: '+sec+'秒','success');
}
function setPlayMode(mode){
playMode=mode;
const modeNames={order:'顺序播放',loop:'单曲循环',random:'随机播放'};
showToast('播放模式: '+modeNames[mode],'success');
if(mode==='loop'){
artPlayer.loop=true;
}else{
artPlayer.loop=false;
}
}
function toggleGesture(enabled){gestureEnabled=enabled;showToast('手势控制: '+(enabled?'开启':'关闭'),'success');}
function toggleDoubleClick(enabled){doubleClickEnabled=enabled;showToast('双击播放/暂停: '+(enabled?'开启':'关闭'),'success');}
function toggleBrightnessGesture(enabled){brightnessGestureEnabled=enabled;showToast('左侧滑动调亮度: '+(enabled?'开启':'关闭'),'success');}
function toggleVolumeGesture(enabled){volumeGestureEnabled=enabled;showToast('右侧滑动调音量: '+(enabled?'开启':'关闭'),'success');}
function clearVideoCache(){
if(confirm('确定清除缩略图缓存吗？')){
showToast('缩略图缓存已清除','success');
}
}
function clearPlayHistory(){
if(confirm('确定清除播放历史吗？')){
localStorage.removeItem('videoHistory');
showToast('播放历史已清除','success');
}
}
function resetVideoSettings(){
if(confirm('确定重置所有播放器设置吗？')){
videoRotation=0;videoFlip='none';videoZoom=1;seekTime=10;playMode='order';
if(artPlayer){
artPlayer.video.style.objectFit='contain';
artPlayer.video.style.transform='none';
artPlayer.video.style.filter='none';
artPlayer.playbackRate=1;
artPlayer.volume=0.7;
}
document.getElementById('videoSettingsPanel')?.remove();
showToast('设置已重置','success');
}
}

// 启动播放
if(shouldTryDirect){
// 常见格式直接播放，失败自动转码
createPlayer(videoUrl,videoType,false);
}else{
// 不常见格式直接转码
showToast('正在转码播放...','info');
createPlayer(transcodeUrl,'m3u8',true);
}
}

function filterMedia(type){
openMediaCategory(type||'all');
}

let mediaViewMode='list';
function toggleMediaView(){
const grid=document.getElementById('mediaGrid');
const btn=document.getElementById('viewToggleBtn');
mediaViewMode=mediaViewMode==='list'?'grid':'list';
if(mediaViewMode==='grid'){
grid.classList.add('grid-view');
btn.innerHTML='<svg viewBox="0 0 24 24" fill="white" width="20" height="20"><path d="M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z"/></svg>';
btn.title='列表视图';
}else{
grid.classList.remove('grid-view');
btn.innerHTML='<svg viewBox="0 0 24 24" fill="white" width="20" height="20"><path d="M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z"/></svg>';
btn.title='方格视图';
}
localStorage.setItem('media-view',mediaViewMode);
}

function formatTime(sec){
if(isNaN(sec))return '00:00';
const m=Math.floor(sec/60);
const s=Math.floor(sec%60);
return (m<10?'0':'')+m+':'+(s<10?'0':'')+s;
}

// ===== APlayer 音乐播放器（完整功能）=====
let musicList=[];
let currentMusicIndex=-1;

// 判断是否需要转码的音频格式
function needAudioTranscode(filename){
const ext=filename.toLowerCase().split('.').pop();
const unsupported=['flac','wav','ape','ogg','opus','m4a','aac','wma','alac'];
return unsupported.includes(ext);
}

// 获取音乐播放URL
function getMusicUrl(file){
if(!file||!file.path)return '';
const token=localStorage.getItem('token')||'';
if(needAudioTranscode(file.name||'')){
return '/api/media/audio-transcode?path='+encodeURIComponent(file.path)+'&token='+token;
}
return '/webdav'+file.path+'?token='+token;
}

async function loadMusicList(){
const res=await fetch('/api/media/list?type=audio');
const data=await res.json();
// 过滤掉无效元素
musicList=(data.files||[]).filter(f=>f&&f.name&&f.path);
const container=document.getElementById('musicList');
if(musicList.length===0){
container.innerHTML='<div class="empty">暂无音乐，点击"扫描"按钮扫描媒体文件</div>';
return;
}

// 渲染音乐列表（4列网格布局）
container.innerHTML='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:8px">'+
musicList.map((f,i)=>{
const isPlaying=i===currentMusicIndex;
const ext=f.name.split('.').pop().toUpperCase();
return '<div class="music-grid-item '+(isPlaying?'playing':'')+'" onclick="playMusic('+i+')" style="background:#fff;border-radius:12px;padding:10px 6px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06);text-align:center;transition:transform .2s">'+
'<div style="width:48px;height:48px;border-radius:10px;background:linear-gradient(135deg,#84fab0,#8fd3f4);display:flex;align-items:center;justify-content:center;font-size:24px;margin:0 auto 6px">🎵</div>'+
'<div style="font-size:11px;font-weight:600;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-bottom:2px">'+f.name+'</div>'+
'<div style="font-size:10px;color:#999">'+formatSize(f.size)+'</div>'+
'</div>';
}).join('')+'</div>';

// 初始化或更新APlayer
if(!aplayer){
initAPlayer();
}else{
// 更新播放列表
aplayer.list.clear();
musicList.forEach((f,i)=>{
aplayer.list.add({
name:f.name,
artist:'NAS私有云',
url:getMusicUrl(f),
cover:''
});
});
}
}

// ===== 音乐播放器 - 主流UI设计 =====
// 底部迷你条 + 点击展开全屏播放页

let miniPlayerBar=null;
let fullPlayerPage=null;

function createMiniPlayerBar(){
if(miniPlayerBar)return;
miniPlayerBar=document.createElement('div');
miniPlayerBar.id='miniPlayerBar';
miniPlayerBar.style.cssText='display:none;position:fixed;bottom:0;left:0;right:0;height:64px;background:linear-gradient(135deg,#1a1a2e,#16213e);backdrop-filter:blur(24px);z-index:99998;box-shadow:0 -4px 24px rgba(0,0,0,.4);transition:transform .3s cubic-bezier(.4,0,.2,1);border-top:1px solid rgba(255,255,255,.05);';
miniPlayerBar.innerHTML='<div style="display:flex;align-items:center;height:100%;padding:0 16px;">'+
'<div id="miniCover" style="width:48px;height:48px;border-radius:8px;background:linear-gradient(135deg,#667eea,#764ba2);flex-shrink:0;display:flex;align-items:center;justify-content:center;color:#fff;font-size:20px;box-shadow:0 4px 12px rgba(102,126,234,.4);">&#127925;</div>'+
'<div style="flex:1;margin:0 16px;min-width:0;">'+
'<div id="miniTitle" style="color:#fff;font-size:15px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">未播放</div>'+
'<div style="color:rgba(255,255,255,.5);font-size:12px;margin-top:2px;">NAS私有云</div>'+
'</div>'+
'<button id="miniPlayBtn" style="width:44px;height:44px;border:none;background:rgba(255,255,255,.1);color:#fff;font-size:18px;cursor:pointer;flex-shrink:0;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:all .2s;">&#9654;</button>'+
'<button id="miniCloseBtn" style="width:40px;height:40px;border:none;background:transparent;color:rgba(255,255,255,.6);font-size:16px;cursor:pointer;flex-shrink:0;border-radius:50%;transition:all .2s;margin-left:4px;">&#10005;</button>'+
'</div>';
document.body.appendChild(miniPlayerBar);

miniPlayerBar.addEventListener('click',function(e){
if(e.target.id!=='miniPlayBtn'&&e.target.id!=='miniCloseBtn'){
showFullPlayer();
}
});

document.getElementById('miniPlayBtn').onclick=function(e){
e.stopPropagation();
if(!aplayer)return;
if(aplayer.audio.paused){
aplayer.play();
this.innerHTML='&#9646;&#9646;';
this.style.background='rgba(255,255,255,.2)';
}else{
aplayer.pause();
this.innerHTML='&#9654;';
this.style.background='rgba(255,255,255,.1)';
}
};

document.getElementById('miniCloseBtn').onclick=function(e){
e.stopPropagation();
closeMusicPlayer();
};
}

function createFullPlayerPage(){
if(fullPlayerPage)return;
fullPlayerPage=document.createElement('div');
fullPlayerPage.id='fullPlayerPage';
fullPlayerPage.style.cssText='display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:linear-gradient(180deg,#1a1a2e 0%,#16213e 50%,#0f0f23 100%);z-index:99999;flex-direction:column;transition:transform .35s cubic-bezier(.4,0,.2,1);transform:translateY(100%);';
fullPlayerPage.innerHTML='<div style="height:56px;display:flex;align-items:center;padding:0 16px;background:transparent;">'+
'<button id="fullCloseBtn" style="width:48px;height:48px;border:none;background:rgba(255,255,255,.1);color:#fff;font-size:18px;cursor:pointer;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:all .2s;">&#8595;</button>'+
'<div style="flex:1;text-align:center;">'+
'<div style="color:rgba(255,255,255,.6);font-size:12px;">正在播放</div>'+
'</div>'+
'<button style="width:48px;height:48px;border:none;background:rgba(255,255,255,.1);color:#fff;font-size:18px;cursor:pointer;border-radius:50%;display:flex;align-items:center;justify-content:center;">&#8943;</button>'+
'</div>'+
'<div style="flex:1;display:flex;align-items:center;justify-content:center;padding:20px;">'+
'<div id="fullCover" style="width:260px;height:260px;border-radius:20px;background:linear-gradient(135deg,#667eea,#764ba2);display:flex;align-items:center;justify-content:center;color:#fff;font-size:72px;box-shadow:0 24px 64px rgba(102,126,234,.4);">&#127925;</div>'+
'</div>'+
'<div style="padding:0 32px 32px;">'+
'<div id="fullTitle" style="color:#fff;font-size:22px;font-weight:600;text-align:center;margin-bottom:8px;">未播放</div>'+
'<div id="fullArtist" style="color:rgba(255,255,255,.5);font-size:14px;text-align:center;margin-bottom:24px;">NAS私有云</div>'+
'<div id="aplayerContainer" style="width:100%;border-radius:12px;overflow:hidden;"></div>'+
'</div>';
document.body.appendChild(fullPlayerPage);

document.getElementById('fullCloseBtn').onclick=function(){
hideFullPlayer();
};
}

function showMiniPlayer(){
createMiniPlayerBar();
miniPlayerBar.style.display='block';
miniPlayerBar.style.transform='translateY(0)';
}

function hideMiniPlayer(){
if(miniPlayerBar){
miniPlayerBar.style.transform='translateY(100%)';
setTimeout(function(){miniPlayerBar.style.display='none';},300);
}
}

function showFullPlayer(){
createFullPlayerPage();
showMiniPlayer();
fullPlayerPage.style.display='flex';
requestAnimationFrame(function(){
fullPlayerPage.style.transform='translateY(0)';
});
}

function hideFullPlayer(){
if(fullPlayerPage){
fullPlayerPage.style.transform='translateY(100%)';
setTimeout(function(){
fullPlayerPage.style.display='none';
},300);
}
}

function updateMiniPlayerUI(){
if(!miniPlayerBar||!aplayer)return;
const track=musicList[aplayer.list.index];
const titleEl=document.getElementById('miniTitle');
const playBtn=document.getElementById('miniPlayBtn');
if(track&&titleEl){
titleEl.textContent=track.name||'未知歌曲';
}
if(playBtn){
playBtn.innerHTML=aplayer.audio.paused?'&#9654;':'&#9646;&#9646;';
}
}

function closeMusicPlayer(){
if(aplayer){
aplayer.pause();
}
hideFullPlayer();
hideMiniPlayer();
}

function closeAPlayer(){
closeMusicPlayer();
}

function showAPlayer(){
showMiniPlayer();
}

// ===== APK打包兼容性优化 =====
// 检测是否在APK环境中
const isAPKEnv=window.AndroidJSBridge?true:false;

// APK兼容：后台播放不暂停
if(isAPKEnv){
document.addEventListener('visibilitychange',function(){
if(!document.hidden&&aplayer&&!aplayer.audio.paused){
// 回到前台时保持播放状态
console.log('回到前台，继续播放');
}
});

// 防止页面关闭时音频残留
window.addEventListener('beforeunload',function(){
// 禁用长按弹出菜单
document.addEventListener('contextmenu',function(e){e.preventDefault();});
// 视频区域禁用触摸滚动
document.addEventListener('DOMContentLoaded',function(){
const artContainer=document.querySelector('.artplayer-container');
if(artContainer){
artContainer.style.touchAction='none';
}
});
if(aplayer){
aplayer.pause();
}
});

// 视频手势控制：左右滑动调进度，上下调音量
function initVideoGestures(){
const container=document.querySelector('.artplayer-container');
if(!container)return;

let startX=0,startY=0,isDragging=false,isHorizontal=false;
let currentTime=0,duration=0;

container.addEventListener('touchstart',function(e){
if(!artPlayer)return;
const touch=e.touches[0];
startX=touch.clientX;
startY=touch.clientY;
isDragging=true;
isHorizontal=false;
currentTime=artPlayer.currentTime;
duration=artPlayer.duration;
},{passive:true});

container.addEventListener('touchmove',function(e){
if(!isDragging||!artPlayer)return;
const touch=e.touches[0];
const dx=touch.clientX-startX;
const dy=touch.clientY-startY;

if(!isHorizontal&&Math.abs(dx)>20&&Math.abs(dx)>Math.abs(dy)){
isHorizontal=true;
}

if(isHorizontal){
const progress=dx/container.offsetWidth;
const newTime=currentTime+progress*duration;
artPlayer.seek(Math.max(0,Math.min(duration,newTime)));
}else{
const volume=artPlayer.volume-(dy/300);
artPlayer.volume=Math.max(0,Math.min(1,volume));
}
},{passive:true});

container.addEventListener('touchend',function(e){
isDragging=false;
isHorizontal=false;
});
}
}

// ===== Media Session API（锁屏通知和系统媒体控制）=====
function updateMediaSession(){
if(!('mediaSession' in navigator))return;
try{
const track=musicList[aplayer.list.index];
if(!track)return;
navigator.mediaSession.metadata=new MediaMetadata({
title:track.name||'未知歌曲',
artist:'NAS私有云',
album:'本地音乐',
artwork:[
{src:'/static/icon.png',sizes:'96x96',type:'image/png'}
]
});
// 设置播放状态
navigator.mediaSession.playbackState=aplayer.audio.paused?'paused':'playing';
// 绑定媒体控制事件
navigator.mediaSession.setActionHandler('play',function(){aplayer.play();});
navigator.mediaSession.setActionHandler('pause',function(){aplayer.pause();});
navigator.mediaSession.setActionHandler('previoustrack',function(){aplayer.skipBack();});
navigator.mediaSession.setActionHandler('nexttrack',function(){aplayer.skipForward();});
navigator.mediaSession.setActionHandler('seekto',function(details){
if(details.seekTime){aplayer.audio.currentTime=details.seekTime;}
});
}catch(e){
console.warn('Media Session设置失败:',e);
}
}

function initAPlayer(){
// 自动创建容器（如果不存在）
let container=document.getElementById('aplayerContainer');
if(!container){
container=document.createElement('div');
container.id='aplayerContainer';
container.style.cssText='display:none;position:fixed;bottom:0;left:0;right:0;z-index:9999;width:100%;box-shadow:0 -2px 10px rgba(0,0,0,.1);';
document.body.appendChild(container);

// 添加关闭按钮
let closeBtn=document.createElement('div');
closeBtn.id='aplayerCloseBtn';
closeBtn.innerHTML='✕';
closeBtn.style.cssText='position:absolute;top:6px;right:6px;width:28px;height:28px;line-height:28px;text-align:center;background:rgba(0,0,0,.5);color:#fff;border-radius:50%;cursor:pointer;z-index:10;font-size:14px;';
closeBtn.onclick=function(e){
e.stopPropagation();
closeAPlayer();
};
container.appendChild(closeBtn);
}

try{
// 过滤掉无效元素，确保每个文件都有name和path
const validMusicList=(musicList||[]).filter(f=>f&&f.name&&f.path);
aplayer=new APlayer({
container:container,
mini:false,
autoplay:false,
theme:'#667eea',
loop:'all',
order:'list',
preload:'metadata',
volume:0.7,
mutex:true,
listFolded:true,
listMaxHeight:'300px',
lrcType:0,
storageName:'nas-aplayer-setting',
audio:validMusicList.map(f=>({
name:f.name||'未知歌曲',
artist:'NAS私有云',
url:getMusicUrl(f),
cover:'',
lrc:''
}))
});

// APK兼容：添加倍速和循环模式切换按钮
setTimeout(function(){
try{
// 添加倍速切换按钮
let speedBtn=document.createElement('div');
speedBtn.id='aplayerSpeedBtn';
speedBtn.innerHTML='1.0x';
speedBtn.style.cssText='position:absolute;top:10px;left:10px;padding:4px 8px;background:rgba(255,255,255,.9);border-radius:4px;font-size:12px;cursor:pointer;z-index:10;color:#333;';
speedBtn.onclick=function(e){
e.stopPropagation();
const speeds=[0.5,0.75,1.0,1.25,1.5,2.0];
let current=speeds.indexOf(aplayer.audio.playbackRate||1);
current=(current+1)%speeds.length;
aplayer.audio.playbackRate=speeds[current];
this.innerHTML=speeds[current]+'x';
showToast('倍速: '+speeds[current]+'x','info',1500);
};
container.appendChild(speedBtn);

// 添加循环模式切换按钮
let loopBtn=document.createElement('div');
loopBtn.id='aplayerLoopBtn';
loopBtn.innerHTML='🔁';
loopBtn.style.cssText='position:absolute;top:10px;right:50px;padding:4px 8px;background:rgba(255,255,255,.9);border-radius:4px;font-size:12px;cursor:pointer;z-index:10;color:#333;';
loopBtn.onclick=function(e){
e.stopPropagation();
const modes=['list','one','random'];
const labels=['🔁','🔂','🔀'];
let current=modes.indexOf(aplayer.loop||'all');
if(current===-1)current=0;
current=(current+1)%modes.length;
aplayer.loop=modes[current];
this.innerHTML=labels[current];
showToast('循环模式: '+modes[current],'info',1500);
};
container.appendChild(loopBtn);
}catch(e){console.warn('添加播放器按钮失败:',e);}
},500);

// 错误计数，避免反复提示
let musicErrorCount=0;
let lastErrorTime=0;

// 事件监听
if(aplayer){
aplayer.on('play',function(){
currentMusicIndex=aplayer.list.index;
updateMusicListUI();
// 更新Media Session（锁屏通知）
updateMediaSession();
});
aplayer.on('pause',function(){
// 暂停时不需要更新UI
updateMediaSession();
});
aplayer.on('ended',function(){
updateMediaSession();
});
aplayer.on('error',function(){
// 音乐加载错误处理
musicErrorCount++;
const now=Date.now();
if(now-lastErrorTime>3000&&musicErrorCount<=3){
showToast('音乐加载失败，请检查文件格式或网络','error',3000);
lastErrorTime=now;
}
});
aplayer.on('ended',function(){
// 播放结束
});
aplayer.on('listswitch',function(){
currentMusicIndex=aplayer.list.index;
updateMusicListUI();
});
aplayer.on('error',function(){
const currentSong=musicList[currentMusicIndex];
logError('音乐播放','音乐加载失败','歌曲: '+(currentSong?currentSong.name:'未知')+'\n索引: '+currentMusicIndex+'\nURL: '+(currentSong?getMusicUrl(currentSong):'未知'));
updateErrorLogBadge();
const now=Date.now();
if(now-lastErrorTime>3000){
musicErrorCount=0;
}
lastErrorTime=now;
musicErrorCount++;
if(musicErrorCount>=3){
aplayer.pause();
showToast('部分音乐格式不支持，已停止自动播放','warning');
musicErrorCount=0;
}else{
showToast('音乐加载失败，尝试下一首','error');
}
});
}
}catch(e){
console.error('APlayer初始化失败:',e);
showToast('播放器初始化失败: '+e.message,'error');
}
}

function updateMusicListUI(){
const items=document.querySelectorAll('#musicList .music-item');
items.forEach((item,i)=>{
item.classList.toggle('playing',i===currentMusicIndex);
const num=item.querySelector('.num');
if(num)num.textContent=i===currentMusicIndex?'▶':(i+1);
});
}

// 直接播放音乐文件（不依赖播放列表）
function playMusicDirect(path,name){
try{
const token=localStorage.getItem('token')||'';
const encodedPath=path.split('/').filter(Boolean).map(encodeURIComponent).join('/');
const url='/webdav/'+encodedPath+(token?'?token='+encodeURIComponent(token):'');
// 显示APlayer容器
let container=document.getElementById('aplayerContainer');
if(!container){
container=document.createElement('div');
container.id='aplayerContainer';
container.style.cssText='position:fixed;bottom:0;left:0;right:0;z-index:99997;display:block;';
document.body.appendChild(container);
}else{
container.style.display='block';
container.style.position='fixed';
container.style.bottom='0';
container.style.left='0';
container.style.right='0';
container.style.zIndex='99997';
}
// 初始化或切换播放
if(!aplayer){
initAPlayer();
setTimeout(()=>{
try{
if(aplayer){
aplayer.list.clear();
aplayer.list.add({name:name||'未知音乐',artist:'NAS',url:url,cover:''});
aplayer.play();
}
}catch(e){console.error('playMusicDirect播放错误:',e);}
},300);
}else{
aplayer.list.clear();
aplayer.list.add({name:name||'未知音乐',artist:'NAS',url:url,cover:''});
aplayer.play();
}
showToast('正在播放: '+(name||'未知音乐'),'success');
}catch(e){
console.error('playMusicDirect错误:',e);
showToast('音乐播放失败: '+e.message,'error');
}
}

function playMusic(index){
try{
if(typeof index!=='number'||index<0||index>=musicList.length||!musicList[index]){
console.error('playMusic: 无效的索引',index,'musicList长度:',musicList.length);
showToast('音乐索引无效','error');
return;
}
currentMusicIndex=index;
// 显示APlayer容器
let container=document.getElementById('aplayerContainer');
if(!container){
container=document.createElement('div');
container.id='aplayerContainer';
container.style.cssText='position:fixed;bottom:0;left:0;right:0;z-index:99997;display:block;';
document.body.appendChild(container);
}else{
container.style.display='block';
container.style.position='fixed';
container.style.bottom='0';
container.style.left='0';
container.style.right='0';
container.style.zIndex='99997';
}
// 初始化或切换播放
if(!aplayer){
initAPlayer();
setTimeout(()=>{
try{
if(aplayer){
aplayer.list.switch(index);
aplayer.play();
}
}catch(e){console.error('playMusic切换播放错误:',e);}
},300);
}else{
aplayer.list.switch(index);
aplayer.play();
}
updateMusicListUI();
// 重新加载歌词
lyricsData=[];
currentLyricIndex=-1;
if(document.getElementById('lyricsPanel')&&document.getElementById('lyricsPanel').style.display!=='none'){
loadLyrics();
}
}catch(e){
console.error('playMusic错误:',e);
showToast('音乐播放失败: '+e.message,'error');
}
}

// 音乐控制函数（供其他地方调用）
function musicPlay(){if(aplayer)aplayer.play();}
function musicPause(){if(aplayer)aplayer.pause();}
function musicPrev(){if(aplayer)aplayer.skipBack();}
function musicNext(){if(aplayer)aplayer.skipForward();}
function musicToggle(){if(aplayer){if(aplayer.audio.paused)aplayer.play();else aplayer.pause();}}

// ===== 酷我风格播放器 =====
let kuwoAudioCtx=null;
let kuwoSourceNode=null;
let kuwoGainNode=null;
let kuwoEqNodes=[];
let kuwoCurrentEffect='none';
let kuwoLikedSongs=new Set();
let kuwoPlayMode='list'; // list, loop, random
let kuwoProgressTimer=null;

const kuwoEffects=[
{id:'none',name:'原声',desc:'不添加任何音效',icon:'🎵',eq:[0,0,0,0,0,0,0,0,0,0]},
{id:'vocal',name:'悦耳人声',desc:'聆听近在耳畔的哼唱',icon:'🎤',eq:[2,3,4,3,1,0,-1,-1,0,1]},
{id:'theater',name:'环绕剧院',desc:'重现循环声场',icon:'🏛',eq:[1,2,3,4,3,2,1,0,-1,0]},
{id:'stage',name:'悠扬舞台',desc:'歌声如临舞台现场',icon:'🎭',eq:[0,1,2,3,4,3,2,1,0,-1]},
{id:'live',name:'浩渺声场',desc:'畅享无拘的音乐会',icon:'🎪',eq:[1,1,2,2,3,3,2,2,1,1]},
{id:'speaker',name:'澎湃外放',desc:'环绕的音乐现场超大声场体验',icon:'🔊',eq:[3,4,3,2,1,0,1,2,3,4]},
{id:'bass',name:'超重低音',desc:'强劲低音震撼体验',icon:'💥',eq:[5,4,3,2,1,0,0,0,0,0]},
{id:'treble',name:'清澈高音',desc:'通透高音细节丰富',icon:'✨',eq:[0,0,0,0,0,1,2,3,4,5]},
];

const kuwoEqBands=['31Hz','62Hz','125Hz','250Hz','500Hz','1K','2K','4K','8K','16K'];

function initKuwoAudio(){
if(kuwoAudioCtx)return;
try{
kuwoAudioCtx=new (window.AudioContext||window.webkitAudioContext)();
kuwoGainNode=kuwoAudioCtx.createGain();
kuwoGainNode.gain.value=1;
kuwoGainNode.connect(kuwoAudioCtx.destination);
// 创建10段均衡器
const frequencies=[31,62,125,250,500,1000,2000,4000,8000,16000];
kuwoEqNodes=[];
let prevNode=kuwoGainNode;
for(let i=0;i<10;i++){
const eq=kuwoAudioCtx.createBiquadFilter();
eq.type=i===0?'lowshelf':(i===9?'highshelf':'peaking');
eq.frequency.value=frequencies[i];
eq.Q.value=1;
eq.gain.value=0;
eq.connect(prevNode);
kuwoEqNodes.unshift(eq);
prevNode=eq;
}
}catch(e){
console.log('Web Audio API不支持',e);
}
}

function connectKuwoAudio(audioEl){
if(!kuwoAudioCtx||!audioEl)return;
try{
if(kuwoSourceNode)kuwoSourceNode.disconnect();
kuwoSourceNode=kuwoAudioCtx.createMediaElementSource(audioEl);
kuwoSourceNode.connect(kuwoEqNodes[kuwoEqNodes.length-1]);
}catch(e){
console.log('连接音频失败',e);
}
}

function openKuwoPlayer(){
document.getElementById('kuwoPlayer').classList.add('active');
updateKuwoPlayerUI();
startKuwoProgressTimer();
}

function closeKuwoPlayer(){
document.getElementById('kuwoPlayer').classList.remove('active');
// 关闭所有子面板
document.getElementById('kuwoMask').classList.remove('active');
document.getElementById('kuwoEffectPanel').classList.remove('active');
document.getElementById('kuwoPlaylistPanel').classList.remove('active');
document.getElementById('kuwoMoreMenu').classList.remove('active');
document.getElementById('lyricsPanel').style.display='none';
}

// ===== 歌词显示功能 =====
let lyricsData=[]; // 解析后的歌词数组 [{time, text}]
let currentLyricIndex=-1;

function toggleLyricsPanel(){
const panel=document.getElementById('lyricsPanel');
if(panel.style.display==='none'){
panel.style.display='block';
loadLyrics();
}else{
panel.style.display='none';
}
}

function loadLyrics(){
if(currentMusicIndex<0||!musicList[currentMusicIndex])return;
const song=musicList[currentMusicIndex];
// 尝试加载同名LRC文件
const lrcPath=song.path.replace(/\.[^.]+$/,'.lrc');
const token=localStorage.getItem('token')||'';
const lrcUrl='/webdav'+lrcPath+(token?'?token='+encodeURIComponent(token):'');
fetch(lrcUrl)
.then(res=>{
if(!res.ok)throw new Error('歌词不存在');
return res.text();
})
.then(text=>{
lyricsData=parseLrc(text);
renderLyrics();
})
.catch(()=>{
// 没有歌词文件，显示提示
lyricsData=[];
document.getElementById('lyricsContent').innerHTML='<div style="padding:40px 0">暂无歌词<br><span style="font-size:12px;opacity:.5">将同名.lrc文件放在歌曲同目录即可</span></div>';
});
}

function parseLrc(lrcText){
const lines=lrcText.split('\n');
const result=[];
const timeReg=/\[(\d{2}):(\d{2})\.(\d{2,3})\]/g;
lines.forEach(line=>{
let match;
while((match=timeReg.exec(line))!==null){
const minutes=parseInt(match[1]);
const seconds=parseInt(match[2]);
const ms=parseInt(match[3].padEnd(3,'0'));
const time=minutes*60+seconds+ms/1000;
const text=line.replace(timeReg,'').trim();
if(text){
result.push({time:time,text:text});
}
}
});
result.sort((a,b)=>a.time-b.time);
return result;
}

function renderLyrics(){
const container=document.getElementById('lyricsContent');
if(lyricsData.length===0){
container.innerHTML='<div style="padding:40px 0">暂无歌词</div>';
return;
}
container.innerHTML=lyricsData.map((l,i)=>{
return '<div class="lyric-line" data-index="'+i+'" data-time="'+l.time+'" onclick="seekToLyric('+l.time+')" style="padding:8px 0;cursor:pointer;transition:all .3s">'+l.text+'</div>';
}).join('');
}

function updateLyrics(currentTime){
if(lyricsData.length===0)return;
// 找到当前时间对应的歌词行
let index=-1;
for(let i=0;i<lyricsData.length;i++){
if(lyricsData[i].time<=currentTime){
index=i;
}else{
break;
}
}
if(index===currentLyricIndex)return;
currentLyricIndex=index;
// 更新高亮
document.querySelectorAll('.lyric-line').forEach((el,i)=>{
if(i===index){
el.style.color='#fff';
el.style.fontSize='16px';
el.style.fontWeight='600';
}else{
el.style.color='rgba(255,255,255,.6)';
el.style.fontSize='14px';
el.style.fontWeight='400';
}
});
// 滚动到当前行
if(index>=0){
const activeEl=document.querySelector('.lyric-line[data-index="'+index+'"]');
if(activeEl){
const panel=document.getElementById('lyricsPanel');
const offset=activeEl.offsetTop-panel.clientHeight/2+activeEl.clientHeight;
panel.scrollTo({top:offset,behavior:'smooth'});
}
}
}

function seekToLyric(time){
if(typeof aplayer!=='undefined'&&aplayer&&aplayer.audio){
aplayer.audio.currentTime=time;
}
}

function updateKuwoPlayerUI(){
try{
if(currentMusicIndex<0||currentMusicIndex>=musicList.length||!musicList[currentMusicIndex]){
const songNameEl=document.getElementById('kuwoSongName');
if(songNameEl)songNameEl.textContent='未选择歌曲';
const songArtistEl=document.getElementById('kuwoSongArtist');
if(songArtistEl)songArtistEl.textContent='NAS私有云';
return;
}
const song=musicList[currentMusicIndex];
const songNameEl=document.getElementById('kuwoSongName');
if(songNameEl)songNameEl.textContent=song.name||'未知歌曲';
const songArtistEl=document.getElementById('kuwoSongArtist');
if(songArtistEl)songArtistEl.textContent='NAS私有云';
// 更新播放按钮
const playBtn=document.getElementById('kuwoPlayBtn');
const coverEl=document.getElementById('kuwoCover');
if(aplayer&&!aplayer.audio.paused){
if(playBtn)playBtn.textContent='⏸';
if(coverEl&&kuwoRotateEnabled)coverEl.classList.add('playing');
}else{
if(playBtn)playBtn.textContent='▶';
if(coverEl)coverEl.classList.remove('playing');
}
// 更新喜欢按钮
const likeBtn=document.getElementById('kuwoLikeBtn');
if(likeBtn){
const likeIcon=likeBtn.querySelector('.kuwo-action-icon');
if(kuwoLikedSongs.has(song.name||'')){
likeBtn.classList.add('liked');
if(likeIcon)likeIcon.textContent='♥';
}else{
likeBtn.classList.remove('liked');
if(likeIcon)likeIcon.textContent='♡';
}
}
}catch(e){
console.error('updateKuwoPlayerUI错误:',e);
}
}

function toggleKuwoPlay(){
if(!aplayer){
if(musicList.length>0)playMusic(0);
return;
}
if(aplayer.audio.paused){
aplayer.play();
}else{
aplayer.pause();
}
updateKuwoPlayerUI();
}

function kuwoPrev(){
if(!aplayer)return;
aplayer.skipBack();
setTimeout(updateKuwoPlayerUI,100);
}

function kuwoNext(){
if(!aplayer)return;
aplayer.skipForward();
setTimeout(updateKuwoPlayerUI,100);
}

function toggleKuwoMode(){
const modes=['list','loop','random'];
const icons=['🔁','🔂','🔀'];
const idx=modes.indexOf(kuwoPlayMode);
kuwoPlayMode=modes[(idx+1)%3];
document.getElementById('kuwoModeBtn').textContent=icons[(idx+1)%3];
if(aplayer){
if(kuwoPlayMode==='loop')aplayer.loop='one';
else if(kuwoPlayMode==='random')aplayer.loop='none';
else aplayer.loop='all';
}
showToast('播放模式: '+(kuwoPlayMode==='list'?'列表循环':kuwoPlayMode==='loop'?'单曲循环':'随机播放'));
}

function toggleKuwoLike(){
if(currentMusicIndex<0||!musicList[currentMusicIndex])return;
const song=musicList[currentMusicIndex];
if(kuwoLikedSongs.has(song.name||'')){
kuwoLikedSongs.delete(song.name||'');
showToast('已取消喜欢');
}else{
kuwoLikedSongs.add(song.name||'');
showToast('已添加到喜欢');
}
updateKuwoPlayerUI();
}

function seekKuwo(e){
if(!aplayer||!aplayer.audio.duration)return;
const rect=e.currentTarget.getBoundingClientRect();
const percent=(e.clientX-rect.left)/rect.width;
aplayer.seek(percent*aplayer.audio.duration);
updateKuwoProgress();
}

function updateKuwoProgress(){
if(!aplayer||!aplayer.audio.duration)return;
const percent=(aplayer.audio.currentTime/aplayer.audio.duration)*100;
document.getElementById('kuwoProgressBar').style.width=percent+'%';
document.getElementById('kuwoCurTime').textContent=formatTime(aplayer.audio.currentTime);
document.getElementById('kuwoTotalTime').textContent=formatTime(aplayer.audio.duration);
// 同步歌词滚动
if(typeof updateLyrics==='function'&&lyricsPanel.style.display!=='none'){
updateLyrics(aplayer.audio.currentTime);
}
}

function startKuwoProgressTimer(){
if(kuwoProgressTimer)clearInterval(kuwoProgressTimer);
kuwoProgressTimer=setInterval(()=>{
if(document.getElementById('kuwoPlayer').classList.contains('active')){
updateKuwoProgress();
updateKuwoPlayerUI();
}
},500);
}

// ===== 音效功能 =====
function showKuwoEffect(){
try{
// 先关闭播放列表和更多菜单
document.getElementById('kuwoPlaylistPanel').classList.remove('active');
document.getElementById('kuwoMoreMenu').classList.remove('active');
initKuwoAudio();
renderKuwoEffects();
renderKuwoEq();
}catch(e){
console.error('音效面板初始化错误:',e);
}
// 延迟显示，确保播放列表面板完全关闭
setTimeout(()=>{
document.getElementById('kuwoMask').classList.add('active');
document.getElementById('kuwoEffectPanel').classList.add('active');
},100);
}

function hideKuwoEffect(){
document.getElementById('kuwoMask').classList.remove('active');
document.getElementById('kuwoEffectPanel').classList.remove('active');
document.getElementById('kuwoPlaylistPanel').classList.remove('active');
}

function switchKuwoEffectTab(tab,type){
document.querySelectorAll('.kuwo-effect-tab').forEach(t=>t.classList.remove('active'));
tab.classList.add('active');
document.getElementById('kuwoEffectPresets').style.display=type==='presets'?'block':'none';
document.getElementById('kuwoEffectEq').style.display=type==='eq'?'block':'none';
}

function renderKuwoEffects(){
const list=document.getElementById('kuwoEffectList');
list.innerHTML=kuwoEffects.map(effect=>{
const active=kuwoCurrentEffect===effect.id?'active':'';
return '<div class="kuwo-effect-item '+active+'" onclick="applyKuwoEffect(\''+effect.id+'\')">'+
'<div class="kuwo-effect-icon">'+effect.icon+'</div>'+
'<div class="kuwo-effect-info">'+
'<div class="kuwo-effect-name">'+effect.name+'</div>'+
'<div class="kuwo-effect-desc">'+effect.desc+'</div>'+
'</div>'+
'<button class="kuwo-effect-btn">'+(active?'使用中':'使用')+'</button>'+
'</div>';
}).join('');
}

function applyKuwoEffect(id){
kuwoCurrentEffect=id;
const effect=kuwoEffects.find(e=>e.id===id);
if(effect&&kuwoEqNodes.length===10){
for(let i=0;i<10;i++){
kuwoEqNodes[i].gain.value=effect.eq[i];
}
}
document.getElementById('kuwoEffectTag').textContent=effect?effect.name:'无损音效';
renderKuwoEffects();
showToast('音效: '+(effect?effect.name:'原声'));
}

function renderKuwoEq(){
const bands=document.getElementById('kuwoEqBands');
bands.innerHTML=kuwoEqBands.map((label,i)=>{
const val=kuwoEqNodes[i]?kuwoEqNodes[i].gain.value:0;
return '<div class="kuwo-eq-band">'+
'<input type="range" class="kuwo-eq-slider" min="-12" max="12" value="'+val+'" oninput="setKuwoEqGain('+i+',this.value)">'+
'<span class="kuwo-eq-label">'+label+'</span>'+
'</div>';
}).join('');
const presets=document.getElementById('kuwoEqPresets');
presets.innerHTML=kuwoEffects.map(e=>{
const active=kuwoCurrentEffect===e.id?'active':'';
return '<span class="kuwo-eq-preset '+active+'" onclick="applyKuwoEffect(\''+e.id+'\')">'+e.name+'</span>';
}).join('');
}

function setKuwoEqGain(index,value){
if(kuwoEqNodes[index]){
kuwoEqNodes[index].gain.value=parseFloat(value);
}
kuwoCurrentEffect='custom';
}

// ===== 播放列表 =====
function showKuwoPlaylist(){
try{
// 先关闭音效面板和更多菜单
document.getElementById('kuwoEffectPanel').classList.remove('active');
document.getElementById('kuwoMoreMenu').classList.remove('active');
// 如果音乐列表为空，先加载
if(musicList.length===0){
showToast('正在加载音乐列表...');
loadMusicList().then(()=>{
setTimeout(()=>{
try{renderKuwoPlaylist();}catch(e){console.error('渲染播放列表错误:',e);}
},500);
});
}else{
renderKuwoPlaylist();
}
}catch(e){
console.error('播放列表面板初始化错误:',e);
}
// 延迟显示，确保音效面板完全关闭
setTimeout(()=>{
document.getElementById('kuwoMask').classList.add('active');
document.getElementById('kuwoPlaylistPanel').classList.add('active');
},100);
}

function hideKuwoPlaylist(){
document.getElementById('kuwoMask').classList.remove('active');
document.getElementById('kuwoPlaylistPanel').classList.remove('active');
}

function renderKuwoPlaylist(){
document.getElementById('kuwoPlaylistCount').textContent=musicList.length;
const container=document.getElementById('kuwoPlaylistItems');
if(musicList.length===0){
container.innerHTML='<div style="padding:40px;text-align:center;color:#999">播放列表为空</div>';
return;
}
container.innerHTML=musicList.map((f,i)=>{
const isPlaying=i===currentMusicIndex;
const ext=f.name.split('.').pop().toUpperCase();
return '<div onclick="playKuwoSong('+i+')" style="padding:12px 16px;border-bottom:1px solid #f5f5f5;cursor:pointer;display:flex;align-items:center">'+
'<span style="width:24px;color:'+(isPlaying?'#667eea':'#999')+';text-align:center;margin-right:12px">'+(isPlaying?'▶':(i+1))+'</span>'+
'<div style="flex:1;min-width:0">'+
'<div style="font-size:14px;color:'+(isPlaying?'#667eea':'#333')+';white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+f.name+'</div>'+
'<div style="font-size:11px;color:#999;margin-top:2px">'+ext+' · '+formatSize(f.size)+'</div>'+
'</div>'+
'</div>';
}).join('');
}

function playKuwoSong(index){
hideKuwoPlaylist();
playMusic(index);
}

// 歌曲更多操作菜单
function showKuwoSongMenu(index){
const song=musicList[index];
if(!song){showToast('歌曲信息无效','error');return;}
const html='<div style="padding:8px 0">'+
'<div onclick="playMusic('+index+');closeModal()" style="padding:14px 20px;cursor:pointer;border-bottom:1px solid #f5f5f5">▶ 播放</div>'+
'<div onclick="showToast(\'添加到歌单\');closeModal()" style="padding:14px 20px;cursor:pointer;border-bottom:1px solid #f5f5f5">📋 添加到歌单</div>'+
'<div onclick="showToast(\'分享功能开发中\');closeModal()" style="padding:14px 20px;cursor:pointer;border-bottom:1px solid #f5f5f5">⤴ 分享</div>'+
'<div onclick="showToast(\'文件路径: '+song.path+'\');closeModal()" style="padding:14px 20px;cursor:pointer;border-bottom:1px solid #f5f5f5">ℹ️ 歌曲信息</div>'+
'<div onclick="deleteMusicFile('+index+')" style="padding:14px 20px;cursor:pointer;color:#ff4757">🗑 删除文件</div>'+
'</div>';
showModal('操作',html,'300px');
}

async function deleteMusicFile(index){
const song=musicList[index];
if(!song||!song.path){showToast('文件信息无效','error');return;}
if(!confirm('确定删除文件 '+(song.name||'未知文件')+' 吗？'))return;
try{
const res=await fetch('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:song.path})});
const data=await res.json();
if(data.success){
showToast('删除成功');
closeModal();
loadMusicList();
}else{
showToast('删除失败: '+(data.error||'未知错误'),'error');
}
}catch(e){
showToast('删除失败: '+e.message,'error');
}
}

// ===== 更多操作菜单 =====
let kuwoRotateEnabled=true;
let kuwoSleepTimer=null;

function showKuwoMoreMenu(){
document.getElementById('kuwoMoreMenu').classList.add('active');
}

function hideKuwoMoreMenu(){
document.getElementById('kuwoMoreMenu').classList.remove('active');
}

// 点击其他地方关闭菜单
document.addEventListener('click',function(e){
const menu=document.getElementById('kuwoMoreMenu');
const btn=e.target.closest('button');
if(menu&&menu.classList.contains('active')){
if(!menu.contains(e.target)&&!(btn&&btn.getAttribute('onclick')&&btn.getAttribute('onclick').indexOf('showKuwoMoreMenu')>=0)){
hideKuwoMoreMenu();
}
}
});

function showKuwoSleepTimer(){
const options=['关闭','15分钟','30分钟','45分钟','60分钟','90分钟'];
const minutes=[0,15,30,45,60,90];
let html='<div style="padding:16px"><h4 style="margin:0 0 12px">睡眠定时</h4>';
options.forEach((opt,i)=>{
html+='<div onclick="setKuwoSleepTimer('+minutes[i]+')" style="padding:12px;border-bottom:1px solid #eee;cursor:pointer">'+opt+'</div>';
});
html+='</div>';
showModal('睡眠定时',html);
}

function setKuwoSleepTimer(minutes){
if(kuwoSleepTimer){clearTimeout(kuwoSleepTimer);kuwoSleepTimer=null;}
if(minutes>0){
kuwoSleepTimer=setTimeout(()=>{
if(aplayer)aplayer.pause();
showToast('睡眠定时到，已暂停播放');
},minutes*60*1000);
showToast('已设置'+minutes+'分钟后暂停');
}else{
showToast('已关闭睡眠定时');
}
closeModal();
}

function showKuwoSpeed(){
const speeds=[0.5,0.75,1.0,1.25,1.5,2.0];
let html='<div style="padding:16px"><h4 style="margin:0 0 12px">倍速播放</h4>';
speeds.forEach(s=>{
const current=aplayer&&aplayer.audio.playbackRate===s?'style="color:#667eea;font-weight:600"':'';
html+='<div onclick="setKuwoSpeed('+s+')" '+current+' style="padding:12px;border-bottom:1px solid #eee;cursor:pointer">'+s+'x</div>';
});
html+='</div>';
showModal('倍速播放',html);
}

function setKuwoSpeed(speed){
if(aplayer){
aplayer.audio.playbackRate=speed;
showToast('播放速度: '+speed+'x');
}
closeModal();
}

function showKuwoSongInfo(){
if(currentMusicIndex<0||!musicList[currentMusicIndex]){
showToast('未选择歌曲');
return;
}
const song=musicList[currentMusicIndex];
const duration=aplayer&&aplayer.audio.duration?formatTime(aplayer.audio.duration):'未知';
const html='<div style="padding:16px">'+
'<div style="margin-bottom:12px"><strong>歌曲名：</strong>'+song.name+'</div>'+
'<div style="margin-bottom:12px"><strong>文件大小：</strong>'+formatSize(song.size)+'</div>'+
'<div style="margin-bottom:12px"><strong>时长：</strong>'+duration+'</div>'+
'<div style="margin-bottom:12px"><strong>路径：</strong>'+song.path+'</div>'+
'<div style="margin-bottom:12px"><strong>当前音效：</strong>'+(kuwoCurrentEffect==='none'?'原声':kuwoEffects.find(e=>e.id===kuwoCurrentEffect)?.name||'自定义')+'</div>'+
'</div>';
showModal('歌曲信息',html);
}

function toggleKuwoRotate(){
kuwoRotateEnabled=!kuwoRotateEnabled;
const cover=document.getElementById('kuwoCover');
if(kuwoRotateEnabled){
if(aplayer&&!aplayer.audio.paused)cover.classList.add('playing');
}else{
cover.classList.remove('playing');
}
showToast('封面旋转已'+(kuwoRotateEnabled?'开启':'关闭'));
}

// ===== 设置页面 =====
function showSetting(type){
document.querySelector('.settings-menu').style.display='none';
document.getElementById('settingContent').style.display='block';
const detail=document.getElementById('settingDetail');
if(type==='network'){
detail.innerHTML='<h3 style="margin-bottom:16px">组网设置</h3><div id="networkStatus"></div>'+
'<div style="margin-top:20px;padding:16px;background:#f8f9fa;border-radius:8px">'+
'<h4 style="font-size:14px;margin-bottom:12px">自助接入组网</h4>'+
'<div class="form-group"><label>组网服务商</label><select id="netProvider" onchange="toggleN2NConfig()"><option value="n2n">n2n（免费，推荐）</option><option value="tailscale">Tailscale</option><option value="zerotier">ZeroTier</option><option value="custom">自定义</option></select></div>'+
'<div id="n2nConfig" style="display:none;margin-top:12px;padding:12px;background:#fff;border-radius:6px">'+
'<div style="font-size:13px;color:#666;margin-bottom:8px">n2n 配置（免费公共节点，无需公网IP）</div>'+
'<div class="form-group"><label>超级节点</label><input type="text" id="n2nSupernode" value="wang.switchy.hin2n.stars:10086"></div>'+
'<div class="form-group"><label>社区名（同社区互通）</label><input type="text" id="n2nCommunity" value="nas-network"></div>'+
'<div class="form-group"><label>加密密钥</label><input type="text" id="n2nKey" value="nas123456"></div>'+
'<div class="form-group"><label>虚拟IP</label><input type="text" id="n2nIP" value="192.168.100.1"></div>'+
'<button class="btn" style="background:#27ae60" onclick="downloadN2NConfig()">下载配置（导入Hin2n）</button>'+
'<div style="margin-top:16px;padding:12px;background:#f0f7ff;border-radius:6px;font-size:12px;color:#333;line-height:1.8">'+
'<div style="font-weight:600;margin-bottom:8px;color:#1976d2">📱 使用步骤</div>'+
'<div>1. 安装 Hin2n App：</div>'+
'<div style="padding-left:16px">• <a href="https://play.google.com/store/apps/details?id=me.esyou.hin2n" target="_blank" style="color:#1976d2">Google Play 下载</a></div>'+
'<div style="padding-left:16px">• <a href="https://www.coolapk.com/apk/me.esyou.hin2n" target="_blank" style="color:#1976d2">酷安下载</a></div>'+
'<div style="padding-left:16px">• <a href="https://github.com/switchy/switchy/releases" target="_blank" style="color:#1976d2">GitHub  releases</a></div>'+
'<div>2. 点击上方「下载配置」保存 n2n.conf</div>'+
'<div>3. 打开 Hin2n → 右上角 + → 导入配置 → 选择 n2n.conf</div>'+
'<div>4. 点击启动开关，连接成功后获得 192.168.100.x IP</div>'+
'<div>5. 其他设备用相同社区名和密钥，即可互通</div>'+
'<div style="margin-top:8px;padding-top:8px;border-top:1px dashed #ddd">'+
'<div style="font-weight:600;margin-bottom:4px">💡 默认配置</div>'+
'<div>超级节点：wang.switchy.hin2n.stars:10086</div>'+
'<div>社区名：nas-network</div>'+
'<div>密钥：nas123456</div>'+
'<div>本设备IP：192.168.100.1</div>'+
'</div></div></div>'+
'<div class="form-group"><label>认证密钥 / 网络ID</label><input type="text" id="netAuthKey" placeholder="输入 Auth Key 或 Network ID（n2n无需）"></div>'+
'<div class="form-group"><label>设备名称</label><input type="text" id="netDeviceName" value="termux-nas"></div>'+
'<button class="btn btn-primary" onclick="joinNetwork()">加入组网</button>'+
'<button class="btn btn-danger" onclick="leaveNetwork()" style="margin-left:8px">断开</button></div>'+
'<div style="margin-top:16px;padding:12px;background:#d1ecf1;border-radius:6px;font-size:12px;color:#0c5460">💡 n2n 使用免费公共超级节点，无需自己搭建服务器。Android 端安装 Hin2n App，导入配置即可连接。</div>'+
'<div style="margin-top:8px;padding:12px;background:#fff3cd;border-radius:6px;font-size:12px;color:#856404">安全提示：通过组网访问 NAS 无需暴露公网端口，所有流量端到端加密。</div>';
loadNetworkStatus();
toggleN2NConfig();
}else if(type==='autostart'){
detail.innerHTML='<h3 style="margin-bottom:16px">开机自启</h3>'+
'<div style="background:#fff;padding:20px;border-radius:12px;border:1px solid #eee">'+
'<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">'+
'<div><div style="font-weight:500">Termux 开机自启</div><div style="font-size:12px;color:#999;margin-top:4px">手机重启后自动启动 NAS 服务</div></div>'+
'<div class="toggle-switch" id="autostartToggle" onclick="toggleAutostart()"></div></div>'+
'<div style="font-size:12px;color:#999;line-height:1.6;margin-top:16px;padding:12px;background:#f8f9fa;border-radius:8px">'+
'设置方法：<br>1. 安装 Termux:Boot 应用<br>2. 创建 ~/.termux/boot/start-nas.sh 脚本<br>3. 脚本内容：<br><code style="background:#eee;padding:2px 6px;border-radius:4px">#!/data/data/com.termux/files/usr/bin/sh<br>cd ~/nas-server &amp;&amp; ./nas-server -config config.yaml &</code></div></div>';
}else if(type==='security'){
detail.innerHTML='<h3 style="margin-bottom:16px">安全管理</h3>'+
'<div class="form-group"><label>修改密码</label><input type="password" id="newPassword" placeholder="输入新密码"></div>'+
'<div class="form-group"><label>确认密码</label><input type="password" id="confirmPassword" placeholder="再次输入新密码"></div>'+
'<button class="btn btn-primary" onclick="changePassword()">修改密码</button>'+
'<div style="margin-top:24px"><h4 style="margin-bottom:12px">登录日志</h4><div id="loginLogs" style="background:#f8f9fa;padding:12px;border-radius:8px;font-size:12px;color:#666;max-height:200px;overflow-y:auto">加载中...</div></div>';
loadLoginLogs();
}else if(type==='update'){
detail.innerHTML='<h3 style="margin-bottom:16px">检查更新</h3>'+
'<div style="background:#fff;padding:20px;border-radius:12px;border:1px solid #eee;text-align:center">'+
'<div style="font-size:48px;margin-bottom:12px">📦</div>'+
'<div style="font-weight:500;margin-bottom:4px">当前版本 v1.2.0</div>'+
'<div style="font-size:12px;color:#999;margin-bottom:16px">发布日期：2026-09-12</div>'+
'<button class="btn btn-primary" onclick="checkUpdate()">检查更新</button>'+
'<div id="updateResult" style="margin-top:16px;font-size:13px"></div></div>';
}else if(type==='about'){
detail.innerHTML='<h3 style="margin-bottom:16px">关于</h3>'+
'<div style="background:#fff;padding:24px;border-radius:12px;border:1px solid #eee;text-align:center">'+
'<div style="font-size:56px;margin-bottom:16px">☁️</div>'+
'<div style="font-size:20px;font-weight:600;margin-bottom:4px">NAS 私有云</div>'+
'<div style="font-size:13px;color:#999;margin-bottom:16px">v1.2.0</div>'+
'<div style="font-size:12px;color:#666;line-height:1.8;text-align:left">'+
'基于 Go 语言开发的轻量级私有云存储服务<br>'+
'支持文件管理、影音播放、数据备份、远程组网<br>'+
'采用 HTTPS + JWT + bcrypt 安全认证<br>'+
'适用于 Android Termux 环境运行</div></div>';
}else if(type==='debug'){
detail.innerHTML='<h3 style="margin-bottom:16px">调试工具</h3>'+
'<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">'+
'<button class="btn" onclick="loadDebugInfo()" style="padding:16px">📊 系统信息</button>'+
'<button class="btn" onclick="loadDebugConfig()" style="padding:16px">✅ 配置检查</button>'+
'<button class="btn" onclick="loadDebugLogs()" style="padding:16px">📝 查看日志</button>'+
'<button class="btn" onclick="showDebugCommand()" style="padding:16px">⚡ 执行命令</button>'+
'</div>'+
'<div id="debugResult" style="background:#f8f9fa;padding:16px;border-radius:8px;min-height:200px;font-size:13px;color:#333;white-space:pre-wrap;word-break:break-all">点击上方按钮开始调试...</div>';
}else if(type==='iconSize'){
detail.innerHTML='<h3 style="margin-bottom:16px">图标大小</h3>'+
'<div style="background:#fff;padding:24px;border-radius:16px;box-shadow:0 2px 10px rgba(0,0,0,.04);margin-bottom:20px">'+
'<div style="text-align:center;margin-bottom:24px">'+
'<div style="display:inline-flex;align-items:center;justify-content:center;width:var(--icon-canvas);height:var(--icon-canvas);border-radius:var(--icon-radius);background:#f5f6f8;box-shadow:0 2px 8px rgba(0,0,0,.06);transition:all .3s">'+
'<svg viewBox="0 0 24 24" fill="#4facfe" style="width:var(--icon-body);height:var(--icon-body);transition:all .3s"><path d="M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>'+
'</div></div>'+
'<div style="text-align:center;margin-bottom:8px;font-size:15px;font-weight:600;color:#333">当前档位：<span id="currentSizeLabel">M（中等）</span></div>'+
'<div style="text-align:center;font-size:12px;color:#999;margin-bottom:20px">画布 <span id="canvasSize">120</span>×<span id="canvasSize2">120</span>px · 图标 <span id="iconSize">96</span>×<span id="iconSize2">96</span>px</div>'+
'<div style="margin-bottom:20px">'+
'<div style="display:flex;justify-content:space-between;font-size:12px;color:#999;margin-bottom:8px">'+
'<span>XS</span><span>S</span><span>M</span><span>L</span><span>XL</span></div>'+
'<input type="range" id="iconSizeSlider" min="25" max="144" value="120" step="1" style="width:100%;height:6px;-webkit-appearance:none;background:#e0e0e0;border-radius:3px;outline:none" oninput="updateIconSize(this.value)">'+
'</div>'+
'<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px">'+
'<button class="btn btn-sm" onclick="setIconSize(96)" style="padding:10px 4px">XS</button>'+
'<button class="btn btn-sm" onclick="setIconSize(108)" style="padding:10px 4px">S</button>'+
'<button class="btn btn-sm btn-primary" onclick="setIconSize(120)" style="padding:10px 4px">M</button>'+
'<button class="btn btn-sm" onclick="setIconSize(132)" style="padding:10px 4px">L</button>'+
'<button class="btn btn-sm" onclick="setIconSize(144)" style="padding:10px 4px">XL</button>'+
'</div></div>'+
'<div style="background:#e8f4fd;padding:14px;border-radius:10px;font-size:12px;color:#1976d2;line-height:1.6">'+
'<div style="font-weight:600;margin-bottom:4px">💡 档位说明（滑块支持 25-144px 无级调节）</div>'+
'<div>XS：画布 96×96px，图标 77×77px</div>'+
'<div>S：画布 108×108px，图标 86×86px</div>'+
'<div>M（默认）：画布 120×120px，图标 96×96px</div>'+
'<div>L：画布 132×132px，图标 106×106px</div>'+
'<div>XL：画布 144×144px，图标 115×115px</div>'+
'<div style="margin-top:6px;padding-top:6px;border-top:1px dashed #b3d9ff">最小支持 25×25px（拖动滑块）</div>'+
'</div>';
setTimeout(function(){
const saved=localStorage.getItem('nas-icon-size');
if(saved){document.getElementById('iconSizeSlider').value=saved;updateIconSize(saved);}
},100);
}
}
function backToSettings(){
document.querySelector('.settings-menu').style.display='block';
document.getElementById('settingContent').style.display='none';
}

// ========== PWA管理 ==========
function showPWAManager(){
openPanel('pwa');
setTimeout(pwaRefresh,100);
}

async function pwaRefresh(){
const status=await PWAManager.getStatus();
const statusEl=document.getElementById('pwaStatus');
if(statusEl){
let html='';
html+='<div><strong>Service Worker支持：</strong>'+(status.supported?'✅ 支持':'❌ 不支持')+'</div>';
html+='<div><strong>已注册：</strong>'+(status.registered?'✅ 是':'❌ 否')+'</div>';
html+='<div><strong>网络状态：</strong>'+(status.online?'🟢 在线':'🔴 离线')+'</div>';
html+='<div><strong>独立应用模式：</strong>'+(status.standalone?'✅ 是':'❌ 否')+'</div>';
if(status.serviceWorker){
html+='<div><strong>SW状态：</strong>'+(status.serviceWorker.active?'✅ 活跃':'⏳ 等待')+'</div>';
html+='<div><strong>作用域：</strong>'+status.serviceWorker.scope+'</div>';
}
statusEl.innerHTML=html;
}

// 刷新缓存列表
const cacheEl=document.getElementById('pwaCacheList');
if(cacheEl){
if(status.caches.length===0){
cacheEl.innerHTML='<div style="color:#999;text-align:center;padding:20px">暂无缓存</div>';
}else{
cacheEl.innerHTML=status.caches.map(function(c){
return '<div style="padding:8px 0;border-bottom:1px solid #f0f0f0;display:flex;justify-content:space-between;align-items:center">'+
'<div><strong>'+c.name+'</strong><br><span style="color:#999;font-size:12px">'+c.itemCount+' 个资源</span></div>'+
'<button class="btn btn-ghost btn-sm" onclick="pwaClearOneCache(\''+c.name+'\')">清除</button>'+
'</div>';
}).join('');
}
}
}

async function pwaRegister(){
const result=await PWAManager.register();
if(result.success){
showToast('Service Worker注册成功','success');
}else{
showToast('注册失败：'+result.error,'error');
}
pwaRefresh();
}

async function pwaUnregister(){
if(!confirm('确定要注销Service Worker吗？离线功能将失效'))return;
const result=await PWAManager.unregister();
if(result.success){
showToast('Service Worker已注销','success');
}else{
showToast('注销失败：'+result.error,'error');
}
pwaRefresh();
}

async function pwaUpdate(){
const result=await PWAManager.checkUpdate();
if(result.success){
showToast(result.message,result.hasUpdate?'warning':'success');
}else{
showToast('检查失败：'+result.error,'error');
}
pwaRefresh();
}

async function pwaClearCache(){
if(!confirm('确定要清除所有缓存吗？'))return;
const result=await PWAManager.clearAllCaches();
if(result.success){
showToast('已清除'+result.cleared+'个缓存','success');
}else{
showToast('清除失败：'+result.error,'error');
}
pwaRefresh();
}

async function pwaClearOneCache(name){
const result=await PWAManager.clearCache(name);
if(result.success){
showToast('缓存已清除','success');
}else{
showToast('清除失败：'+result.error,'error');
}
pwaRefresh();
}

function toggleAutostart(){
document.getElementById('autostartToggle').classList.toggle('active');
showToast('请按说明手动配置开机自启脚本','info');
}
async function changePassword(){
const p1=document.getElementById('newPassword').value;
const p2=document.getElementById('confirmPassword').value;
if(!p1||p1.length<6){showToast('密码至少6位','error');return;}
if(p1!==p2){showToast('两次密码不一致','error');return;}
showToast('密码修改功能需要重新生成配置','info');
}
async function loadLoginLogs(){
document.getElementById('loginLogs').innerHTML='登录日志功能开发中...';
}
function checkUpdate(){
document.getElementById('updateResult').innerHTML='<span style="color:#27ae60">✓ 已是最新版本</span>';
}

// ===== 系统监控 =====
function startSystemMonitor(){
if(systemMonitorTimer)clearInterval(systemMonitorTimer);
loadSystemInfo();
systemMonitorTimer=setInterval(loadSystemInfo,5000);
}
function stopSystemMonitor(){
if(systemMonitorTimer){clearInterval(systemMonitorTimer);systemMonitorTimer=null;}
}
async function loadSystemInfo(){
try{
const res=await fetch('/api/system/info');
const data=await res.json();
// CPU
document.getElementById('cpuValue').textContent=data.cpu.usage.toFixed(1)+'%';
document.getElementById('cpuBar').style.width=Math.min(data.cpu.usage,100)+'%';
document.getElementById('cpuDetail').textContent=data.cpu.cores+' 核';
// 内存
document.getElementById('memValue').textContent=data.memory.usage.toFixed(1)+'%';
document.getElementById('memBar').style.width=Math.min(data.memory.usage,100)+'%';
document.getElementById('memDetail').textContent=formatSize(data.memory.used)+' / '+formatSize(data.memory.total);
// 存储
document.getElementById('storageValue').textContent=data.storage.usage.toFixed(1)+'%';
document.getElementById('storageBar').style.width=Math.min(data.storage.usage,100)+'%';
document.getElementById('storageDetail').textContent=formatSize(data.storage.used)+' / '+formatSize(data.storage.total);
// 网络
const netConnected=data.network.connected?'已连接':'未连接';
let netIP='';
if(data.network.interfaces&&data.network.interfaces.length>0){
const active=data.network.interfaces.find(i=>i.up&&i.ip);
if(active)netIP=active.ip;
else if(data.network.interfaces.length>0)netIP=data.network.interfaces[0].name;
}
document.getElementById('netValue').textContent=netConnected;
document.getElementById('netRx').textContent=netIP||'无接口';
document.getElementById('netTx').textContent=data.network.interfaces.length+' 个接口';
// 运行时间
document.getElementById('systemUptime').textContent=data.uptime;
// 进程
const pl=document.getElementById('processList');
pl.innerHTML=data.processes.map(p=>{
return '<div class="process-item"><span class="process-pid">'+p.pid+'</span><span class="process-name">'+p.name+'</span><span class="process-mem">'+formatSize(p.memory)+'</span><span class="process-cpu">'+p.cpu.toFixed(1)+'%</span></div>';
}).join('');
}catch(e){
stopSystemMonitor();
}
// 加载增强监控数据
loadEnhancedMonitor();
}

// 加载增强监控数据
async function loadEnhancedMonitor(){
try{
const res=await fetch('/api/monitor/status');
const data=await res.json();
if(!data.success)return;

// AList状态
const alist=data.data.alist;
if(alist){
document.getElementById('alistStatusDot').style.background=alist.running?'#43e97b':'#ff4757';
document.getElementById('alistStatusText').textContent=alist.running?'运行中':'未运行';
document.getElementById('alistVersion').textContent=alist.version||'';
document.getElementById('alistPort').textContent=alist.port||'5244';
}
}catch(e){
console.error('加载增强监控失败:',e);
}
}

// 加载监控历史
async function loadMonitorHistory(){
try{
const res=await fetch('/api/monitor/history');
const data=await res.json();
if(!data.success||!data.data||data.data.length===0){
document.getElementById('monitorHistory').innerHTML='<div style="text-align:center;color:#999;padding:20px">暂无历史数据</div>';
return;
}
document.getElementById('monitorHistory').innerHTML=data.data.slice(-20).reverse().map(function(r){
const time=new Date(r.timestamp*1000).toLocaleTimeString();
return '<div style="padding:4px 0;border-bottom:1px solid #f0f0f0">'+
'<span style="color:#999">'+time+'</span> '+
'CPU:'+r.cpu.toFixed(1)+'% '+
'MEM:'+r.memory.toFixed(1)+'% '+
'DISK:'+r.storage.toFixed(1)+'% '+
'PROCS:'+r.processes+
'</div>';
}).join('');
}catch(e){
document.getElementById('monitorHistory').innerHTML='加载失败: '+e.message;
}
}

// 加载监控日志
async function loadMonitorLogs(){
try{
const res=await fetch('/api/monitor/logs');
const data=await res.json();
if(!data.success||!data.data||!data.data.logs){
document.getElementById('monitorLogs').innerHTML='暂无日志';
return;
}
document.getElementById('monitorLogs').innerHTML=data.data.logs.filter(function(l){return l.trim();}).join('<br>');
}catch(e){
document.getElementById('monitorLogs').innerHTML='加载失败: '+e.message;
}
}

// 离开监控页时停止刷新
const origGoHome=goHome;
goHome=function(){stopSystemMonitor();stopVPNMonitor();origGoHome();};

// ===== VPN管理 =====
let vpnCurrentConfig=null;
function startVPNMonitor(){
if(vpnMonitorTimer)clearInterval(vpnMonitorTimer);
loadVPNStatus();
vpnMonitorTimer=setInterval(loadVPNStatus,5000);
}
function stopVPNMonitor(){
if(vpnMonitorTimer){clearInterval(vpnMonitorTimer);vpnMonitorTimer=null;}
}
async function loadVPNStatus(){
try{
const res=await fetch('/api/vpn/status');
const data=await res.json();
// 状态
document.getElementById('vpnStatusDot').className='vpn-status-dot'+(data.running?' running':'');
document.getElementById('vpnStatusText').textContent=data.running?'运行中':'未运行';
document.getElementById('vpnToggleBtn').textContent=data.running?'停止':'启动';
// 统计
document.getElementById('vpnOnlineCount').textContent=data.online_count+' / '+data.client_count;
document.getElementById('vpnTotalUpload').textContent=formatSize(data.total_upload);
document.getElementById('vpnTotalDownload').textContent=formatSize(data.total_download);
// 客户端列表
const list=document.getElementById('vpnClientList');
list.innerHTML=data.clients.map(c=>{
return '<div class="vpn-client-row">'+
'<div>'+c.name+'</div>'+
'<div>'+c.ip+'</div>'+
'<div><span class="vpn-client-status '+(c.online?'online':'offline')+'">'+(c.online?'已连接':'已断开')+'</span></div>'+
'<div class="vpn-client-actions">'+
'<button class="vpn-client-btn" onclick="vpnDownloadConfig(\''+c.id+'\')">下载</button>'+
'<button class="vpn-client-btn danger" onclick="vpnDeleteClient(\''+c.id+'\')">删除</button>'+
'</div></div>';
}).join('');
}catch(e){
stopVPNMonitor();
}
}
async function vpnLoadConfig(){
const res=await fetch('/api/vpn/config');
vpnCurrentConfig=await res.json();
document.getElementById('vpnServerInfo').textContent='WireGuard · '+vpnCurrentConfig.endpoint;
document.getElementById('vpnSubnet').textContent='子网: '+vpnCurrentConfig.subnet;
document.getElementById('vpnDNS').textContent=vpnCurrentConfig.dns;
}
function vpnShowConfig(){
document.getElementById('vpnPort').value=vpnCurrentConfig.listen_port;
document.getElementById('vpnEndpoint').value=vpnCurrentConfig.endpoint;
document.getElementById('vpnDNSInput').value=vpnCurrentConfig.dns;
document.getElementById('vpnSubnetInput').value=vpnCurrentConfig.subnet;
document.getElementById('vpnConfigModal').style.display='flex';
}
async function vpnSaveConfig(){
const config={
listen_port:parseInt(document.getElementById('vpnPort').value),
endpoint:document.getElementById('vpnEndpoint').value,
dns:document.getElementById('vpnDNSInput').value,
subnet:document.getElementById('vpnSubnetInput').value,
enabled:vpnCurrentConfig.enabled
};
await fetch('/api/vpn/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(config)});
document.getElementById('vpnConfigModal').style.display='none';
vpnLoadConfig();
alert('配置已保存');
}
async function vpnAddClient(){
const name=prompt('输入客户端名称：');
if(!name)return;
const res=await fetch('/api/vpn/clients',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})});
const client=await res.json();
if(confirm('客户端「'+name+'」已创建，IP: '+client.ip+'\n是否下载配置文件？')){
vpnDownloadConfig(client.id);
}
loadVPNStatus();
}
function vpnDownloadConfig(id){
window.open('/api/vpn/client/config?id='+id,'_blank');
}
async function vpnDeleteClient(id){
if(!confirm('确定删除此客户端？'))return;
await fetch('/api/vpn/client/delete?id='+id);
loadVPNStatus();
}
function vpnToggle(){
alert('VPN 服务需要 root 权限才能启动/停止。\n\n当前使用方案3：在其他设备运行服务器。\n请点击「部署指南」查看详细步骤。');
}
function vpnShowGuide(){
document.getElementById('vpnGuideModal').style.display='flex';
}
function vpnDownloadServerConfig(){
window.open('/api/vpn/server/config','_blank');
}
function vpnDownloadNASConfig(){
window.open('/api/vpn/nas-client/config','_blank');
}
// 打开VPN面板时加载
const origOpenPanel=openPanel;
openPanel=function(name){
origOpenPanel(name);
if(name==='vpn'){vpnLoadConfig();startVPNMonitor();}
};

// ===== 备份恢复 =====
async function loadBackups(){
const res=await fetch('/api/backup/list');
const data=await res.json();
document.getElementById('backupCount').textContent=data.backups.length;
let total=0;data.backups.forEach(b=>total+=b.size);
document.getElementById('backupSize').textContent=formatSize(total);
document.getElementById('backupRetention').textContent=data.config.retention_days;
const list=document.getElementById('backupList');
if(data.backups.length===0){list.innerHTML='<div class="empty">暂无备份</div>';return;}
list.innerHTML='<div class="file-list">'+data.backups.map(b=>{
const statusClass=b.status==='completed'?'success':b.status==='in_progress'?'warning':'danger';
const statusText=b.status==='completed'?'已完成':b.status==='in_progress'?'进行中':'失败';
return '<div class="backup-item"><div class="backup-info">'+
'<div class="backup-name">'+b.name+' <span class="badge '+statusClass+'">'+statusText+'</span></div>'+
'<div class="backup-meta">'+b.file_count+' 个文件 · '+formatSize(b.size)+' · '+new Date(b.created_at).toLocaleString('zh-CN')+'</div>'+
'</div><div style="display:flex;gap:6px;flex-wrap:wrap">'+
'<button class="btn btn-primary btn-sm" onclick="restoreBackup(\''+b.id+'\')">恢复</button>'+
'<button class="btn btn-sm" style="background:#4facfe;color:#fff" onclick="exportBackup(\''+b.id+'\')">导出</button>'+
'<button class="btn btn-danger btn-sm" onclick="deleteBackup(\''+b.id+'\')">删除</button>'+
'</div></div>';
}).join('')+'</div>';
}
function showBackupModal(){document.getElementById('backupModal').style.display='flex';}
async function createBackup(){
const name=document.getElementById('backupName').value;
const sources=document.getElementById('backupSources').value.split('\n').filter(s=>s.trim());
document.getElementById('backupModal').style.display='none';
showProgress('正在创建备份');
try{
addLog('INFO','备份恢复','创建备份','开始创建备份: '+(name||'自动命名')+', 源目录数: '+sources.length);
setProgress(10,'扫描文件...');await sleep(500);
setProgress(30,'压缩数据...');await sleep(800);
setProgress(60,'打包中...');
const res=await fetch('/api/backup/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,sources})});
if(!res.ok){
const err=await res.text();
addLog('ERROR','备份恢复','创建备份','失败: '+err);
logError('备份恢复','备份创建失败','名称: '+(name||'自动命名')+'\n源目录: '+sources.join(', ')+'\n错误: '+err);
updateErrorLogBadge();
hideProgress();alert('备份失败：'+err);return;
}
addLog('INFO','备份恢复','创建备份','成功');
setProgress(90,'写入文件...');await sleep(500);
setProgress(100,'备份完成');await sleep(300);
hideProgress();
showToast('备份完成','success');
setTimeout(loadBackups,1000);
}catch(e){
addLog('ERROR','备份恢复','创建备份','异常: '+e.message);
logError('备份恢复','备份创建异常',e.message+'\n'+e.stack);
updateErrorLogBadge();
hideProgress();alert('备份异常：'+e.message);
}
}
async function restoreBackup(id){
const target=prompt('恢复到目录（留空使用默认）：','');
showProgress('正在恢复备份');
try{
addLog('INFO','备份恢复','恢复备份','开始恢复: 备份ID='+id+', 目标='+(target||'默认'));
setProgress(10,'读取备份...');await sleep(500);
setProgress(40,'解压数据...');await sleep(800);
setProgress(70,'恢复文件...');
const res=await fetch('/api/backup/restore',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({backup_id:id,target})});
if(!res.ok){
const err=await res.text();
addLog('ERROR','备份恢复','恢复备份','失败: '+err);
logError('备份恢复','备份恢复失败','备份ID: '+id+'\n目标: '+(target||'默认')+'\n错误: '+err);
updateErrorLogBadge();
hideProgress();alert('恢复失败：'+err);return;
}
addLog('INFO','备份恢复','恢复备份','成功');
setProgress(90,'完成恢复...');await sleep(500);
setProgress(100,'恢复完成');await sleep(300);
hideProgress();
showToast('恢复完成','success');
}catch(e){
addLog('ERROR','备份恢复','恢复备份','异常: '+e.message);
logError('备份恢复','备份恢复异常',e.message+'\n'+e.stack);
updateErrorLogBadge();
hideProgress();alert('恢复异常：'+e.message);
}
}
async function deleteBackup(id){
if(!confirm('确定删除此备份？'))return;
showProgress('正在删除备份');
try{
addLog('INFO','备份恢复','删除备份','开始删除: 备份ID='+id);
setProgress(30,'删除备份文件...');await sleep(300);
setProgress(70,'清理记录...');
const res=await fetch('/api/backup/'+id,{method:'DELETE'});
if(!res.ok){
const err=await res.text();
addLog('ERROR','备份恢复','删除备份','失败: '+err);
logError('备份恢复','备份删除失败','备份ID: '+id+'\n错误: '+err);
updateErrorLogBadge();
}
addLog('INFO','备份恢复','删除备份','成功');
setProgress(100,'删除完成');await sleep(300);
hideProgress();
loadBackups();
}catch(e){
addLog('ERROR','备份恢复','删除备份','异常: '+e.message);
logError('备份恢复','备份删除异常',e.message+'\n'+e.stack);
updateErrorLogBadge();
hideProgress();alert('删除失败：'+e.message);
}
}

// 导出备份文件
function exportBackup(id){
showToast('正在导出备份...','info');
const token=localStorage.getItem('token')||'';
fetch('/api/backup/export?id='+id,{
headers:{'Authorization':'Bearer '+token}
}).then(res=>{
if(!res.ok)throw new Error('导出失败');
return res.blob();
}).then(blob=>{
const url=window.URL.createObjectURL(blob);
const a=document.createElement('a');
a.href=url;
a.download='nas-backup-'+id+'.tar.gz';
document.body.appendChild(a);
a.click();
document.body.removeChild(a);
window.URL.revokeObjectURL(url);
showToast('备份导出成功','success');
}).catch(e=>{
alert('导出失败：'+e.message);
});
}

// 导入备份文件
function importBackup(){
const input=document.createElement('input');
input.type='file';
input.accept='.tar.gz,.gz,.tar';
input.onchange=async function(e){
const file=e.target.files[0];
if(!file)return;
if(file.size>5*1024*1024*1024){
alert('文件过大，最大支持5GB');
return;
}
showProgress('正在导入备份');
try{
setProgress(20,'上传文件...');
const formData=new FormData();
formData.append('file',file);
const token=localStorage.getItem('token')||'';
const res=await fetch('/api/backup/import',{
method:'POST',
headers:{'Authorization':'Bearer '+token},
body:formData
});
setProgress(80,'处理中...');
const data=await res.json();
if(!res.ok)throw new Error(data.error||'导入失败');
setProgress(100,'导入完成');await sleep(300);
hideProgress();
showToast('备份导入成功，可在列表中恢复','success');
loadBackups();
}catch(err){
hideProgress();
alert('导入失败：'+err.message);
}
};
input.click();
}

// ===== 用户管理 =====
let editingUsername='';
async function loadUsers(){
try{
const token=localStorage.getItem('token')||'';
const res=await fetch('/api/users/list',{headers:{'Authorization':'Bearer '+token}});
if(!res.ok){
if(res.status===403){
document.getElementById('userList').innerHTML='<div class="empty">权限不足，仅管理员可访问</div>';
return;
}
throw new Error('加载失败');
}
const data=await res.json();
const users=data.users||[];

// 更新统计
document.getElementById('userCount').textContent=users.length;
document.getElementById('adminCount').textContent=users.filter(u=>u.role==='admin').length;
document.getElementById('activeUserCount').textContent=users.filter(u=>u.active).length;

// 渲染用户列表
const list=document.getElementById('userList');
if(users.length===0){
list.innerHTML='<div class="empty">暂无用户</div>';
return;
}
list.innerHTML='<div class="file-list">'+users.map(u=>{
const roleBadge=u.role==='admin'?'<span class="badge" style="background:#f093fb;color:#fff">管理员</span>':'<span class="badge" style="background:#4facfe;color:#fff">普通用户</span>';
const statusBadge=u.active?'<span class="badge success">正常</span>':'<span class="badge danger">禁用</span>';
return '<div class="file-item">'+
'<div class="file-icon" style="background:linear-gradient(135deg,#fa709a,#fee140)">👤</div>'+
'<div class="file-info">'+
'<div class="file-name">'+u.username+' '+roleBadge+' '+statusBadge+'</div>'+
'<div class="file-meta">'+(u.email||'未设置邮箱')+' · 创建于 '+new Date(u.created_at).toLocaleDateString('zh-CN')+(u.last_login?' · 最后登录 '+new Date(u.last_login).toLocaleString('zh-CN'):'')+'</div>'+
'</div>'+
'<div style="display:flex;gap:6px;flex-wrap:wrap">'+
'<button class="btn btn-sm" onclick="editUser(\''+u.username+'\')">编辑</button>'+
(u.username!=='admin'?'<button class="btn btn-sm" style="background:#667eea;color:#fff" onclick="showPermissionModal(\''+u.username+'\')">权限</button>':'')+
(u.username!=='admin'?'<button class="btn btn-danger btn-sm" onclick="deleteUser(\''+u.username+'\')">删除</button>':'')+
'</div></div>';
}).join('')+'</div>';
}catch(e){
document.getElementById('userList').innerHTML='<div class="empty">加载失败：'+e.message+'</div>';
}
}
function showUserModal(){
editingUsername='';
document.getElementById('userModalTitle').textContent='添加用户';
document.getElementById('userUsername').value='';
document.getElementById('userUsername').disabled=false;
document.getElementById('userPassword').value='';
document.getElementById('userRole').value='user';
document.getElementById('userEmail').value='';
document.getElementById('userModal').style.display='flex';
}
function editUser(username){
editingUsername=username;
document.getElementById('userModalTitle').textContent='编辑用户';
document.getElementById('userUsername').value=username;
document.getElementById('userUsername').disabled=true;
document.getElementById('userPassword').value='';
document.getElementById('userRole').value='user';
document.getElementById('userEmail').value='';
document.getElementById('userModal').style.display='flex';
}
function hideUserModal(){
document.getElementById('userModal').style.display='none';
}
async function saveUser(){
const username=document.getElementById('userUsername').value.trim();
const password=document.getElementById('userPassword').value;
const role=document.getElementById('userRole').value;
const email=document.getElementById('userEmail').value.trim();

if(!username){alert('请输入用户名');return;}
if(!editingUsername && !password){alert('请输入密码');return;}

const token=localStorage.getItem('token')||'';
const url=editingUsername?'/api/users/update':'/api/users/create';
const body=editingUsername?
JSON.stringify({username:editingUsername,password,role,email}):
JSON.stringify({username,password,role,email});

try{
addLog('INFO','用户管理',editingUsername?'更新用户':'创建用户','开始操作: 用户名='+username+', 角色='+role);
const res=await fetch(url,{
method:'POST',
headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},
body:body
});
const data=await res.json();
if(!res.ok){
addLog('ERROR','用户管理',editingUsername?'更新用户':'创建用户','失败: '+(data.error||'操作失败'));
logError('用户管理',(editingUsername?'用户更新失败':'用户创建失败'),'用户名: '+username+'\n角色: '+role+'\n错误: '+(data.error||'未知'));
updateErrorLogBadge();
throw new Error(data.error||'操作失败');
}
addLog('INFO','用户管理',editingUsername?'更新用户':'创建用户','成功: '+username);
showToast(editingUsername?'用户更新成功':'用户创建成功','success');
hideUserModal();
loadUsers();
}catch(e){
addLog('ERROR','用户管理',editingUsername?'更新用户':'创建用户','异常: '+e.message);
logError('用户管理',(editingUsername?'用户更新异常':'用户创建异常'),'用户名: '+username+'\n错误: '+e.message+'\n'+e.stack);
updateErrorLogBadge();
alert('操作失败：'+e.message);
}
}
async function deleteUser(username){
if(!confirm('确定删除用户 '+username+'？'))return;
const token=localStorage.getItem('token')||'';
try{
addLog('INFO','用户管理','删除用户','开始删除: '+username);
const res=await fetch('/api/users/delete?username='+encodeURIComponent(username),{
method:'DELETE',
headers:{'Authorization':'Bearer '+token}
});
if(!res.ok){
const err=await res.text();
addLog('ERROR','用户管理','删除用户','失败: '+err);
logError('用户管理','用户删除失败','用户名: '+username+'\n错误: '+err);
updateErrorLogBadge();
throw new Error('删除失败');
}
addLog('INFO','用户管理','删除用户','成功: '+username);
showToast('用户删除成功','success');
loadUsers();
}catch(e){
addLog('ERROR','用户管理','删除用户','异常: '+e.message);
logError('用户管理','用户删除异常','用户名: '+username+'\n错误: '+e.message+'\n'+e.stack);
updateErrorLogBadge();
alert('删除失败：'+e.message);
}
}

// ===== 权限管理 =====
let currentPermissionUser='';
const permissionNames={
files:'文件管理',
video:'视频播放',
music:'音乐播放',
backup:'备份恢复',
vault:'加密空间',
cloud:'网盘访问(AList)',
alist_upload:'网盘上传',
alist_download:'网盘下载',
alist_delete:'网盘删除',
alist_manage:'网盘管理设置',
dlna:'DLNA投屏',
system:'系统监控',
settings:'系统设置',
users:'用户管理'
};
async function showPermissionModal(username){
currentPermissionUser=username;
document.getElementById('permissionModalTitle').textContent='设置权限 - '+username;
const token=localStorage.getItem('token')||'';
try{
const res=await fetch('/api/users/permissions?username='+encodeURIComponent(username),{
headers:{'Authorization':'Bearer '+token}
});
const data=await res.json();
const userPerms=data.permissions||[];
const allPerms=data.all_permissions||[];
const list=document.getElementById('permissionList');
list.innerHTML=allPerms.map(p=>{
const checked=userPerms.includes(p)?'checked':'';
return '<label style="display:flex;align-items:center;gap:10px;padding:10px;border:1px solid #eee;border-radius:8px;cursor:pointer">'+
'<input type="checkbox" value="'+p+'" '+checked+' style="width:18px;height:18px">'+
'<span>'+(permissionNames[p]||p)+'</span>'+
'</label>';
}).join('');
document.getElementById('permissionModal').style.display='flex';
}catch(e){
alert('加载权限失败：'+e.message);
}
}
function hidePermissionModal(){
document.getElementById('permissionModal').style.display='none';
}
async function savePermissions(){
const token=localStorage.getItem('token')||'';
const checkboxes=document.querySelectorAll('#permissionList input[type=checkbox]:checked');
const permissions=Array.from(checkboxes).map(cb=>cb.value);
try{
const res=await fetch('/api/users/set-permissions',{
method:'POST',
headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},
body:JSON.stringify({username:currentPermissionUser,permissions:permissions})
});
const data=await res.json();
if(!data.success)throw new Error(data.error||'保存失败');
showToast('权限设置成功','success');
hidePermissionModal();
}catch(e){
alert('保存失败：'+e.message);
}
}

// ===== 自动备份 =====
let autoBackupEnabled=false;
let currentBackupTab='backup';
let selectedCategories=[];
let currentBrand='';
async function loadAutoBackupStatus(){
const res=await fetch('/api/backup/auto/status');
const data=await res.json();
const s=data.status;
autoBackupEnabled=s.enabled;
// 更新开关
const toggle=document.getElementById('autoBackupToggle');
if(toggle){
toggle.classList.toggle('active',s.enabled);
}
// 更新信息
document.getElementById('detectedBrand').textContent=s.detected_brand==='xiaomi'?'小米/Redmi':s.detected_brand==='oneplus'?'一加/OPPO':'通用安卓';
document.getElementById('backupInterval').textContent=s.interval_hours>0?s.interval_hours+' 小时':s.backup_time||'未设置';
document.getElementById('lastBackupTime').textContent=s.last_backup||'从未';
document.getElementById('nextBackupTime').textContent=s.next_backup||'--';
}
async function toggleAutoBackup(){
autoBackupEnabled=!autoBackupEnabled;
await saveAutoBackupConfig(true);
}
function showAutoBackupConfig(){
currentBackupTab='backup';
selectedCategories=[];
currentBrand='';
document.getElementById('brandSelect').value='';
document.getElementById('backupCategories').style.display='none';
document.getElementById('restoreListSection').style.display='none';
document.getElementById('autoBackupSettings').style.display='none';
document.getElementById('backupActionBtn').textContent='立即备份';
switchBackupTab('backup');
document.getElementById('autoBackupModal').style.display='flex';
}
function switchBackupTab(tab){
currentBackupTab=tab;
document.getElementById('tabBackup').classList.toggle('active',tab==='backup');
document.getElementById('tabRestore').classList.toggle('active',tab==='restore');
if(tab==='backup'){
document.getElementById('brandSelectGroup').style.display='block';
document.getElementById('backupCategories').style.display=currentBrand?'block':'none';
document.getElementById('restoreListSection').style.display='none';
document.getElementById('autoBackupSettings').style.display='block';
document.getElementById('backupActionBtn').textContent='立即备份';
}else{
document.getElementById('brandSelectGroup').style.display='none';
document.getElementById('backupCategories').style.display='none';
document.getElementById('restoreListSection').style.display='block';
document.getElementById('autoBackupSettings').style.display='none';
document.getElementById('backupActionBtn').textContent='恢复选中';
loadRestoreList();
}
}
async function loadBackupCategories(){
currentBrand=document.getElementById('brandSelect').value;
if(!currentBrand){
document.getElementById('backupCategories').style.display='none';
return;
}
document.getElementById('backupCategories').style.display='block';
document.getElementById('categoryList').innerHTML='<div style="text-align:center;color:#999;padding:20px">扫描中...</div>';
// 从后端获取分类
const res=await fetch('/api/backup/categories?brand='+currentBrand);
const data=await res.json();
const categories=data.categories||[];
selectedCategories=categories.filter(c=>c.selected).map(c=>c.id);
renderCategories(categories);
}
function renderCategories(categories){
const list=document.getElementById('categoryList');
list.innerHTML=categories.map(cat=>{
const selected=selectedCategories.includes(cat.id);
return '<div class="category-item'+(selected?' selected':'')+'" onclick="toggleCategory(\''+cat.id+'\')">'+
'<div class="category-icon" style="background:'+cat.color+'20">'+cat.icon+'</div>'+
'<div class="category-info">'+
'<div class="category-name">'+cat.name+'</div>'+
'<div class="category-meta">'+formatSize(cat.total_size)+' · '+cat.file_count+' 项</div>'+
'</div>'+
'<div class="category-checkbox"></div>'+
'</div>';
}).join('');
}
function toggleCategory(id){
const idx=selectedCategories.indexOf(id);
if(idx>-1){
selectedCategories.splice(idx,1);
}else{
selectedCategories.push(id);
}
// 更新UI
document.querySelectorAll('.category-item').forEach(item=>{
const catId=item.getAttribute('onclick').match(/'([^']+)'/)[1];
item.classList.toggle('selected',selectedCategories.includes(catId));
});
}
async function applyBrandPreset(){
const brand=document.getElementById('brandSelect').value;
if(!brand)return;
const res=await fetch('/api/backup/brand/preset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({brand})});
const data=await res.json();
if(data.success){
showToast('已应用品牌预设','success');
}
}
async function saveAutoBackupConfig(skipModal){
const enable=skipModal?autoBackupEnabled:true;
const interval=parseInt(document.getElementById('backupIntervalInput')?.value)||0;
const time=document.getElementById('backupTimeInput')?.value||'';
const retention=parseInt(document.getElementById('retentionDaysInput')?.value)||30;
const maxBackups=parseInt(document.getElementById('maxBackupsInput')?.value)||0;
const sources=document.getElementById('backupSourcesInput')?.value?.split('\n').filter(s=>s.trim())||[];
const brand=document.getElementById('brandSelect')?.value||'';
await fetch('/api/backup/auto/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enable,interval_hours:interval,backup_time:time,retention_days:retention,max_backups:maxBackups,sources,brand})});
if(!skipModal)document.getElementById('autoBackupModal').style.display='none';
showToast(enable?'自动备份已启用':'自动备份已关闭','success');
loadAutoBackupStatus();
}
async function doBackupAction(){
if(currentBackupTab==='backup'){
if(!currentBrand){showToast('请先选择手机品牌','error');return;}
if(selectedCategories.length===0){showToast('请至少选择一个备份分类','error');return;}
document.getElementById('autoBackupModal').style.display='none';
showProgress('正在创建备份');
try{
setProgress(15,'获取备份目录...');await sleep(400);
const res=await fetch('/api/backup/categories?brand='+currentBrand);
const data=await res.json();
const dirs=[];
data.categories.forEach(cat=>{
if(selectedCategories.includes(cat.id)){dirs.push(...cat.dirs);}
});
setProgress(35,'扫描文件...');await sleep(500);
setProgress(60,'压缩数据...');await sleep(800);
setProgress(85,'打包中...');
await fetch('/api/backup/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:'手动备份-'+new Date().toLocaleDateString(),sources:dirs})});
setProgress(100,'备份完成');await sleep(300);
hideProgress();
showToast('备份完成','success');
setTimeout(loadBackups,1000);
}catch(e){hideProgress();alert('备份失败：'+e.message);}
}else{
showToast('恢复功能请在备份列表中操作','info');
}
}
function loadRestoreList(){
fetch('/api/backup/list').then(res=>res.json()).then(data=>{
const list=document.getElementById('restoreBackupList');
if(data.backups.length===0){
list.innerHTML='<div style="text-align:center;color:#999;padding:20px">暂无备份</div>';
return;
}
list.innerHTML=data.backups.map(b=>{
return '<div class="category-item" onclick="restoreBackup(\''+b.id+'\')">'+
'<div class="category-icon" style="background:#3d7eff20">📦</div>'+
'<div class="category-info">'+
'<div class="category-name">'+b.name+'</div>'+
'<div class="category-meta">'+b.file_count+' 个文件 · '+formatSize(b.size)+' · '+new Date(b.created_at).toLocaleDateString()+'</div>'+
'</div>'+
'<div style="color:#ccc;font-size:20px">›</div>'+
'</div>';
}).join('');
});
}

// ===== 应用备份 =====
function showAppBackup(){
document.getElementById('appBackupModal').style.display='flex';
document.getElementById('installedAppsSection').style.display='none';
loadAppBackupList();
}
async function loadAppBackupList(){
const res=await fetch('/api/app/backup/list');
const data=await res.json();
const list=document.getElementById('appBackupList');
if(data.backups.length===0){
list.innerHTML='<div style="text-align:center;color:#999;padding:20px">暂无应用备份，点击上方按钮创建</div>';
return;
}
list.innerHTML='<div style="font-size:14px;font-weight:600;margin-bottom:8px">备份历史</div>'+data.backups.map(b=>{
return '<div class="app-item">'+
'<div class="app-item-icon">📦</div>'+
'<div class="app-item-info">'+
'<div class="app-item-name">'+b.name+'</div>'+
'<div class="app-item-pkg">'+b.app_count+' 个应用 · '+formatSize(b.total_size)+'</div>'+
'<div class="app-item-version">'+new Date(b.created_at).toLocaleString('zh-CN')+'</div>'+
'</div>'+
'<div class="app-item-actions">'+
'<button class="app-download-btn play" onclick="restoreAppBackup(\''+b.id+'\')">恢复</button>'+
'<button class="app-download-btn browser" onclick="deleteAppBackup(\''+b.id+'\')">删除</button>'+
'</div></div>';
}).join('');
}
async function createAppBackup(){
showProgress('正在备份应用列表');
try{
setProgress(20,'扫描已安装应用...');await sleep(500);
setProgress(50,'获取应用信息...');await sleep(500);
setProgress(80,'生成备份文件...');
const res=await fetch('/api/app/backup/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:'',include_apk:false})});
const data=await res.json();
setProgress(100,'备份完成');await sleep(300);
hideProgress();
if(data.success){
showToast('应用备份成功，共 '+data.backup.app_count+' 个应用','success');
loadAppBackupList();
}else{
showToast('备份失败','error');
}
}catch(e){hideProgress();alert('备份失败：'+e.message);}
}
async function deleteAppBackup(id){
if(!confirm('确定删除此备份？'))return;
showProgress('正在删除应用备份');
try{
setProgress(30,'删除备份文件...');await sleep(300);
setProgress(70,'清理记录...');
await fetch('/api/app/backup/delete?id='+id);
setProgress(100,'删除完成');await sleep(300);
hideProgress();
loadAppBackupList();
showToast('已删除','success');
}catch(e){hideProgress();alert('删除失败：'+e.message);}
}
async function restoreAppBackup(id){
const res=await fetch('/api/app/backup/detail?id='+id);
const data=await res.json();
document.getElementById('appRestoreTitle').textContent='恢复应用 - '+data.name;
const list=document.getElementById('appRestoreList');
list.innerHTML=data.apps.map(app=>{
return '<div class="app-item">'+
'<div class="app-item-icon">📱</div>'+
'<div class="app-item-info">'+
'<div class="app-item-name">'+app.app_name+'</div>'+
'<div class="app-item-pkg">'+app.package_name+'</div>'+
'<div class="app-item-version">v'+app.version_name+'</div>'+
'</div>'+
'<div class="app-item-actions">'+
'<button class="app-download-btn play" onclick="openAppStore(\''+app.package_name+'\')">应用商店</button>'+
'<button class="app-download-btn browser" onclick="openBrowserDownload(\''+app.package_name+'\')">浏览器</button>'+
'</div></div>';
}).join('');
document.getElementById('appRestoreModal').style.display='flex';
}
async function loadInstalledApps(){
document.getElementById('installedAppsSection').style.display='block';
showToast('正在获取已安装应用...','info');
const res=await fetch('/api/app/installed');
const data=await res.json();
const list=document.getElementById('installedAppsList');
list.innerHTML=data.apps.map(app=>{
return '<div class="app-item">'+
'<div class="app-item-icon">📱</div>'+
'<div class="app-item-info">'+
'<div class="app-item-name">'+app.app_name+'</div>'+
'<div class="app-item-pkg">'+app.package_name+'</div>'+
'<div class="app-item-version">v'+app.version_name+'</div>'+
'</div>'+
'<div class="app-item-actions">'+
'<button class="app-download-btn play" onclick="openAppStore(\''+app.package_name+'\')">商店</button>'+
'<button class="app-download-btn browser" onclick="openBrowserDownload(\''+app.package_name+'\')">下载</button>'+
'</div></div>';
}).join('');
}
function openAppStore(pkg){
// 尝试多个应用商店
const stores=[
'market://details?id='+pkg,
'mimarket://details?id='+pkg,
'oppomarket://details?pkg_name='+pkg,
'coolmarket://apk/'+pkg
];
// 优先使用 Google Play
window.location.href=stores[0];
setTimeout(()=>{window.location.href=stores[1];},500);
setTimeout(()=>{window.location.href=stores[2];},1000);
}
function openBrowserDownload(pkg){
// 打开 APKPure 下载页面
window.open('https://apkpure.com/cn/android/'+pkg,'_blank');
}
function restoreAllApps(type){
const items=document.querySelectorAll('#appRestoreList .app-item');
let delay=0;
items.forEach((item,index)=>{
const pkg=item.querySelector('.app-item-pkg').textContent;
setTimeout(()=>{
if(type==='play'){
openAppStore(pkg);
}else{
openBrowserDownload(pkg);
}
},delay);
delay+=2000;
});
showToast('正在依次打开下载页面...','info');
}

// ===== 组网设置 =====
async function loadNetworkStatus(){
const res=await fetch('/api/network/status');
const data=await res.json();
const s=data.status;
let html='<div class="stat-cards">';
html+='<div class="stat-card"><div class="num" style="color:'+(s.connected?'#27ae60':'#e74c3c')+'">'+(s.connected?'已连接':'未连接')+'</div><div class="label">连接状态</div></div>';
html+='<div class="stat-card"><div class="num">'+(s.device_ip||'—')+'</div><div class="label">组网 IP</div></div>';
html+='<div class="stat-card"><div class="num">'+(s.peers?s.peers.length:0)+'</div><div class="label">在线设备</div></div>';
html+='</div>';
if(s.peers&&s.peers.length>0){
html+='<div style="margin-top:12px"><h4 style="font-size:14px;margin-bottom:8px">设备列表</h4><div class="file-list">';
s.peers.forEach(p=>{
html+='<div class="file-item"><span class="file-icon">'+(p.online?'🟢':'⚫')+'</span>'+
'<span class="file-name">'+p.name+'</span><span class="file-size">'+p.ip+'</span>'+
'<span class="file-time">'+(p.os||'')+'</span></div>';
});
html+='</div></div>';
}
if(s.error){html+='<div style="margin-top:12px;padding:10px;background:#f8d7da;color:#721c24;border-radius:6px;font-size:13px">'+s.error+'</div>';}
document.getElementById('networkStatus').innerHTML=html;
}
async function joinNetwork(){
const provider=document.getElementById('netProvider').value;
const authKey=document.getElementById('netAuthKey').value.trim();
if(provider!=='n2n'&&!authKey){showToast('请输入认证密钥','error');return;}
showToast('正在加入组网...','info');
const res=await fetch('/api/network/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({provider,auth_key:authKey})});
const data=await res.json();
if(data.success)showToast('组网加入成功','success');else showToast('加入失败: '+(data.error||'未知错误'),'error');
loadNetworkStatus();
}
async function leaveNetwork(){
if(!confirm('确定断开组网连接？'))return;
await fetch('/api/network/leave',{method:'POST'});
showToast('已断开','info');loadNetworkStatus();
}
function toggleN2NConfig(){
const provider=document.getElementById('netProvider').value;
document.getElementById('n2nConfig').style.display=provider==='n2n'?'block':'none';
}
function downloadN2NConfig(){
const config='# n2n 配置（导入 Hin2n App 使用）\n'+
'supernode = '+document.getElementById('n2nSupernode').value+'\n'+
'community = '+document.getElementById('n2nCommunity').value+'\n'+
'encryptkey = '+document.getElementById('n2nKey').value+'\n'+
'ipaddr = '+document.getElementById('n2nIP').value+'\n'+
'netmask = 255.255.255.0\n';
const blob=new Blob([config],{type:'text/plain'});
const url=URL.createObjectURL(blob);
const a=document.createElement('a');
a.href=url;a.download='n2n.conf';a.click();
URL.revokeObjectURL(url);
showToast('配置已下载，导入 Hin2n App 即可','success');
}

// ===== 通用 =====
function showToast(msg,type){
const t=document.createElement('div');
t.className='toast '+type;t.textContent=msg;
document.body.appendChild(t);
setTimeout(()=>t.remove(),3000);
}
async function logout(){await fetch('/api/logout',{method:'POST'});location.reload();}

// ===== 主题切换 =====
function toggleTheme(){
document.body.classList.toggle('dark');
const isDark=document.body.classList.contains('dark');
document.getElementById('themeBtn').textContent=isDark?'☀️':'🌙';
localStorage.setItem('nas-theme',isDark?'dark':'light');
}
// 加载主题
if(localStorage.getItem('nas-theme')==='dark'){
document.body.classList.add('dark');
document.getElementById('themeBtn').textContent='☀️';
}

// ===== 图标大小调节 =====
function updateIconSize(value){
const canvas=parseInt(value);
const body=Math.round(canvas*0.8);
document.documentElement.style.setProperty('--icon-canvas',canvas+'px');
document.documentElement.style.setProperty('--icon-body',body+'px');
// 更新显示
document.getElementById('canvasSize').textContent=canvas;
document.getElementById('canvasSize2').textContent=canvas;
document.getElementById('iconSize').textContent=body;
document.getElementById('iconSize2').textContent=body;
// 档位标签
let label='M（中等）';
if(canvas<=50)label='极小';
else if(canvas<=96)label='XS（最小）';
else if(canvas<=108)label='S（小）';
else if(canvas<=120)label='M（中等）';
else if(canvas<=132)label='L（大）';
else label='XL（最大）';
document.getElementById('currentSizeLabel').textContent=label;
// 保存
localStorage.setItem('nas-icon-size',canvas);
}
function setIconSize(value){
document.getElementById('iconSizeSlider').value=value;
updateIconSize(value);
}
// 加载保存的图标大小
const savedIconSize=localStorage.getItem('nas-icon-size');
if(savedIconSize){
document.documentElement.style.setProperty('--icon-canvas',savedIconSize+'px');
document.documentElement.style.setProperty('--icon-body',Math.round(savedIconSize*0.8)+'px');
}

// ===== 消息通知 =====
function toggleNotificationPanel(){
notificationPanelOpen=!notificationPanelOpen;
const panel=document.getElementById('notificationPanel');
const overlay=document.getElementById('notificationOverlay');
if(notificationPanelOpen){
panel.style.display='block';
overlay.style.display='block';
setTimeout(()=>{panel.style.transform='translateX(0)';},10);
loadNotifications();
}else{
panel.style.transform='translateX(100%)';
overlay.style.display='none';
setTimeout(()=>{panel.style.display='none';},300);
// 关闭后强制重排，防止图标变大
window.dispatchEvent(new Event('resize'));
}
}
async function loadNotifications(){
try{
const res=await fetch('/api/notification/list');
if(!res.ok){
document.getElementById('notificationList').innerHTML='<div class="notify-empty"><div class="notify-empty-icon">❌</div><div>加载失败: '+res.status+'</div></div>';
return;
}
const data=await res.json();
// 更新未读角标
const badge=document.getElementById('notifyBadge');
if(badge){
if(data.unread_count>0){
badge.style.display='flex';
badge.textContent=data.unread_count>99?'99+':data.unread_count;
}else{
badge.style.display='none';
}
}
// 渲染列表
const list=document.getElementById('notificationList');
if(!data.notifications||data.notifications.length===0){
list.innerHTML='<div class="notify-empty"><div class="notify-empty-icon">🔔</div><div>暂无通知</div></div>';
return;
}
const icons={info:'ℹ️',success:'✅',warning:'⚠️',error:'❌'};
const typeColors={info:'#2196f3',success:'#4caf50',warning:'#ff9800',error:'#f44336'};
list.innerHTML=data.notifications.map(n=>{
const safeId=String(n.id).replace(/'/g,"\\'");
const safeTitle=String(n.title||'').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const safeMsg=String(n.message||'').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const icon=icons[n.type]||'📌';
const color=typeColors[n.type]||'#999';
return '<div class="notify-item'+(n.read?'':' unread')+'" onclick="readNotification(\''+safeId+'\')" style="display:flex;gap:12px;padding:12px;border-bottom:1px solid #f0f0f0;cursor:pointer;background:'+(n.read?'#fff':'#f8f9ff')+'">'+
'<div class="notify-icon" style="width:36px;height:36px;border-radius:50%;background:'+color+'15;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">'+icon+'</div>'+
'<div class="notify-content" style="flex:1;min-width:0">'+
'<div class="notify-title" style="font-size:14px;font-weight:600;color:#333;margin-bottom:4px;'+(n.read?'':'color:#1976d2')+'">'+safeTitle+'</div>'+
'<div class="notify-message" style="font-size:12px;color:#666;line-height:1.5;word-break:break-all">'+safeMsg+'</div>'+
'<div class="notify-time" style="font-size:11px;color:#999;margin-top:6px">'+formatTimeAgo(n.created_at)+(n.category?' · '+n.category:'')+'</div>'+
'</div>'+
(n.read?'':'<div style="width:8px;height:8px;border-radius:50%;background:#ff4757;flex-shrink:0;margin-top:6px"></div>')+
'</div>';
}).join('');
}catch(e){
document.getElementById('notificationList').innerHTML='<div class="notify-empty"><div class="notify-empty-icon">❌</div><div>加载失败: '+e.message+'</div></div>';
}
}
async function readNotification(id){
await fetch('/api/notification/read',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});
loadNotifications();
}
async function markAllRead(){
await fetch('/api/notification/read',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({all:true})});
loadNotifications();
showToast('已全部标记为已读','success');
}
async function clearNotifications(){
if(!confirm('确定清空所有通知？'))return;
await fetch('/api/notification/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({clear:true})});
loadNotifications();
showToast('已清空通知','success');
}
function formatTimeAgo(timeStr){
const date=new Date(timeStr);
const now=new Date();
const diff=now-date;
if(diff<60000)return '刚刚';
if(diff<3600000)return Math.floor(diff/60000)+'分钟前';
if(diff<86400000)return Math.floor(diff/3600000)+'小时前';
return date.toLocaleDateString('zh-CN')+' '+date.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'});
}
// 定时刷新未读数（每30秒）
setInterval(async()=>{
try{
const res=await fetch('/api/notification/list?unread=true');
if(!res.ok)return;
const data=await res.json();
const badge=document.getElementById('notifyBadge');
if(badge){
if(data.unread_count>0){
badge.style.display='flex';
badge.textContent=data.unread_count>99?'99+':data.unread_count;
}else{
badge.style.display='none';
}
}
}catch(e){}
},15000);

// ===== DLNA投屏 =====
let dlnaRunning=false;
async function loadDlnaStatus(){
const res=await fetch('/api/dlna/status');
const data=await res.json();
dlnaRunning=data.running;
// 更新状态
const icon=document.getElementById('dlnaStatusIcon');
const title=document.getElementById('dlnaStatusTitle');
const desc=document.getElementById('dlnaStatusDesc');
const btn=document.getElementById('dlnaToggleBtn');
const infoSection=document.getElementById('dlnaInfoSection');
const mediaSection=document.getElementById('dlnaMediaSection');
const manualSection=document.getElementById('dlnaManualSection');
if(data.running){
icon.textContent='✅';
title.textContent='运行中';
desc.textContent='电视/投影可发现并播放';
btn.textContent='停止服务';
btn.className='btn btn-danger';
infoSection.style.display='block';
manualSection.style.display='block';
document.getElementById('dlnaLocalIP').textContent=data.local_ip||'--';
document.getElementById('dlnaVideoCount').textContent=(data.video_count||0)+' 个';
document.getElementById('dlnaAudioCount').textContent=(data.audio_count||0)+' 个';
document.getElementById('dlnaImageCount').textContent=(data.image_count||0)+' 个';
document.getElementById('dlnaManualURL').textContent=data.manual_url||'--';
// SSDP状态
const ssdpEl=document.getElementById('dlnaSsdpStatus');
if(data.ssdp_ok){
ssdpEl.textContent='正常';
ssdpEl.style.color='#22c55e';
}else{
ssdpEl.textContent='失败（用手动连接）';
ssdpEl.style.color='#ef4444';
}
loadDlnaMedia();
}else{
icon.textContent='📺';
title.textContent='未启动';
desc.textContent='点击下方按钮启动DLNA服务';
btn.textContent='启动服务';
btn.className='btn btn-primary';
infoSection.style.display='none';
manualSection.style.display='none';
}
}
async function toggleDlna(){
if(dlnaRunning){
await fetch('/api/dlna/stop',{method:'POST'});
showToast('DLNA服务已停止','info');
}else{
showToast('正在启动DLNA服务...','info');
const res=await fetch('/api/dlna/start',{method:'POST'});
if(!res.ok){
const err=await res.text();
showToast('启动失败: '+err,'error');
return;
}
showToast('DLNA服务已启动','success');
}
loadDlnaStatus();
}
async function loadDlnaMedia(){
const res=await fetch('/api/dlna/media');
const data=await res.json();
const list=document.getElementById('dlnaMediaList');
if(data.count===0){
list.innerHTML='<div style="text-align:center;color:#999;padding:20px">暂无视频文件</div>';
return;
}
list.innerHTML=data.files.map(f=>{
return '<div class="dlna-media-item">'+
'<div class="dlna-media-icon">🎬</div>'+
'<div class="dlna-media-info">'+
'<div class="dlna-media-name">'+f.Name+'</div>'+
'<div class="dlna-media-size">'+formatSize(f.Size)+'</div>'+
'</div></div>';
}).join('');
}

// ===== 加密存储 =====
let currentEncryptedFolder=null;
let currentEncryptedToken=null;
let currentEncryptedPassword=null;

async function loadEncryptedFolders(){
const res=await fetch('/api/encrypted/folders');
const data=await res.json();
const list=document.getElementById('encryptedFoldersList');
if(data.count===0){
list.innerHTML='<div style="text-align:center;color:#999;padding:40px"><div style="font-size:48px;margin-bottom:12px">🔐</div><div>暂无加密文件夹</div><div style="font-size:12px;margin-top:8px">点击右上角「新建」创建</div></div>';
return;
}
list.innerHTML=data.folders.map(f=>{
return '<div class="enc-folder-card" onclick="openEncryptedFolder(\''+f.id+'\',\''+f.name+'\')">'+
'<div class="enc-folder-icon">🔐</div>'+
'<div class="enc-folder-info">'+
'<div class="enc-folder-name">'+f.name+'</div>'+
'<div class="enc-folder-meta">'+f.file_count+' 个文件 · '+formatSize(f.total_size)+' · '+new Date(f.created_at).toLocaleDateString()+'</div>'+
'</div>'+
'<div class="enc-folder-actions">'+
'<button class="btn btn-danger btn-sm" onclick="event.stopPropagation();deleteEncryptedFolder(\''+f.id+'\',\''+f.name+'\')">删除</button>'+
'</div></div>';
}).join('');
}
function showCreateEncrypted(){
document.getElementById('encFolderName').value='';
document.getElementById('encFolderPassword').value='';
document.getElementById('encFolderPassword2').value='';
document.getElementById('createEncryptedModal').style.display='flex';
}
async function createEncryptedFolder(){
const name=document.getElementById('encFolderName').value.trim();
const pwd=document.getElementById('encFolderPassword').value;
const pwd2=document.getElementById('encFolderPassword2').value;
if(!name){showToast('请输入文件夹名称','error');return;}
if(!pwd||pwd.length<6){showToast('密码至少6位','error');return;}
if(pwd!==pwd2){showToast('两次密码不一致','error');return;}
const res=await fetch('/api/encrypted/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,password:pwd})});
if(!res.ok){const err=await res.text();showToast(err,'error');return;}
document.getElementById('createEncryptedModal').style.display='none';
showToast('加密文件夹创建成功','success');
loadEncryptedFolders();
}
async function deleteEncryptedFolder(id,name){
if(!confirm('确定删除加密文件夹「'+name+'」？所有加密文件将被删除！'))return;
await fetch('/api/encrypted/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});
showToast('已删除','success');
loadEncryptedFolders();
}
function openEncryptedFolder(id,name){
currentEncryptedFolder=id;
document.getElementById('unlockFolderTitle').textContent='解锁：'+name;
document.getElementById('unlockFolderPassword').value='';
document.getElementById('unlockEncryptedModal').style.display='flex';
}
async function unlockEncryptedFolder(){
const pwd=document.getElementById('unlockFolderPassword').value;
if(!pwd){showToast('请输入密码','error');return;}
const res=await fetch('/api/encrypted/unlock',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:currentEncryptedFolder,password:pwd})});
if(!res.ok){showToast('密码错误','error');return;}
const data=await res.json();
currentEncryptedToken=data.token;
currentEncryptedPassword=pwd;
document.getElementById('unlockEncryptedModal').style.display='none';
document.getElementById('encryptedFilesTitle').textContent='加密文件';
document.getElementById('encryptedFilesModal').style.display='flex';
loadEncryptedFiles();
}
function closeEncryptedFiles(){
document.getElementById('encryptedFilesModal').style.display='none';
currentEncryptedFolder=null;
currentEncryptedToken=null;
currentEncryptedPassword=null;
}
async function loadEncryptedFiles(){
const res=await fetch('/api/encrypted/files?id='+currentEncryptedFolder+'&token='+currentEncryptedToken);
if(!res.ok){showToast('会话已过期，请重新解锁','error');closeEncryptedFiles();return;}
const data=await res.json();
const list=document.getElementById('encryptedFilesList');
if(data.count===0){
list.innerHTML='<div style="text-align:center;color:#999;padding:20px">暂无文件，点击上方上传</div>';
return;
}
list.innerHTML=data.files.map(f=>{
return '<div class="enc-file-item">'+
'<div class="enc-file-icon">📄</div>'+
'<div class="enc-file-info">'+
'<div class="enc-file-name">'+f.name+'</div>'+
'<div class="enc-file-meta">'+formatSize(f.size)+' · '+new Date(f.time).toLocaleString()+'</div>'+
'</div>'+
'<div style="display:flex;gap:6px">'+
'<button class="btn btn-primary btn-sm" onclick="downloadEncryptedFile(\''+f.name+'\')">下载</button>'+
'<button class="btn btn-danger btn-sm" onclick="deleteEncryptedFile(\''+f.name+'\')">删除</button>'+
'</div></div>';
}).join('');
}
async function uploadEncryptedFile(){
const input=document.getElementById('encFileInput');
if(!input.files[0])return;
const formData=new FormData();
formData.append('file',input.files[0]);
showToast('正在加密上传...','info');
const res=await fetch('/api/encrypted/upload?id='+currentEncryptedFolder+'&token='+currentEncryptedToken+'&password='+encodeURIComponent(currentEncryptedPassword),{method:'POST',body:formData});
if(!res.ok){showToast('上传失败','error');return;}
showToast('加密上传成功','success');
input.value='';
loadEncryptedFiles();
}
function downloadEncryptedFile(filename){
window.open('/api/encrypted/download?id='+currentEncryptedFolder+'&token='+currentEncryptedToken+'&file='+encodeURIComponent(filename)+'&password='+encodeURIComponent(currentEncryptedPassword));
}
async function deleteEncryptedFile(filename){
if(!confirm('确定删除此加密文件？'))return;
await fetch('/api/encrypted/delete-file',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:currentEncryptedFolder,filename,token:currentEncryptedToken})});
showToast('已删除','success');
loadEncryptedFiles();
}

// ===== 加密空间 - 简洁稳定版 =====
let vaultUnlocked=false;
let vaultSecret='';

async function loadVaultStatus(){
try{
const res=await fetch('/api/vault/status');
const data=await res.json();
vaultUnlocked=data.unlocked;
document.getElementById('vaultNotInit').style.display=data.enabled?'none':'block';
document.getElementById('vaultLocked').style.display=(data.enabled&&!data.unlocked)?'block':'none';
document.getElementById('vaultUnlocked').style.display=(data.enabled&&data.unlocked)?'block':'none';
const patternTab=document.querySelector('#vaultLocked .vault-tab[data-method="pattern"]');
if(patternTab)patternTab.style.display=data.has_pattern?'flex':'none';
if(data.unlocked)loadVaultFiles();
}catch(e){
console.error('加载加密空间状态失败:',e);
}
}

// ===== 加密空间图案密码支持 =====
let vaultInitMethod='password';
let vaultUnlockMethod='password';
let initPatternValue='';
let unlockPatternValue='';
let initPatternLockInited=false;
let unlockPatternLockInited=false;

function switchVaultInitMethod(method){
vaultInitMethod=method;
document.querySelectorAll('#vaultNotInit .vault-tab').forEach(t=>t.classList.toggle('active',t.dataset.method===method));
document.getElementById('initPasswordPanel').style.display=method==='password'?'block':'none';
document.getElementById('initPatternPanel').style.display=method==='pattern'?'block':'none';
if(method==='pattern'&&!initPatternLockInited){
initPatternLockInited=true;
setTimeout(()=>{initPatternLock('initPatternLock',(pattern)=>{
initPatternValue=pattern.join('-');
console.log('[VAULT] 初始化图案:',initPatternValue,'点数:',pattern.length);
document.getElementById('initPatternHint').textContent='已设置图案（'+pattern.length+'个点）';
});},100);
}
}

function switchVaultUnlockMethod(method){
vaultUnlockMethod=method;
document.querySelectorAll('#vaultLocked .vault-tab').forEach(t=>t.classList.toggle('active',t.dataset.method===method));
document.getElementById('unlockPasswordPanel').style.display=method==='password'?'block':'none';
document.getElementById('unlockPatternPanel').style.display=method==='pattern'?'block':'none';
if(method==='pattern'&&!unlockPatternLockInited){
unlockPatternLockInited=true;
setTimeout(()=>{initPatternLock('unlockPatternLock',(pattern)=>{
unlockPatternValue=pattern.join('-');
console.log('[VAULT] 解锁图案:',unlockPatternValue,'点数:',pattern.length);
document.getElementById('unlockPatternHint').textContent='已绘制图案，点击解锁';
});},100);
}
}

// vault-tab激活样式
const vaultTabStyle=document.createElement('style');
vaultTabStyle.textContent='.vault-tab.active{background:linear-gradient(135deg,#667eea,#764ba2)!important;color:#fff!important;border-color:transparent!important}';
document.head.appendChild(vaultTabStyle);
async function simpleInitVault(){
let password='',pattern='';
if(vaultInitMethod==='password'){
password=document.getElementById('initPassword').value;
const pwd2=document.getElementById('initPassword2').value;
if(!password||password.length<6){alert('密码至少6位');return;}
if(password!==pwd2){alert('两次密码不一致');return;}
}else{
pattern=initPatternValue;
if(!pattern||pattern.split('-').length<4){alert('图案至少连接4个点');return;}
}
const btn=event.target;
const oldText=btn.textContent;
btn.textContent='初始化中...';
btn.disabled=true;
addLog('INFO','加密空间','初始化','开始初始化，方式: '+(password?'密码':'图案'));
try{
const body={};
if(password)body.password=password;
if(pattern)body.pattern=pattern;
const res=await fetch('/api/vault/init',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
if(res.status===401){alert('登录已过期，请重新登录');window.location.reload();return;}
if(!res.ok){
const err=await res.text();
addLog('ERROR','加密空间','初始化','失败: HTTP '+res.status+' '+err);
logError('加密空间','初始化失败','方式: '+(password?'密码':'图案')+'\nHTTP状态: '+res.status+'\n错误: '+err);
updateErrorLogBadge();
if(err.includes('已初始化')){alert('加密空间已初始化，请直接用密码解锁');await loadVaultStatus();return;}
alert('创建失败：HTTP '+res.status+'\n'+err);return;
}
const data=await res.json();
if(!data.success){
addLog('ERROR','加密空间','初始化','失败: 返回success=false');
logError('加密空间','初始化失败','返回success=false');
updateErrorLogBadge();
alert('创建失败');return;
}
addLog('INFO','加密空间','初始化','成功');
vaultSecret=password||pattern;
vaultUnlocked=true;
document.getElementById('initPassword').value='';
document.getElementById('initPassword2').value='';
initPatternValue='';
// 直接切换到已解锁界面，不需要再次解锁
document.getElementById('vaultNotInit').style.display='none';
document.getElementById('vaultLocked').style.display='none';
document.getElementById('vaultUnlocked').style.display='block';
loadVaultFiles();
alert('加密空间创建成功！\n'+(password?'密码：'+password:'图案已设置')+'\n请牢记，丢失无法找回');
}catch(e){alert('创建异常：'+e.message);}finally{btn.textContent=oldText;btn.disabled=false;}
}
async function simpleUnlockVault(){
let password='',pattern='';
if(vaultUnlockMethod==='password'){
password=document.getElementById('unlockPassword').value;
if(!password){alert('请输入密码');return;}
}else{
pattern=unlockPatternValue;
console.log('[VAULT] 尝试图案解锁，图案值:',pattern);
if(!pattern){alert('请绘制图案');return;}
if(pattern.split('-').length<4){alert('图案至少连接4个点');return;}
}
try{
const body={};
if(password)body.password=password;
if(pattern)body.pattern=pattern;
addLog('INFO','加密空间','解锁','开始解锁，方式: '+(password?'密码':'图案'));
console.log('[VAULT] 发送解锁请求:',JSON.stringify(body));
const res=await fetch('/api/vault/unlock',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
console.log('[VAULT] 解锁响应状态:',res.status);
if(!res.ok){
const err=await res.text();
console.error('[VAULT] 解锁失败:',res.status,err);
addLog('ERROR','加密空间','解锁','失败: HTTP '+res.status+' '+err);
logError('加密空间','解锁失败','方式: '+(password?'密码':'图案')+'\nHTTP状态: '+res.status+'\n错误: '+err);
updateErrorLogBadge();
alert((vaultUnlockMethod==='password'?'密码错误':'图案错误')+'\n'+err+'\n\n提示：如果初始化时使用的是密码，请切换到密码标签解锁');
return;
}
const data=await res.json();
console.log('[VAULT] 解锁成功:',JSON.stringify(data));
addLog('INFO','加密空间','解锁','成功');
vaultSecret=password||pattern;
vaultUnlocked=true;
document.getElementById('unlockPassword').value='';
unlockPatternValue='';
document.getElementById('vaultNotInit').style.display='none';
document.getElementById('vaultLocked').style.display='none';
document.getElementById('vaultUnlocked').style.display='block';
loadVaultFiles();
}catch(e){
console.error('[VAULT] 解锁异常:',e);
if(debugDiv){debugDiv.textContent='解锁异常: '+e.message;debugDiv.style.display='block';}
alert('解锁异常：'+e.message);
}
}
function simpleLockVault(){
fetch('/api/vault/lock',{method:'POST'});
vaultUnlocked=false;
vaultSecret='';
loadVaultStatus();
}
let currentVaultCat='all';
function switchVaultCat(cat){
openVaultCategory(cat);
}
async function loadVaultFiles(){
try{
const res=await fetch('/api/vault/files');
if(!res.ok)return;
const data=await res.json();
const allFiles=data.files;
// 更新分类统计（添加null检查，避免元素不存在导致错误）
const cats={all:allFiles,image:[],video:[],audio:[],other:[]};
allFiles.forEach(f=>{
if(cats[f.type])cats[f.type].push(f);
else cats.other.push(f);
});
const setVaultText=function(id,text){const el=document.getElementById(id);if(el)el.textContent=text;};
setVaultText('vaultAllCount',cats.all.length);
setVaultText('vaultAllSize',formatSize(cats.all.reduce((s,f)=>s+f.size,0)));
setVaultText('vaultImageCount',cats.image.length);
setVaultText('vaultImageSize',formatSize(cats.image.reduce((s,f)=>s+f.size,0)));
setVaultText('vaultVideoCount',cats.video.length);
setVaultText('vaultVideoSize',formatSize(cats.video.reduce((s,f)=>s+f.size,0)));
setVaultText('vaultAudioCount',cats.audio.length);
setVaultText('vaultAudioSize',formatSize(cats.audio.reduce((s,f)=>s+f.size,0)));
setVaultText('vaultOtherCount',cats.other.length);
setVaultText('vaultOtherSize',formatSize(cats.other.reduce((s,f)=>s+f.size,0)));
// 如果在分类浏览界面，加载对应分类的文件
if(document.getElementById('vaultCategoryView').style.display!=='none'){
let files=[];
if(currentVaultCat==='all'){
files=allFiles;
}else if(currentVaultCat==='other'){
files=allFiles.filter(f=>!['image','video','audio'].includes(f.type));
}else{
files=allFiles.filter(f=>f.type===currentVaultCat);
}
renderVaultFileGrid(files);
}
}catch(e){
console.error('加载加密文件失败:',e);
}
}

function renderVaultFileGrid(files){
const list=document.getElementById('vaultFileList');
if(files.length===0){
list.style.display='block';
list.innerHTML='<div style="text-align:center;color:#999;padding:60px 20px"><div style="font-size:48px;margin-bottom:12px">📁</div>暂无文件<br><br>点击右上角「添加」导入</div>';
return;
}
list.style.display='grid';
list.innerHTML=files.map(f=>{
const thumbUrl='/api/vault/preview?id='+f.id+'&secret='+encodeURIComponent(vaultSecret);
let content='';
if(f.type==='image'){
content='<img src="'+thumbUrl+'" style="width:100%;height:100%;object-fit:cover;position:absolute;top:0;left:0" onerror="this.style.display=\'none\';this.parentNode.querySelector(\'.vault-fallback\').style.display=\'flex\'">';
}else if(f.type==='video'){
content='<img src="'+thumbUrl+'" style="width:100%;height:100%;object-fit:cover;position:absolute;top:0;left:0" onerror="this.style.display=\'none\';this.parentNode.querySelector(\'.vault-fallback\').style.display=\'flex\'">'+
'<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:36px;height:36px;background:rgba(0,0,0,.6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:16px;color:#fff">▶</div>';
}else{
const icon=f.type==='audio'?'🎵':'📄';
content='<div class="vault-fallback" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:32px;background:#f5f5f5">'+icon+'</div>';
}
return '<div style="position:relative;aspect-ratio:1;border-radius:12px;overflow:hidden;background:#f5f5f5;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.06)" onclick="previewVaultFile(\''+f.id+'\',\''+f.type+'\',\''+encodeURIComponent(f.name)+'\')">'+
content+
'<div class="vault-fallback" style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:32px;background:#f5f5f5;position:absolute;top:0;left:0">'+(f.type==='image'?'🖼️':f.type==='video'?'🎬':f.type==='audio'?'🎵':'📄')+'</div>'+
'<button onclick="event.stopPropagation();showVaultFileMenu(\''+f.id+'\',\''+f.type+'\',\''+encodeURIComponent(f.name)+'\',\''+f.size+'\')" style="position:absolute;top:4px;right:4px;width:24px;height:24px;background:rgba(0,0,0,.5);border:none;border-radius:50%;color:#fff;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0">⋯</button>'+
'<div style="position:absolute;bottom:0;left:0;right:0;background:linear-gradient(transparent,rgba(0,0,0,.7));padding:16px 8px 6px">'+
'<div style="font-size:11px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+f.name+'</div>'+
'</div>'+
'</div>';
}).join('');
}

function openVaultCategory(cat){
currentVaultCat=cat;
const titles={all:'全部文件',image:'图片',video:'视频',audio:'音乐',other:'文档'};
document.getElementById('vaultCategoryTitle').textContent=titles[cat];
document.getElementById('vaultHome').style.display='none';
document.getElementById('vaultCategoryView').style.display='block';
loadVaultFiles();
}

function backToVaultHome(){
document.getElementById('vaultHome').style.display='block';
document.getElementById('vaultCategoryView').style.display='none';
}

// ===== 加密空间文件操作菜单 =====
let currentVaultFile=null;
function showVaultFileMenu(id,type,nameEnc,size){
currentVaultFile={id:id,type:type,name:decodeURIComponent(nameEnc),size:parseInt(size)};
const name=currentVaultFile.name;
const isText=['text','document','other'].includes(type)||name.match(/\.(txt|md|json|xml|html|css|js|py|java|c|cpp|go|rs|php|sql|yaml|yml|conf|log|csv)$/i);
const menu=[
'<div style="padding:16px;border-bottom:1px solid #eee">',
'<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:4px;word-break:break-all">'+name+'</div>',
'<div style="font-size:12px;color:#999">'+formatSize(size)+' · '+type+'</div>',
'</div>',
'<div style="padding:8px">',
'<button class="btn btn-block" onclick="vaultFilePreview()" style="justify-content:flex-start;margin-bottom:4px">▶️ 打开/预览</button>',
'<button class="btn btn-block" onclick="vaultFileDetail()" style="justify-content:flex-start;margin-bottom:4px">ℹ️ 文件详情</button>',
'<button class="btn btn-block" onclick="vaultFileShare()" style="justify-content:flex-start;margin-bottom:4px">🔗 分享链接</button>',
'<button class="btn btn-block" onclick="vaultFileOpenWith()" style="justify-content:flex-start;margin-bottom:4px">📤 其他应用打开</button>',
isText?'<button class="btn btn-block" onclick="vaultFileEdit()" style="justify-content:flex-start;margin-bottom:4px">✏️ 编辑文件</button>':'',
'<button class="btn btn-block" onclick="vaultFileRepair()" style="justify-content:flex-start;margin-bottom:4px">🔧 修复文件</button>',
'<button class="btn btn-block" onclick="vaultFileExport()" style="justify-content:flex-start;margin-bottom:4px">📥 导出到存储</button>',
'<button class="btn btn-danger btn-block" onclick="vaultFileDelete()" style="justify-content:flex-start">🗑️ 删除文件</button>',
'</div>'
].join('');
showModal('文件操作',menu,'400px');
}

function vaultFilePreview(){
closeModal();
if(currentVaultFile){
previewVaultFile(currentVaultFile.id,currentVaultFile.type,encodeURIComponent(currentVaultFile.name));
}
}

async function vaultFileDetail(){
if(!currentVaultFile)return;
try{
const res=await fetch('/api/vault/file-detail?id='+currentVaultFile.id);
const data=await res.json();
if(data.success){
const f=data.file;
const html='<div style="padding:16px">'+
'<div style="margin-bottom:12px"><span style="color:#999">文件名：</span><span style="color:#333;word-break:break-all">'+f.name+'</span></div>'+
'<div style="margin-bottom:12px"><span style="color:#999">文件ID：</span><span style="color:#333">'+f.id+'</span></div>'+
'<div style="margin-bottom:12px"><span style="color:#999">文件类型：</span><span style="color:#333">'+f.type+'</span></div>'+
'<div style="margin-bottom:12px"><span style="color:#999">原始大小：</span><span style="color:#333">'+formatSize(f.size)+'</span></div>'+
'<div style="margin-bottom:12px"><span style="color:#999">加密大小：</span><span style="color:#333">'+formatSize(f.encrypted_size||f.size)+'</span></div>'+
'<div style="margin-bottom:12px"><span style="color:#999">加密算法：</span><span style="color:#333">AES-256-GCM</span></div>'+
'<div style="margin-bottom:12px"><span style="color:#999">创建时间：</span><span style="color:#333">'+f.created_at+'</span></div>'+
'<div style="margin-bottom:12px"><span style="color:#999">加密文件名：</span><span style="color:#333;font-size:12px">'+f.enc_name+'</span></div>'+
'</div>';
showModal('文件详情',html,'450px');
}else{
alert('获取详情失败: '+(data.error||'未知错误'));
}
}catch(e){alert('获取详情异常: '+e.message);}
}

async function vaultFileShare(){
if(!currentVaultFile)return;
try{
const res=await fetch('/api/vault/share/create',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({file_id:currentVaultFile.id,expire_hours:24})
});
const data=await res.json();
if(data.success){
const url=location.origin+'/share/'+data.share_id;
const html='<div style="padding:16px;text-align:center">'+
'<div style="font-size:14px;color:#666;margin-bottom:12px">分享链接已生成（24小时有效）</div>'+
'<div style="background:#f5f5f5;padding:12px;border-radius:8px;word-break:break-all;font-size:12px;color:#333;margin-bottom:16px">'+url+'</div>'+
'<button class="btn btn-primary btn-block" onclick="navigator.clipboard.writeText(\''+url+'\').then(()=>alert(\'已复制到剪贴板\'))">复制链接</button>'+
'</div>';
showModal('分享成功',html,'400px');
}else{
alert('创建分享失败: '+(data.error||'未知错误'));
}
}catch(e){alert('创建分享异常: '+e.message);}
}

async function vaultFileOpenWith(){
if(!currentVaultFile)return;
try{
const res=await fetch('/api/vault/temp-link',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({file_id:currentVaultFile.id,expire_minutes:10})
});
const data=await res.json();
if(data.success){
const url=location.origin+data.url;
const html='<div style="padding:16px;text-align:center">'+
'<div style="font-size:14px;color:#666;margin-bottom:12px">临时链接已生成（10分钟有效）</div>'+
'<div style="background:#f5f5f5;padding:12px;border-radius:8px;word-break:break-all;font-size:12px;color:#333;margin-bottom:16px">'+url+'</div>'+
'<button class="btn btn-primary btn-block" onclick="window.open(\''+url+'\',\'_blank\')">在浏览器打开</button>'+
'<div style="margin-top:8px;font-size:12px;color:#999">复制链接到其他应用打开</div>'+
'</div>';
showModal('其他应用打开',html,'400px');
}else{
alert('生成临时链接失败: '+(data.error||'未知错误'));
}
}catch(e){alert('生成临时链接异常: '+e.message);}
}

async function vaultFileEdit(){
if(!currentVaultFile)return;
try{
const url='/api/vault/preview?id='+currentVaultFile.id+'&secret='+encodeURIComponent(vaultSecret);
const res=await fetch(url);
const text=await res.text();
const html='<div style="padding:16px">'+
'<div style="font-size:14px;color:#666;margin-bottom:8px">编辑：'+currentVaultFile.name+'</div>'+
'<textarea id="vaultEditArea" style="width:100%;height:300px;padding:12px;border:1px solid #ddd;border-radius:8px;font-family:monospace;font-size:13px;resize:vertical">'+text.replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</textarea>'+
'<div style="margin-top:12px;text-align:right">'+
'<button class="btn" onclick="closeModal()" style="margin-right:8px">取消</button>'+
'<button class="btn btn-primary" onclick="saveVaultEdit()">保存</button>'+
'</div></div>';
showModal('编辑文件',html,'500px');
}catch(e){alert('加载文件异常: '+e.message);}
}

async function saveVaultEdit(){
if(!currentVaultFile)return;
const content=document.getElementById('vaultEditArea').value;
try{
const res=await fetch('/api/vault/save-file',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({file_id:currentVaultFile.id,content:content})
});
const data=await res.json();
if(data.success){
alert('保存成功');
closeModal();
loadVaultFiles();
}else{
alert('保存失败: '+(data.error||'未知错误'));
}
}catch(e){alert('保存异常: '+e.message);}
}

async function vaultFileRepair(){
if(!currentVaultFile)return;
if(!confirm('确定要修复这个文件吗？\n\n修复将尝试重建加密文件头和校验和，可能恢复损坏的文件。'))return;
try{
const res=await fetch('/api/vault/repair-file',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({file_id:currentVaultFile.id})
});
const data=await res.json();
if(data.success){
alert('修复成功！\n\n修复详情：\n'+(data.message||'文件已修复'));
loadVaultFiles();
}else{
alert('修复失败: '+(data.error||'未知错误'));
}
}catch(e){alert('修复异常: '+e.message);}
}

function vaultFileExport(){
if(!currentVaultFile)return;
closeModal();
exportVaultFile(currentVaultFile.id,encodeURIComponent(currentVaultFile.name));
}

function vaultFileDelete(){
if(!currentVaultFile)return;
closeModal();
deleteVaultFile(currentVaultFile.id,encodeURIComponent(currentVaultFile.name));
}

async function simpleUploadVault(){
const input=document.getElementById('vaultFileInput');
if(!input.files||input.files.length===0)return;
for(const file of input.files){
const formData=new FormData();
formData.append('file',file);
formData.append('secret',vaultSecret);
await fetch('/api/vault/upload',{method:'POST',body:formData});
}
input.value='';
loadVaultFiles();
alert('上传完成');
}
async function previewVaultFile(id,type,nameEnc){
const name=decodeURIComponent(nameEnc);
const url='/api/vault/preview?id='+id+'&secret='+encodeURIComponent(vaultSecret);
if(type==='video'){
openVideoPlayer(name,url);
}else if(type==='image'){
// 进入图片浏览器，左右滑动浏览所有图片
openVaultImageViewer(id);
}else if(type==='audio'){
playAudio(name,url);
}else{
// 文档类型，进入文档查看器
openVaultDocumentViewer(id,name,url);
}
}

// 加密空间图片浏览器 - 支持左右滑动
let vaultImageList=[];
let vaultImageIndex=0;
async function openVaultImageViewer(currentId){
try{
const res=await fetch('/api/vault/files');
const data=await res.json();
// 筛选所有图片
vaultImageList=data.files.filter(f=>f.type==='image');
if(vaultImageList.length===0){alert('没有图片');return;}
// 找到当前图片的索引
vaultImageIndex=vaultImageList.findIndex(f=>f.id===currentId);
if(vaultImageIndex<0)vaultImageIndex=0;
showVaultImage();
document.getElementById('imageModal').classList.add('active');
// 绑定触摸滑动
const wrap=document.getElementById('imgWrap');
wrap.ontouchstart=function(e){touchStartX=e.touches[0].clientX;};
wrap.ontouchend=function(e){
const diff=e.changedTouches[0].clientX-touchStartX;
if(Math.abs(diff)>50){
if(diff>0&&vaultImageIndex>0){vaultImageIndex--;showVaultImage();}
else if(diff<0&&vaultImageIndex<vaultImageList.length-1){vaultImageIndex++;showVaultImage();}
}
};
}catch(e){alert('加载图片列表失败: '+e.message);}
}
function showVaultImage(){
const f=vaultImageList[vaultImageIndex];
const url='/api/vault/preview?id='+f.id+'&secret='+encodeURIComponent(vaultSecret);
const img=document.getElementById('imageViewer');
img.style.transform='scale(1) rotate(0deg)';
imgScale=1;imgRotation=0;
img.src=url;
img.onload=function(){
document.getElementById('imageMeta').textContent=this.naturalWidth+'×'+this.naturalHeight;
};
document.getElementById('imageTitle').textContent=f.name;
document.getElementById('imgCounter').textContent=(vaultImageIndex+1)+' / '+vaultImageList.length;
document.querySelector('.img-nav.prev').style.display=vaultImageIndex>0?'flex':'none';
document.querySelector('.img-nav.next').style.display=vaultImageIndex<vaultImageList.length-1?'flex':'none';
// 切换按钮事件为加密空间版本
const prevBtn=document.querySelector('.img-nav.prev');
const nextBtn=document.querySelector('.img-nav.next');
if(prevBtn)prevBtn.setAttribute('onclick','event.stopPropagation();prevVaultImage()');
if(nextBtn)nextBtn.setAttribute('onclick','event.stopPropagation();nextVaultImage()');
}
// 加密空间图片浏览器的上下页按钮
function prevVaultImage(){if(vaultImageIndex>0){vaultImageIndex--;showVaultImage();}}
function nextVaultImage(){if(vaultImageIndex<vaultImageList.length-1){vaultImageIndex++;showVaultImage();}}

// 加密空间文档查看器
async function openVaultDocumentViewer(id,name,url){
try{
const res=await fetch(url);
const text=await res.text();
const html='<div style="padding:16px">'+
'<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">'+
'<div style="font-size:15px;font-weight:600;color:#333;word-break:break-all;flex:1">'+name+'</div>'+
'<button class="btn btn-sm btn-primary" onclick="editVaultDoc(\''+id+'\',\''+encodeURIComponent(name)+'\')" style="margin-left:12px">✏️ 编辑</button>'+
'</div>'+
'<div style="background:#f9f9f9;padding:16px;border-radius:12px;max-height:60vh;overflow:auto;font-family:monospace;font-size:13px;line-height:1.6;color:#333;white-space:pre-wrap;word-break:break-all">'+text.replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</div>'+
'</div>';
showModal('文档查看',html,'90%');
}catch(e){alert('加载文档失败: '+e.message);}
}
async function editVaultDoc(id,nameEnc){
const name=decodeURIComponent(nameEnc);
const url='/api/vault/preview?id='+id+'&secret='+encodeURIComponent(vaultSecret);
try{
const res=await fetch(url);
const text=await res.text();
const html='<div style="padding:16px">'+
'<div style="font-size:14px;color:#666;margin-bottom:8px">编辑：'+name+'</div>'+
'<textarea id="vaultDocEditArea" style="width:100%;height:50vh;padding:12px;border:1px solid #ddd;border-radius:8px;font-family:monospace;font-size:13px;resize:vertical;box-sizing:border-box">'+text.replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</textarea>'+
'<div style="margin-top:12px;text-align:right">'+
'<button class="btn" onclick="closeModal()" style="margin-right:8px">取消</button>'+
'<button class="btn btn-primary" onclick="saveVaultDocument(\''+id+'\')">保存</button>'+
'</div></div>';
showModal('编辑文档',html,'90%');
}catch(e){alert('加载文档失败: '+e.message);}
}
async function saveVaultDocument(id){
const content=document.getElementById('vaultDocEditArea').value;
try{
const res=await fetch('/api/vault/save-file',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({file_id:id,content:content})
});
const data=await res.json();
if(data.success){
alert('保存成功');
closeModal();
loadVaultFiles();
}else{
alert('保存失败: '+(data.error||'未知错误'));
}
}catch(e){alert('保存异常: '+e.message);}
}
async function exportVaultFile(id,nameEnc){
const name=decodeURIComponent(nameEnc);
try{
const res=await fetch('/api/vault/export-file',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({file_id:id,secret:vaultSecret})});
if(!res.ok){const err=await res.text();alert('导出失败：'+err);return;}
const data=await res.json();
alert('已导出到：'+data.path);
}catch(e){alert('导出异常：'+e.message);}
}
async function deleteVaultFile(id,nameEnc){
const name=decodeURIComponent(nameEnc);
if(!confirm('确定删除「'+name+'」？'))return;
await fetch('/api/vault/delete-file',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});
loadVaultFiles();
}
async function resetVault(){
if(!confirm('确定重置加密空间？所有加密文件将被删除，无法恢复！'))return;
await fetch('/api/vault/reset',{method:'POST'});
vaultUnlocked=false;
vaultSecret='';
loadVaultStatus();
alert('已重置');
}
let currentVaultTab='all';

function getVaultFileIcon(name,type){
if(type==='video')return '🎬';
if(type==='image')return '🖼️';
if(type==='audio')return '🎵';
const ext=name.split('.').pop().toLowerCase();
const icons={
pdf:'📕',doc:'📘',docx:'📘',xls:'📗',xlsx:'📗',ppt:'📙',pptx:'📙',
txt:'📄',md:'📝',zip:'📦',rar:'📦','7z':'📦',tar:'📦',gz:'📦',
apk:'📱',exe:'💻',go:'🐹',py:'🐍',js:'📜',ts:'📘',java:'☕',
c:'⚙️',cpp:'⚙️',rs:'🦀',html:'🌐',css:'🎨',json:'📋',xml:'📋',
sh:'💻',jpg:'🖼️',jpeg:'🖼️',png:'🖼️',gif:'🖼️',webp:'🖼️',
mp4:'🎬',mkv:'🎬',avi:'🎬',mov:'🎬',mp3:'🎵',flac:'🎵',wav:'🎵',
};
return icons[ext]||'📄';
}
async function shareVaultFile(id,nameEnc){
const name=decodeURIComponent(nameEnc);
const expire=prompt('分享有效期（小时），默认24：','24');
if(expire===null)return;
const pwd=prompt('设置访问密码（留空无密码）：','');
if(pwd===null)return;
showProgress('正在生成分享链接');
try{
setProgress(30,'创建分享令牌...');await sleep(300);
setProgress(60,'生成访问地址...');
const res=await fetch('/api/vault/share/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,password:pwd,expire_hours:parseInt(expire)||24})});
const data=await res.json();
setProgress(100,'生成完成');await sleep(200);
hideProgress();
if(!data.success){showToast('创建分享失败','error');return;}
prompt('分享链接已创建（复制发送给他人）：',data.url);
}catch(e){hideProgress();alert('创建分享失败：'+e.message);}
}
async function renameVaultFile(id,nameEnc){
const oldName=decodeURIComponent(nameEnc);
const newName=prompt('重命名为：',oldName);
if(!newName||newName===oldName)return;
const res=await fetch('/api/vault/rename',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,new_name:newName})});
if(!res.ok){showToast('重命名失败','error');return;}
showToast('已重命名','success');
loadVaultFiles();
}
function openVaultDocEditor(id,name,url){
fetch(url).then(r=>r.text()).then(content=>{
const editor=document.createElement('div');
editor.id='vaultDocEditor';
editor.style.cssText='position:fixed;top:0;left:0;width:100%;height:100%;background:#fff;z-index:3000;display:flex;flex-direction:column';
editor.innerHTML='<div style="display:flex;align-items:center;padding:12px 16px;background:#f8f9fa;border-bottom:1px solid #e0e0e0">'+
'<button onclick="document.getElementById(\'vaultDocEditor\').remove()" style="border:none;background:none;font-size:20px;cursor:pointer">←</button>'+
'<span style="margin-left:12px;font-weight:600">'+name+'</span>'+
'<button onclick="saveVaultDoc(\''+id+'\')" style="margin-left:auto;padding:8px 16px;background:#3d7eff;color:#fff;border:none;border-radius:8px;cursor:pointer">保存</button>'+
'</div>'+
'<textarea id="vaultDocText" style="flex:1;border:none;outline:none;padding:16px;font-family:monospace;font-size:14px;resize:none">'+content.replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</textarea>';
document.body.appendChild(editor);
});
}
async function saveVaultDoc(id){
const content=document.getElementById('vaultDocText').value;
const res=await fetch('/api/vault/save-file',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,content,secret:vaultSecret})});
if(!res.ok){showToast('保存失败','error');return;}
showToast('保存成功，已重新加密','success');
document.getElementById('vaultDocEditor').remove();
loadVaultFiles();
}
function editVaultFile(id,nameEnc,type){
const name=decodeURIComponent(nameEnc);
if(type==='document'&&(name.endsWith('.txt')||name.endsWith('.md')||name.endsWith('.csv'))){
const url='/api/vault/preview?id='+id+'&secret='+encodeURIComponent(vaultSecret);
openVaultDocEditor(id,name,url);
}else{
showToast('此文件类型暂不支持在线编辑，请下载后编辑','info');
}
}
async function openWithOtherApp(id,nameEnc){
const name=decodeURIComponent(nameEnc);
const res=await fetch('/api/vault/temp-link',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,duration_minutes:60})});
const data=await res.json();
if(!data.success){showToast('生成链接失败','error');return;}
prompt('临时链接已生成（60分钟有效，复制到其他应用打开）：',data.url);
}
async function showVaultFileDetail(id){
const res=await fetch('/api/vault/file-detail?id='+id);
const data=await res.json();
const typeNames={video:'视频',image:'图片',audio:'音乐',document:'文档',other:'其他'};
const detail=document.createElement('div');
detail.style.cssText='position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.5);z-index:3000;display:flex;align-items:center;justify-content:center';
detail.onclick=()=>detail.remove();
detail.innerHTML='<div onclick="event.stopPropagation()" style="background:#fff;padding:20px;border-radius:16px;width:90%;max-width:400px;max-height:80vh;overflow-y:auto">'+
'<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">'+
'<h4 style="margin:0">文件详情</h4>'+
'<button onclick="this.closest(\'div\').parentElement.parentElement.remove()" style="border:none;background:none;font-size:20px;cursor:pointer">&times;</button>'+
'</div>'+
'<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">'+
'<div style="background:#f8f9fa;padding:12px;border-radius:8px"><div style="font-size:11px;color:#999">文件名</div><div style="font-size:13px;font-weight:600;word-break:break-all">'+data.origin_name+'</div></div>'+
'<div style="background:#f8f9fa;padding:12px;border-radius:8px"><div style="font-size:11px;color:#999">类型</div><div style="font-size:13px;font-weight:600">'+(typeNames[data.type]||data.type)+'</div></div>'+
'<div style="background:#f8f9fa;padding:12px;border-radius:8px"><div style="font-size:11px;color:#999">原始大小</div><div style="font-size:13px;font-weight:600">'+formatSize(data.size)+'</div></div>'+
'<div style="background:#f8f9fa;padding:12px;border-radius:8px"><div style="font-size:11px;color:#999">加密后大小</div><div style="font-size:13px;font-weight:600">'+formatSize(data.enc_size)+'</div></div>'+
'<div style="background:#f8f9fa;padding:12px;border-radius:8px"><div style="font-size:11px;color:#999">创建时间</div><div style="font-size:13px;font-weight:600">'+new Date(data.created_at).toLocaleString()+'</div></div>'+
'<div style="background:#f8f9fa;padding:12px;border-radius:8px"><div style="font-size:11px;color:#999">修改时间</div><div style="font-size:13px;font-weight:600">'+new Date(data.modified_at).toLocaleString()+'</div></div>'+
'</div>'+
'<div style="background:#f8f9fa;padding:12px;border-radius:8px;margin-top:12px"><div style="font-size:11px;color:#999">SHA-256校验和</div><div style="font-size:11px;font-family:monospace;word-break:break-all">'+data.checksum+'</div></div>'+
'<div style="background:#f8f9fa;padding:12px;border-radius:8px;margin-top:12px"><div style="font-size:11px;color:#999">文件ID</div><div style="font-size:11px;font-family:monospace">'+data.id+'</div></div>'+
'<div style="background:#e8f5e9;padding:12px;border-radius:8px;margin-top:12px"><div style="font-size:11px;color:#2e7d32">加密算法</div><div style="font-size:13px;font-weight:600;color:#2e7d32">AES-256-GCM + SHA-256</div></div>'+
'</div>';
document.body.appendChild(detail);
}
async function repairVaultFile(id,nameEnc){
const name=decodeURIComponent(nameEnc);
if(!confirm('确定尝试修复「'+name+'」？\n\n修复功能会尝试用多种方式解密文件，适用于文件头损坏的情况。'))return;
showToast('正在修复...','info');
const res=await fetch('/api/vault/repair-file',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,secret:vaultSecret})});
const data=await res.json();
if(data.success){
showToast('修复成功','success');
loadVaultFiles();
}else{
showToast('修复失败：'+(data.error||'无法修复'),'error');
}
}

// 从视频/音乐页面访问加密空间
async function openVaultFromVideo(){
const res=await fetch('/api/vault/status');
const data=await res.json();
if(!data.enabled){
showToast('请先初始化加密空间','info');
openPanel('vault');
return;
}
if(!data.unlocked){
showToast('请先解锁加密空间','info');
openPanel('vault');
return;
}
// 显示加密视频
const section=document.getElementById('vaultVideoSection');
section.style.display=section.style.display==='none'?'block':'none';
if(section.style.display==='block'){
loadVaultVideos();
}
}
async function loadVaultVideos(){
const res=await fetch('/api/vault/files?type=video');
if(!res.ok)return;
const data=await res.json();
const grid=document.getElementById('vaultVideoGrid');
if(data.count===0){
grid.innerHTML='<div style="text-align:center;color:#999;padding:20px">暂无加密视频</div>';
return;
}
grid.innerHTML=data.files.map(f=>{
return '<div class="media-item" onclick="openVideoPlayer(\''+f.name+'\',\'/api/vault/preview?id='+f.id+'&secret='+encodeURIComponent(vaultSecret)+'\')">'+
'<div class="media-thumb">🎬</div>'+
'<div class="media-name">'+f.name+'</div>'+
'<div class="media-size">'+formatSize(f.size)+'</div></div>';
}).join('');
}
async function openVaultFromMusic(){
const res=await fetch('/api/vault/status');
const data=await res.json();
if(!data.enabled){
showToast('请先初始化加密空间','info');
openPanel('vault');
return;
}
if(!data.unlocked){
showToast('请先解锁加密空间','info');
openPanel('vault');
return;
}
const section=document.getElementById('vaultMusicSection');
section.style.display=section.style.display==='none'?'block':'none';
if(section.style.display==='block'){
loadVaultMusic();
}
}
async function loadVaultMusic(){
const res=await fetch('/api/vault/files?type=audio');
if(!res.ok)return;
const data=await res.json();
const list=document.getElementById('vaultMusicList');
if(data.count===0){
list.innerHTML='<div style="text-align:center;color:#999;padding:20px">暂无加密音乐</div>';
return;
}
list.innerHTML=data.files.map((f,i)=>{
return '<div class="music-item" onclick="playAudio(\''+f.name+'\',\'/api/vault/preview?id='+f.id+'&secret='+encodeURIComponent(vaultSecret)+'\')">'+
'<div class="music-index">'+(i+1)+'</div>'+
'<div class="music-name">'+f.name+'</div>'+
'<div class="music-duration">'+formatSize(f.size)+'</div></div>';
}).join('');
}
// 更新加密空间按钮显示
async function updateVaultButtons(){
// 加密空间按钮已移除，保留函数兼容
}
async function uploadVaultFile(){
const input=document.getElementById('vaultFileInput');
if(!input.files[0])return;
const formData=new FormData();
formData.append('file',input.files[0]);
showToast('正在加密上传...','info');
const res=await fetch('/api/vault/upload?secret='+encodeURIComponent(vaultSecret),{method:'POST',body:formData});
if(!res.ok){showToast('上传失败','error');return;}
showToast('加密上传成功','success');
input.value='';
loadVaultFiles();
loadVaultStatus();
}

// ===== 图案密码绘制 =====
function initPatternLock(containerId, onComplete){
const container=document.getElementById(containerId);
if(!container)return;
const dots=container.querySelectorAll('.pattern-dot');
let pattern=[];
let isDrawing=false;

function getDotIndex(x,y){
for(let i=0;i<dots.length;i++){
const rect=dots[i].getBoundingClientRect();
const cx=rect.left+rect.width/2;
const cy=rect.top+rect.height/2;
const dist=Math.sqrt((x-cx)**2+(y-cy)**2);
if(dist<rect.width/2+10)return i;
}
return -1;
}

function handleStart(e){
e.preventDefault();
isDrawing=true;
pattern=[];
dots.forEach(d=>d.classList.remove('active'));
handleMove(e);
}
function handleMove(e){
if(!isDrawing)return;
e.preventDefault();
const touch=e.touches?e.touches[0]:e;
const idx=getDotIndex(touch.clientX,touch.clientY);
if(idx>=0&&!pattern.includes(idx)){
pattern.push(idx);
dots[idx].classList.add('active');
}
}
function handleEnd(e){
if(!isDrawing)return;
isDrawing=false;
if(onComplete)onComplete(pattern);
}

container.addEventListener('mousedown',handleStart);
container.addEventListener('mousemove',handleMove);
container.addEventListener('mouseup',handleEnd);
container.addEventListener('touchstart',handleStart,{passive:false});
container.addEventListener('touchmove',handleMove,{passive:false});
container.addEventListener('touchend',handleEnd);
}

// 初始化
document.addEventListener('DOMContentLoaded',()=>{
// APK环境检测
const isAPK=window.AndroidJSBridge?true:false;
// 顶部header显示控制：APK环境完全隐藏，Web环境主界面显示
const header=document.querySelector('.header');
const container=document.getElementById('mainContainer');
if(!isAPK){
// Web环境：默认显示顶部header（主界面）
if(header)header.classList.add('show');
if(container)container.classList.add('with-header');
}else{
// APK环境：完全隐藏顶部header，内容全屏显示
if(header)header.classList.remove('show');
if(header)header.style.display='none';
if(container)container.classList.remove('with-header');
if(container)container.style.paddingTop='0';
}
// 彻底禁用页面滚动和皮筋效果
document.addEventListener('touchmove',function(e){
// 检查是否在图案锁区域内，让图案锁自己处理
let el=e.target;
while(el&&el!==document.body){
if(el.classList&&el.classList.contains('pattern-lock')){
return;
}
el=el.parentElement;
}
// 检查是否在可滚动区域内
el=e.target;
let allowScroll=false;
while(el&&el!==document.body&&el!==document.documentElement){
const style=window.getComputedStyle(el);
if((style.overflowY==='auto'||style.overflowY==='scroll'||style.overflow==='auto'||style.overflow==='scroll')&&
   el.scrollHeight>el.clientHeight+2){
allowScroll=true;
break;
}
if((style.overflowX==='auto'||style.overflowX==='scroll')&&
   el.scrollWidth>el.clientWidth+2){
allowScroll=true;
break;
}
el=el.parentElement;
}
if(!allowScroll){
e.preventDefault();
}
},{passive:false});
// 恢复上次访问的面板
try{
const lastPanel=localStorage.getItem('lastPanel');
if(lastPanel&&lastPanel!=='home'&&document.getElementById('panel-'+lastPanel)){
setTimeout(()=>{openPanel(lastPanel);},100);
}
}catch(e){}
// 恢复媒体列表视图偏好
const savedView=localStorage.getItem('media-view');
if(savedView==='grid'){
document.getElementById('mediaGrid').classList.add('grid-view');
mediaViewMode='grid';
}
// 恢复文件管理器视图偏好（列表/宫格）
const savedFileView=localStorage.getItem('fileViewMode');
if(savedFileView==='grid'||savedFileView==='list'){
currentView=savedFileView;
document.querySelectorAll('.view-btn').forEach((b,i)=>b.classList.toggle('active',(i===0&&savedFileView==='list')||(i===1&&savedFileView==='grid')));
}
// 加载用户权限
loadCurrentUserPermissions().then(()=>{
applyPermissionControl();
});
// 加载通知未读数
setTimeout(()=>{
try{loadNotifications();}catch(e){}
},1000);
// 滑动手势返回（从屏幕左边缘向右滑动，或从右边缘向左滑动）
let touchStartX=0,touchStartY=0,touchStartTime=0,isEdgeSwipe=false;
document.addEventListener('touchstart',function(e){
if(e.touches.length===1){
touchStartX=e.touches[0].clientX;
touchStartY=e.touches[0].clientY;
touchStartTime=Date.now();
const screenWidth=window.innerWidth;
// 从屏幕左右边缘50px范围内开始
isEdgeSwipe=(touchStartX<50||touchStartX>screenWidth-50);
}
},{passive:true});
document.addEventListener('touchend',function(e){
if(!isEdgeSwipe||e.changedTouches.length!==1)return;
const endX=e.changedTouches[0].clientX;
const endY=e.changedTouches[0].clientY;
const deltaX=endX-touchStartX;
const deltaY=Math.abs(endY-touchStartY);
const deltaTime=Date.now()-touchStartTime;
const screenWidth=window.innerWidth;
// 从左边缘向右滑动超过40px，或从右边缘向左滑动超过40px
const isLeftSwipe=(touchStartX<50&&deltaX>40);
const isRightSwipe=(touchStartX>screenWidth-50&&deltaX<-40);
if((isLeftSwipe||isRightSwipe)&&deltaY<80&&deltaTime<800){
// 检查是否在特殊界面（播放器、图片查看器等）
const activePanel=document.querySelector('.panel.active,.home-panel.active');
if(activePanel&&activePanel.id!=='panel-home'){
// 检查是否有弹窗打开
const modals=document.querySelectorAll('[style*="display:flex"][style*="position:fixed"],[style*="display:block"][style*="position:fixed"]');
let hasModal=false;
modals.forEach(m=>{if(m.offsetParent!==null)hasModal=true;});
if(!hasModal){
goHome();
}
}
}
isEdgeSwipe=false;
},{passive:true});
});

// ===== 在线笔记 =====
let currentNoteId=null;
let isPreviewMode=false;
async function loadNotes(){
const res=await fetch('/api/notes/list');
const data=await res.json();
const list=document.getElementById('notesList');
if(data.notes.length===0){
list.innerHTML='<div class="empty-notes"><div class="icon">📝</div><div>还没有笔记，点击右上角新建</div></div>';
return;
}
list.innerHTML=data.notes.map(n=>{
const preview=n.content.replace(/#/g,'').replace(/\*/g,'').replace(/>/g,'').substring(0,80);
return '<div class="note-card'+(n.pinned?' pinned':'')+'" onclick="openNote(\''+n.id+'\')">'+
'<div class="note-title">'+(n.pinned?'📌 ':'')+n.title+'</div>'+
'<div class="note-preview">'+preview+'</div>'+
'<div class="note-meta"><span>'+n.updatedAt+'</span><span>'+(n.content.length)+' 字</span></div>'+
(n.tags&&n.tags.length>0?'<div class="note-tags">'+n.tags.map(t=>'<span class="note-tag">'+t+'</span>').join('')+'</div>':'')+
'</div>';
}).join('');
}
function newNote(){
currentNoteId=null;
document.getElementById('noteTitle').value='';
document.getElementById('noteContent').value='';
document.getElementById('noteMeta').textContent='新笔记';
showNoteEditor();
}
async function openNote(id){
const res=await fetch('/api/notes/get?id='+id);
const note=await res.json();
currentNoteId=note.id;
document.getElementById('noteTitle').value=note.title;
document.getElementById('noteContent').value=note.content;
document.getElementById('noteMeta').textContent='创建: '+note.created_at+' | 更新: '+note.updated_at;
showNoteEditor();
}
function showNoteEditor(){
document.getElementById('notesListView').style.display='none';
document.getElementById('notesEditorView').style.display='block';
isPreviewMode=false;
document.getElementById('notePreview').style.display='none';
document.getElementById('previewBtn').textContent='预览';
}
function backToNotes(){
document.getElementById('notesListView').style.display='block';
document.getElementById('notesEditorView').style.display='none';
loadNotes();
}
async function saveNote(){
const title=document.getElementById('noteTitle').value;
const content=document.getElementById('noteContent').value;
if(!title){showToast('请输入标题','error');return;}
if(currentNoteId){
await fetch('/api/notes/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:currentNoteId,title,content,tags:[]})});
showToast('笔记已更新','success');
}else{
const res=await fetch('/api/notes/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,content,tags:[]})});
const note=await res.json();
currentNoteId=note.id;
showToast('笔记已创建','success');
}
document.getElementById('noteMeta').textContent='已保存: '+new Date().toLocaleString();
}
async function deleteCurrentNote(){
if(!currentNoteId){backToNotes();return;}
if(!confirm('确定删除这篇笔记？'))return;
showProgress('正在删除笔记');
try{
setProgress(40,'删除笔记文件...');await sleep(200);
setProgress(80,'清理记录...');
await fetch('/api/notes/delete?id='+currentNoteId);
setProgress(100,'删除完成');await sleep(200);
hideProgress();
showToast('笔记已删除','success');
backToNotes();
}catch(e){hideProgress();alert('删除失败：'+e.message);}
}
function togglePreview(){
isPreviewMode=!isPreviewMode;
const preview=document.getElementById('notePreview');
if(isPreviewMode){
preview.style.display='flex';
document.getElementById('previewBtn').textContent='编辑';
renderMarkdown();
}else{
preview.style.display='none';
document.getElementById('previewBtn').textContent='预览';
}
}
function renderMarkdown(){
const content=document.getElementById('noteContent').value;
document.getElementById('notePreviewContent').innerHTML=simpleMarkdown(content);
}
function simpleMarkdown(text){
let html=text;
const bt=String.fromCharCode(96);
// 代码块
const cbStart=bt+bt+bt;
const codeBlockRe=new RegExp(cbStart+'([\\s\\S]*?)'+cbStart,'g');
html=html.replace(codeBlockRe,'<pre><code>$1</code></pre>');
// 行内代码
const inlineCodeRe=new RegExp(bt+'([^'+bt+']+)'+bt,'g');
html=html.replace(inlineCodeRe,'<code>$1</code>');
// 标题
html=html.replace(/^### (.*$)/gm,'<h3>$1</h3>');
html=html.replace(/^## (.*$)/gm,'<h2>$1</h2>');
html=html.replace(/^# (.*$)/gm,'<h1>$1</h1>');
// 粗体
html=html.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>');
// 斜体
html=html.replace(/\*(.*?)\*/g,'<em>$1</em>');
// 引用
html=html.replace(/^> (.*$)/gm,'<blockquote>$1</blockquote>');
// 无序列表
html=html.replace(/^- (.*$)/gm,'<li>$1</li>');
const ulRe=new RegExp('(<li>.*</li>\\n?)+','g');
html=html.replace(ulRe,'<ul>$&</ul>');
// 有序列表
html=html.replace(/^\d+\. (.*$)/gm,'<li>$1</li>');
// 链接
html=html.replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" target="_blank">$1</a>');
// 图片
html=html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g,'<img src="$2" alt="$1">');
// 换行
html=html.replace(/\n/g,'<br>');
return html;
}
// 打开笔记面板时加载
const origOpenPanelNotes=openPanel;
openPanel=function(name){
origOpenPanelNotes(name);
if(name==='notes'){loadNotes();}
};
// 返回按钮处理
const origGoHomeNotes=goHome;
goHome=function(){
if(document.getElementById('notesEditorView').style.display==='block'){
backToNotes();return;
}
origGoHomeNotes();
};

// ===== 调试工具 =====
async function loadDebugInfo(){
document.getElementById('debugResult').textContent='加载中...';
const res=await fetch('/api/debug/info');
const data=await res.json();
let html='【系统信息】\n';
html+='版本: '+data.version+'\n';
html+='Go版本: '+data.go_version+'\n';
html+='系统: '+data.os+'/'+data.arch+'\n';
html+='主机: '+data.hostname+'\n';
html+='时间: '+data.timestamp+'\n\n';
html+='【配置】\n';
html+='存储目录: '+data.config.storage_root+(data.config.storage_exists?' ✓':' ✗')+'\n';
html+='监听地址: '+data.config.listen_addr+'\n';
html+='HTTPS: '+(data.config.https?'启用':'禁用')+'\n';
html+='证书: '+(data.config.cert_exists?'✓':'✗')+' '+data.config.cert_file+'\n';
html+='私钥: '+(data.config.key_exists?'✓':'✗')+' '+data.config.key_file+'\n';
html+='用户名: '+data.config.username+'\n\n';
html+='【存储】\n';
html+='文件数: '+data.storage.total_files+'\n';
html+='目录数: '+data.storage.total_dirs+'\n';
html+='总大小: '+formatSize(data.storage.total_size)+'\n';
html+='可写: '+(data.storage.writable?'✓':'✗')+'\n\n';
html+='【网络接口】\n';
data.network.interfaces.forEach(i=>{
html+='- '+i.name+(i.up?' (UP)':' (DOWN)')+' MTU:'+i.mtu+'\n';
i.ips.forEach(ip=>html+='  '+ip+'\n');
});
if(data.warnings&&data.warnings.length>0){
html+='\n【警告】\n';
data.warnings.forEach(w=>html+='⚠ '+w+'\n');
}
document.getElementById('debugResult').textContent=html;
}
async function loadDebugConfig(){
document.getElementById('debugResult').textContent='检查中...';
const res=await fetch('/api/debug/config');
const data=await res.json();
let html='【配置检查】\n\n';
data.checks.forEach(c=>{
const icon=c.status==='pass'?'✓':c.status==='fail'?'✗':'ℹ';
const color=c.status==='pass'?'绿色':c.status==='fail'?'红色':'蓝色';
html+=icon+' ['+color+'] '+c.name;
if(c.path)html+=' ('+c.path+')';
if(c.value)html+=' = '+c.value;
html+='\n';
});
html+='\n总体: '+(data.all_ok?'✓ 全部通过':'✗ 存在问题');
document.getElementById('debugResult').textContent=html;
}
async function loadDebugLogs(){
const result=document.getElementById('debugResult');
result.innerHTML='<div style="padding:16px">加载日志...</div>';

// 加载日志统计和模块列表
const statsRes=await fetch('/api/logs/stats');
const statsData=await statsRes.json();

let modulesHtml=statsData.modules.map(m=>'<option value="'+m+'">'+m+'</option>').join('');

result.innerHTML=
'<div style="padding:16px">'+
'<div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap">'+
'<select id="logLevelFilter" onchange="refreshLogs()" style="padding:8px;border-radius:6px;border:1px solid #ddd">'+
'<option value="all">全部级别</option>'+
'<option value="INFO">INFO</option>'+
'<option value="WARN">WARN</option>'+
'<option value="ERROR">ERROR</option>'+
'<option value="DEBUG">DEBUG</option>'+
'</select>'+
'<select id="logModuleFilter" onchange="refreshLogs()" style="padding:8px;border-radius:6px;border:1px solid #ddd">'+
'<option value="all">全部模块</option>'+modulesHtml+
'</select>'+
'<input type="text" id="logKeyword" placeholder="搜索关键词..." oninput="refreshLogs()" style="flex:1;min-width:120px;padding:8px;border-radius:6px;border:1px solid #ddd">'+
'<button class="btn btn-sm" onclick="refreshLogs()">刷新</button>'+
'<button class="btn btn-sm btn-danger" onclick="clearLogs()">清空</button>'+
'</div>'+
'<div style="display:flex;gap:16px;margin-bottom:12px;font-size:12px">'+
'<span>总计: <b>'+statsData.stats.total+'</b></span>'+
'<span style="color:#2196f3">INFO: <b>'+statsData.stats.levels.INFO+'</b></span>'+
'<span style="color:#ff9800">WARN: <b>'+statsData.stats.levels.WARN+'</b></span>'+
'<span style="color:#f44336">ERROR: <b>'+statsData.stats.levels.ERROR+'</b></span>'+
'</div>'+
'<div id="logList" style="background:#1e1e1e;color:#d4d4d4;padding:12px;border-radius:8px;max-height:400px;overflow-y:auto;font-family:monospace;font-size:12px;line-height:1.6"></div>'+
'</div>';

refreshLogs();
}
async function refreshLogs(){
const level=document.getElementById('logLevelFilter').value;
const module=document.getElementById('logModuleFilter').value;
const keyword=document.getElementById('logKeyword').value;
const res=await fetch('/api/logs?level='+level+'&module='+module+'&keyword='+encodeURIComponent(keyword)+'&limit=200');
const data=await res.json();
const list=document.getElementById('logList');
if(data.count===0){
list.innerHTML='<div style="color:#888;text-align:center;padding:20px">暂无日志</div>';
return;
}
const levelColors={INFO:'#64b5f6',WARN:'#ffb74d',ERROR:'#ef5350',DEBUG:'#81c784'};
list.innerHTML=data.logs.map(log=>{
const color=levelColors[log.level]||'#d4d4d4';
return '<div style="border-bottom:1px solid #333;padding:4px 0">'+
'<span style="color:#888">'+log.time+'</span> '+
'<span style="color:'+color+';font-weight:bold">['+log.level+']</span> '+
'<span style="color:#ce93d8">['+log.module+']</span> '+
'<span style="color:#a5d6a7">'+log.action+'</span> '+
'<span>'+log.message+'</span>'+
(log.user?' <span style="color:#ffcc80">user='+log.user+'</span>':'')+
(log.ip?' <span style="color:#90caf9">ip='+log.ip+'</span>':'')+
'</div>';
}).join('');
}
async function clearLogs(){
if(!confirm('确定清空所有日志？'))return;
await fetch('/api/logs/clear',{method:'POST'});
loadDebugLogs();
}
function showDebugCommand(){
const cmds=['ifconfig','ip_addr','ip_route','ping','df','free','uptime','uname','ps','top','netstat','ls_storage','whoami','date'];
let html='【选择命令执行】\n\n';
cmds.forEach(c=>{
html+='<button onclick="runDebugCommand(\''+c+'\')" style="margin:4px;padding:8px 12px;border:1px solid #ddd;border-radius:6px;background:#fff;cursor:pointer">'+c+'</button>';
});
html+='\n\n<div id="cmdOutput"></div>';
document.getElementById('debugResult').innerHTML=html;
}
async function runDebugCommand(cmd){
document.getElementById('cmdOutput').innerHTML='执行中...';
const res=await fetch('/api/debug/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:cmd})});
const data=await res.json();
document.getElementById('cmdOutput').innerHTML='<pre style="background:#000;color:#0f0;padding:12px;border-radius:6px;overflow-x:auto;max-height:300px">'+(data.output||data.error)+'</pre>';
}

loadHomeStats();

// 注册Service Worker（PWA离线支持）
if('serviceWorker' in navigator){
navigator.serviceWorker.register('/static/sw.js').then(function(reg){
console.log('Service Worker注册成功');
}).catch(function(err){
console.log('Service Worker注册失败:',err);
});
}
</script>

<!-- 底部导航栏 -->
<div class="bottom-nav">
<div class="bottom-nav-item active" onclick="switchTab('home')">
<div class="icon">🏠</div>
<div>首页</div>
</div>
<div class="bottom-nav-item" onclick="switchTab('files')">
<div class="icon">📁</div>
<div>文件</div>
</div>
<div class="bottom-nav-item" onclick="switchTab('media')">
<div class="icon">🎵</div>
<div>媒体</div>
</div>
<div class="bottom-nav-item" onclick="switchTab('me')">
<div class="icon">👤</div>
<div>我的</div>
</div>
</div>

</body>
</html>`
