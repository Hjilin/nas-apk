package main

import (
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
)

// EnhancedMonitor 增强版系统监控器
type EnhancedMonitor struct {
	mu            sync.Mutex
	history       []MonitorRecord
	maxHistory    int
	alistStatus   *AListStatus
	logFile       *os.File
	lastCPU       *cpuStats
	lastProcCPU   map[int]*processCPUStats
	lastTotalCPU  uint64
}

// cpuStats CPU统计信息
type cpuStats struct {
	user    uint64
	nice    uint64
	system  uint64
	idle    uint64
	iowait  uint64
	irq     uint64
	softirq uint64
	steal   uint64
	total   uint64
}

// MonitorRecord 监控记录
type MonitorRecord struct {
	Timestamp int64          `json:"timestamp"`
	CPU       float64        `json:"cpu"`
	Memory    float64        `json:"memory"`
	Storage   float64        `json:"storage"`
	Processes int            `json:"processes"`
	AList     *MonitorAListStatus  `json:"alist,omitempty"`
}

// MonitorAListStatus AList运行状态
type MonitorAListStatus struct {
	Running   bool   `json:"running"`
	Port      int    `json:"port"`
	Version   string `json:"version"`
	Storage   string `json:"storage"`
	Files     int    `json:"files"`
	StartTime string `json:"start_time"`
}

// ProcessDetail 进程详情
type ProcessDetail struct {
	PID        int     `json:"pid"`
	Name       string  `json:"name"`
	CPU        float64 `json:"cpu"`
	Memory     uint64  `json:"memory"`
	MemoryStr  string  `json:"memory_str"`
	Status     string  `json:"status"`
	User       string  `json:"user"`
	StartTime  string  `json:"start_time"`
	CmdLine    string  `json:"cmdline"`
	IsNAS      bool    `json:"is_nas"`
	IsAList    bool    `json:"is_alist"`
	Threads    int     `json:"threads"`
	State      string  `json:"state"`
}

// processCPUStats 进程CPU统计（用于计算差值）
type processCPUStats struct {
	utime  uint64
	stime  uint64
	cutime uint64
	cstime uint64
	total  uint64
}

// NewEnhancedMonitor 创建增强版监控器
func NewEnhancedMonitor(logDir string) *EnhancedMonitor {
	em := &EnhancedMonitor{
		maxHistory:  100,
		lastProcCPU: make(map[int]*processCPUStats),
	}

	// 打开日志文件
	logPath := filepath.Join(logDir, "monitor.log")
	if f, err := os.OpenFile(logPath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644); err == nil {
		em.logFile = f
	}

	// 启动后台监控
	go em.backgroundMonitor()

	return em
}

// backgroundMonitor 后台监控循环
func (em *EnhancedMonitor) backgroundMonitor() {
	defer func() {
		if r := recover(); r != nil {
			fmt.Printf("[MONITOR] 后台监控恢复: %v\n", r)
			// 重启监控
			go em.backgroundMonitor()
		}
	}()

	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		func() {
			defer func() {
				if r := recover(); r != nil {
					fmt.Printf("[MONITOR] 采集数据恢复: %v\n", r)
				}
			}()
			em.collectAndLog()
		}()
	}
}

// collectAndLog 采集并记录监控数据
func (em *EnhancedMonitor) collectAndLog() {
	em.mu.Lock()
	defer em.mu.Unlock()

	record := MonitorRecord{
		Timestamp: time.Now().Unix(),
	}

	// CPU使用率
	record.CPU = em.getCPUUsage()

	// 内存使用率
	record.Memory = em.getMemoryUsage()

	// 存储使用率
	record.Storage = em.getStorageUsage()

	// 进程数
	processes := em.getProcessList()
	record.Processes = len(processes)

	// AList状态
	record.AList = em.getAListStatus()

	// 保存到历史
	em.history = append(em.history, record)
	if len(em.history) > em.maxHistory {
		em.history = em.history[len(em.history)-em.maxHistory:]
	}

	// 写入日志
	em.writeLog(record)
}

// writeLog 写入监控日志
func (em *EnhancedMonitor) writeLog(record MonitorRecord) {
	if em.logFile == nil {
		return
	}

	logLine := fmt.Sprintf("[%s] CPU:%.1f%% MEM:%.1f%% DISK:%.1f%% PROCS:%d AList:%v\n",
		time.Now().Format("2006-01-02 15:04:05"),
		record.CPU,
		record.Memory,
		record.Storage,
		record.Processes,
		record.AList != nil && record.AList.Running,
	)

	em.logFile.WriteString(logLine)
}

// getCPUUsage 获取CPU使用率（使用/proc/stat标准方法）
func (em *EnhancedMonitor) getCPUUsage() float64 {
	current, err := readCPUStats()
	if err != nil {
		return 0
	}

	// 如果是第一次读取，保存后返回0
	if em.lastCPU == nil {
		em.lastCPU = current
		return 0
	}

	// 计算差值
	prev := em.lastCPU
	totalDiff := current.total - prev.total
	idleDiff := (current.idle + current.iowait) - (prev.idle + prev.iowait)

	// 保存当前统计
	em.lastCPU = current

	// 计算使用率
	if totalDiff <= 0 {
		return 0
	}
	usage := (float64(totalDiff-idleDiff) / float64(totalDiff)) * 100
	if usage < 0 {
		usage = 0
	}
	if usage > 100 {
		usage = 100
	}
	return usage
}

// readCPUStats 读取/proc/stat获取CPU统计
func readCPUStats() (*cpuStats, error) {
	data, err := os.ReadFile("/proc/stat")
	if err != nil {
		return nil, err
	}

	lines := strings.Split(string(data), "\n")
	for _, line := range lines {
		if strings.HasPrefix(line, "cpu ") {
			parts := strings.Fields(line)
			if len(parts) < 5 {
				continue
			}

			stats := &cpuStats{}
			// 格式: cpu user nice system idle iowait irq softirq steal guest guest_nice
			if len(parts) > 1 {
				stats.user, _ = parseUint(parts[1])
			}
			if len(parts) > 2 {
				stats.nice, _ = parseUint(parts[2])
			}
			if len(parts) > 3 {
				stats.system, _ = parseUint(parts[3])
			}
			if len(parts) > 4 {
				stats.idle, _ = parseUint(parts[4])
			}
			if len(parts) > 5 {
				stats.iowait, _ = parseUint(parts[5])
			}
			if len(parts) > 6 {
				stats.irq, _ = parseUint(parts[6])
			}
			if len(parts) > 7 {
				stats.softirq, _ = parseUint(parts[7])
			}
			if len(parts) > 8 {
				stats.steal, _ = parseUint(parts[8])
			}

			// 计算总时间
			stats.total = stats.user + stats.nice + stats.system + stats.idle +
				stats.iowait + stats.irq + stats.softirq + stats.steal

			return stats, nil
		}
	}
	return nil, fmt.Errorf("未找到cpu行")
}

// getMemoryUsage 获取内存使用率
func (em *EnhancedMonitor) getMemoryUsage() float64 {
	data, err := os.ReadFile("/proc/meminfo")
	if err != nil {
		return 0
	}

	var total, available uint64
	for _, line := range strings.Split(string(data), "\n") {
		parts := strings.Fields(line)
		if len(parts) < 2 {
			continue
		}
		switch parts[0] {
		case "MemTotal:":
			total, _ = parseUint(parts[1])
		case "MemAvailable:":
			available, _ = parseUint(parts[1])
		}
	}

	if total == 0 {
		return 0
	}
	return float64(total-available) / float64(total) * 100
}

// getStorageUsage 获取存储使用率
func (em *EnhancedMonitor) getStorageUsage() float64 {
	// 尝试多个路径，适配Android环境
	paths := []string{"/data", "/sdcard", "/storage", "/"}
	for _, path := range paths {
		var stat syscall.Statfs_t
		if err := syscall.Statfs(path, &stat); err == nil {
			total := stat.Blocks * uint64(stat.Bsize)
			free := stat.Bfree * uint64(stat.Bsize)
			if total > 0 {
				return float64(total-free) / float64(total) * 100
			}
		}
	}
	return 0
}

// getProcessList 获取进程列表（使用/proc文件系统，更准确）
func (em *EnhancedMonitor) getProcessList() []ProcessDetail {
	// 读取/proc目录获取所有进程
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return em.getProcessListFallback()
	}

	var processes []ProcessDetail
	currentTotalCPU := uint64(0)

	// 获取当前总CPU时间
	if cpuStats, err := readCPUStats(); err == nil {
		currentTotalCPU = cpuStats.total
	}

	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		pid, err := parseInt(entry.Name())
		if err != nil || pid <= 0 {
			continue
		}

		proc := ProcessDetail{PID: pid}

		// 读取/proc/<pid>/stat获取CPU统计和进程名
		if statData, err := os.ReadFile(fmt.Sprintf("/proc/%d/stat", pid)); err == nil {
			statStr := string(statData)
			// 格式: pid (comm) state ppid ...
			// 进程名在括号中
			if start := strings.Index(statStr, "("); start > 0 {
				if end := strings.Index(statStr[start:], ")"); end > 0 {
					proc.Name = statStr[start+1 : start+end]
				}
			}
			parts := strings.Fields(statStr)
			if len(parts) > 2 {
				proc.State = parts[2]
			}
			if len(parts) > 13 {
				// utime(14) stime(15) cutime(16) cstime(17) - 从1开始计数
				utime, _ := parseUint(parts[13])
				stime, _ := parseUint(parts[14])
				cutime, _ := parseUint(parts[15])
				cstime, _ := parseUint(parts[16])
				numThreads, _ := parseInt(parts[19])
				proc.Threads = numThreads

				procTotal := utime + stime + cutime + cstime

				// 计算CPU使用率
				if lastStats, ok := em.lastProcCPU[pid]; ok {
					procDiff := procTotal - lastStats.total
					totalDiff := currentTotalCPU - em.lastTotalCPU
					if totalDiff > 0 && procDiff >= 0 {
						proc.CPU = (float64(procDiff) / float64(totalDiff)) * 100
						if proc.CPU < 0 {
							proc.CPU = 0
						}
						if proc.CPU > 100 {
							proc.CPU = 100
						}
					}
				}

				// 保存当前统计
				em.lastProcCPU[pid] = &processCPUStats{
					utime:  utime,
					stime:  stime,
					cutime: cutime,
					cstime: cstime,
					total:  procTotal,
				}
			}
		}

		// 读取/proc/<pid>/status获取内存和状态
		if statusData, err := os.ReadFile(fmt.Sprintf("/proc/%d/status", pid)); err == nil {
			for _, line := range strings.Split(string(statusData), "\n") {
				parts := strings.Fields(line)
				if len(parts) < 2 {
					continue
				}
				switch parts[0] {
				case "VmRSS:":
					// VmRSS单位是kB
					if rss, err := parseUint(parts[1]); err == nil {
						proc.Memory = rss * 1024
						proc.MemoryStr = formatMemory(rss * 1024)
					}
				case "Name:":
					if proc.Name == "" {
						proc.Name = parts[1]
					}
				case "State:":
					if proc.State == "" {
						proc.State = parts[1]
					}
				case "Uid:":
					if len(parts) > 1 {
						proc.User = parts[1]
					}
				case "Threads:":
					if threads, err := parseInt(parts[1]); err == nil {
						proc.Threads = threads
					}
				}
			}
		}

		// 读取/proc/<pid>/cmdline获取完整命令行
		if cmdData, err := os.ReadFile(fmt.Sprintf("/proc/%d/cmdline", pid)); err == nil {
			proc.CmdLine = strings.ReplaceAll(string(cmdData), "\x00", " ")
			proc.CmdLine = strings.TrimSpace(proc.CmdLine)
		}

		// 标记NAS和AList进程
		lowerName := strings.ToLower(proc.Name + " " + proc.CmdLine)
		if strings.Contains(lowerName, "nas-server") || strings.Contains(lowerName, "nas_server") {
			proc.IsNAS = true
		}
		if strings.Contains(lowerName, "alist") {
			proc.IsAList = true
		}

		if proc.Name == "" {
			proc.Name = fmt.Sprintf("pid_%d", pid)
		}
		proc.Status = "running"

		processes = append(processes, proc)
	}

	// 保存当前总CPU时间
	em.lastTotalCPU = currentTotalCPU

	// 清理已退出进程的缓存
	for pid := range em.lastProcCPU {
		found := false
		for _, p := range processes {
			if p.PID == pid {
				found = true
				break
			}
		}
		if !found {
			delete(em.lastProcCPU, pid)
		}
	}

	// 按CPU使用率排序（降序）
	for i := 0; i < len(processes); i++ {
		for j := i + 1; j < len(processes); j++ {
			if processes[j].CPU > processes[i].CPU {
				processes[i], processes[j] = processes[j], processes[i]
			}
		}
	}

	// 只返回前50个进程，避免数据过大
	if len(processes) > 50 {
		processes = processes[:50]
	}

	return processes
}

// getProcessListFallback 使用ps命令的备用方案
func (em *EnhancedMonitor) getProcessListFallback() []ProcessDetail {
	var output []byte
	var err error

	cmd := exec.Command("ps", "-A")
	output, err = cmd.Output()
	if err != nil || len(output) == 0 {
		cmd = exec.Command("ps")
		output, err = cmd.Output()
		if err != nil {
			return nil
		}
	}

	var processes []ProcessDetail
	lines := strings.Split(string(output), "\n")
	for i, line := range lines {
		if i == 0 || strings.TrimSpace(line) == "" {
			continue
		}
		parts := strings.Fields(line)
		if len(parts) < 2 {
			continue
		}

		pid, _ := parseInt(parts[1])
		proc := ProcessDetail{
			PID:    pid,
			Name:   parts[len(parts)-1],
			Status: "running",
		}
		if len(parts) >= 1 {
			proc.User = parts[0]
		}
		processes = append(processes, proc)
	}
	return processes
}

// formatMemory 格式化内存大小
func formatMemory(bytes uint64) string {
	const unit = 1024
	if bytes < unit {
		return fmt.Sprintf("%d B", bytes)
	}
	div, exp := uint64(unit), 0
	for n := bytes / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %cB", float64(bytes)/float64(div), "KMGTPE"[exp])
}

// getAListStatus 获取AList状态
func (em *EnhancedMonitor) getAListStatus() *MonitorAListStatus {
	status := &MonitorAListStatus{
		Port: 5244,
	}

	// 方式1：检查AList进程
	cmd := exec.Command("pgrep", "-f", "alist")
	if output, err := cmd.Output(); err == nil && len(output) > 0 {
		status.Running = true
	} else {
		// 方式2：检查端口
		cmd = exec.Command("sh", "-c", "netstat -tlnp 2>/dev/null | grep :5244 || ss -tlnp 2>/dev/null | grep :5244")
		if output, err := cmd.Output(); err == nil && len(output) > 0 {
			status.Running = true
		}
	}

	// 尝试获取AList版本（不影响状态检测）
	if status.Running {
		cmd = exec.Command("alist", "version")
		if output, err := cmd.Output(); err == nil {
			status.Version = strings.TrimSpace(string(output))
		}
	}

	return status
}

// GetMonitorStatus 获取监控状态
func (em *EnhancedMonitor) GetMonitorStatus() map[string]interface{} {
	em.mu.Lock()
	defer em.mu.Unlock()

	return map[string]interface{}{
		"current":   em.getCurrentStatus(),
		"history":   em.history,
		"processes": em.getProcessList(),
		"alist":     em.getAListStatus(),
	}
}

// getCurrentStatus 获取当前状态
func (em *EnhancedMonitor) getCurrentStatus() map[string]interface{} {
	return map[string]interface{}{
		"cpu":       em.getCPUUsage(),
		"memory":    em.getMemoryUsage(),
		"storage":   em.getStorageUsage(),
		"goroutine": runtime.NumGoroutine(),
		"timestamp": time.Now().Unix(),
	}
}

// GetMonitorHistory 获取监控历史
func (em *EnhancedMonitor) GetMonitorHistory() []MonitorRecord {
	em.mu.Lock()
	defer em.mu.Unlock()
	return em.history
}

// GetMonitorLogs 获取监控日志
func (em *EnhancedMonitor) GetMonitorLogs(limit int) ([]string, error) {
	if em.logFile == nil {
		return nil, fmt.Errorf("日志文件未打开")
	}

	// 读取最后N行
	data, err := os.ReadFile(em.logFile.Name())
	if err != nil {
		return nil, err
	}

	lines := strings.Split(string(data), "\n")
	if len(lines) > limit {
		lines = lines[len(lines)-limit:]
	}

	return lines, nil
}

// Close 关闭监控器
func (em *EnhancedMonitor) Close() {
	if em.logFile != nil {
		em.logFile.Close()
	}
}

// 辅助函数
func parseFloat(s string) (float64, error) {
	var f float64
	_, err := fmt.Sscanf(s, "%f", &f)
	return f, err
}

func parseUint(s string) (uint64, error) {
	var u uint64
	_, err := fmt.Sscanf(s, "%d", &u)
	return u, err
}

func parseInt(s string) (int, error) {
	var i int
	_, err := fmt.Sscanf(s, "%d", &i)
	return i, err
}

// 全局监控器实例
var globalMonitor *EnhancedMonitor

// InitEnhancedMonitor 初始化全局监控器
func InitEnhancedMonitor(logDir string) {
	globalMonitor = NewEnhancedMonitor(logDir)
}

// HandleMonitorStatus 处理监控状态请求
func HandleMonitorStatus(w http.ResponseWriter, r *http.Request) {
	if globalMonitor == nil {
		WriteError(w, CodeInternalError, "监控器未初始化")
		return
	}
	WriteSuccess(w, globalMonitor.GetMonitorStatus())
}

// HandleMonitorHistory 处理监控历史请求
func HandleMonitorHistory(w http.ResponseWriter, r *http.Request) {
	if globalMonitor == nil {
		WriteError(w, CodeInternalError, "监控器未初始化")
		return
	}
	WriteSuccess(w, globalMonitor.GetMonitorHistory())
}

// HandleMonitorLogs 处理监控日志请求
func HandleMonitorLogs(w http.ResponseWriter, r *http.Request) {
	if globalMonitor == nil {
		WriteError(w, CodeInternalError, "监控器未初始化")
		return
	}

	logs, err := globalMonitor.GetMonitorLogs(100)
	if err != nil {
		WriteError(w, CodeInternalError, err.Error())
		return
	}
	WriteSuccess(w, map[string]interface{}{
		"logs": logs,
	})
}
