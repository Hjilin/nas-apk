package main

import (
	"bytes"
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"image"
	"image/gif"
	"image/jpeg"
	"image/png"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"golang.org/x/image/draw"
)

// ThumbnailManager 缩略图管理器
type ThumbnailManager struct {
	cacheDir string
	mu       sync.Mutex
	generating map[string]bool
}

// NewThumbnailManager 创建缩略图管理器
func NewThumbnailManager(cacheDir string) *ThumbnailManager {
	os.MkdirAll(cacheDir, 0755)
	return &ThumbnailManager{
		cacheDir:   cacheDir,
		generating: make(map[string]bool),
	}
}

// cacheKey 生成缓存键
func (tm *ThumbnailManager) cacheKey(filePath string, width, height int) string {
	info, err := os.Stat(filePath)
	modTime := ""
	if err == nil {
		modTime = info.ModTime().String()
	}
	hash := md5.Sum([]byte(filePath + modTime + fmt.Sprintf("%dx%d", width, height)))
	return hex.EncodeToString(hash[:]) + ".jpg"
}

// cachePath 获取缓存文件路径
func (tm *ThumbnailManager) cachePath(filePath string, width, height int) string {
	return filepath.Join(tm.cacheDir, tm.cacheKey(filePath, width, height))
}

// GetThumbnail 获取缩略图（优先从缓存，没有则生成）
func (tm *ThumbnailManager) GetThumbnail(filePath string, width, height int) ([]byte, error) {
	cacheFile := tm.cachePath(filePath, width, height)

	// 检查缓存
	if data, err := os.ReadFile(cacheFile); err == nil {
		return data, nil
	}

	tm.mu.Lock()
	if tm.generating[cacheFile] {
		tm.mu.Unlock()
		// 等待生成完成（简单等待）
		for i := 0; i < 50; i++ {
			if data, err := os.ReadFile(cacheFile); err == nil {
				return data, nil
			}
			// 短暂等待
			time.Sleep(100 * time.Millisecond)
		}
		return nil, fmt.Errorf("缩略图生成超时")
	}
	tm.generating[cacheFile] = true
	tm.mu.Unlock()

	defer func() {
		tm.mu.Lock()
		delete(tm.generating, cacheFile)
		tm.mu.Unlock()
	}()

	// 生成缩略图
	data, err := tm.generateThumbnail(filePath, width, height)
	if err != nil {
		return nil, err
	}

	// 保存缓存
	os.WriteFile(cacheFile, data, 0644)
	return data, nil
}

// generateThumbnail 根据文件类型生成缩略图
func (tm *ThumbnailManager) generateThumbnail(filePath string, width, height int) ([]byte, error) {
	ext := strings.ToLower(filepath.Ext(filePath))

	switch ext {
	case ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp":
		return tm.generateImageThumbnail(filePath, width, height)
	case ".mp4", ".mkv", ".avi", ".mov", ".flv", ".webm", ".m4v", ".ts":
		return tm.generateVideoThumbnail(filePath, width, height)
	default:
		return nil, fmt.Errorf("不支持的文件类型: %s", ext)
	}
}

// generateImageThumbnail 生成图片缩略图
func (tm *ThumbnailManager) generateImageThumbnail(filePath string, width, height int) ([]byte, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var img image.Image
	ext := strings.ToLower(filepath.Ext(filePath))

	switch ext {
	case ".jpg", ".jpeg":
		img, err = jpeg.Decode(file)
	case ".png":
		img, err = png.Decode(file)
	case ".gif":
		img, err = gif.Decode(file)
	default:
		// 尝试用 jpeg 解码
		file.Seek(0, 0)
		img, err = jpeg.Decode(file)
		if err != nil {
			file.Seek(0, 0)
			img, err = png.Decode(file)
		}
	}

	if err != nil {
		return nil, fmt.Errorf("图片解码失败: %v", err)
	}

	// 计算缩放后的尺寸（保持宽高比）
	srcBounds := img.Bounds()
	srcW := srcBounds.Dx()
	srcH := srcBounds.Dy()
	if srcW == 0 || srcH == 0 {
		return nil, fmt.Errorf("无效的图片尺寸")
	}

	// 按比例缩放
	scale := float64(width) / float64(srcW)
	if float64(height)/float64(srcH) < scale {
		scale = float64(height) / float64(srcH)
	}
	dstW := int(float64(srcW) * scale)
	dstH := int(float64(srcH) * scale)

	// 创建目标图片
	dst := image.NewRGBA(image.Rect(0, 0, dstW, dstH))
	draw.CatmullRom.Scale(dst, dst.Bounds(), img, srcBounds, draw.Over, nil)

	// 编码为 JPEG
	var buf bytes.Buffer
	if err := jpeg.Encode(&buf, dst, &jpeg.Options{Quality: 80}); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

// generateVideoThumbnail 生成视频缩略图（使用 ffmpeg）
func (tm *ThumbnailManager) generateVideoThumbnail(filePath string, width, height int) ([]byte, error) {
	// 检查 ffmpeg 是否可用
	if _, err := exec.LookPath("ffmpeg"); err != nil {
		return nil, fmt.Errorf("ffmpeg 未安装，请执行: pkg install ffmpeg")
	}

	// 使用 ffmpeg 截取第一帧
	cmd := exec.Command("ffmpeg",
		"-i", filePath,
		"-ss", "00:00:01", // 从第1秒截取
		"-vframes", "1",
		"-vf", fmt.Sprintf("scale=%d:%d:force_original_aspect_ratio=decrease", width, height),
		"-f", "image2pipe",
		"-vcodec", "mjpeg",
		"-q:v", "5",
		"pipe:1",
	)

	var stdout bytes.Buffer
	var stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("ffmpeg 截取失败: %v, %s", err, stderr.String())
	}

	if stdout.Len() == 0 {
		return nil, fmt.Errorf("ffmpeg 未输出缩略图")
	}

	return stdout.Bytes(), nil
}

// IsThumbnailSupported 检查文件是否支持缩略图
func IsThumbnailSupported(filename string) bool {
	ext := strings.ToLower(filepath.Ext(filename))
	supported := map[string]bool{
		".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".webp": true, ".bmp": true,
		".mp4": true, ".mkv": true, ".avi": true, ".mov": true, ".flv": true, ".webm": true, ".m4v": true, ".ts": true,
	}
	return supported[ext]
}

// HandleThumbnail 处理缩略图请求
func (h *NASHandler) HandleThumbnail(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Query().Get("path")
	if path == "" {
		http.Error(w, "Missing path", http.StatusBadRequest)
		return
	}

	fullPath, ok := h.safePath(path)
	if !ok {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}

	if !IsThumbnailSupported(fullPath) {
		http.Error(w, "Unsupported file type", http.StatusUnsupportedMediaType)
		return
	}

	width := 200
	height := 200

	data, err := h.thumbMgr.GetThumbnail(fullPath, width, height)
	if err != nil {
		http.Error(w, "Failed to generate thumbnail: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "image/jpeg")
	w.Header().Set("Cache-Control", "public, max-age=86400")
	io.Copy(w, bytes.NewReader(data))
}

// CleanCache 清理缩略图缓存
func (tm *ThumbnailManager) CleanCache(maxAgeHours int) error {
	entries, err := os.ReadDir(tm.cacheDir)
	if err != nil {
		return err
	}
	cutoff := time.Now().Add(-time.Duration(maxAgeHours) * time.Hour)
	for _, e := range entries {
		info, err := e.Info()
		if err != nil {
			continue
		}
		if info.ModTime().Before(cutoff) {
			os.Remove(filepath.Join(tm.cacheDir, e.Name()))
		}
	}
	return nil
}
