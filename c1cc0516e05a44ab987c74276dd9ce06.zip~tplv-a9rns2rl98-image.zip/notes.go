package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

// Note 笔记
type Note struct {
	ID        string `json:"id"`
	Title     string `json:"title"`
	Content   string `json:"content"`
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
	Tags      []string `json:"tags"`
	Pinned    bool   `json:"pinned"`
}

// NoteManager 笔记管理器
type NoteManager struct {
	notesDir string
	mu       sync.Mutex
}

// NewNoteManager 创建笔记管理器
func NewNoteManager(storageRoot string) *NoteManager {
	notesDir := filepath.Join(storageRoot, ".notes")
	os.MkdirAll(notesDir, 0755)
	return &NoteManager{notesDir: notesDir}
}

// notePath 笔记文件路径
func (nm *NoteManager) notePath(id string) string {
	return filepath.Join(nm.notesDir, id+".json")
}

// List 列出所有笔记
func (nm *NoteManager) List() ([]Note, error) {
	entries, err := os.ReadDir(nm.notesDir)
	if err != nil {
		return nil, err
	}

	var notes []Note
	for _, entry := range entries {
		if !strings.HasSuffix(entry.Name(), ".json") {
			continue
		}
		data, err := os.ReadFile(filepath.Join(nm.notesDir, entry.Name()))
		if err != nil {
			continue
		}
		var note Note
		if err := json.Unmarshal(data, &note); err != nil {
			continue
		}
		notes = append(notes, note)
	}

	// 排序：置顶优先，然后按更新时间倒序
	sort.Slice(notes, func(i, j int) bool {
		if notes[i].Pinned != notes[j].Pinned {
			return notes[i].Pinned
		}
		return notes[i].UpdatedAt > notes[j].UpdatedAt
	})

	return notes, nil
}

// Get 获取笔记
func (nm *NoteManager) Get(id string) (*Note, error) {
	data, err := os.ReadFile(nm.notePath(id))
	if err != nil {
		return nil, fmt.Errorf("笔记不存在")
	}
	var note Note
	if err := json.Unmarshal(data, &note); err != nil {
		return nil, err
	}
	return &note, nil
}

// Create 创建笔记
func (nm *NoteManager) Create(title, content string, tags []string) (*Note, error) {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	id := fmt.Sprintf("note_%d", time.Now().UnixNano())
	now := time.Now().Format("2006-01-02 15:04:05")

	if title == "" {
		title = "无标题笔记"
	}

	note := Note{
		ID:        id,
		Title:     title,
		Content:   content,
		CreatedAt: now,
		UpdatedAt: now,
		Tags:      tags,
		Pinned:    false,
	}

	data, err := json.MarshalIndent(note, "", "  ")
	if err != nil {
		return nil, err
	}
	if err := os.WriteFile(nm.notePath(id), data, 0644); err != nil {
		return nil, err
	}

	return &note, nil
}

// Update 更新笔记
func (nm *NoteManager) Update(id, title, content string, tags []string, pinned bool) (*Note, error) {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	note, err := nm.Get(id)
	if err != nil {
		return nil, err
	}

	note.Title = title
	note.Content = content
	note.Tags = tags
	note.Pinned = pinned
	note.UpdatedAt = time.Now().Format("2006-01-02 15:04:05")

	data, err := json.MarshalIndent(note, "", "  ")
	if err != nil {
		return nil, err
	}
	if err := os.WriteFile(nm.notePath(id), data, 0644); err != nil {
		return nil, err
	}

	return note, nil
}

// Delete 删除笔记
func (nm *NoteManager) Delete(id string) error {
	nm.mu.Lock()
	defer nm.mu.Unlock()
	return os.Remove(nm.notePath(id))
}

// HandleNotesList 处理笔记列表请求
func (nm *NoteManager) HandleNotesList(w http.ResponseWriter, r *http.Request) {
	notes, err := nm.List()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{"notes": notes})
}

// HandleNoteGet 处理获取笔记请求
func (nm *NoteManager) HandleNoteGet(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "Missing id", http.StatusBadRequest)
		return
	}
	note, err := nm.Get(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(note)
}

// HandleNoteCreate 处理创建笔记请求
func (nm *NoteManager) HandleNoteCreate(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Title   string   `json:"title"`
		Content string   `json:"content"`
		Tags    []string `json:"tags"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	note, err := nm.Create(req.Title, req.Content, req.Tags)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(note)
}

// HandleNoteUpdate 处理更新笔记请求
func (nm *NoteManager) HandleNoteUpdate(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		ID      string   `json:"id"`
		Title   string   `json:"title"`
		Content string   `json:"content"`
		Tags    []string `json:"tags"`
		Pinned  bool     `json:"pinned"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	note, err := nm.Update(req.ID, req.Title, req.Content, req.Tags, req.Pinned)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(note)
}

// HandleNoteDelete 处理删除笔记请求
func (nm *NoteManager) HandleNoteDelete(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "Missing id", http.StatusBadRequest)
		return
	}
	if err := nm.Delete(id); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}
