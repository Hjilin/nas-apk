package main

import (
	"fmt"
	"os"
	"path/filepath"

	"gopkg.in/yaml.v3"
)

// Config 服务端配置
type Config struct {
	Server   ServerConfig   `yaml:"server"`
	Auth     AuthConfig     `yaml:"auth"`
	Security SecurityConfig `yaml:"security"`
	Storage  StorageConfig  `yaml:"storage"`
	Media    MediaConfig    `yaml:"media"`
	Backup   BackupConfig   `yaml:"backup"`
	Network  NetworkConfig  `yaml:"network"`
	Log      LogConfig      `yaml:"log"`
}

type ServerConfig struct {
	Host      string `yaml:"host"`      // 监听地址，默认 0.0.0.0
	Port      int    `yaml:"port"`      // 监听端口，默认 8443
	HTTPS     bool   `yaml:"https"`     // 是否启用 HTTPS
	CertFile  string `yaml:"cert_file"` // TLS 证书路径
	KeyFile   string `yaml:"key_file"`  // TLS 私钥路径
	UploadMax int64  `yaml:"upload_max"`// 单文件上传上限(MB)，默认 1024
	FTPPort   int    `yaml:"ftp_port"`  // FTP服务端口，默认 2121
}

type AuthConfig struct {
	Username        string `yaml:"username"`         // 登录用户名
	PasswordHash    string `yaml:"password_hash"`    // bcrypt 密码哈希（生成后填入）
	JWTSecret       string `yaml:"jwt_secret"`       // JWT 签名密钥（随机生成）
	TokenExpireHour int    `yaml:"token_expire_hour"`// Token 有效期(小时)，默认 24
}

type SecurityConfig struct {
	MaxFailedLogin   int    `yaml:"max_failed_login"`   // 最大失败次数，默认 5
	LockoutMinute    int    `yaml:"lockout_minute"`     // 锁定时长(分钟)，默认 30
	RateLimitPerMin  int    `yaml:"rate_limit_per_min"` // 每 IP 每分钟请求上限，默认 120
	AllowedIPs       []string `yaml:"allowed_ips"`      // IP 白名单（空=不限制）
	TrustedProxy     string `yaml:"trusted_proxy"`      // 可信代理 IP（用于获取真实 IP）
}

type StorageConfig struct {
	RootDir   string   `yaml:"root_dir"`   // 文件根目录
	ReadOnly  bool     `yaml:"read_only"`  // 只读模式
	HiddenExt []string `yaml:"hidden_ext"` // 隐藏的文件扩展名
}

// MediaConfig 影音播放配置
type MediaConfig struct {
	EnableDLNA  bool     `yaml:"enable_dlna"`  // 启用 DLNA/UPnP 媒体服务器
	DLNAPort    int      `yaml:"dlna_port"`     // DLNA 端口，默认 8200
	MediaDirs   []string `yaml:"media_dirs"`    // 媒体扫描目录（相对 root_dir）
	EnableWebPlayer bool `yaml:"enable_web_player"` // 启用网页播放器
	Transcode   bool     `yaml:"transcode"`     // 是否启用转码（手机性能有限，默认关闭）
}

// BackupConfig 备份恢复配置
type BackupConfig struct {
	Enable        bool     `yaml:"enable"`          // 启用自动备份
	BackupDir     string   `yaml:"backup_dir"`      // 备份存储目录
	Sources       []string `yaml:"sources"`         // 要备份的源目录（手机路径）
	Schedule      string   `yaml:"schedule"`        // 定时备份 cron 表达式（空=不自动）
	IntervalHours int      `yaml:"interval_hours"`  // 自动备份间隔（小时），0=不自动
	BackupTime    string   `yaml:"backup_time"`     // 每日备份时间（HH:MM），空=不按时间
	RetentionDays int      `yaml:"retention_days"`  // 备份保留天数，默认 30
	MaxBackups    int      `yaml:"max_backups"`     // 最大保留备份数，0=不限制
	Compress      bool     `yaml:"compress"`        // 是否压缩备份
	ExcludeExt    []string `yaml:"exclude_ext"`     // 排除的文件扩展名
	NotifyOnDone  bool     `yaml:"notify_on_done"`  // 备份完成通知
}

// NetworkConfig 组网配置
type NetworkConfig struct {
	Provider    string `yaml:"provider"`     // 组网服务商: tailscale / zerotier / n2n / custom
	AuthKey     string `yaml:"auth_key"`     // 组网认证密钥（自助接入用）
	APIEndpoint string `yaml:"api_endpoint"` // 自定义 API 地址
	DeviceName  string `yaml:"device_name"`  // 本设备在组网中的名称
	AutoJoin    bool   `yaml:"auto_join"`    // 启动时自动加入组网
	// N2N 配置
	N2NSupernode string `yaml:"n2n_supernode"` // n2n 超级节点地址
	N2NCommunity string `yaml:"n2n_community"` // n2n 社区名
	N2NEncryptKey string `yaml:"n2n_encrypt_key"` // n2n 加密密钥
	N2NIP        string `yaml:"n2n_ip"`        // n2n 虚拟IP
	N2NPort      int    `yaml:"n2n_port"`      // n2n 本地端口
}

type LogConfig struct {
	Level    string `yaml:"level"`     // debug/info/warn/error
	File     string `yaml:"file"`      // 日志文件路径（空=输出到终端）
	MaxSize  int    `yaml:"max_size"`  // 单日志文件上限(MB)，默认 10
	MaxDays  int    `yaml:"max_days"`  // 保留天数，默认 7
}

// DefaultConfig 返回默认配置
func DefaultConfig() *Config {
	home, _ := os.UserHomeDir()
	return &Config{
		Server: ServerConfig{
			Host:      "0.0.0.0",
			Port:      8443,
			HTTPS:     true,
			UploadMax: 1024,
			FTPPort:   2121,
		},
		Auth: AuthConfig{
			Username:        "admin",
			TokenExpireHour: 24,
		},
		Security: SecurityConfig{
			MaxFailedLogin:  5,
			LockoutMinute:   30,
			RateLimitPerMin: 300,
		},
		Storage: StorageConfig{
			RootDir:  filepath.Join(home, "nas-share"),
			ReadOnly: false,
		},
		Media: MediaConfig{
			EnableDLNA:     false,
			DLNAPort:       8200,
			EnableWebPlayer: true,
			Transcode:      false,
		},
		Backup: BackupConfig{
			Enable:        false,
			BackupDir:     filepath.Join(home, "nas-backups"),
			IntervalHours: 24,
			BackupTime:    "03:00",
			RetentionDays: 30,
			MaxBackups:    10,
			Compress:      true,
			NotifyOnDone:  true,
		},
		Network: NetworkConfig{
			Provider:    "n2n",
			DeviceName:  "termux-nas",
			AutoJoin:    false,
			N2NSupernode: "wang.switchy.hin2n.stars:10086",
			N2NCommunity: "nas-network",
			N2NEncryptKey: "nas123456",
			N2NIP:       "192.168.100.1",
			N2NPort:     50000,
		},
		Log: LogConfig{
			Level:   "info",
			MaxSize: 10,
			MaxDays: 7,
		},
	}
}

// LoadConfig 从文件加载配置
func LoadConfig(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("读取配置文件失败: %w", err)
	}
	cfg := DefaultConfig()
	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, fmt.Errorf("解析配置文件失败: %w", err)
	}
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	return cfg, nil
}

// Validate 校验配置
func (c *Config) Validate() error {
	if c.Auth.Username == "" {
		return fmt.Errorf("auth.username 不能为空")
	}
	if c.Auth.PasswordHash == "" {
		return fmt.Errorf("auth.password_hash 不能为空，请先用 -gen-pass 生成")
	}
	if c.Auth.JWTSecret == "" || len(c.Auth.JWTSecret) < 32 {
		return fmt.Errorf("auth.jwt_secret 不能为空且至少32字符，请用 -gen-secret 生成")
	}
	if c.Server.HTTPS {
		if c.Server.CertFile == "" || c.Server.KeyFile == "" {
			return fmt.Errorf("启用 HTTPS 时必须配置 cert_file 和 key_file")
		}
	}
	if c.Storage.RootDir == "" {
		return fmt.Errorf("storage.root_dir 不能为空")
	}
	// 确保根目录存在
	if err := os.MkdirAll(c.Storage.RootDir, 0755); err != nil {
		return fmt.Errorf("创建存储目录失败: %w", err)
	}
	return nil
}

// SaveConfig 保存配置到文件
func (c *Config) SaveConfig(path string) error {
	data, err := yaml.Marshal(c)
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0600)
}
