package main

import (
	"archive/tar"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

// BackupInfo 备份信息
type BackupInfo struct {
	ID        string    `json:"id"`
	Name      string    `json:"name"`
	Type      string    `json:"type"`      // full / incremental
	Size      int64     `json:"size"`
	FileCount int       `json:"file_count"`
	CreatedAt time.Time `json:"created_at"`
	Sources   []string  `json:"sources"`
	Status    string    `json:"status"` // completed / in_progress / failed
	Error     string    `json:"error,omitempty"`
}

// BackupCategory 备份分类
type BackupCategory struct {
	ID       string   `json:"id"`
	Name     string   `json:"name"`
	Icon     string   `json:"icon"`
	Color    string   `json:"color"`
	Dirs     []string `json:"dirs"`
	FileCount int     `json:"file_count"`
	TotalSize int64   `json:"total_size"`
	Selected bool    `json:"selected"`
}

// GetBackupCategories 获取备份分类
func GetBackupCategories(brand string) []BackupCategory {
	home, _ := os.UserHomeDir()
	sp := filepath.Join(home, "storage", "shared")

	categories := []BackupCategory{
		{
			ID:    "photos",
			Name:  "图片",
			Icon:  "🖼️",
			Color: "#8b5cf6",
			Dirs:  []string{filepath.Join(sp, "DCIM", "Camera"), filepath.Join(sp, "Pictures"), filepath.Join(sp, "DCIM", "Screenshots")},
		},
		{
			ID:    "media",
			Name:  "音频、视频和文档",
			Icon:  "🎬",
			Color: "#6366f1",
			Dirs:  []string{filepath.Join(sp, "Movies"), filepath.Join(sp, "Music"), filepath.Join(sp, "Download"), filepath.Join(sp, "Documents")},
		},
		{
			ID:    "wechat",
			Name:  "QQ、微信",
			Icon:  "💬",
			Color: "#22c55e",
			Dirs:  []string{filepath.Join(sp, "Tencent"), filepath.Join(sp, "Android", "data", "com.tencent.mm"), filepath.Join(sp, "Android", "data", "com.tencent.mobileqq")},
		},
		{
			ID:    "apps",
			Name:  "第三方应用数据",
			Icon:  "📦",
			Color: "#3b82f6",
			Dirs:  []string{filepath.Join(sp, "Android", "data")},
		},
	}

	// 小米专属分类
	if brand == "xiaomi" {
		categories = append(categories, BackupCategory{
			ID:    "xiaomi_system",
			Name:  "小米系统数据",
			Icon:  "⚙️",
			Color: "#f59e0b",
			Dirs:  []string{filepath.Join(sp, "MIUI", "sound_recorder"), filepath.Join(sp, "MIUI", "backup"), filepath.Join(sp, "MIUI", "screen_recorder")},
		})
	}

	// 一加/OPPO专属分类
	if brand == "oneplus" {
		categories = append(categories, BackupCategory{
			ID:    "oppo_system",
			Name:  "OPPO系统数据",
			Icon:  "⚙️",
			Color: "#f59e0b",
			Dirs:  []string{filepath.Join(sp, "OPPO", "录音"), filepath.Join(sp, "OPPO", "备份")},
		})
	}

	// 统计每个分类的文件数和大小
	for i := range categories {
		count, size := countDirs(categories[i].Dirs)
		categories[i].FileCount = count
		categories[i].TotalSize = size
	}

	return categories
}

// countDirs 统计目录文件数和大小
func countDirs(dirs []string) (int, int64) {
	var count int
	var size int64
	for _, dir := range dirs {
		filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
			if err != nil || info == nil || info.IsDir() {
				return nil
			}
			count++
			size += info.Size()
			return nil
		})
	}
	return count, size
}

// GetCategoriesFromIDs 根据ID列表获取目录
func GetCategoriesFromIDs(ids []string, brand string) []string {
	categories := GetBackupCategories(brand)
	var dirs []string
	idSet := make(map[string]bool)
	for _, id := range ids {
		idSet[id] = true
	}
	for _, cat := range categories {
		if idSet[cat.ID] {
			dirs = append(dirs, cat.Dirs...)
		}
	}
	return dirs
}

// PhoneBrandPreset 手机品牌备份预设
type PhoneBrandPreset struct {
	Brand    string   `json:"brand"`
	Name     string   `json:"name"`
	Icon     string   `json:"icon"`
	Dirs     []string `json:"dirs"`
	Desc     string   `json:"desc"`
}

// GetPhoneBrandPresets 获取手机品牌备份预设
func GetPhoneBrandPresets() []PhoneBrandPreset {
	home, _ := os.UserHomeDir()
	storagePrefix := filepath.Join(home, "storage", "shared")

	return []PhoneBrandPreset{
		{
			Brand: "xiaomi",
			Name:  "小米 / Redmi",
			Icon:  "📱",
			Desc:  "MIUI/HyperOS 完整数据备份",
			Dirs: []string{
				filepath.Join(storagePrefix, "DCIM", "Camera"),
				filepath.Join(storagePrefix, "DCIM", "Screenshots"),
				filepath.Join(storagePrefix, "DCIM", "ScreenRecorder"),
				filepath.Join(storagePrefix, "MIUI", "sound_recorder"),
				filepath.Join(storagePrefix, "MIUI", "backup"),
				filepath.Join(storagePrefix, "Download"),
				filepath.Join(storagePrefix, "Documents"),
				filepath.Join(storagePrefix, "Pictures"),
				filepath.Join(storagePrefix, "Movies"),
				filepath.Join(storagePrefix, "Music"),
				filepath.Join(storagePrefix, "WhatsApp"),
			},
		},
		{
			Brand: "oneplus",
			Name:  "一加 / OPPO",
			Icon:  "📱",
			Desc:  "ColorOS/OxygenOS 完整数据备份",
			Dirs: []string{
				filepath.Join(storagePrefix, "DCIM", "Camera"),
				filepath.Join(storagePrefix, "DCIM", "Screenshots"),
				filepath.Join(storagePrefix, "OPPO", "录音"),
				filepath.Join(storagePrefix, "OPPO", "备份"),
				filepath.Join(storagePrefix, "Download"),
				filepath.Join(storagePrefix, "Documents"),
				filepath.Join(storagePrefix, "Pictures"),
				filepath.Join(storagePrefix, "Movies"),
				filepath.Join(storagePrefix, "Music"),
				filepath.Join(storagePrefix, "WhatsApp"),
			},
		},
		{
			Brand: "common",
			Name:  "通用安卓",
			Icon:  "📱",
			Desc:  "通用手机数据备份",
			Dirs: []string{
				filepath.Join(storagePrefix, "DCIM"),
				filepath.Join(storagePrefix, "Download"),
				filepath.Join(storagePrefix, "Documents"),
				filepath.Join(storagePrefix, "Pictures"),
				filepath.Join(storagePrefix, "Movies"),
				filepath.Join(storagePrefix, "Music"),
			},
		},
		{
			Brand: "photos_only",
			Name:  "仅照片视频",
			Icon:  "🖼️",
			Desc:  "只备份照片和视频",
			Dirs: []string{
				filepath.Join(storagePrefix, "DCIM"),
				filepath.Join(storagePrefix, "Pictures"),
				filepath.Join(storagePrefix, "Movies"),
			},
		},
		{
			Brand: "full",
			Name:  "全部存储",
			Icon:  "💾",
			Desc:  "备份整个共享存储",
			Dirs: []string{
				storagePrefix,
			},
		},
	}
}

// DetectPhoneBrand 检测手机品牌
func DetectPhoneBrand() string {
	// 检测 MIUI 目录
	home, _ := os.UserHomeDir()
	if _, err := os.Stat(filepath.Join(home, "storage", "shared", "MIUI")); err == nil {
		return "xiaomi"
	}
	// 检测 OPPO/一加目录
	if _, err := os.Stat(filepath.Join(home, "storage", "shared", "OPPO")); err == nil {
		return "oneplus"
	}
	// 通过系统属性检测
	if output, err := exec.Command("getprop", "ro.product.manufacturer").Output(); err == nil {
		manufacturer := strings.ToLower(strings.TrimSpace(string(output)))
		if strings.Contains(manufacturer, "xiaomi") || strings.Contains(manufacturer, "redmi") {
			return "xiaomi"
		}
		if strings.Contains(manufacturer, "oneplus") || strings.Contains(manufacturer, "oppo") {
			return "oneplus"
		}
	}
	return "common"
}

// ApplyBrandPreset 应用品牌预设
func (bm *BackupManager) ApplyBrandPreset(brand string) error {
	presets := GetPhoneBrandPresets()
	for _, p := range presets {
		if p.Brand == brand {
			bm.cfg.Sources = p.Dirs
			bm.logger.Info("应用备份预设: %s, 目录数: %d", p.Name, len(p.Dirs))
			return nil
		}
	}
	return fmt.Errorf("未知品牌预设: %s", brand)
}

// BackupManager 备份管理器
type BackupManager struct {
	cfg           *BackupConfig
	logger        *Logger
	notifyMgr     *NotificationManager
	mu            sync.Mutex
	backups       []BackupInfo
	current       *BackupInfo
	autoBackupRunning bool
	stopAutoBackup chan struct{}
	lastBackupTime time.Time
	nextBackupTime time.Time
}

// NewBackupManager 创建备份管理器
func NewBackupManager(cfg *BackupConfig, logger *Logger, notifyMgr *NotificationManager) *BackupManager {
	bm := &BackupManager{
		cfg:    cfg,
		logger: logger,
		notifyMgr: notifyMgr,
		stopAutoBackup: make(chan struct{}),
	}
	os.MkdirAll(cfg.BackupDir, 0755)
	bm.loadBackups()
	// 如果启用了自动备份，启动定时任务
	if cfg.Enable && (cfg.IntervalHours > 0 || cfg.BackupTime != "") {
		go bm.startAutoBackup()
	}
	return bm
}

// startAutoBackup 启动自动备份定时任务
func (bm *BackupManager) startAutoBackup() {
	bm.mu.Lock()
	if bm.autoBackupRunning {
		bm.mu.Unlock()
		return
	}
	bm.autoBackupRunning = true
	bm.mu.Unlock()

	bm.logger.Info("backup", "action", "自动备份任务已启动")

	ticker := time.NewTicker(1 * time.Minute)
	defer ticker.Stop()

	for {
		select {
		case <-bm.stopAutoBackup:
			bm.mu.Lock()
			bm.autoBackupRunning = false
			bm.mu.Unlock()
			bm.logger.Info("backup", "action", "自动备份任务已停止")
			return
		case <-ticker.C:
			bm.checkAndBackup()
		}
	}
}

// checkAndBackup 检查是否需要备份
func (bm *BackupManager) checkAndBackup() {
	bm.mu.Lock()
	cfg := *bm.cfg
	bm.mu.Unlock()

	now := time.Now()

	// 按间隔时间备份
	if cfg.IntervalHours > 0 {
		if bm.lastBackupTime.IsZero() || now.Sub(bm.lastBackupTime) >= time.Duration(cfg.IntervalHours)*time.Hour {
			bm.doAutoBackup("interval")
			return
		}
	}

	// 按每日时间备份
	if cfg.BackupTime != "" {
		parts := strings.Split(cfg.BackupTime, ":")
		if len(parts) == 2 {
			var hour, minute int
			fmt.Sscanf(parts[0], "%d", &hour)
			fmt.Sscanf(parts[1], "%d", &minute)
			targetTime := time.Date(now.Year(), now.Month(), now.Day(), hour, minute, 0, 0, now.Location())
			// 如果目标时间已过，且距离上次备份超过23小时，则备份
			if now.After(targetTime) && now.Sub(targetTime) < 5*time.Minute {
				if bm.lastBackupTime.IsZero() || now.Sub(bm.lastBackupTime) > 23*time.Hour {
					bm.doAutoBackup("scheduled")
				}
			}
		}
	}
}

// doAutoBackup 执行自动备份
func (bm *BackupManager) doAutoBackup(reason string) {
	bm.mu.Lock()
	if bm.current != nil && bm.current.Status == "in_progress" {
		bm.mu.Unlock()
		return
	}
	bm.mu.Unlock()

	name := fmt.Sprintf("auto-%s-%s", reason, time.Now().Format("20060102-150405"))
	bm.logger.Info("触发自动备份: %s", name)

	info, err := bm.CreateBackup(name, nil)
	if err != nil {
		bm.logger.Error("自动备份失败: %v", err)
		return
	}

	bm.mu.Lock()
	bm.lastBackupTime = time.Now()
	bm.updateNextBackupTime()
	bm.mu.Unlock()

	_ = info
}

// updateNextBackupTime 更新下次备份时间
func (bm *BackupManager) updateNextBackupTime() {
	if bm.cfg.IntervalHours > 0 {
		bm.nextBackupTime = bm.lastBackupTime.Add(time.Duration(bm.cfg.IntervalHours) * time.Hour)
	} else if bm.cfg.BackupTime != "" {
		now := time.Now()
		parts := strings.Split(bm.cfg.BackupTime, ":")
		if len(parts) == 2 {
			var hour, minute int
			fmt.Sscanf(parts[0], "%d", &hour)
			fmt.Sscanf(parts[1], "%d", &minute)
			bm.nextBackupTime = time.Date(now.Year(), now.Month(), now.Day(), hour, minute, 0, 0, now.Location())
			if bm.nextBackupTime.Before(now) {
				bm.nextBackupTime = bm.nextBackupTime.Add(24 * time.Hour)
			}
		}
	}
}

// StopAutoBackup 停止自动备份
func (bm *BackupManager) StopAutoBackup() {
	bm.mu.Lock()
	defer bm.mu.Unlock()
	if bm.autoBackupRunning {
		close(bm.stopAutoBackup)
		bm.stopAutoBackup = make(chan struct{})
	}
}

// StartAutoBackup 启动自动备份
func (bm *BackupManager) StartAutoBackup() {
	go bm.startAutoBackup()
}

// GetAutoBackupStatus 获取自动备份状态
func (bm *BackupManager) GetAutoBackupStatus() map[string]interface{} {
	bm.mu.Lock()
	defer bm.mu.Unlock()

	return map[string]interface{}{
		"enabled":         bm.cfg.Enable,
		"running":         bm.autoBackupRunning,
		"interval_hours":  bm.cfg.IntervalHours,
		"backup_time":     bm.cfg.BackupTime,
		"last_backup":     bm.lastBackupTime.Format("2006-01-02 15:04:05"),
		"next_backup":     bm.nextBackupTime.Format("2006-01-02 15:04:05"),
		"retention_days":  bm.cfg.RetentionDays,
		"max_backups":     bm.cfg.MaxBackups,
		"sources":         bm.cfg.Sources,
		"detected_brand":  DetectPhoneBrand(),
	}
}

// loadBackups 加载备份列表
func (bm *BackupManager) loadBackups() {
	bm.mu.Lock()
	defer bm.mu.Unlock()

	bm.backups = nil
	entries, err := os.ReadDir(bm.cfg.BackupDir)
	if err != nil {
		return
	}
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		data, err := os.ReadFile(filepath.Join(bm.cfg.BackupDir, e.Name()))
		if err != nil {
			continue
		}
		var info BackupInfo
		if err := json.Unmarshal(data, &info); err == nil {
			bm.backups = append(bm.backups, info)
		}
	}
	sort.Slice(bm.backups, func(i, j int) bool {
		return bm.backups[i].CreatedAt.After(bm.backups[j].CreatedAt)
	})
}

// saveBackupInfo 保存备份信息
func (bm *BackupManager) saveBackupInfo(info *BackupInfo) error {
	path := filepath.Join(bm.cfg.BackupDir, info.ID+".json")
	data, err := json.MarshalIndent(info, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0644)
}

// CreateBackup 创建备份
func (bm *BackupManager) CreateBackup(name string, sources []string) (*BackupInfo, error) {
	bm.mu.Lock()
	if bm.current != nil && bm.current.Status == "in_progress" {
		bm.mu.Unlock()
		return nil, fmt.Errorf("已有备份正在进行中")
	}
	bm.mu.Unlock()

	if len(sources) == 0 {
		sources = bm.cfg.Sources
	}
	if name == "" {
		name = fmt.Sprintf("backup-%s", time.Now().Format("20060102-150405"))
	}

	info := &BackupInfo{
		ID:        fmt.Sprintf("bk_%d", time.Now().Unix()),
		Name:      name,
		Type:      "full",
		CreatedAt: time.Now(),
		Sources:   sources,
		Status:    "in_progress",
	}

	bm.mu.Lock()
	bm.current = info
	bm.mu.Unlock()

	go func() {
		defer func() {
			bm.mu.Lock()
			bm.current = nil
			bm.mu.Unlock()
			bm.loadBackups()
		}()

		archivePath := filepath.Join(bm.cfg.BackupDir, info.ID+".tar.gz")
		fileCount, size, err := bm.createArchive(archivePath, sources)
		if err != nil {
			info.Status = "failed"
			info.Error = err.Error()
			bm.saveBackupInfo(info)
			bm.logger.Error("备份失败: %v", err)
			return
		}

		info.Status = "completed"
		info.FileCount = fileCount
		info.Size = size
		bm.saveBackupInfo(info)
		bm.logger.Info("备份完成: %s, 文件数: %d, 大小: %s", info.Name, fileCount, formatSize(size))
		// 发送通知
		if bm.notifyMgr != nil {
			bm.notifyMgr.Add("success", "backup", "备份完成",
				fmt.Sprintf("%s 备份成功，共 %d 个文件，大小 %s", info.Name, fileCount, formatSize(size)))
		}

		// 清理过期备份
		bm.cleanupOld()
	}()

	return info, nil
}

// createArchive 创建压缩包
func (bm *BackupManager) createArchive(archivePath string, sources []string) (int, int64, error) {
	file, err := os.Create(archivePath)
	if err != nil {
		return 0, 0, err
	}
	defer file.Close()

	var gzWriter *gzip.Writer
	var tarWriter *tar.Writer

	if bm.cfg.Compress {
		gzWriter = gzip.NewWriter(file)
		defer gzWriter.Close()
		tarWriter = tar.NewWriter(gzWriter)
	} else {
		tarWriter = tar.NewWriter(file)
	}
	defer tarWriter.Close()

	fileCount := 0
	var totalSize int64

	for _, src := range sources {
		// 展开 ~ 为用户主目录
		if strings.HasPrefix(src, "~/") {
			home, _ := os.UserHomeDir()
			src = filepath.Join(home, src[2:])
		}

		err := filepath.Walk(src, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return nil // 跳过无法访问的文件
			}
			if info.IsDir() {
				return nil
			}

			// 检查排除扩展名
			ext := strings.ToLower(filepath.Ext(path))
			for _, e := range bm.cfg.ExcludeExt {
				if ext == strings.ToLower(e) {
					return nil
				}
			}

			// 跳过过大的文件（>2GB）
			if info.Size() > 2*1024*1024*1024 {
				return nil
			}

			// 读取文件
			f, err := os.Open(path)
			if err != nil {
				return nil
			}
			defer f.Close()

			// 创建 tar header
			header, err := tar.FileInfoHeader(info, path)
			if err != nil {
				return nil
			}
			header.Name = path

			if err := tarWriter.WriteHeader(header); err != nil {
				return nil
			}
			if _, err := io.Copy(tarWriter, f); err != nil {
				return nil
			}

			fileCount++
			totalSize += info.Size()
			return nil
		})
		if err != nil {
			return fileCount, totalSize, err
		}
	}

	return fileCount, totalSize, nil
}

// RestoreBackup 恢复备份
func (bm *BackupManager) RestoreBackup(backupID, targetDir string) error {
	bm.mu.Lock()
	defer bm.mu.Unlock()

	archivePath := filepath.Join(bm.cfg.BackupDir, backupID+".tar.gz")
	if _, err := os.Stat(archivePath); os.IsNotExist(err) {
		// 尝试未压缩版本
		archivePath = filepath.Join(bm.cfg.BackupDir, backupID+".tar")
		if _, err := os.Stat(archivePath); os.IsNotExist(err) {
			return fmt.Errorf("备份文件不存在: %s", backupID)
		}
	}

	if targetDir == "" {
		targetDir = filepath.Join(bm.cfg.BackupDir, "restore_"+backupID)
	}
	os.MkdirAll(targetDir, 0755)

	file, err := os.Open(archivePath)
	if err != nil {
		return err
	}
	defer file.Close()

	var tarReader *tar.Reader

	if strings.HasSuffix(archivePath, ".gz") {
		gzReader, err := gzip.NewReader(file)
		if err != nil {
			return err
		}
		defer gzReader.Close()
		tarReader = tar.NewReader(gzReader)
	} else {
		tarReader = tar.NewReader(file)
	}

	restoredCount := 0
	for {
		header, err := tarReader.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			continue
		}

		target := filepath.Join(targetDir, header.Name)
		// 安全检查：防止路径遍历
		if !strings.HasPrefix(filepath.Clean(target), filepath.Clean(targetDir)) {
			continue
		}

		switch header.Typeflag {
		case tar.TypeDir:
			os.MkdirAll(target, 0755)
		case tar.TypeReg:
			os.MkdirAll(filepath.Dir(target), 0755)
			f, err := os.Create(target)
			if err != nil {
				continue
			}
			io.Copy(f, tarReader)
			f.Close()
			restoredCount++
		}
	}

	bm.logger.Info("备份恢复完成: %s -> %s, 恢复文件数: %d", backupID, targetDir, restoredCount)
	return nil
}

// handleBackupDelete 删除备份
func (h *NASHandler) handleBackupDelete(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodDelete {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	backupID := strings.TrimPrefix(r.URL.Path, "/api/backup/")
	if backupID == "" {
		http.Error(w, "Missing backup ID", http.StatusBadRequest)
		return
	}
	if err := h.backupMgr.DeleteBackup(backupID); err != nil {
		http.Error(w, "Failed to delete", http.StatusInternalServerError)
		return
	}
	h.logger.Info("删除备份: %s", backupID)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// ListBackups 列出备份
func (bm *BackupManager) ListBackups() []BackupInfo {
	bm.mu.Lock()
	defer bm.mu.Unlock()
	return bm.backups
}

// DeleteBackup 删除备份
func (bm *BackupManager) DeleteBackup(backupID string) error {
	bm.mu.Lock()
	defer bm.mu.Unlock()

	os.Remove(filepath.Join(bm.cfg.BackupDir, backupID+".tar.gz"))
	os.Remove(filepath.Join(bm.cfg.BackupDir, backupID+".tar"))
	os.Remove(filepath.Join(bm.cfg.BackupDir, backupID+".json"))

	bm.loadBackups()
	return nil
}

// cleanupOld 清理过期备份
func (bm *BackupManager) cleanupOld() {
	cutoff := time.Now().AddDate(0, 0, -bm.cfg.RetentionDays)
	for _, b := range bm.backups {
		if b.CreatedAt.Before(cutoff) {
			os.Remove(filepath.Join(bm.cfg.BackupDir, b.ID+".tar.gz"))
			os.Remove(filepath.Join(bm.cfg.BackupDir, b.ID+".json"))
			bm.logger.Info("清理过期备份: %s", b.Name)
		}
	}
	bm.loadBackups()
}

// GetCurrent 获取当前正在进行的备份
func (bm *BackupManager) GetCurrent() *BackupInfo {
	bm.mu.Lock()
	defer bm.mu.Unlock()
	return bm.current
}

// formatSize 格式化文件大小
func formatSize(bytes int64) string {
	if bytes < 1024 {
		return fmt.Sprintf("%d B", bytes)
	}
	if bytes < 1048576 {
		return fmt.Sprintf("%.1f KB", float64(bytes)/1024)
	}
	if bytes < 1073741824 {
		return fmt.Sprintf("%.1f MB", float64(bytes)/1048576)
	}
	return fmt.Sprintf("%.2f GB", float64(bytes)/1073741824)
}

// ===== HTTP API 处理函数 =====

func (h *NASHandler) handleBackupList(w http.ResponseWriter, r *http.Request) {
	backups := h.backupMgr.ListBackups()
	current := h.backupMgr.GetCurrent()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"backups": backups,
		"current": current,
		"config": map[string]interface{}{
			"backup_dir":     h.cfg.Backup.BackupDir,
			"retention_days": h.cfg.Backup.RetentionDays,
			"compress":       h.cfg.Backup.Compress,
			"sources":        h.cfg.Backup.Sources,
		},
	})
}

func (h *NASHandler) handleBackupCreate(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Name    string   `json:"name"`
		Sources []string `json:"sources"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	info, err := h.backupMgr.CreateBackup(req.Name, req.Sources)
	if err != nil {
		http.Error(w, err.Error(), http.StatusConflict)
		return
	}
	h.logger.Info("创建备份任务: %s", info.Name)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"backup":  info,
	})
}

func (h *NASHandler) handleBackupRestore(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		BackupID string `json:"backup_id"`
		Target   string `json:"target"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	go func() {
		if err := h.backupMgr.RestoreBackup(req.BackupID, req.Target); err != nil {
			h.logger.Error("恢复备份失败: %v", err)
		}
	}()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "恢复任务已开始",
	})
}

// handleBackupAutoStatus 自动备份状态
func (h *NASHandler) handleBackupAutoStatus(w http.ResponseWriter, r *http.Request) {
	status := h.backupMgr.GetAutoBackupStatus()
	presets := GetPhoneBrandPresets()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":  status,
		"presets": presets,
	})
}

// handleBackupAutoConfig 配置自动备份
func (h *NASHandler) handleBackupAutoConfig(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Enable        bool     `json:"enable"`
		IntervalHours int      `json:"interval_hours"`
		BackupTime    string   `json:"backup_time"`
		RetentionDays int      `json:"retention_days"`
		MaxBackups    int      `json:"max_backups"`
		Sources       []string `json:"sources"`
		Brand         string   `json:"brand"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}

	// 应用品牌预设
	if req.Brand != "" {
		h.backupMgr.ApplyBrandPreset(req.Brand)
	}

	// 更新配置
	h.cfg.Backup.Enable = req.Enable
	if req.IntervalHours > 0 {
		h.cfg.Backup.IntervalHours = req.IntervalHours
	}
	if req.BackupTime != "" {
		h.cfg.Backup.BackupTime = req.BackupTime
	}
	if req.RetentionDays > 0 {
		h.cfg.Backup.RetentionDays = req.RetentionDays
	}
	if req.MaxBackups > 0 {
		h.cfg.Backup.MaxBackups = req.MaxBackups
	}
	if len(req.Sources) > 0 {
		h.cfg.Backup.Sources = req.Sources
	}

	// 启动/停止自动备份
	if req.Enable {
		h.backupMgr.StartAutoBackup()
	} else {
		h.backupMgr.StopAutoBackup()
	}

	h.logger.Info("自动备份配置已更新: enable=%v, interval=%dh, time=%s", req.Enable, req.IntervalHours, req.BackupTime)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"status":  h.backupMgr.GetAutoBackupStatus(),
	})
}

// handleBackupBrandPreset 应用品牌预设
func (h *NASHandler) handleBackupBrandPreset(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Brand string `json:"brand"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	if err := h.backupMgr.ApplyBrandPreset(req.Brand); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"sources": h.cfg.Backup.Sources,
	})
}

// handleBackupCategories 获取备份分类
func (h *NASHandler) handleBackupCategories(w http.ResponseWriter, r *http.Request) {
	brand := r.URL.Query().Get("brand")
	if brand == "" {
		brand = DetectPhoneBrand()
	}
	categories := GetBackupCategories(brand)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"brand":      brand,
		"categories": categories,
	})
}

// handleBackupExport 导出备份文件（下载）
func (h *NASHandler) handleBackupExport(w http.ResponseWriter, r *http.Request) {
	backupID := r.URL.Query().Get("id")
	if backupID == "" {
		http.Error(w, "缺少备份ID", http.StatusBadRequest)
		return
	}

	// 查找备份文件
	backupDir := filepath.Join(h.cfg.Storage.RootDir, ".backups")
	backupFile := filepath.Join(backupDir, backupID+".tar.gz")

	if _, err := os.Stat(backupFile); os.IsNotExist(err) {
		// 尝试其他命名格式
		entries, _ := os.ReadDir(backupDir)
		for _, e := range entries {
			if strings.Contains(e.Name(), backupID) {
				backupFile = filepath.Join(backupDir, e.Name())
				break
			}
		}
	}

	if _, err := os.Stat(backupFile); os.IsNotExist(err) {
		http.Error(w, "备份文件不存在", http.StatusNotFound)
		return
	}

	// 设置下载头
	fileName := "nas-backup-" + backupID + ".tar.gz"
	w.Header().Set("Content-Type", "application/gzip")
	w.Header().Set("Content-Disposition", "attachment; filename=\""+fileName+"\"")

	http.ServeFile(w, r, backupFile)
}

// handleBackupImport 导入备份文件（上传）
func (h *NASHandler) handleBackupImport(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseMultipartForm(5 << 30); err != nil {
		http.Error(w, "文件过大或解析失败", http.StatusBadRequest)
		return
	}

	file, _, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "未找到上传文件", http.StatusBadRequest)
		return
	}
	defer file.Close()

	// 生成备份ID
	backupID := fmt.Sprintf("import-%d", time.Now().Unix())
	backupDir := filepath.Join(h.cfg.Storage.RootDir, ".backups")
	os.MkdirAll(backupDir, 0755)

	backupFile := filepath.Join(backupDir, backupID+".tar.gz")
	out, err := os.Create(backupFile)
	if err != nil {
		http.Error(w, "创建文件失败", http.StatusInternalServerError)
		return
	}
	defer out.Close()

	written, err := io.Copy(out, file)
	if err != nil {
		http.Error(w, "保存文件失败", http.StatusInternalServerError)
		return
	}

	// 记录备份信息
	backupInfo := BackupInfo{
		ID:        backupID,
		Name:      "导入备份-" + time.Now().Format("2006-01-02 15:04:05"),
		Type:      "imported",
		Size:      written,
		CreatedAt: time.Now(),
		Status:    "completed",
	}

	// 保存备份记录
	recordsFile := filepath.Join(backupDir, "records.json")
	var records []BackupInfo
	if data, err := os.ReadFile(recordsFile); err == nil {
		json.Unmarshal(data, &records)
	}
	records = append([]BackupInfo{backupInfo}, records...)
	if data, err := json.MarshalIndent(records, "", "  "); err == nil {
		os.WriteFile(recordsFile, data, 0644)
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"backup_id": backupID,
		"size": written,
		"message": "备份导入成功，可在备份列表中恢复",
	})
}
