package main

import (
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// User 用户信息
type User struct {
	Username     string   `json:"username"`
	PasswordHash string   `json:"password_hash"`
	Role         string   `json:"role"`        // admin / user
	Email        string   `json:"email,omitempty"`
	CreatedAt    time.Time `json:"created_at"`
	LastLogin    time.Time `json:"last_login,omitempty"`
	Active       bool     `json:"active"`
	Permissions  []string `json:"permissions,omitempty"` // 可访问的功能模块
}

// 所有可用权限模块
var AllPermissions = []string{
	"files",         // 文件管理
	"video",         // 视频播放
	"music",         // 音乐播放
	"backup",        // 备份恢复
	"vault",         // 加密空间
	"cloud",         // 网盘访问（AList）
	"alist_upload",  // 网盘上传
	"alist_download",// 网盘下载
	"alist_delete",  // 网盘删除
	"alist_manage",  // 网盘管理（添加存储、设置等）
	"dlna",          // DLNA投屏
	"system",        // 系统监控
	"settings",      // 系统设置
	"users",         // 用户管理（仅管理员）
}

// UserManager 用户管理器
type UserManager struct {
	users    map[string]*User
	mu       sync.RWMutex
	filePath string
}

var globalUserManager *UserManager

// InitUserManager 初始化用户管理器
func InitUserManager(storageRoot string) {
	um := &UserManager{
		users:    make(map[string]*User),
		filePath: filepath.Join(storageRoot, ".users.json"),
	}
	um.load()
	globalUserManager = um
}

// load 从文件加载用户
func (um *UserManager) load() {
	um.mu.Lock()
	defer um.mu.Unlock()

	data, err := os.ReadFile(um.filePath)
	if err != nil {
		// 文件不存在，创建默认admin用户
		um.users["admin"] = &User{
			Username:    "admin",
			PasswordHash: "", // 使用配置中的密码
			Role:        "admin",
			CreatedAt:   time.Now(),
			Active:      true,
		}
		um.saveLocked()
		return
	}

	var users []User
	if err := json.Unmarshal(data, &users); err != nil {
		// 文件损坏，重建admin用户
		um.users["admin"] = &User{
			Username:    "admin",
			PasswordHash: "",
			Role:        "admin",
			CreatedAt:   time.Now(),
			Active:      true,
		}
		um.saveLocked()
		return
	}
	for i := range users {
		um.users[users[i].Username] = &users[i]
	}

	// 确保admin用户始终存在且为管理员
	if admin, exists := um.users["admin"]; exists {
		if admin.Role != "admin" {
			admin.Role = "admin"
			um.saveLocked()
		}
	} else {
		um.users["admin"] = &User{
			Username:    "admin",
			PasswordHash: "",
			Role:        "admin",
			CreatedAt:   time.Now(),
			Active:      true,
		}
		um.saveLocked()
	}
}

// saveLocked 保存用户（调用方需持有锁）
func (um *UserManager) saveLocked() {
	var users []User
	for _, u := range um.users {
		users = append(users, *u)
	}
	data, _ := json.MarshalIndent(users, "", "  ")
	os.WriteFile(um.filePath, data, 0600)
}

// GetUser 获取用户
func (um *UserManager) GetUser(username string) *User {
	um.mu.RLock()
	defer um.mu.RUnlock()
	return um.users[username]
}

// GetAllUsers 获取所有用户
func (um *UserManager) GetAllUsers() []User {
	um.mu.RLock()
	defer um.mu.RUnlock()
	var users []User
	for _, u := range um.users {
		users = append(users, *u)
	}
	return users
}

// AddUser 添加用户
func (um *UserManager) AddUser(username, password, role, email string) error {
	um.mu.Lock()
	defer um.mu.Unlock()

	if _, exists := um.users[username]; exists {
		return errUserExists
	}

	hash, err := HashPassword(password)
	if err != nil {
		return err
	}

	um.users[username] = &User{
		Username:     username,
		PasswordHash: hash,
		Role:         role,
		Email:        email,
		CreatedAt:    time.Now(),
		Active:       true,
	}
	um.saveLocked()
	return nil
}

// UpdateUser 更新用户
func (um *UserManager) UpdateUser(username, password, role, email string, active *bool) error {
	um.mu.Lock()
	defer um.mu.Unlock()

	u, exists := um.users[username]
	if !exists {
		return errUserNotFound
	}

	if password != "" {
		hash, err := HashPassword(password)
		if err != nil {
			return err
		}
		u.PasswordHash = hash
	}
	if role != "" {
		u.Role = role
	}
	if email != "" {
		u.Email = email
	}
	if active != nil {
		u.Active = *active
	}
	um.saveLocked()
	return nil
}

// DeleteUser 删除用户
func (um *UserManager) DeleteUser(username string) error {
	um.mu.Lock()
	defer um.mu.Unlock()

	if username == "admin" {
		return errCannotDeleteAdmin
	}
	if _, exists := um.users[username]; !exists {
		return errUserNotFound
	}
	delete(um.users, username)
	um.saveLocked()
	return nil
}

// VerifyPassword 验证用户密码
func (um *UserManager) VerifyPassword(username, password string) bool {
	um.mu.RLock()
	defer um.mu.RUnlock()

	u, exists := um.users[username]
	if !exists || !u.Active {
		return false
	}

	// admin用户使用配置中的密码
	if username == "admin" && u.PasswordHash == "" {
		return globalAuthMgr.CheckPassword(password)
	}

	return checkPasswordHash(u.PasswordHash, password)
}

// UpdateLastLogin 更新最后登录时间
func (um *UserManager) UpdateLastLogin(username string) {
	um.mu.Lock()
	defer um.mu.Unlock()
	if u, exists := um.users[username]; exists {
		u.LastLogin = time.Now()
		um.saveLocked()
	}
}

// IsAdmin 检查是否为管理员
func (um *UserManager) IsAdmin(username string) bool {
	u := um.GetUser(username)
	return u != nil && u.Role == "admin"
}

// HasPermission 检查用户是否有指定模块的访问权限
func (um *UserManager) HasPermission(username, module string) bool {
	// admin拥有所有权限
	if um.IsAdmin(username) {
		return true
	}
	u := um.GetUser(username)
	if u == nil || !u.Active {
		return false
	}
	// 空权限列表表示没有任何权限
	if len(u.Permissions) == 0 {
		return false
	}
	for _, p := range u.Permissions {
		if p == module {
			return true
		}
	}
	return false
}

// GetPermissions 获取用户权限列表
func (um *UserManager) GetPermissions(username string) []string {
	u := um.GetUser(username)
	if u == nil {
		return []string{}
	}
	if u.Permissions == nil {
		return []string{}
	}
	return u.Permissions
}

// SetPermissions 设置用户权限
func (um *UserManager) SetPermissions(username string, permissions []string) error {
	um.mu.Lock()
	defer um.mu.Unlock()

	u, exists := um.users[username]
	if !exists {
		return errUserNotFound
	}
	// 过滤无效权限
	validPerms := []string{}
	for _, p := range permissions {
		for _, valid := range AllPermissions {
			if p == valid {
				validPerms = append(validPerms, p)
				break
			}
		}
	}
	u.Permissions = validPerms
	um.saveLocked()
	return nil
}

// 错误定义
var (
	errUserExists       = &userError{"用户已存在"}
	errUserNotFound     = &userError{"用户不存在"}
	errCannotDeleteAdmin = &userError{"不能删除管理员"}
	errPermissionDenied = &userError{"权限不足"}
)

type userError struct{ msg string }

func (e *userError) Error() string { return e.msg }

// writeJSONError 返回JSON格式的错误
func writeJSONError(w http.ResponseWriter, message string, status int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(map[string]interface{}{
		"error":   message,
		"success": false,
	})
}

// checkPasswordHash 验证密码哈希
func checkPasswordHash(hash, password string) bool {
	if hash == "" {
		return false
	}
	return globalAuthMgr != nil && globalAuthMgr.CheckPasswordWithHash(hash, password)
}

// ===== HTTP Handlers =====

// handleUserList 用户列表
func (h *NASHandler) handleUserList(w http.ResponseWriter, r *http.Request) {
	username := h.getCurrentUser(r)
	if !globalUserManager.IsAdmin(username) {
		writeJSONError(w, "权限不足", http.StatusForbidden)
		return
	}

	users := globalUserManager.GetAllUsers()
	// 隐藏密码哈希
	for i := range users {
		users[i].PasswordHash = ""
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"users": users,
	})
}

// handleUserCreate 创建用户
func (h *NASHandler) handleUserCreate(w http.ResponseWriter, r *http.Request) {
	username := h.getCurrentUser(r)
	if !globalUserManager.IsAdmin(username) {
		writeJSONError(w, "权限不足", http.StatusForbidden)
		return
	}

	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
		Role     string `json:"role"`
		Email    string `json:"email"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSONError(w, "参数错误", http.StatusBadRequest)
		return
	}

	if req.Username == "" || req.Password == "" {
		writeJSONError(w, "用户名和密码不能为空", http.StatusBadRequest)
		return
	}
	if req.Role == "" {
		req.Role = "user"
	}

	if err := globalUserManager.AddUser(req.Username, req.Password, req.Role, req.Email); err != nil {
		writeJSONError(w, err.Error(), http.StatusBadRequest)
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "用户创建成功",
	})
}

// handleUserUpdate 更新用户
func (h *NASHandler) handleUserUpdate(w http.ResponseWriter, r *http.Request) {
	currentUser := h.getCurrentUser(r)

	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
		Role     string `json:"role"`
		Email    string `json:"email"`
		Active   *bool  `json:"active"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSONError(w, "参数错误", http.StatusBadRequest)
		return
	}

	// 只能修改自己，或管理员修改任何人
	if currentUser != req.Username && !globalUserManager.IsAdmin(currentUser) {
		writeJSONError(w, "权限不足", http.StatusForbidden)
		return
	}

	// 普通用户不能修改角色和状态
	if !globalUserManager.IsAdmin(currentUser) {
		req.Role = ""
		req.Active = nil
	}

	if err := globalUserManager.UpdateUser(req.Username, req.Password, req.Role, req.Email, req.Active); err != nil {
		writeJSONError(w, err.Error(), http.StatusBadRequest)
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "用户更新成功",
	})
}

// handleUserDelete 删除用户
func (h *NASHandler) handleUserDelete(w http.ResponseWriter, r *http.Request) {
	currentUser := h.getCurrentUser(r)
	if !globalUserManager.IsAdmin(currentUser) {
		writeJSONError(w, "权限不足", http.StatusForbidden)
		return
	}

	username := r.URL.Query().Get("username")
	if username == "" {
		writeJSONError(w, "缺少用户名", http.StatusBadRequest)
		return
	}

	if err := globalUserManager.DeleteUser(username); err != nil {
		writeJSONError(w, err.Error(), http.StatusBadRequest)
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "用户删除成功",
	})
}

// handleUserPermissions 获取用户权限
func (h *NASHandler) handleUserPermissions(w http.ResponseWriter, r *http.Request) {
	currentUser := h.getCurrentUser(r)
	username := r.URL.Query().Get("username")
	if username == "" {
		username = currentUser
	}

	// 只能查看自己的权限，或管理员查看任何人
	if currentUser != username && !globalUserManager.IsAdmin(currentUser) {
		writeJSONError(w, "权限不足", http.StatusForbidden)
		return
	}

	permissions := globalUserManager.GetPermissions(username)
	isAdmin := globalUserManager.IsAdmin(username)

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success":     true,
		"username":    username,
		"is_admin":    isAdmin,
		"permissions": permissions,
		"all_permissions": AllPermissions,
	})
}

// handleUserSetPermissions 设置用户权限
func (h *NASHandler) handleUserSetPermissions(w http.ResponseWriter, r *http.Request) {
	currentUser := h.getCurrentUser(r)
	if !globalUserManager.IsAdmin(currentUser) {
		writeJSONError(w, "权限不足", http.StatusForbidden)
		return
	}

	var req struct {
		Username    string   `json:"username"`
		Permissions []string `json:"permissions"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSONError(w, "参数错误", http.StatusBadRequest)
		return
	}

	if req.Username == "" {
		writeJSONError(w, "缺少用户名", http.StatusBadRequest)
		return
	}

	// 不能修改admin的权限
	if req.Username == "admin" {
		writeJSONError(w, "不能修改管理员权限", http.StatusBadRequest)
		return
	}

	if err := globalUserManager.SetPermissions(req.Username, req.Permissions); err != nil {
		writeJSONError(w, err.Error(), http.StatusBadRequest)
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "权限设置成功",
	})
}

// getCurrentUser 从请求中获取当前用户
func (h *NASHandler) getCurrentUser(r *http.Request) string {
	token := ExtractToken(r)
	if token == "" {
		return ""
	}
	username, err := globalAuthMgr.ValidateToken(token)
	if err != nil {
		return ""
	}
	return username
}
