package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"net/http"
	"runtime"
	"strings"
	"sync"
	"time"
)

// RateLimiter 基于 IP 的令牌桶限流器
type RateLimiter struct {
	mu       sync.Mutex
	visitors map[string]*visitor
	rate     int           // 每分钟允许的请求数
	cleanup  time.Duration // 清理间隔
}

type visitor struct {
	tokens   int
	lastSeen time.Time
}

// NewRateLimiter 创建限流器
func NewRateLimiter(ratePerMin int) *RateLimiter {
	rl := &RateLimiter{
		visitors: make(map[string]*visitor),
		rate:     ratePerMin,
		cleanup:  5 * time.Minute,
	}
	go rl.cleanupStale()
	return rl
}

func (rl *RateLimiter) cleanupStale() {
	ticker := time.NewTicker(rl.cleanup)
	defer ticker.Stop()
	for range ticker.C {
		rl.mu.Lock()
		for ip, v := range rl.visitors {
			if time.Since(v.lastSeen) > 10*time.Minute {
				delete(rl.visitors, ip)
			}
		}
		rl.mu.Unlock()
	}
}

// Allow 检查是否允许请求
func (rl *RateLimiter) Allow(ip string) bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()
	v, ok := rl.visitors[ip]
	if !ok {
		rl.visitors[ip] = &visitor{tokens: rl.rate - 1, lastSeen: time.Now()}
		return true
	}
	// 补充令牌：每分钟补充 rate 个
	elapsed := time.Since(v.lastSeen).Minutes()
	v.tokens += int(elapsed * float64(rl.rate))
	if v.tokens > rl.rate {
		v.tokens = rl.rate
	}
	v.lastSeen = time.Now()
	if v.tokens > 0 {
		v.tokens--
		return true
	}
	return false
}

// SecurityMiddleware 安全中间件链
type SecurityMiddleware struct {
	auth     *AuthManager
	limiter  *RateLimiter
	cfg      *Config
	logger   *log.Logger
}

// NewSecurityMiddleware 创建安全中间件
func NewSecurityMiddleware(cfg *Config, auth *AuthManager, logger *log.Logger) *SecurityMiddleware {
	return &SecurityMiddleware{
		auth:    auth,
		limiter: NewRateLimiter(cfg.Security.RateLimitPerMin),
		cfg:     cfg,
		logger:  logger,
	}
}

// Chain 应用所有安全中间件
func (sm *SecurityMiddleware) Chain(next http.Handler) http.Handler {
	// 顺序：recover → 安全头 → IP白名单 → 限流 → 日志 → 认证
	handler := sm.authMiddleware(next)
	handler = sm.loggingMiddleware(handler)
	handler = sm.rateLimitMiddleware(handler)
	handler = sm.ipWhitelistMiddleware(handler)
	handler = sm.securityHeadersMiddleware(handler)
	handler = sm.recoverMiddleware(handler)
	return handler
}

// recoverMiddleware 全局panic恢复
func (sm *SecurityMiddleware) recoverMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				sm.logger.Printf("[PANIC] %s %s: %v", r.Method, r.URL.Path, err)
				// 打印堆栈
				buf := make([]byte, 4096)
				n := runtime.Stack(buf, false)
				sm.logger.Printf("[STACK] %s", buf[:n])
				// 返回错误响应
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusInternalServerError)
				json.NewEncoder(w).Encode(map[string]string{
					"error": "服务器内部错误",
					"detail": fmt.Sprintf("%v", err),
				})
			}
		}()
		next.ServeHTTP(w, r)
	})
}

// securityHeadersMiddleware 安全响应头
func (sm *SecurityMiddleware) securityHeadersMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-XSS-Protection", "1; mode=block")
		w.Header().Set("Referrer-Policy", "no-referrer")
		// 允许iframe嵌入AList（8444端口）
		w.Header().Del("X-Frame-Options")
		w.Header().Set("Content-Security-Policy", "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; img-src 'self' data: blob: https://127.0.0.1:8444 https://localhost:8444; media-src 'self' blob: https://127.0.0.1:8444 https://localhost:8444; connect-src 'self' https://127.0.0.1:8444 https://localhost:8444 ws: wss:; frame-src 'self' https://127.0.0.1:8444 https://localhost:8444; frame-ancestors 'self'")
		next.ServeHTTP(w, r)
	})
}

// ipWhitelistMiddleware IP 白名单
func (sm *SecurityMiddleware) ipWhitelistMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if len(sm.cfg.Security.AllowedIPs) == 0 {
			next.ServeHTTP(w, r)
			return
		}
		ip := GetClientIP(r, sm.cfg.Security.TrustedProxy)
		for _, allowed := range sm.cfg.Security.AllowedIPs {
			if ip == allowed || strings.HasPrefix(ip, allowed) {
				next.ServeHTTP(w, r)
				return
			}
		}
		sm.logger.Printf("[拒绝] IP %s 不在白名单中，访问 %s", ip, r.URL.Path)
		http.Error(w, "Forbidden", http.StatusForbidden)
	})
}

// rateLimitMiddleware 请求限流
func (sm *SecurityMiddleware) rateLimitMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ip := GetClientIP(r, sm.cfg.Security.TrustedProxy)
		// 本地请求豁免限流（127.x.x.x, ::1, localhost）
		if strings.HasPrefix(ip, "127.") || ip == "::1" || ip == "localhost" || strings.HasPrefix(ip, "[::1]") {
			next.ServeHTTP(w, r)
			return
		}
		// 静态资源和图片请求豁免限流
		path := r.URL.Path
		if strings.HasPrefix(path, "/static/") || strings.HasPrefix(path, "/webdav/") || strings.HasPrefix(path, "/api/thumb") {
			next.ServeHTTP(w, r)
			return
		}
		if !sm.limiter.Allow(ip) {
			sm.logger.Printf("[限流] IP %s 请求过于频繁", ip)
			w.Header().Set("Retry-After", "60")
			http.Error(w, "Too Many Requests", http.StatusTooManyRequests)
			return
		}
		next.ServeHTTP(w, r)
	})
}

// loggingMiddleware 访问日志
func (sm *SecurityMiddleware) loggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		ip := GetClientIP(r, sm.cfg.Security.TrustedProxy)
		next.ServeHTTP(w, r)
		duration := time.Since(start)
		sm.logger.Printf("[访问] %s %s %s %s 耗时=%v", ip, r.Method, r.URL.Path, r.UserAgent(), duration)
	})
}

// authMiddleware 认证中间件
func (sm *SecurityMiddleware) authMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// 登录接口不需要认证
		if r.URL.Path == "/api/login" || r.URL.Path == "/login" {
			next.ServeHTTP(w, r)
			return
		}

		// Web 页面访问直接放行（由 handleWebUI 内部判断是否显示登录页）
		if r.Method == http.MethodGet && (r.URL.Path == "/" || r.URL.Path == "/index.html") {
			next.ServeHTTP(w, r)
			return
		}

		ip := GetClientIP(r, sm.cfg.Security.TrustedProxy)

		// 检查 IP 是否被锁定
		if sm.auth.IsLocked(ip) {
			sm.logger.Printf("[拒绝] IP %s 因登录失败过多被锁定", ip)
			http.Error(w, "Account locked due to too many failed attempts", http.StatusTooManyRequests)
			return
		}

		// 验证 token
		token := ExtractToken(r)
		if token == "" {
			// WebDAV 客户端可能使用 Basic Auth
			if user, pass, ok := r.BasicAuth(); ok {
				if user == sm.cfg.Auth.Username && sm.auth.CheckPassword(pass) {
					sm.auth.RecordSuccessLogin(ip)
					next.ServeHTTP(w, r)
					return
				}
				sm.auth.RecordFailedLogin(ip)
				sm.logger.Printf("[失败] IP %s Basic Auth 认证失败，用户=%s", ip, user)
			}
			// WebDAV 请求返回 Basic Auth 挑战，其他请求返回 JSON 401
			if strings.HasPrefix(r.URL.Path, "/webdav/") || r.URL.Path == "/webdav" {
				w.Header().Set("WWW-Authenticate", `Basic realm="NAS"`)
			}
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			json.NewEncoder(w).Encode(map[string]string{"error": "Unauthorized"})
			return
		}

		username, err := sm.auth.ValidateToken(token)
		if err != nil {
			sm.logger.Printf("[失败] IP %s 无效 token: %v", ip, err)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			json.NewEncoder(w).Encode(map[string]string{"error": "Invalid or expired token"})
			return
		}

		// 将用户名存入上下文
		r.Header.Set("X-Auth-User", username)
		next.ServeHTTP(w, r)
	})
}

// IsPrivateIP 检查是否为内网 IP（辅助函数）
func IsPrivateIP(ipStr string) bool {
	ip := net.ParseIP(ipStr)
	if ip == nil {
		return false
	}
	privateRanges := []string{
		"10.0.0.0/8",
		"172.16.0.0/12",
		"192.168.0.0/16",
		"127.0.0.0/8",
		"fc00::/7",
		"::1/128",
	}
	for _, cidr := range privateRanges {
		_, network, _ := net.ParseCIDR(cidr)
		if network.Contains(ip) {
			return true
		}
	}
	return false
}
