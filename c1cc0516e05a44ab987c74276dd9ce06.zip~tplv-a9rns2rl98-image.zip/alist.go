package main

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

var (
	alistCmd     *exec.Cmd
	alistMutex   sync.Mutex
	alistRunning bool
)

const (
	AListPort    = "5244"
	AListDataDir = "alist-data"
)

// AListStatus AList服务状态
type AListStatus struct {
	Running  bool   `json:"running"`
	Port     string `json:"port"`
	DataDir  string `json:"data_dir"`
	Version  string `json:"version"`
	URL      string `json:"url"`
}

// initAList 初始化AList（从assets解压并启动）
func initAList() error {
	alistMutex.Lock()
	defer alistMutex.Unlock()

	if alistRunning {
		return nil
	}

	// 获取工作目录
	workDir, err := os.Getwd()
	if err != nil {
		return fmt.Errorf("获取工作目录失败: %v", err)
	}

	// AList二进制路径
	alistPath := filepath.Join(workDir, "alist")
	dataDir := filepath.Join(workDir, AListDataDir)

	// 检查AList二进制是否存在
	if _, err := os.Stat(alistPath); os.IsNotExist(err) {
		// 尝试从assets目录复制（APK环境）
		assetsPath := filepath.Join(workDir, "assets", "alist-android-arm64")
		if _, err := os.Stat(assetsPath); err == nil {
			if err := copyFile(assetsPath, alistPath); err != nil {
				return fmt.Errorf("复制AList二进制失败: %v", err)
			}
		} else {
			// Termux环境：检查是否已安装
			if path, err := exec.LookPath("alist"); err == nil {
				alistPath = path
			} else {
				return fmt.Errorf("未找到AList二进制文件，请将alist-android-arm64放到程序目录或assets目录")
			}
		}
	}

	// 设置执行权限
	os.Chmod(alistPath, 0755)

	// 创建数据目录
	os.MkdirAll(dataDir, 0755)

	// 清除AList的site_url配置（8444端口纯代理，AList在根路径运行）
	clearAListSiteURL(dataDir)

	// 检查端口是否已被占用（AList可能已经在运行）
	if checkAListRunning() {
		alistRunning = true
		log.Printf("[ALIST] AList服务已在运行，跳过启动")
		return nil
	}

	// 启动AList服务
	cmd := exec.Command(alistPath, "server", "--data", dataDir)
	cmd.Dir = workDir
	cmd.Env = append(os.Environ(),
		"ALIST_PORT="+AListPort,
		"ALIST_ADDR=0.0.0.0",
	)

	// 重定向输出到日志
	logFile, err := os.OpenFile(filepath.Join(dataDir, "alist.log"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err == nil {
		cmd.Stdout = logFile
		cmd.Stderr = logFile
	}

	if err := cmd.Start(); err != nil {
		return fmt.Errorf("启动AList失败: %v", err)
	}

	alistCmd = cmd
	alistRunning = true

	// 等待AList服务就绪
	go waitAListReady()

	log.Printf("[ALIST] AList服务启动中，端口: %s，数据目录: %s", AListPort, dataDir)
	return nil
}

// waitAListReady 等待AList服务就绪
func waitAListReady() {
	for i := 0; i < 30; i++ {
		time.Sleep(500 * time.Millisecond)
		if checkAListRunning() {
			log.Printf("[ALIST] AList服务已就绪")
			return
		}
	}
	log.Printf("[ALIST] 警告: AList服务启动超时，请检查日志")
}

// checkAListRunning 检查AList服务是否运行
func checkAListRunning() bool {
	client := &http.Client{Timeout: 2 * time.Second}
	resp, err := client.Get(fmt.Sprintf("http://127.0.0.1:%s/api/public/settings", AListPort))
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	return resp.StatusCode == 200 || resp.StatusCode == 401
}

// stopAList 停止AList服务
func stopAList() error {
	alistMutex.Lock()
	defer alistMutex.Unlock()

	if !alistRunning || alistCmd == nil {
		return nil
	}

	if err := alistCmd.Process.Kill(); err != nil {
		return fmt.Errorf("停止AList失败: %v", err)
	}

	alistCmd.Wait()
	alistRunning = false
	alistCmd = nil

	log.Printf("[ALIST] AList服务已停止")
	return nil
}

// getAListStatus 获取AList状态
func getAListStatus() AListStatus {
	status := AListStatus{
		Running: checkAListRunning(),
		Port:    AListPort,
		URL:     fmt.Sprintf("http://127.0.0.1:%s", AListPort),
	}

	workDir, _ := os.Getwd()
	status.DataDir = filepath.Join(workDir, AListDataDir)

	// 获取版本号
	if status.Running {
		if path, err := exec.LookPath("alist"); err == nil {
			if out, err := exec.Command(path, "version").Output(); err == nil {
				status.Version = strings.TrimSpace(string(out))
			}
		}
	}

	return status
}

// copyFile 复制文件
func copyFile(src, dst string) error {
	sourceFile, err := os.Open(src)
	if err != nil {
		return err
	}
	defer sourceFile.Close()

	destFile, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer destFile.Close()

	_, err = io.Copy(destFile, sourceFile)
	return err
}

// clearAListSiteURL 清除AList的site_url配置（8444端口纯代理，AList在根路径运行）
func clearAListSiteURL(dataDir string) {
	configPath := filepath.Join(dataDir, "config.json")

	// 读取配置文件
	data, err := os.ReadFile(configPath)
	if err != nil {
		// 配置文件不存在，AList首次启动会自动创建
		log.Printf("[ALIST] 配置文件不存在，将使用默认配置")
		return
	}

	// 解析JSON
	var config map[string]interface{}
	if err := json.Unmarshal(data, &config); err != nil {
		log.Printf("[ALIST] 解析配置文件失败: %v", err)
		return
	}

	// 清除site_url（设置为空字符串，让AList在根路径运行）
	if config["site_url"] != nil && config["site_url"] != "" {
		config["site_url"] = ""
		newData, err := json.MarshalIndent(config, "", "  ")
		if err != nil {
			log.Printf("[ALIST] 序列化配置失败: %v", err)
			return
		}
		if err := os.WriteFile(configPath, newData, 0644); err != nil {
			log.Printf("[ALIST] 写入配置失败: %v", err)
			return
		}
		log.Printf("[ALIST] 已清除 site_url（纯代理模式，根路径运行）")
	}
}

// alistAPIHandler AList API处理
func alistAPIHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	switch r.URL.Path {
	case "/api/alist/status":
		status := getAListStatus()
		json.NewEncoder(w).Encode(status)
	case "/api/alist/start":
		if err := initAList(); err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]interface{}{"error": err.Error()})
			return
		}
		json.NewEncoder(w).Encode(map[string]interface{}{"success": true, "message": "AList启动中"})
	case "/api/alist/stop":
		if err := stopAList(); err != nil {
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]interface{}{"error": err.Error()})
			return
		}
		json.NewEncoder(w).Encode(map[string]interface{}{"success": true, "message": "AList已停止"})
	case "/api/media/list":
		handleMediaList(w, r)
	default:
		w.WriteHeader(http.StatusNotFound)
		json.NewEncoder(w).Encode(map[string]interface{}{"error": "未知的API路径"})
	}
}

// AlistMediaFile AList媒体文件
type AlistMediaFile struct {
	Name string `json:"name"`
	Path string `json:"path"`
	Size int64  `json:"size"`
	Type string `json:"type"`
}

// getAlistToken 获取AList token
func getAlistToken() (string, error) {
	loginData := map[string]string{
		"username": "admin",
		"password": "admin123",
	}
	jsonData, _ := json.Marshal(loginData)
	resp, err := http.Post(fmt.Sprintf("http://127.0.0.1:%s/api/auth/login", AListPort),
		"application/json", strings.NewReader(string(jsonData)))
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	var result struct {
		Code int `json:"code"`
		Data struct {
			Token string `json:"token"`
		} `json:"data"`
		Message string `json:"message"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", err
	}
	if result.Code != 200 {
		return "", fmt.Errorf("AList登录失败: %s", result.Message)
	}
	return result.Data.Token, nil
}

// listAlistDir 列出AList目录
func listAlistDir(path, token string) ([]map[string]interface{}, error) {
	reqData := map[string]interface{}{
		"path":     path,
		"password": "",
		"page":     1,
		"per_page": 0,
		"refresh":  false,
	}
	jsonData, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", fmt.Sprintf("http://127.0.0.1:%s/api/fs/list", AListPort),
		strings.NewReader(string(jsonData)))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", token)
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var result struct {
		Code int `json:"code"`
		Data struct {
			Content []map[string]interface{} `json:"content"`
		} `json:"data"`
		Message string `json:"message"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	if result.Code != 200 {
		return nil, fmt.Errorf("列出目录失败: %s", result.Message)
	}
	return result.Data.Content, nil
}

// handleMediaList 处理媒体文件列表请求
func handleMediaList(w http.ResponseWriter, r *http.Request) {
	mediaType := r.URL.Query().Get("type")
	if mediaType != "video" && mediaType != "music" && mediaType != "image" {
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(map[string]interface{}{"error": "type参数必须是video、music或image"})
		return
	}

	log.Printf("[MEDIA] 开始扫描 %s 文件...", mediaType)

	token, err := getAlistToken()
	if err != nil {
		log.Printf("[MEDIA] 获取AList token失败: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]interface{}{"error": "AList登录失败: " + err.Error() + "，请检查AList管理员密码"})
		return
	}
	log.Printf("[MEDIA] AList登录成功")

	videoExts := map[string]bool{
		".mp4": true, ".mkv": true, ".avi": true, ".mov": true, ".flv": true,
		".webm": true, ".m4v": true, ".ts": true, ".mpg": true, ".mpeg": true,
		".3gp": true, ".wmv": true, ".rm": true, ".rmvb": true,
	}
	musicExts := map[string]bool{
		".mp3": true, ".flac": true, ".wav": true, ".aac": true, ".ogg": true,
		".m4a": true, ".wma": true, ".ape": true, ".opus": true, ".aiff": true,
	}
	imageExts := map[string]bool{
		".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".webp": true,
		".bmp": true, ".heic": true, ".heif": true, ".avif": true, ".tiff": true,
		".tif": true, ".svg": true, ".ico": true, ".raw": true, ".cr2": true,
		".nef": true, ".arw": true, ".dng": true, ".psd": true, ".tga": true,
	}

	var files []AlistMediaFile
	var scanErrors []string
	var scan func(path string)
	scan = func(path string) {
		items, err := listAlistDir(path, token)
		if err != nil {
			scanErrors = append(scanErrors, path+": "+err.Error())
			log.Printf("[MEDIA] 扫描目录失败 %s: %v", path, err)
			return
		}
		for _, item := range items {
			name, _ := item["name"].(string)
			isDir, _ := item["is_dir"].(bool)
			size, _ := item["size"].(float64)
			itemPath := path
			if itemPath == "/" {
				itemPath = "/" + name
			} else {
				itemPath = itemPath + "/" + name
			}
			if isDir {
				// 跳过隐藏目录和系统目录
				if !strings.HasPrefix(name, ".") && name != "Android" && name != "android" {
					scan(itemPath)
				}
			} else {
				ext := strings.ToLower(filepath.Ext(name))
				if mediaType == "video" && videoExts[ext] {
					files = append(files, AlistMediaFile{Name: name, Path: itemPath, Size: int64(size), Type: "video"})
				} else if mediaType == "music" && musicExts[ext] {
					files = append(files, AlistMediaFile{Name: name, Path: itemPath, Size: int64(size), Type: "music"})
				} else if mediaType == "image" && imageExts[ext] {
					files = append(files, AlistMediaFile{Name: name, Path: itemPath, Size: int64(size), Type: "image"})
				}
			}
		}
	}
	scan("/")

	log.Printf("[MEDIA] 扫描完成，找到 %d 个 %s 文件，%d 个目录扫描失败", len(files), mediaType, len(scanErrors))

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"type":    mediaType,
		"count":   len(files),
		"files":   files,
		"errors":  scanErrors,
	})
}
