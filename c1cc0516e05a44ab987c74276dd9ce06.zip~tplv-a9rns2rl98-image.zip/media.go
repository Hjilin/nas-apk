package main

import (
	"crypto/md5"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

// MediaType 媒体类型
type MediaType string

const (
	MediaTypeVideo MediaType = "video"
	MediaTypeAudio MediaType = "audio"
	MediaTypeImage MediaType = "image"
)

// MediaFile 媒体文件信息
type MediaFile struct {
	Path     string    `json:"path"`
	Name     string    `json:"name"`
	Type     MediaType `json:"type"`
	Size     int64     `json:"size"`
	Duration int       `json:"duration"` // 秒（暂不解析，预留）
	ModTime  string    `json:"mod_time"`
	Thumb    string    `json:"thumb"` // 缩略图路径（预留）
}

// MediaLibrary 媒体库
type MediaLibrary struct {
	cfg      *MediaConfig
	rootDir  string
	scanRoot string // 实际扫描根目录（优先 /storage/emulated/0）
	mu       sync.RWMutex
	files    []MediaFile
	lastScan time.Time
	scanning bool
}

// NewMediaLibrary 创建媒体库
func NewMediaLibrary(cfg *MediaConfig, rootDir string) *MediaLibrary {
	// 优先使用安卓内部存储真实路径
	scanRoot := rootDir
	if _, err := os.Stat("/storage/emulated/0"); err == nil {
		scanRoot = "/storage/emulated/0"
	}
	return &MediaLibrary{
		cfg:      cfg,
		rootDir:  rootDir,
		scanRoot: scanRoot,
	}
}

// videoExts 视频扩展名
var videoExts = map[string]bool{
	".mp4": true, ".mkv": true, ".avi": true, ".mov": true, ".wmv": true,
	".flv": true, ".webm": true, ".m4v": true, ".ts": true, ".rmvb": true,
	".3gp": true, ".mpg": true, ".mpeg": true, ".m2ts": true, ".vob": true,
	".divx": true, ".xvid": true, ".f4v": true, ".ogv": true, ".drc": true,
}

// audioExts 音频扩展名
var audioExts = map[string]bool{
	".mp3": true, ".flac": true, ".wav": true, ".aac": true, ".ogg": true,
	".m4a": true, ".wma": true, ".ape": true, ".opus": true, ".aiff": true,
	".alac": true, ".amr": true, ".mid": true, ".midi": true, ".dsf": true,
}

// imageExts 图片扩展名
var imageExts = map[string]bool{
	".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".bmp": true,
	".webp": true, ".tiff": true, ".svg": true, ".heic": true, ".ico": true,
	".avif": true, ".raw": true, ".cr2": true, ".nef": true, ".arw": true,
}

// getMediaType 根据扩展名判断媒体类型
func getMediaType(filename string) (MediaType, bool) {
	ext := strings.ToLower(filepath.Ext(filename))
	if videoExts[ext] {
		return MediaTypeVideo, true
	}
	if audioExts[ext] {
		return MediaTypeAudio, true
	}
	if imageExts[ext] {
		return MediaTypeImage, true
	}
	return "", false
}

// Scan 扫描媒体文件
func (ml *MediaLibrary) Scan() error {
	ml.mu.Lock()
	if ml.scanning {
		ml.mu.Unlock()
		return nil
	}
	ml.scanning = true
	ml.mu.Unlock()

	defer func() {
		ml.mu.Lock()
		ml.scanning = false
		ml.lastScan = time.Now()
		ml.mu.Unlock()
	}()

	var files []MediaFile
	scanDirs := ml.cfg.MediaDirs
	if len(scanDirs) == 0 {
		scanDirs = []string{""} // 扫描根目录
	}

	for _, dir := range scanDirs {
		fullDir := filepath.Join(ml.scanRoot, dir)
		filepath.Walk(fullDir, func(path string, info os.FileInfo, err error) error {
			if err != nil || info.IsDir() {
				return nil
			}
			mediaType, ok := getMediaType(info.Name())
			if !ok {
				return nil
			}
			// 使用 scanRoot 计算相对路径，因为 scanRoot 和 rootDir 指向同一存储
			relPath, _ := filepath.Rel(ml.scanRoot, path)
			files = append(files, MediaFile{
				Path:    "/" + filepath.ToSlash(relPath),
				Name:    info.Name(),
				Type:    mediaType,
				Size:    info.Size(),
				ModTime: info.ModTime().Format("2006-01-02 15:04:05"),
			})
			return nil
		})
	}

	// 按类型分组，同类型按名称排序
	sort.Slice(files, func(i, j int) bool {
		if files[i].Type != files[j].Type {
			return files[i].Type < files[j].Type
		}
		return files[i].Name < files[j].Name
	})

	ml.mu.Lock()
	ml.files = files
	ml.mu.Unlock()

	return nil
}

// GetFiles 获取媒体文件列表
func (ml *MediaLibrary) GetFiles(mediaType MediaType) []MediaFile {
	ml.mu.RLock()
	defer ml.mu.RUnlock()
	if mediaType == "" {
		return ml.files
	}
	var result []MediaFile
	for _, f := range ml.files {
		if f.Type == mediaType {
			result = append(result, f)
		}
	}
	return result
}

// GetStats 获取媒体库统计
func (ml *MediaLibrary) GetStats() map[string]interface{} {
	ml.mu.RLock()
	defer ml.mu.RUnlock()
	var videoCount, audioCount, imageCount int
	var totalSize int64
	for _, f := range ml.files {
		switch f.Type {
		case MediaTypeVideo:
			videoCount++
		case MediaTypeAudio:
			audioCount++
		case MediaTypeImage:
			imageCount++
		}
		totalSize += f.Size
	}
	return map[string]interface{}{
		"total":      len(ml.files),
		"video":      videoCount,
		"audio":      audioCount,
		"image":      imageCount,
		"total_size": totalSize,
		"last_scan":  ml.lastScan.Format("2006-01-02 15:04:05"),
		"scanning":   ml.scanning,
		"scan_root":  ml.scanRoot,
	}
}

// MediaHandler 媒体服务处理器
type MediaHandler struct {
	library *MediaLibrary
	cfg     *Config
	logger  *Logger
}

// NewMediaHandler 创建媒体处理器
func NewMediaHandler(cfg *Config, logger *Logger) *MediaHandler {
	return &MediaHandler{
		library: NewMediaLibrary(&cfg.Media, cfg.Storage.RootDir),
		cfg:     cfg,
		logger:  logger,
	}
}

// handleMediaScan 触发媒体扫描
func (h *NASHandler) handleMediaScan(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	log.Printf("[MEDIA-SCAN] 收到扫描请求，来自: %s", r.RemoteAddr)
	// 先使缓存失效，确保扫描后能立即看到结果
	globalMediaCache.mu.Lock()
	globalMediaCache.valid = false
	globalMediaCache.mu.Unlock()
	// 使用稳定版扫描函数，直接扫描文件系统
	go func() {
		if err := scanMediaFiles(h.cfg.Storage.RootDir); err != nil {
			log.Printf("[MEDIA-SCAN] 扫描失败: %v", err)
		}
	}()
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "扫描已开始",
	})
}

// handleMediaList 获取媒体列表
func (h *NASHandler) handleMediaList(w http.ResponseWriter, r *http.Request) {
	mediaType := MediaType(r.URL.Query().Get("type"))
	files := h.mediaHandler.library.GetFiles(mediaType)
	stats := h.mediaHandler.library.GetStats()
	// 确保不为null，返回空数组
	if files == nil {
		files = []MediaFile{}
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"files": files,
		"stats": stats,
	})
}

// ServeMedia 提供媒体文件流式传输（支持 Range 请求）
func (h *NASHandler) ServeMedia(w http.ResponseWriter, r *http.Request) {
	// 从 /webdav/ 路径提供媒体文件，Go 的 http.ServeFile 自动支持 Range
	// 这个函数主要用于特殊处理，实际文件服务由 WebDAV handler 处理
}

// handleMediaProbe 探测视频文件编码信息
func (h *NASHandler) handleMediaProbe(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	filePath := r.URL.Query().Get("path")
	if filePath == "" {
		http.Error(w, "path required", http.StatusBadRequest)
		return
	}
	fullPath := filepath.Join(h.cfg.Storage.RootDir, filePath)
	if _, err := os.Stat(fullPath); os.IsNotExist(err) {
		http.Error(w, "file not found", http.StatusNotFound)
		return
	}
	// 使用ffprobe探测
	cmd := exec.Command("ffprobe", "-v", "quiet", "-print_format", "json",
		"-show_format", "-show_streams", fullPath)
	output, err := cmd.Output()
	if err != nil {
		h.logger.Error("ffprobe failed: %v", err)
		http.Error(w, "probe failed", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(output)
}

// handleMediaTranscode 视频转码为H.264+AAC的m3u8流（主流方案：缓存+低延迟+快速启动）
func (h *NASHandler) handleMediaTranscode(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("path")
	if filePath == "" {
		http.Error(w, "path required", http.StatusBadRequest)
		return
	}
	fullPath := filepath.Join(h.cfg.Storage.RootDir, filePath)
	if _, err := os.Stat(fullPath); os.IsNotExist(err) {
		http.Error(w, "file not found", http.StatusNotFound)
		return
	}
	// 生成缓存key（基于文件路径和修改时间）
	fileInfo, _ := os.Stat(fullPath)
	cacheKey := fmt.Sprintf("%x", md5.Sum([]byte(filePath+fmt.Sprintf("%d", fileInfo.ModTime().Unix()))))
	cacheDir := filepath.Join(os.TempDir(), "nas-transcode", cacheKey)
	playlistPath := filepath.Join(cacheDir, "playlist.m3u8")
	// 如果缓存已存在，直接返回
	if _, err := os.Stat(playlistPath); err == nil {
		http.Redirect(w, r, "/tmp-transcode/"+cacheKey+"/playlist.m3u8", http.StatusFound)
		return
	}
	os.MkdirAll(cacheDir, 0755)
	// 主流转码参数：低延迟、快速启动、合理分片
	cmd := exec.Command("ffmpeg",
		"-hide_banner",
		"-loglevel", "error",
		"-analyzeduration", "1000000",
		"-probesize", "1000000",
		"-fflags", "+genpts+discardcorrupt",
		"-i", fullPath,
		"-c:v", "libx264",
		"-preset", "veryfast",
		"-tune", "zerolatency",
		"-crf", "26",
		"-maxrate", "2000k",
		"-bufsize", "4000k",
		"-c:a", "aac",
		"-b:a", "128k",
		"-ac", "2",
		"-ar", "44100",
		"-f", "hls",
		"-hls_time", "3",
		"-hls_list_size", "0",
		"-hls_flags", "delete_segments+append_list+independent_segments",
		"-hls_allow_cache", "1",
		"-hls_segment_type", "mpegts",
		"-hls_segment_filename", filepath.Join(cacheDir, "segment_%03d.ts"),
		playlistPath,
	)
	cmd.Stderr = nil
	// 启动转码
	if err := cmd.Start(); err != nil {
		h.logger.Error("ffmpeg transcode start failed: %v", err)
		http.Error(w, "transcode failed", http.StatusInternalServerError)
		return
	}
	// 等待第一个分片生成（快速启动，最多1.5秒）
	for i := 0; i < 30; i++ {
		matches, _ := filepath.Glob(filepath.Join(cacheDir, "segment_*.ts"))
		if len(matches) > 0 {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	// 缓存清理：30分钟后删除
	go func() {
		time.Sleep(30 * time.Minute)
		os.RemoveAll(cacheDir)
		cmd.Process.Kill()
	}()
	// 返回m3u8地址
	http.Redirect(w, r, "/tmp-transcode/"+cacheKey+"/playlist.m3u8", http.StatusFound)
}

// handleTranscodeFile 提供转码后的ts和m3u8文件
func (h *NASHandler) handleTranscodeFile(w http.ResponseWriter, r *http.Request) {
	relPath := strings.TrimPrefix(r.URL.Path, "/tmp-transcode/")
	fullPath := filepath.Join(os.TempDir(), "nas-transcode", relPath)
	if _, err := os.Stat(fullPath); os.IsNotExist(err) {
		http.Error(w, "file not found", http.StatusNotFound)
		return
	}
	http.ServeFile(w, r, fullPath)
}

// DLNAMediaServer DLNA/UPnP 媒体服务器（轻量实现）
type DLNAMediaServer struct {
	cfg    *MediaConfig
	lib    *MediaLibrary
	port   int
	server *http.Server
}

// NewDLNAMediaServer 创建 DLNA 服务器
func NewDLNAMediaServer(cfg *MediaConfig, lib *MediaLibrary) *DLNAMediaServer {
	return &DLNAMediaServer{
		cfg:  cfg,
		lib:  lib,
		port: cfg.DLNAPort,
	}
}

// Start 启动 DLNA 服务器
func (d *DLNAMediaServer) Start() error {
	mux := http.NewServeMux()

	// UPnP 设备描述
	mux.HandleFunc("/description.xml", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/xml; charset=utf-8")
		w.Write([]byte(d.deviceDescription()))
	})

	// 内容目录服务
	mux.HandleFunc("/content", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/xml; charset=utf-8")
		w.Write([]byte(d.contentDirectoryResponse()))
	})

	d.server = &http.Server{
		Addr:    fmt.Sprintf(":%d", d.port),
		Handler: mux,
	}

	go d.server.ListenAndServe()
	return nil
}

// Stop 停止 DLNA 服务器
func (d *DLNAMediaServer) Stop() {
	if d.server != nil {
		d.server.Close()
	}
}

// deviceDescription UPnP 设备描述 XML
func (d *DLNAMediaServer) deviceDescription() string {
	return `<?xml version="1.0"?>
<root xmlns="urn:schemas-upnp-org:device-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <device>
    <deviceType>urn:schemas-upnp-org:device:MediaServer:1</deviceType>
    <friendlyName>NAS 私有云媒体服务器</friendlyName>
    <manufacturer>NAS Private Cloud</manufacturer>
    <modelName>NAS Media Server</modelName>
    <modelDescription>Termux NAS Media Server</modelDescription>
    <UDN>uuid:nas-media-server-001</UDN>
    <serviceList>
      <service>
        <serviceType>urn:schemas-upnp-org:service:ContentDirectory:1</serviceType>
        <serviceId>urn:upnp-org:serviceId:ContentDirectory</serviceId>
        <controlURL>/content</controlURL>
        <eventSubURL>/content</eventSubURL>
        <SCPDURL>/content.xml</SCPDURL>
      </service>
    </serviceList>
  </device>
</root>`
}

// contentDirectoryResponse 简化的内容目录响应
func (d *DLNAMediaServer) contentDirectoryResponse() string {
	return `<?xml version="1.0"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body>
    <u:BrowseResponse xmlns:u="urn:schemas-upnp-org:service:ContentDirectory:1">
      <Result>&lt;DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/"&gt;&lt;/DIDL-Lite&gt;</Result>
      <NumberReturned>0</NumberReturned>
      <TotalMatches>0</TotalMatches>
      <UpdateID>0</UpdateID>
    </u:BrowseResponse>
  </s:Body>
</s:Envelope>`
}

// 格式化文件大小
func formatMediaSize(bytes int64) string {
	if bytes < 1024 {
		return fmt.Sprintf("%d B", bytes)
	}
	if bytes < 1048576 {
		return fmt.Sprintf("%.1f MB", float64(bytes)/1024/1024)
	}
	if bytes < 1073741824 {
		return fmt.Sprintf("%.1f MB", float64(bytes)/1048576)
	}
	return fmt.Sprintf("%.2f GB", float64(bytes)/1073741824)
}

// ===== 音乐转码 =====

// handleAudioTranscode 音乐转码（flac/wav/ape等转mp3）
func (h *NASHandler) handleAudioTranscode(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("path")
	if filePath == "" {
		http.Error(w, "缺少文件路径", http.StatusBadRequest)
		return
	}

	// 安全检查：防止路径遍历
	if strings.Contains(filePath, "..") {
		http.Error(w, "非法路径", http.StatusBadRequest)
		return
	}

	fullPath := filepath.Join(h.cfg.Storage.RootDir, filePath)
	if _, err := os.Stat(fullPath); os.IsNotExist(err) {
		http.Error(w, "文件不存在", http.StatusNotFound)
		return
	}

	// 生成缓存key
	cacheKey := fmt.Sprintf("%x", md5.Sum([]byte(fullPath+fmt.Sprintf("%d", getFileModTime(fullPath)))))
	// 使用存储目录下的缓存文件夹，避免/tmp权限问题
	cacheDir := filepath.Join(h.cfg.Storage.RootDir, ".audio-cache")
	cacheFile := filepath.Join(cacheDir, cacheKey+".mp3")

	// 确保缓存目录存在
	if err := os.MkdirAll(cacheDir, 0755); err != nil {
		h.logger.Error("创建缓存目录失败:", err.Error())
		http.Error(w, "创建缓存目录失败: "+err.Error(), http.StatusInternalServerError)
		return
	}

	// 检查缓存
	if _, err := os.Stat(cacheFile); err == nil {
		w.Header().Set("Content-Type", "audio/mpeg")
		w.Header().Set("Accept-Ranges", "bytes")
		http.ServeFile(w, r, cacheFile)
		return
	}

	// 检查ffmpeg
	if _, err := exec.LookPath("ffmpeg"); err != nil {
		http.Error(w, "ffmpeg未安装，无法转码", http.StatusInternalServerError)
		return
	}

	// 转码为mp3，增加探测时间以正确解析FLAC
	cmd := exec.Command("ffmpeg",
		"-analyzeduration", "10000000",
		"-probesize", "10000000",
		"-i", fullPath,
		"-vn",
		"-acodec", "libmp3lame",
		"-ab", "192k",
		"-ar", "44100",
		"-ac", "2",
		"-y",
		cacheFile,
	)

	output, err := cmd.CombinedOutput()
	if err != nil {
		h.logger.Error("音乐转码失败:", err.Error(), "输出:", string(output))
		http.Error(w, "转码失败: "+err.Error()+" "+string(output), http.StatusInternalServerError)
		return
	}

	// 验证输出文件
	if _, err := os.Stat(cacheFile); os.IsNotExist(err) {
		h.logger.Error("转码完成但输出文件不存在:", cacheFile)
		http.Error(w, "转码失败：输出文件未生成", http.StatusInternalServerError)
		return
	}

	// 返回转码后的文件
	w.Header().Set("Content-Type", "audio/mpeg")
	w.Header().Set("Accept-Ranges", "bytes")
	http.ServeFile(w, r, cacheFile)
}

// getFileModTime 获取文件修改时间
func getFileModTime(path string) int64 {
	info, err := os.Stat(path)
	if err != nil {
		return 0
	}
	return info.ModTime().Unix()
}
