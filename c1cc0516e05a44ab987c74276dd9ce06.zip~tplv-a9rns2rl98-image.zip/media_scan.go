package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// MediaScanCache 媒体扫描缓存
type MediaScanCache struct {
	mu       sync.Mutex
	videos   []AlistMediaFile
	musics   []AlistMediaFile
	images   []AlistMediaFile
	docs     []AlistMediaFile
	scanTime time.Time
	valid    bool
}

var globalMediaCache = &MediaScanCache{}

// 视频扩展名（扫描用）
var scanVideoExts = map[string]bool{
	".mp4": true, ".mkv": true, ".avi": true, ".mov": true, ".flv": true,
	".webm": true, ".m4v": true, ".ts": true, ".mpg": true, ".mpeg": true,
	".3gp": true, ".wmv": true, ".rm": true, ".rmvb": true,
}

// 音乐扩展名（扫描用）
var scanMusicExts = map[string]bool{
	".mp3": true, ".flac": true, ".wav": true, ".aac": true, ".ogg": true,
	".m4a": true, ".wma": true, ".ape": true, ".opus": true, ".aiff": true,
}

// 图片扩展名（扫描用）
var scanImageExts = map[string]bool{
	".jpg": true, ".jpeg": true, ".png": true, ".gif": true, ".webp": true,
	".bmp": true, ".heic": true, ".heif": true, ".avif": true, ".tiff": true,
	".tif": true, ".svg": true, ".ico": true, ".raw": true, ".cr2": true,
	".nef": true, ".arw": true, ".dng": true, ".psd": true, ".tga": true,
}

// 文档扩展名（扫描用）
var scanDocExts = map[string]bool{
	".pdf": true, ".doc": true, ".docx": true, ".txt": true, ".md": true,
	".ppt": true, ".pptx": true, ".xls": true, ".xlsx": true, ".csv": true,
	".epub": true, ".mobi": true, ".rtf": true, ".odt": true, ".ods": true,
	".odp": true, ".pages": true, ".numbers": true, ".key": true,
}

// scanMediaFiles 直接扫描文件系统
func scanMediaFiles(rootDir string) error {
	globalMediaCache.mu.Lock()
	defer globalMediaCache.mu.Unlock()

	log.Printf("[MEDIA-SCAN] ===== 开始扫描 =====")
	log.Printf("[MEDIA-SCAN] 根目录: %s", rootDir)

	var videos, musics, images, docs []AlistMediaFile
	skippedDirs := 0
	skippedHidden := 0
	scannedFiles := 0

	err := filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			log.Printf("[MEDIA-SCAN] 访问错误: %s, 错误: %v", path, err)
			return nil
		}

		// 跳过隐藏目录和系统目录
		if info.IsDir() {
			name := info.Name()
			if strings.HasPrefix(name, ".") || name == "Android" || name == "android" || name == "lost+found" {
				skippedDirs++
				return filepath.SkipDir
			}
			return nil
		}

		// 跳过隐藏文件
		if strings.HasPrefix(info.Name(), ".") {
			skippedHidden++
			return nil
		}

		scannedFiles++
		ext := strings.ToLower(filepath.Ext(path))
		relPath, _ := filepath.Rel(rootDir, path)
		relPath = "/" + strings.ReplaceAll(relPath, "\\", "/")

		if scanVideoExts[ext] {
			log.Printf("[MEDIA-SCAN] 视频: %s", relPath)
			videos = append(videos, AlistMediaFile{
				Name: info.Name(),
				Path: relPath,
				Size: info.Size(),
				Type: "video",
			})
		} else if scanMusicExts[ext] {
			log.Printf("[MEDIA-SCAN] 音乐: %s", relPath)
			musics = append(musics, AlistMediaFile{
				Name: info.Name(),
				Path: relPath,
				Size: info.Size(),
				Type: "music",
			})
		} else if scanImageExts[ext] {
			log.Printf("[MEDIA-SCAN] 图片: %s", relPath)
			images = append(images, AlistMediaFile{
				Name: info.Name(),
				Path: relPath,
				Size: info.Size(),
				Type: "image",
			})
		} else if scanDocExts[ext] {
			docs = append(docs, AlistMediaFile{
				Name: info.Name(),
				Path: relPath,
				Size: info.Size(),
				Type: "doc",
			})
		}

		return nil
	})

	if err != nil {
		log.Printf("[MEDIA-SCAN] 扫描出错: %v", err)
		return err
	}

	globalMediaCache.videos = videos
	globalMediaCache.musics = musics
	globalMediaCache.images = images
	globalMediaCache.docs = docs
	globalMediaCache.scanTime = time.Now()
	globalMediaCache.valid = true

	log.Printf("[MEDIA-SCAN] ===== 扫描完成 =====")
	log.Printf("[MEDIA-SCAN] 统计: 扫描文件=%d, 跳过隐藏目录=%d, 跳过隐藏文件=%d", scannedFiles, skippedDirs, skippedHidden)
	log.Printf("[MEDIA-SCAN] 分类: 视频=%d, 音乐=%d, 图片=%d, 文档=%d", len(videos), len(musics), len(images), len(docs))
	return nil
}

// handleMediaListStable 稳定版媒体列表API（直接扫描文件系统）
func (h *NASHandler) handleMediaListStable(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	mediaType := r.URL.Query().Get("type")
	log.Printf("[MEDIA-API] 请求媒体列表: type=%s, 来自: %s", mediaType, r.RemoteAddr)

	// type为空时返回所有类型，兼容audio和music
	if mediaType != "" && mediaType != "all" && mediaType != "video" && mediaType != "music" && mediaType != "audio" && mediaType != "image" && mediaType != "doc" {
		log.Printf("[MEDIA-API] 错误: 无效的type参数: %s", mediaType)
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": false,
			"error":   "type参数必须是video、music、audio、image、doc或all",
		})
		return
	}

	rootDir := h.cfg.Storage.RootDir

	// 检查缓存是否有效（5分钟内）
	globalMediaCache.mu.Lock()
	cacheValid := globalMediaCache.valid && time.Since(globalMediaCache.scanTime) < 5*time.Minute
	globalMediaCache.mu.Unlock()

	log.Printf("[MEDIA-API] 缓存状态: valid=%v, cacheValid=%v, 扫描时间=%v", globalMediaCache.valid, cacheValid, globalMediaCache.scanTime)

	if !cacheValid {
		log.Printf("[MEDIA-API] 缓存无效，开始重新扫描...")
		// 重新扫描
		if err := scanMediaFiles(rootDir); err != nil {
			log.Printf("[MEDIA-API] 扫描失败: %v", err)
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "扫描文件失败: " + err.Error(),
			})
			return
		}
	}

	globalMediaCache.mu.Lock()
	defer globalMediaCache.mu.Unlock()

	files := []AlistMediaFile{}
	switch mediaType {
	case "video":
		files = globalMediaCache.videos
	case "music", "audio":
		files = globalMediaCache.musics
	case "image":
		files = globalMediaCache.images
	case "doc":
		files = globalMediaCache.docs
	default:
		// all或空：返回所有类型
		files = append(files, globalMediaCache.videos...)
		files = append(files, globalMediaCache.musics...)
		files = append(files, globalMediaCache.images...)
		files = append(files, globalMediaCache.docs...)
	}

	// 确保不为null
	if files == nil {
		files = []AlistMediaFile{}
	}

	log.Printf("[MEDIA-API] 返回文件数: %d (type=%s)", len(files), mediaType)

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success":  true,
		"type":     mediaType,
		"count":    len(files),
		"files":    files,
		"cached":   cacheValid,
		"scanTime": globalMediaCache.scanTime.Format("2006-01-02 15:04:05"),
	})
}

// handleMediaRefresh 刷新媒体缓存
func (h *NASHandler) handleMediaRefresh(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	rootDir := h.cfg.Storage.RootDir

	go func() {
		scanMediaFiles(rootDir)
	}()

	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"message": "正在后台刷新媒体列表",
	})
}
