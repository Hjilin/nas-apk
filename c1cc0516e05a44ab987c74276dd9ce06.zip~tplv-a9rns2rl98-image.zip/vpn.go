package main

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// VPNManager VPN管理器
type VPNManager struct {
	configDir string
	mu        sync.Mutex
}

// VPNConfig VPN配置
type VPNConfig struct {
	Enabled      bool   `json:"enabled"`
	ServerPubKey string `json:"server_pub_key"`
	ServerPriKey string `json:"server_pri_key"`
	ListenPort   int    `json:"listen_port"`
	Subnet       string `json:"subnet"`
	ServerIP     string `json:"server_ip"`
	DNS          string `json:"dns"`
	Endpoint     string `json:"endpoint"`
}

// VPNClient VPN客户端
type VPNClient struct {
	ID         string `json:"id"`
	Name       string `json:"name"`
	PubKey     string `json:"pub_key"`
	PriKey     string `json:"pri_key"`
	IP         string `json:"ip"`
	AllowedIPs string `json:"allowed_ips"`
	CreatedAt  string `json:"created_at"`
	Enabled    bool   `json:"enabled"`
	Uploaded   int64  `json:"uploaded"`
	Downloaded int64  `json:"downloaded"`
	LastSeen   string `json:"last_seen"`
	Online     bool   `json:"online"`
}

// VPNStatus VPN状态
type VPNStatus struct {
	Running    bool        `json:"running"`
	ClientCount int        `json:"client_count"`
	OnlineCount int        `json:"online_count"`
	TotalUpload int64      `json:"total_upload"`
	TotalDownload int64    `json:"total_download"`
	Clients    []VPNClient `json:"clients"`
}

// NewVPNManager 创建VPN管理器
func NewVPNManager(configDir string) *VPNManager {
	os.MkdirAll(configDir, 0755)
	vm := &VPNManager{configDir: configDir}
	// 初始化默认配置
	if _, err := os.Stat(vm.configPath()); os.IsNotExist(err) {
		vm.initDefaultConfig()
	}
	return vm
}

func (vm *VPNManager) configPath() string {
	return filepath.Join(vm.configDir, "vpn_config.json")
}

func (vm *VPNManager) clientsPath() string {
	return filepath.Join(vm.configDir, "vpn_clients.json")
}

// initDefaultConfig 初始化默认配置
func (vm *VPNManager) initDefaultConfig() {
	priKey, pubKey := generateKeyPair()
	config := VPNConfig{
		Enabled:      false,
		ServerPubKey: pubKey,
		ServerPriKey: priKey,
		ListenPort:   51820,
		Subnet:       "10.0.0.0/24",
		ServerIP:     "10.0.0.1",
		DNS:          "8.8.8.8, 8.8.4.4",
		Endpoint:     "vpn.mynas.com:51820",
	}
	vm.saveConfig(&config)
	vm.saveClients([]VPNClient{})
}

// generateKeyPair 生成WireGuard密钥对
func generateKeyPair() (priKey, pubKey string) {
	// 尝试用wg命令生成
	if output, err := exec.Command("wg", "genkey").Output(); err == nil {
		priKey = strings.TrimSpace(string(output))
		if output2, err := exec.Command("wg", "pubkey").Output(); err == nil {
			pubKey = strings.TrimSpace(string(output2))
			return
		}
	}
	// 备用：生成随机base64密钥
	priKey = randomBase64(32)
	pubKey = randomBase64(32)
	return
}

func randomBase64(length int) string {
	b := make([]byte, length)
	rand.Read(b)
	return base64.StdEncoding.EncodeToString(b)
}

// GetConfig 获取配置
func (vm *VPNManager) GetConfig() (*VPNConfig, error) {
	data, err := os.ReadFile(vm.configPath())
	if err != nil {
		return nil, err
	}
	var config VPNConfig
	if err := json.Unmarshal(data, &config); err != nil {
		return nil, err
	}
	return &config, nil
}

// saveConfig 保存配置
func (vm *VPNManager) saveConfig(config *VPNConfig) error {
	data, err := json.MarshalIndent(config, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(vm.configPath(), data, 0644)
}

// GetClients 获取客户端列表
func (vm *VPNManager) GetClients() ([]VPNClient, error) {
	data, err := os.ReadFile(vm.clientsPath())
	if err != nil {
		return nil, err
	}
	var clients []VPNClient
	if err := json.Unmarshal(data, &clients); err != nil {
		return nil, err
	}
	sort.Slice(clients, func(i, j int) bool {
		return clients[i].CreatedAt < clients[j].CreatedAt
	})
	return clients, nil
}

// saveClients 保存客户端列表
func (vm *VPNManager) saveClients(clients []VPNClient) error {
	data, err := json.MarshalIndent(clients, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(vm.clientsPath(), data, 0644)
}

// AddClient 添加客户端
func (vm *VPNManager) AddClient(name string) (*VPNClient, error) {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	clients, err := vm.GetClients()
	if err != nil {
		return nil, err
	}

	// 分配IP
	usedIPs := make(map[string]bool)
	for _, c := range clients {
		usedIPs[c.IP] = true
	}
	var clientIP string
	for i := 2; i < 254; i++ {
		ip := fmt.Sprintf("10.0.0.%d", i)
		if !usedIPs[ip] {
			clientIP = ip
			break
		}
	}
	if clientIP == "" {
		return nil, fmt.Errorf("IP地址已用完")
	}

	priKey, pubKey := generateKeyPair()
	client := VPNClient{
		ID:         fmt.Sprintf("client_%d", time.Now().UnixNano()),
		Name:       name,
		PubKey:     pubKey,
		PriKey:     priKey,
		IP:         clientIP,
		AllowedIPs: "0.0.0.0/0, ::/0",
		CreatedAt:  time.Now().Format("2006-01-02 15:04:05"),
		Enabled:    true,
	}

	clients = append(clients, client)
	if err := vm.saveClients(clients); err != nil {
		return nil, err
	}

	return &client, nil
}

// DeleteClient 删除客户端
func (vm *VPNManager) DeleteClient(id string) error {
	vm.mu.Lock()
	defer vm.mu.Unlock()

	clients, err := vm.GetClients()
	if err != nil {
		return err
	}

	var newClients []VPNClient
	for _, c := range clients {
		if c.ID != id {
			newClients = append(newClients, c)
		}
	}
	return vm.saveClients(newClients)
}

// GenerateClientConfig 生成客户端配置
func (vm *VPNManager) GenerateClientConfig(id string) (string, error) {
	clients, err := vm.GetClients()
	if err != nil {
		return "", err
	}

	config, err := vm.GetConfig()
	if err != nil {
		return "", err
	}

	var client *VPNClient
	for i := range clients {
		if clients[i].ID == id {
			client = &clients[i]
			break
		}
	}
	if client == nil {
		return "", fmt.Errorf("客户端不存在")
	}

	conf := fmt.Sprintf(`[Interface]
PrivateKey = %s
Address = %s/32
DNS = %s

[Peer]
PublicKey = %s
Endpoint = %s
AllowedIPs = %s
PersistentKeepalive = 25
`, client.PriKey, client.IP, config.DNS, config.ServerPubKey, config.Endpoint, client.AllowedIPs)

	return conf, nil
}

// GetStatus 获取VPN状态
func (vm *VPNManager) GetStatus() (*VPNStatus, error) {
	config, err := vm.GetConfig()
	if err != nil {
		return nil, err
	}

	clients, err := vm.GetClients()
	if err != nil {
		return nil, err
	}

	status := &VPNStatus{
		ClientCount: len(clients),
		Clients:     clients,
	}

	// 尝试用wg命令查询实际状态
	if output, err := exec.Command("wg", "show").Output(); err == nil {
		status.Running = true
		// 解析wg输出获取流量和在线状态
		lines := strings.Split(string(output), "\n")
		for i, line := range lines {
			if strings.Contains(line, "peer:") {
				pubKey := strings.TrimSpace(strings.TrimPrefix(line, "peer:"))
				for j := range clients {
					if clients[j].PubKey == pubKey {
						clients[j].Online = true
						// 查找下一行的流量信息
						if i+2 < len(lines) {
							transferLine := lines[i+2]
							if strings.Contains(transferLine, "transfer:") {
								parts := strings.Split(transferLine, ",")
								for _, p := range parts {
									p = strings.TrimSpace(p)
									if strings.HasPrefix(p, "received:") {
										clients[j].Downloaded = parseSize(strings.TrimPrefix(p, "received:"))
									}
									if strings.HasPrefix(p, "sent:") {
										clients[j].Uploaded = parseSize(strings.TrimPrefix(p, "sent:"))
									}
								}
							}
							if i+3 < len(lines) && strings.Contains(lines[i+3], "latest handshake:") {
								clients[j].LastSeen = strings.TrimSpace(strings.TrimPrefix(lines[i+3], "latest handshake:"))
							}
						}
					}
				}
			}
		}
		status.Clients = clients
	} else {
		status.Running = false
	}

	// 统计在线数和总流量
	for _, c := range clients {
		if c.Online {
			status.OnlineCount++
		}
		status.TotalUpload += c.Uploaded
		status.TotalDownload += c.Downloaded
	}

	_ = config
	return status, nil
}

// parseSize 解析大小字符串
func parseSize(s string) int64 {
	s = strings.TrimSpace(s)
	parts := strings.Fields(s)
	if len(parts) < 2 {
		return 0
	}
	val, _ := strconv.ParseFloat(parts[0], 64)
	unit := strings.ToLower(parts[1])
	switch unit {
	case "b":
		return int64(val)
	case "kib", "kb":
		return int64(val * 1024)
	case "mib", "mb":
		return int64(val * 1024 * 1024)
	case "gib", "gb":
		return int64(val * 1024 * 1024 * 1024)
	}
	return 0
}

// UpdateConfig 更新配置
func (vm *VPNManager) UpdateConfig(config *VPNConfig) error {
	vm.mu.Lock()
	defer vm.mu.Unlock()
	return vm.saveConfig(config)
}

// HandleVPNStatus 处理VPN状态请求
func (vm *VPNManager) HandleVPNStatus(w http.ResponseWriter, r *http.Request) {
	status, err := vm.GetStatus()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(status)
}

// HandleVPNConfig 处理VPN配置请求
func (vm *VPNManager) HandleVPNConfig(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		config, err := vm.GetConfig()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		// 不返回私钥
		config.ServerPriKey = ""
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(config)
		return
	}
	if r.Method == http.MethodPost {
		var config VPNConfig
		if err := json.NewDecoder(r.Body).Decode(&config); err != nil {
			http.Error(w, "Invalid request", http.StatusBadRequest)
			return
		}
		// 保留原有密钥
		oldConfig, _ := vm.GetConfig()
		if oldConfig != nil {
			if config.ServerPriKey == "" {
				config.ServerPriKey = oldConfig.ServerPriKey
			}
			if config.ServerPubKey == "" {
				config.ServerPubKey = oldConfig.ServerPubKey
			}
		}
		if err := vm.UpdateConfig(&config); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]bool{"success": true})
	}
}

// HandleVPNClients 处理VPN客户端请求
func (vm *VPNManager) HandleVPNClients(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		clients, err := vm.GetClients()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{"clients": clients})
		return
	}
	if r.Method == http.MethodPost {
		var req struct {
			Name string `json:"name"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request", http.StatusBadRequest)
			return
		}
		client, err := vm.AddClient(req.Name)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(client)
	}
}

// HandleVPNClientConfig 处理客户端配置下载
func (vm *VPNManager) HandleVPNClientConfig(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "Missing id", http.StatusBadRequest)
		return
	}
	conf, err := vm.GenerateClientConfig(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/plain")
	w.Header().Set("Content-Disposition", "attachment; filename=wg-client.conf")
	w.Write([]byte(conf))
}

// HandleVPNClientDelete 处理删除客户端
func (vm *VPNManager) HandleVPNClientDelete(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "Missing id", http.StatusBadRequest)
		return
	}
	if err := vm.DeleteClient(id); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

// GenerateServerConfig 生成服务器配置
func (vm *VPNManager) GenerateServerConfig() (string, error) {
	config, err := vm.GetConfig()
	if err != nil {
		return "", err
	}

	clients, err := vm.GetClients()
	if err != nil {
		return "", err
	}

	var peers strings.Builder
	for _, c := range clients {
		if c.Enabled {
			peers.WriteString(fmt.Sprintf(`
[Peer]
# %s
PublicKey = %s
AllowedIPs = %s/32
`, c.Name, c.PubKey, c.IP))
		}
	}

	conf := fmt.Sprintf(`[Interface]
# WireGuard 服务器配置
# 部署到其他设备（路由器/树莓派/云服务器）
Address = %s/24
ListenPort = %d
PrivateKey = %s
# 如需开启转发，取消下面注释（Linux）
# PostUp = iptables -A FORWARD -i %%i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
# PostDown = iptables -D FORWARD -i %%i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE
%s
`, config.ServerIP, config.ListenPort, config.ServerPriKey, peers.String())

	return conf, nil
}

// GenerateNASClientConfig 生成NAS作为客户端的配置
func (vm *VPNManager) GenerateNASClientConfig() (string, error) {
	config, err := vm.GetConfig()
	if err != nil {
		return "", err
	}

	// NAS客户端使用 .254 地址
	nasIP := "10.0.0.254"
	priKey, _ := generateKeyPair()

	conf := fmt.Sprintf(`[Interface]
# 手机NAS客户端配置
# 在 Termux 中使用（需 root）或导入 WireGuard App
Address = %s/32
DNS = %s
PrivateKey = %s

[Peer]
PublicKey = %s
Endpoint = %s
AllowedIPs = 10.0.0.0/24
PersistentKeepalive = 25
`, nasIP, config.DNS, priKey, config.ServerPubKey, config.Endpoint)

	return conf, nil
}

// HandleVPNServerConfig 处理服务器配置下载
func (vm *VPNManager) HandleVPNServerConfig(w http.ResponseWriter, r *http.Request) {
	conf, err := vm.GenerateServerConfig()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/plain")
	w.Header().Set("Content-Disposition", "attachment; filename=wg0-server.conf")
	w.Write([]byte(conf))
}

// HandleVPNNASClientConfig 处理NAS客户端配置下载
func (vm *VPNManager) HandleVPNNASClientConfig(w http.ResponseWriter, r *http.Request) {
	conf, err := vm.GenerateNASClientConfig()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/plain")
	w.Header().Set("Content-Disposition", "attachment; filename=wg0-nas-client.conf")
	w.Write([]byte(conf))
}

// 获取本机IP
func getLocalIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "127.0.0.1"
	}
	for _, addr := range addrs {
		if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String()
			}
		}
	}
	return "127.0.0.1"
}
