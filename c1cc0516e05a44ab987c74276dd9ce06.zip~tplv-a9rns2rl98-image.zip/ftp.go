package main

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	ftpserver "github.com/goftp/server"
)

// FTPAuth FTP认证（使用NAS的用户名密码）
type FTPAuth struct {
	auth *AuthManager
}

// CheckPasswd 检查用户名密码
func (a *FTPAuth) CheckPasswd(name, pass string) (bool, error) {
	if a.auth == nil {
		return false, fmt.Errorf("auth manager not initialized")
	}
	// 使用NAS的认证系统
	if name != a.auth.GetUsername() {
		return false, nil
	}
	if !a.auth.CheckPassword(pass) {
		return false, nil
	}
	return true, nil
}

// FTPDriver FTP文件系统驱动
type FTPDriver struct {
	rootDir string
}

// NewFTPDriver 创建FTP驱动
func NewFTPDriver(rootDir string) *FTPDriver {
	return &FTPDriver{rootDir: rootDir}
}

// Init 初始化连接
func (d *FTPDriver) Init(conn *ftpserver.Conn) {
	// 不需要特殊初始化
}

// Stat 获取文件信息
func (d *FTPDriver) Stat(path string) (ftpserver.FileInfo, error) {
	fullPath := d.fullPath(path)
	info, err := os.Stat(fullPath)
	if err != nil {
		return nil, err
	}
	return &ftpFileInfo{info: info}, nil
}

// ChangeDir 切换目录
func (d *FTPDriver) ChangeDir(path string) error {
	fullPath := d.fullPath(path)
	info, err := os.Stat(fullPath)
	if err != nil {
		return err
	}
	if !info.IsDir() {
		return fmt.Errorf("not a directory")
	}
	return nil
}

// ListDir 列出目录内容
func (d *FTPDriver) ListDir(path string, callback func(ftpserver.FileInfo) error) error {
	fullPath := d.fullPath(path)
	entries, err := os.ReadDir(fullPath)
	if err != nil {
		return err
	}
	for _, entry := range entries {
		info, err := entry.Info()
		if err != nil {
			continue
		}
		if err := callback(&ftpFileInfo{info: info}); err != nil {
			return err
		}
	}
	return nil
}

// DeleteDir 删除目录
func (d *FTPDriver) DeleteDir(path string) error {
	fullPath := d.fullPath(path)
	return os.RemoveAll(fullPath)
}

// DeleteFile 删除文件
func (d *FTPDriver) DeleteFile(path string) error {
	fullPath := d.fullPath(path)
	return os.Remove(fullPath)
}

// Rename 重命名
func (d *FTPDriver) Rename(from, to string) error {
	fromPath := d.fullPath(from)
	toPath := d.fullPath(to)
	return os.Rename(fromPath, toPath)
}

// MakeDir 创建目录
func (d *FTPDriver) MakeDir(path string) error {
	fullPath := d.fullPath(path)
	return os.MkdirAll(fullPath, 0755)
}

// GetFile 获取文件（下载）
func (d *FTPDriver) GetFile(path string, offset int64) (int64, io.ReadCloser, error) {
	fullPath := d.fullPath(path)
	file, err := os.Open(fullPath)
	if err != nil {
		return 0, nil, err
	}
	info, err := file.Stat()
	if err != nil {
		file.Close()
		return 0, nil, err
	}
	if offset > 0 {
		if _, err := file.Seek(offset, 0); err != nil {
			file.Close()
			return 0, nil, err
		}
	}
	return info.Size() - offset, file, nil
}

// PutFile 上传文件
func (d *FTPDriver) PutFile(path string, data io.Reader, appendData bool) (int64, error) {
	fullPath := d.fullPath(path)
	// 确保目录存在
	dir := filepath.Dir(fullPath)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return 0, err
	}

	var file *os.File
	var err error
	if appendData {
		file, err = os.OpenFile(fullPath, os.O_APPEND|os.O_WRONLY|os.O_CREATE, 0644)
	} else {
		file, err = os.OpenFile(fullPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0644)
	}
	if err != nil {
		return 0, err
	}
	defer file.Close()

	written, err := io.Copy(file, data)
	if err != nil {
		return 0, err
	}
	return written, nil
}

// fullPath 转换为完整路径
func (d *FTPDriver) fullPath(path string) string {
	// 清理路径，防止路径遍历
	path = filepath.Clean(path)
	if strings.HasPrefix(path, "..") {
		path = "/"
	}
	if path == "/" || path == "." || path == "" {
		return d.rootDir
	}
	return filepath.Join(d.rootDir, path)
}

// ftpFileInfo FTP文件信息包装
type ftpFileInfo struct {
	info os.FileInfo
}

func (f *ftpFileInfo) Name() string       { return f.info.Name() }
func (f *ftpFileInfo) Size() int64        { return f.info.Size() }
func (f *ftpFileInfo) Mode() os.FileMode  { return f.info.Mode() }
func (f *ftpFileInfo) ModTime() time.Time { return f.info.ModTime() }
func (f *ftpFileInfo) IsDir() bool        { return f.info.IsDir() }
func (f *ftpFileInfo) Sys() interface{}   { return f.info.Sys() }
func (f *ftpFileInfo) Owner() string      { return "nas" }
func (f *ftpFileInfo) Group() string      { return "nas" }

// FTPManager FTP服务管理器
type FTPManager struct {
	server *ftpserver.Server
	port   int
}

// NewFTPManager 创建FTP管理器
func NewFTPManager(cfg *Config, auth *AuthManager) *FTPManager {
	ftpPort := 2121
	if cfg.Server.FTPPort > 0 {
		ftpPort = cfg.Server.FTPPort
	}

	authDriver := &FTPAuth{auth: auth}
	fileDriver := NewFTPDriver(cfg.Storage.RootDir)

	factory := &ftpDriverFactory{
		auth:   authDriver,
		driver: fileDriver,
	}

	server := ftpserver.NewServer(
		&ftpserver.ServerOpts{
			Factory:        factory,
			Port:           ftpPort,
			PassivePorts:   "30000-30100",
			WelcomeMessage: "NAS Private Cloud FTP Server",
		},
	)

	return &FTPManager{
		server: server,
		port:   ftpPort,
	}
}

// Start 启动FTP服务
func (m *FTPManager) Start() error {
	fmt.Printf("[FTP] 服务启动，端口: %d\n", m.port)
	return m.server.ListenAndServe()
}

// Stop 停止FTP服务
func (m *FTPManager) Stop() error {
	if m.server != nil {
		return m.server.Shutdown()
	}
	return nil
}

// GetPort 获取FTP端口
func (m *FTPManager) GetPort() int {
	return m.port
}

// ftpDriverFactory FTP驱动工厂
type ftpDriverFactory struct {
	auth   *FTPAuth
	driver *FTPDriver
}

// NewDriver 创建新的驱动实例
func (f *ftpDriverFactory) NewDriver() (ftpserver.Driver, error) {
	return f.driver, nil
}

// NewAuth 创建新的认证实例
func (f *ftpDriverFactory) NewAuth() (ftpserver.Auth, error) {
	return f.auth, nil
}
