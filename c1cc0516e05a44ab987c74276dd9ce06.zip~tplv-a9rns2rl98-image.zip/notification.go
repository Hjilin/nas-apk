package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"
)

// Notification 通知
type Notification struct {
	ID        string    `json:"id"`
	Type      string    `json:"type"`      // info / success / warning / error
	Title     string    `json:"title"`
	Message   string    `json:"message"`
	CreatedAt time.Time `json:"created_at"`
	Read      bool      `json:"read"`
	Category  string    `json:"category"` // backup / download / security / system
}

// NotificationManager 通知管理器
type NotificationManager struct {
	notifications []Notification
	mu            sync.Mutex
	notifyDir     string
	maxNotifications int
}

// NewNotificationManager 创建通知管理器
func NewNotificationManager(storageRoot string) *NotificationManager {
	dir := filepath.Join(storageRoot, ".notifications")
	os.MkdirAll(dir, 0755)
	nm := &NotificationManager{
		notifyDir:        dir,
		maxNotifications: 100,
	}
	nm.load()
	return nm
}

// load 加载通知
func (nm *NotificationManager) load() {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	data, err := os.ReadFile(filepath.Join(nm.notifyDir, "notifications.json"))
	if err != nil {
		return
	}
	json.Unmarshal(data, &nm.notifications)
}

// save 保存通知
func (nm *NotificationManager) save() {
	data, _ := json.MarshalIndent(nm.notifications, "", "  ")
	os.WriteFile(filepath.Join(nm.notifyDir, "notifications.json"), data, 0644)
}

// Add 添加通知
func (nm *NotificationManager) Add(notifyType, category, title, message string) {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	notify := Notification{
		ID:        fmt.Sprintf("ntf_%d", time.Now().UnixNano()),
		Type:      notifyType,
		Category:  category,
		Title:     title,
		Message:   message,
		CreatedAt: time.Now(),
		Read:      false,
	}

	nm.notifications = append([]Notification{notify}, nm.notifications...)

	// 限制数量
	if len(nm.notifications) > nm.maxNotifications {
		nm.notifications = nm.notifications[:nm.maxNotifications]
	}

	nm.save()
}

// List 获取通知列表
func (nm *NotificationManager) List(unreadOnly bool) []Notification {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	if unreadOnly {
		var unread []Notification
		for _, n := range nm.notifications {
			if !n.Read {
				unread = append(unread, n)
			}
		}
		return unread
	}
	return nm.notifications
}

// UnreadCount 未读数量
func (nm *NotificationManager) UnreadCount() int {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	count := 0
	for _, n := range nm.notifications {
		if !n.Read {
			count++
		}
	}
	return count
}

// MarkRead 标记已读
func (nm *NotificationManager) MarkRead(id string) {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	for i := range nm.notifications {
		if nm.notifications[i].ID == id {
			nm.notifications[i].Read = true
			break
		}
	}
	nm.save()
}

// MarkAllRead 全部已读
func (nm *NotificationManager) MarkAllRead() {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	for i := range nm.notifications {
		nm.notifications[i].Read = true
	}
	nm.save()
}

// Delete 删除通知
func (nm *NotificationManager) Delete(id string) {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	for i, n := range nm.notifications {
		if n.ID == id {
			nm.notifications = append(nm.notifications[:i], nm.notifications[i+1:]...)
			break
		}
	}
	nm.save()
}

// Clear 清空通知
func (nm *NotificationManager) Clear() {
	nm.mu.Lock()
	defer nm.mu.Unlock()
	nm.notifications = nil
	nm.save()
}

// GetByCategory 按分类获取
func (nm *NotificationManager) GetByCategory(category string) []Notification {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	var result []Notification
	for _, n := range nm.notifications {
		if n.Category == category {
			result = append(result, n)
		}
	}
	return result
}

// SortByTime 按时间排序
func (nm *NotificationManager) SortByTime() {
	nm.mu.Lock()
	defer nm.mu.Unlock()

	sort.Slice(nm.notifications, func(i, j int) bool {
		return nm.notifications[i].CreatedAt.After(nm.notifications[j].CreatedAt)
	})
}

// ===== HTTP API 处理函数 =====

func (h *NASHandler) handleNotificationList(w http.ResponseWriter, r *http.Request) {
	unreadOnly := r.URL.Query().Get("unread") == "true"
	category := r.URL.Query().Get("category")

	var notifications = []Notification{}
	if category != "" {
		notifications = h.notifyMgr.GetByCategory(category)
	} else {
		notifications = h.notifyMgr.List(unreadOnly)
	}

	// 确保不为null
	if notifications == nil {
		notifications = []Notification{}
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"notifications": notifications,
		"unread_count":  h.notifyMgr.UnreadCount(),
		"total":         len(notifications),
	})
}

func (h *NASHandler) handleNotificationRead(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		ID string `json:"id"`
		All bool   `json:"all"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if req.All {
		h.notifyMgr.MarkAllRead()
	} else if req.ID != "" {
		h.notifyMgr.MarkRead(req.ID)
	}

	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleNotificationDelete(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		ID    string `json:"id"`
		Clear bool   `json:"clear"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if req.Clear {
		h.notifyMgr.Clear()
	} else if req.ID != "" {
		h.notifyMgr.Delete(req.ID)
	}

	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}

func (h *NASHandler) handleNotificationTest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Type    string `json:"type"`
		Title   string `json:"title"`
		Message string `json:"message"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	if req.Type == "" {
		req.Type = "info"
	}
	if req.Title == "" {
		req.Title = "测试通知"
	}
	if req.Message == "" {
		req.Message = "这是一条测试通知"
	}

	h.notifyMgr.Add(req.Type, "system", req.Title, req.Message)
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}
