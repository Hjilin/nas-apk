package main

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
)

// AuthManager 认证管理器
type AuthManager struct {
	cfg          *AuthConfig
	securityCfg  *SecurityConfig
	mu           sync.Mutex
	failedLogins map[string]*loginFailInfo // IP -> 失败记录
}

// globalAuthMgr 全局认证管理器
var globalAuthMgr *AuthManager

type loginFailInfo struct {
	count     int
	lockUntil time.Time
}

// NewAuthManager 创建认证管理器
func NewAuthManager(authCfg *AuthConfig, secCfg *SecurityConfig) *AuthManager {
	return &AuthManager{
		cfg:          authCfg,
		securityCfg:  secCfg,
		failedLogins: make(map[string]*loginFailInfo),
	}
}

// HashPassword 生成 bcrypt 密码哈希
func HashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(bytes), nil
}

// CheckPassword 校验密码
func (a *AuthManager) CheckPassword(password string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(a.cfg.PasswordHash), []byte(password))
	return err == nil
}

// GetUsername 获取用户名
func (a *AuthManager) GetUsername() string {
	return a.cfg.Username
}

// CheckPasswordWithHash 使用指定哈希校验密码
func (a *AuthManager) CheckPasswordWithHash(hash, password string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

// GenerateSecret 生成随机密钥
func GenerateSecret(length int) (string, error) {
	bytes := make([]byte, length)
	if _, err := rand.Read(bytes); err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes), nil
}

// IsLocked 检查 IP 是否被锁定
func (a *AuthManager) IsLocked(ip string) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	info, ok := a.failedLogins[ip]
	if !ok {
		return false
	}
	if time.Now().Before(info.lockUntil) {
		return true
	}
	// 锁定已过期，清除
	if info.count >= a.securityCfg.MaxFailedLogin {
		delete(a.failedLogins, ip)
	}
	return false
}

// RecordFailedLogin 记录登录失败
func (a *AuthManager) RecordFailedLogin(ip string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	info, ok := a.failedLogins[ip]
	if !ok {
		info = &loginFailInfo{}
		a.failedLogins[ip] = info
	}
	info.count++
	if info.count >= a.securityCfg.MaxFailedLogin {
		info.lockUntil = time.Now().Add(time.Duration(a.securityCfg.LockoutMinute) * time.Minute)
	}
}

// RecordSuccessLogin 登录成功，清除失败记录
func (a *AuthManager) RecordSuccessLogin(ip string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	delete(a.failedLogins, ip)
}

// GenerateToken 生成 JWT token
func (a *AuthManager) GenerateToken(username string) (string, error) {
	claims := jwt.MapClaims{
		"sub": username,
		"iat": time.Now().Unix(),
		"exp": time.Now().Add(time.Duration(a.cfg.TokenExpireHour) * time.Hour).Unix(),
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(a.cfg.JWTSecret))
}

// ValidateToken 验证 JWT token
func (a *AuthManager) ValidateToken(tokenString string) (string, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, errors.New("无效的签名方法")
		}
		return []byte(a.cfg.JWTSecret), nil
	})
	if err != nil {
		return "", err
	}
	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		username, _ := claims["sub"].(string)
		return username, nil
	}
	return "", errors.New("无效的 token")
}

// ExtractToken 从请求中提取 token
func ExtractToken(r *http.Request) string {
	// 从 Authorization header 提取
	authHeader := r.Header.Get("Authorization")
	if strings.HasPrefix(authHeader, "Bearer ") {
		return strings.TrimPrefix(authHeader, "Bearer ")
	}
	// 从 cookie 提取
	cookie, err := r.Cookie("nas_token")
	if err == nil {
		return cookie.Value
	}
	// 从 query 参数提取（WebDAV 客户端兼容）
	return r.URL.Query().Get("token")
}

// GetClientIP 获取客户端真实 IP
func GetClientIP(r *http.Request, trustedProxy string) string {
	if trustedProxy != "" {
		if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
			ips := strings.Split(xff, ",")
			if len(ips) > 0 {
				return strings.TrimSpace(ips[0])
			}
		}
	}
	ip := r.RemoteAddr
	if idx := strings.LastIndex(ip, ":"); idx != -1 {
		ip = ip[:idx]
	}
	return ip
}
