package main

import (
	"net/http"
	"os"
	"path/filepath"
)

// PWAManager PWA管理器
type PWAManager struct {
	staticDir string
}

// NewPWAManager 创建PWA管理器
func NewPWAManager(staticDir string) *PWAManager {
	return &PWAManager{staticDir: staticDir}
}

// PWAStatus PWA状态
type PWAStatus struct {
	Enabled       bool     `json:"enabled"`
	ServiceWorker string   `json:"service_worker"`
	Manifest      string   `json:"manifest"`
	CacheStrategy string   `json:"cache_strategy"`
	StaticFiles   []string `json:"static_files"`
	StaticSize    int64    `json:"static_size"`
}

// PWACacheInfo 缓存信息
type PWACacheInfo struct {
	CacheName string `json:"cache_name"`
	Size      int64  `json:"size"`
	FileCount int    `json:"file_count"`
}

// handlePWAStatus 获取PWA状态
func (pm *PWAManager) handlePWAStatus(w http.ResponseWriter, r *http.Request) {
	status := PWAStatus{
		Enabled:       true,
		ServiceWorker: "/static/sw.js",
		Manifest:      "/static/manifest.json",
		CacheStrategy: "静态资源缓存优先，API网络优先",
	}

	// 统计静态文件
	var files []string
	var totalSize int64
	filepath.Walk(pm.staticDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		relPath, _ := filepath.Rel(pm.staticDir, path)
		files = append(files, "/static/"+relPath)
		totalSize += info.Size()
		return nil
	})

	status.StaticFiles = files
	status.StaticSize = totalSize

	WriteSuccess(w, status)
}

// handlePWAClearCache 清除PWA缓存（前端执行，后端提供接口）
func (pm *PWAManager) handlePWAClearCache(w http.ResponseWriter, r *http.Request) {
	WriteSuccess(w, map[string]interface{}{
		"success": true,
		"message": "请在前端执行缓存清除操作",
	})
}

// handlePWAUpdate 更新Service Worker
func (pm *PWAManager) handlePWAUpdate(w http.ResponseWriter, r *http.Request) {
	// 读取当前sw.js内容，修改版本号触发更新
	swPath := filepath.Join(pm.staticDir, "sw.js")
	content, err := os.ReadFile(swPath)
	if err != nil {
		WriteError(w, CodeInternalError, "读取Service Worker失败")
		return
	}

	// 简单的版本更新：修改缓存名称
	// 实际应用中可以通过修改版本号触发更新
	WriteSuccess(w, map[string]interface{}{
		"success": true,
		"message": "Service Worker更新指令已发送",
		"size":    len(content),
	})
}

// handlePWAConfig 获取PWA配置
func (pm *PWAManager) handlePWAConfig(w http.ResponseWriter, r *http.Request) {
	config := map[string]interface{}{
		"app_name":      "NAS私有云",
		"short_name":    "NAS",
		"theme_color":   "#667eea",
		"bg_color":      "#ffffff",
		"display":       "standalone",
		"orientation":   "portrait",
		"start_url":     "/",
		"offline_support": true,
		"cache_static":  true,
		"cache_api":     false,
	}
	WriteSuccess(w, config)
}

// RegisterPWARoutes 注册PWA路由
func (pm *PWAManager) RegisterPWARoutes(mux *http.ServeMux) {
	mux.HandleFunc("/api/pwa/status", pm.handlePWAStatus)
	mux.HandleFunc("/api/pwa/clear-cache", pm.handlePWAClearCache)
	mux.HandleFunc("/api/pwa/update", pm.handlePWAUpdate)
	mux.HandleFunc("/api/pwa/config", pm.handlePWAConfig)
}
